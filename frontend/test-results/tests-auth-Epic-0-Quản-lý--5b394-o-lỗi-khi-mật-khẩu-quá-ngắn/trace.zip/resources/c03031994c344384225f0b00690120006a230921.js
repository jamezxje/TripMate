import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/trips/TripList.jsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Compass, Plus, KeyRound, Layers, Calendar, ArrowLeft } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import { Card } from "/src/components/Card.jsx";
import { Button } from "/src/components/Button.jsx";
import { Alert } from "/src/components/Alert.jsx";
import { Badge } from "/src/components/Badge.jsx";
import { CreateTripModal } from "/src/features/trips/CreateTripModal.jsx";
import { JoinTripModal } from "/src/features/trips/JoinTripModal.jsx";
import { TripDetailView } from "/src/features/trips/TripDetailView.jsx";
import { tripApi } from "/src/features/trips/tripApi.js";
import { useTripStore } from "/src/store/useTripStore.js";
import { formatDate } from "/src/utils/formatters.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/trips/TripList.jsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const TripList = () => {
	_s();
	const { t } = useTranslation();
	const { currentTrip, setCurrentTrip, clearCurrentTrip, trips, setTrips, setIsLoading, isLoading } = useTripStore();
	const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
	const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
	const [error, setError] = useState("");
	const loadAllTrips = useCallback(async () => {
		if (currentTrip) return;
		setIsLoading(true);
		setError("");
		try {
			const res = await tripApi.getUserTrips();
			if (res.data) {
				setTrips(res.data);
			}
		} catch (err) {
			console.error("Failed to load trips:", err);
			setError("Không thể tải danh sách chuyến đi.");
		} finally {
			setIsLoading(false);
		}
	}, [
		currentTrip,
		setTrips,
		setIsLoading
	]);
	useEffect(() => {
		loadAllTrips();
	}, [loadAllTrips]);
	const handleSelectTrip = async (tripId) => {
		setIsLoading(true);
		try {
			const res = await tripApi.getTripDetail(tripId);
			if (res.data) {
				setCurrentTrip(res.data);
			}
		} catch (err) {
			console.error("Failed to load trip details:", err);
			setError("Không thể tải chi tiết chuyến đi.");
		} finally {
			setIsLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Compass, { className: "w-7 h-7 text-indigo-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: currentTrip ? currentTrip.name : t("trip.list_title", "Danh sách Chuyến đi") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-slate-500 text-sm mt-0.5",
					children: currentTrip ? "Chi tiết chuyến đi hiện tại." : "Tạo mới chuyến đi hoặc gia nhập chuyến đi bằng mã mời để bắt đầu quản lý."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this), !currentTrip && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						icon: KeyRound,
						onClick: () => setIsJoinModalOpen(true),
						children: t("trip.join", "Tham gia bằng mã code")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						icon: Plus,
						onClick: () => setIsCreateModalOpen(true),
						children: t("trip.create", "Tạo chuyến đi mới")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV(Alert, {
				type: "error",
				message: error,
				onClose: () => setError("")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 17
			}, this),
			currentTrip ? /* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300",
				children: [/* @__PURE__ */ _jsxDEV(Button, {
					variant: "outline",
					icon: ArrowLeft,
					onClick: clearCurrentTrip,
					className: "self-start text-slate-500 hover:text-slate-800 border-slate-200",
					children: "Quay lại danh sách"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(TripDetailView, {
					trip: currentTrip,
					onRefresh: () => handleSelectTrip(currentTrip.id)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
				children: trips && trips.length > 0 ? trips.map((trip) => /* @__PURE__ */ _jsxDEV(Card, {
					className: "cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1 group",
					onClick: () => handleSelectTrip(trip.id),
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "p-5 flex flex-col gap-3 h-full justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between mb-3",
							children: [/* @__PURE__ */ _jsxDEV(Badge, {
								variant: trip.status ? trip.status.toLowerCase() : "info",
								children: t(`trip.status.${trip.status}`, trip.status)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 23
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-400 font-medium font-mono",
								children: ["#", trip.joinCode]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 23
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "text-lg font-bold text-slate-800 group-hover:text-indigo-600 transition-colors line-clamp-2",
							children: trip.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 21
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 text-xs text-slate-500 mt-2",
							children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: formatDate(trip.createdAt) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 17
					}, this)
				}, trip.id, false, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 15
				}, this)) : /* @__PURE__ */ _jsxDEV("div", {
					className: "col-span-full",
					children: /* @__PURE__ */ _jsxDEV(Card, {
						className: "text-center py-16 px-4 bg-gradient-to-b from-white to-slate-50",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-4 border border-indigo-100 shadow-xs",
								children: /* @__PURE__ */ _jsxDEV(Layers, { className: "w-8 h-8" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 151,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xl font-bold text-slate-800 mb-2",
								children: "Chưa có Chuyến đi nào"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-500 text-sm max-w-md mx-auto mb-6",
								children: t("trip.empty", "Bạn chưa tham gia chuyến đi nào. Hãy tạo chuyến đi mới hoặc tham gia bằng mã code!")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV(Button, {
									variant: "outline",
									icon: KeyRound,
									onClick: () => setIsJoinModalOpen(true),
									children: "Tham gia bằng code"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV(Button, {
									icon: Plus,
									onClick: () => setIsCreateModalOpen(true),
									children: "Tạo chuyến đi mới"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(CreateTripModal, {
				isOpen: isCreateModalOpen,
				onClose: () => setIsCreateModalOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 175,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(JoinTripModal, {
				isOpen: isJoinModalOpen,
				onClose: () => setIsJoinModalOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 179,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 5
	}, this);
};
_s(TripList, "LIvXLr7F5y6h9Jhv+s7jSLQeVTo=", false, function() {
	return [useTranslation, useTripStore];
});
_c = TripList;
var _c;
$RefreshReg$(_c, "TripList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/trips/TripList.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/trips/TripList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/trips/TripList.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/trips/TripList.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsVUFBVSxtQkFBbUI7QUFDeEQsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxTQUFTLE1BQU0sVUFBVSxRQUFRLFVBQVUsaUJBQWlCO0FBQ3JFLFNBQVMsWUFBWTtBQUNyQixTQUFTLGNBQWM7QUFDdkIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsYUFBYTtBQUN0QixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGVBQWU7QUFDeEIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxrQkFBa0I7Ozs7QUFFM0IsT0FBTyxNQUFNLGlCQUFpQjs7Q0FDNUIsTUFBTSxFQUFFLE1BQU0sZUFBZTtDQUM3QixNQUFNLEVBQ0osYUFDQSxnQkFDQSxrQkFDQSxPQUNBLFVBQ0EsY0FDQSxjQUNFLGFBQWE7Q0FFakIsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxLQUFLO0NBQ2hFLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsS0FBSztDQUM1RCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUVyQyxNQUFNLGVBQWUsWUFBWSxZQUFZO0VBQzNDLElBQUksYUFBYTtFQUNqQixhQUFhLElBQUk7RUFDakIsU0FBUyxFQUFFO0VBQ1gsSUFBSTtHQUNGLE1BQU0sTUFBTSxNQUFNLFFBQVEsYUFBYTtHQUN2QyxJQUFJLElBQUksTUFBTTtJQUNaLFNBQVMsSUFBSSxJQUFJO0dBQ25CO0VBQ0YsU0FBUyxLQUFLO0dBQ1osUUFBUSxNQUFNLHlCQUF5QixHQUFHO0dBQzFDLFNBQVMsb0NBQW9DO0VBQy9DLFVBQVU7R0FDUixhQUFhLEtBQUs7RUFDcEI7Q0FDRixHQUFHO0VBQUM7RUFBYTtFQUFVO0NBQVksQ0FBQztDQUV4QyxnQkFBZ0I7RUFDZCxhQUFhO0NBQ2YsR0FBRyxDQUFDLFlBQVksQ0FBQztDQUVqQixNQUFNLG1CQUFtQixPQUFPLFdBQVc7RUFDekMsYUFBYSxJQUFJO0VBQ2pCLElBQUk7R0FDRixNQUFNLE1BQU0sTUFBTSxRQUFRLGNBQWMsTUFBTTtHQUM5QyxJQUFJLElBQUksTUFBTTtJQUNaLGVBQWUsSUFBSSxJQUFJO0dBQ3pCO0VBQ0YsU0FBUyxLQUFLO0dBQ1osUUFBUSxNQUFNLGdDQUFnQyxHQUFHO0dBQ2pELFNBQVMsbUNBQW1DO0VBQzlDLFVBQVU7R0FDUixhQUFhLEtBQUs7RUFDcEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLDBCQUEyQjs7OztlQUM5Qyx3QkFBQyxRQUFELFlBQU8sY0FBYyxZQUFZLE9BQU8sRUFBRSxtQkFBbUIscUJBQXFCLEVBQVE7Ozs7YUFDeEY7Ozs7O2NBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixjQUNHLGlDQUNBO0lBQ0g7Ozs7WUFDQTs7OztjQUVKLENBQUMsZUFDQSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUNFLFNBQVE7TUFDUixNQUFNO01BQ04sZUFBZSxtQkFBbUIsSUFBSTtnQkFFckMsRUFBRSxhQUFhLHVCQUF1QjtLQUNqQzs7OztlQUNSLHdCQUFDLFFBQUQ7TUFDRSxNQUFNO01BQ04sZUFBZSxxQkFBcUIsSUFBSTtnQkFFdkMsRUFBRSxlQUFlLG1CQUFtQjtLQUMvQjs7OzthQUNMOzs7OztZQUVKOzs7Ozs7R0FFSixTQUFTLHdCQUFDLE9BQUQ7SUFBTyxNQUFLO0lBQVEsU0FBUztJQUFPLGVBQWUsU0FBUyxFQUFFO0dBQUk7Ozs7O0dBRzNFLGNBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FDRSxTQUFRO0tBQ1IsTUFBTTtLQUNOLFNBQVM7S0FDVCxXQUFVO2VBQ1g7SUFFTzs7OztjQUNSLHdCQUFDLGdCQUFEO0tBQWdCLE1BQU07S0FBYSxpQkFBaUIsaUJBQWlCLFlBQVksRUFBRTtJQUFJOzs7O1lBQ3BGOzs7OztjQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osU0FBUyxNQUFNLFNBQVMsSUFDdkIsTUFBTSxLQUFJLFNBQ1Isd0JBQUMsTUFBRDtLQUVFLFdBQVU7S0FDVixlQUFlLGlCQUFpQixLQUFLLEVBQUU7ZUFFdkMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQU8sU0FBUyxLQUFLLFNBQVMsS0FBSyxPQUFPLFlBQVksSUFBSTtrQkFDdkQsRUFBRSxlQUFlLEtBQUssVUFBVSxLQUFLLE1BQU07T0FDdkM7Ozs7aUJBQ1Asd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQStELEtBQzNELEtBQUssUUFDSDs7Ozs7ZUFDSDs7Ozs7Z0JBQ0wsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsS0FBSztNQUNKOzs7O2NBQ0Q7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O2lCQUNuQyx3QkFBQyxRQUFELFlBQU8sV0FBVyxLQUFLLFNBQVMsRUFBUTs7OztlQUNyQzs7Ozs7Y0FDRjs7Ozs7O0lBQ0QsR0F2QkMsS0FBSzs7OztXQXVCTixDQUNQLElBRUQsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxNQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztPQUMxQjs7Ozs7T0FDTCx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBd0M7T0FBeUI7Ozs7O09BQy9FLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLEVBQ0MsY0FDQSxvRkFDRjtPQUNDOzs7OztPQUNILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFRLFNBQVE7U0FBVSxNQUFNO1NBQVUsZUFBZSxtQkFBbUIsSUFBSTttQkFBRztRQUUzRTs7OztrQkFDUix3QkFBQyxRQUFEO1NBQVEsTUFBTTtTQUFNLGVBQWUscUJBQXFCLElBQUk7bUJBQUc7UUFFdkQ7Ozs7Z0JBQ0w7Ozs7OztNQUNEOzs7Ozs7SUFDSDs7Ozs7R0FFSjs7Ozs7R0FJUCx3QkFBQyxpQkFBRDtJQUNFLFFBQVE7SUFDUixlQUFlLHFCQUFxQixLQUFLO0dBQzFDOzs7OztHQUNELHdCQUFDLGVBQUQ7SUFDRSxRQUFRO0lBQ1IsZUFBZSxtQkFBbUIsS0FBSztHQUN4Qzs7Ozs7RUFDRTs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVHJpcExpc3QuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSAncmVhY3QtaTE4bmV4dCc7XG5pbXBvcnQgeyBDb21wYXNzLCBQbHVzLCBLZXlSb3VuZCwgTGF5ZXJzLCBDYWxlbmRhciwgQXJyb3dMZWZ0IH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IENhcmQgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0NhcmQnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9CdXR0b24nO1xuaW1wb3J0IHsgQWxlcnQgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0FsZXJ0JztcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9CYWRnZSc7XG5pbXBvcnQgeyBDcmVhdGVUcmlwTW9kYWwgfSBmcm9tICcuL0NyZWF0ZVRyaXBNb2RhbCc7XG5pbXBvcnQgeyBKb2luVHJpcE1vZGFsIH0gZnJvbSAnLi9Kb2luVHJpcE1vZGFsJztcbmltcG9ydCB7IFRyaXBEZXRhaWxWaWV3IH0gZnJvbSAnLi9UcmlwRGV0YWlsVmlldyc7XG5pbXBvcnQgeyB0cmlwQXBpIH0gZnJvbSAnLi90cmlwQXBpJztcbmltcG9ydCB7IHVzZVRyaXBTdG9yZSB9IGZyb20gJy4uLy4uL3N0b3JlL3VzZVRyaXBTdG9yZSc7XG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5cbmV4cG9ydCBjb25zdCBUcmlwTGlzdCA9ICgpID0+IHtcbiAgY29uc3QgeyB0IH0gPSB1c2VUcmFuc2xhdGlvbigpO1xuICBjb25zdCB7IFxuICAgIGN1cnJlbnRUcmlwLCBcbiAgICBzZXRDdXJyZW50VHJpcCwgXG4gICAgY2xlYXJDdXJyZW50VHJpcCwgXG4gICAgdHJpcHMsIFxuICAgIHNldFRyaXBzLCBcbiAgICBzZXRJc0xvYWRpbmcsIFxuICAgIGlzTG9hZGluZyBcbiAgfSA9IHVzZVRyaXBTdG9yZSgpO1xuXG4gIGNvbnN0IFtpc0NyZWF0ZU1vZGFsT3Blbiwgc2V0SXNDcmVhdGVNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNKb2luTW9kYWxPcGVuLCBzZXRJc0pvaW5Nb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcblxuICBjb25zdCBsb2FkQWxsVHJpcHMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgaWYgKGN1cnJlbnRUcmlwKSByZXR1cm47IC8vIE9ubHkgZmV0Y2ggbGlzdCBpZiBubyB0cmlwIGlzIHNlbGVjdGVkXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xuICAgIHNldEVycm9yKCcnKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgdHJpcEFwaS5nZXRVc2VyVHJpcHMoKTtcbiAgICAgIGlmIChyZXMuZGF0YSkge1xuICAgICAgICBzZXRUcmlwcyhyZXMuZGF0YSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gbG9hZCB0cmlwczonLCBlcnIpO1xuICAgICAgc2V0RXJyb3IoJ0tow7RuZyB0aOG7gyB04bqjaSBkYW5oIHPDoWNoIGNodXnhur9uIMSRaS4nKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH0sIFtjdXJyZW50VHJpcCwgc2V0VHJpcHMsIHNldElzTG9hZGluZ10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbG9hZEFsbFRyaXBzKCk7XG4gIH0sIFtsb2FkQWxsVHJpcHNdKTtcblxuICBjb25zdCBoYW5kbGVTZWxlY3RUcmlwID0gYXN5bmMgKHRyaXBJZCkgPT4ge1xuICAgIHNldElzTG9hZGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgdHJpcEFwaS5nZXRUcmlwRGV0YWlsKHRyaXBJZCk7XG4gICAgICBpZiAocmVzLmRhdGEpIHtcbiAgICAgICAgc2V0Q3VycmVudFRyaXAocmVzLmRhdGEpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGxvYWQgdHJpcCBkZXRhaWxzOicsIGVycik7XG4gICAgICBzZXRFcnJvcignS2jDtG5nIHRo4buDIHThuqNpIGNoaSB0aeG6v3QgY2h1eeG6v24gxJFpLicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNlwiPlxuICAgICAgey8qIFRvcCBIZWFkZXIgJiBBY3Rpb25zICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTgwMCB0cmFja2luZy10aWdodCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPENvbXBhc3MgY2xhc3NOYW1lPVwidy03IGgtNyB0ZXh0LWluZGlnby02MDBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+e2N1cnJlbnRUcmlwID8gY3VycmVudFRyaXAubmFtZSA6IHQoJ3RyaXAubGlzdF90aXRsZScsICdEYW5oIHPDoWNoIENodXnhur9uIMSRaScpfTwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIHRleHQtc20gbXQtMC41XCI+XG4gICAgICAgICAgICB7Y3VycmVudFRyaXAgXG4gICAgICAgICAgICAgID8gJ0NoaSB0aeG6v3QgY2h1eeG6v24gxJFpIGhp4buHbiB04bqhaS4nIFxuICAgICAgICAgICAgICA6ICdU4bqhbyBt4bubaSBjaHV54bq/biDEkWkgaG/hurdjIGdpYSBuaOG6rXAgY2h1eeG6v24gxJFpIGLhurFuZyBtw6MgbeG7nWkgxJHhu4MgYuG6r3QgxJHhuqd1IHF14bqjbiBsw70uJ31cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHshY3VycmVudFRyaXAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICBpY29uPXtLZXlSb3VuZH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNKb2luTW9kYWxPcGVuKHRydWUpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7dCgndHJpcC5qb2luJywgJ1RoYW0gZ2lhIGLhurFuZyBtw6MgY29kZScpfVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIGljb249e1BsdXN9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQ3JlYXRlTW9kYWxPcGVuKHRydWUpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7dCgndHJpcC5jcmVhdGUnLCAnVOG6oW8gY2h1eeG6v24gxJFpIG3hu5tpJyl9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3IgJiYgPEFsZXJ0IHR5cGU9XCJlcnJvclwiIG1lc3NhZ2U9e2Vycm9yfSBvbkNsb3NlPXsoKSA9PiBzZXRFcnJvcignJyl9IC8+fVxuXG4gICAgICB7LyogTWFpbiBBY3RpdmUgVHJpcCBEZXRhaWwgb3IgVHJpcCBHcmlkICovfVxuICAgICAge2N1cnJlbnRUcmlwID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTQgYW5pbWF0ZS1pbiBmYWRlLWluIHNsaWRlLWluLWZyb20tYm90dG9tLTIgZHVyYXRpb24tMzAwXCI+XG4gICAgICAgICAgPEJ1dHRvbiBcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCIgXG4gICAgICAgICAgICBpY29uPXtBcnJvd0xlZnR9IFxuICAgICAgICAgICAgb25DbGljaz17Y2xlYXJDdXJyZW50VHJpcH0gXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzZWxmLXN0YXJ0IHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtODAwIGJvcmRlci1zbGF0ZS0yMDBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIFF1YXkgbOG6oWkgZGFuaCBzw6FjaFxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDxUcmlwRGV0YWlsVmlldyB0cmlwPXtjdXJyZW50VHJpcH0gb25SZWZyZXNoPXsoKSA9PiBoYW5kbGVTZWxlY3RUcmlwKGN1cnJlbnRUcmlwLmlkKX0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAgICB7dHJpcHMgJiYgdHJpcHMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgIHRyaXBzLm1hcCh0cmlwID0+IChcbiAgICAgICAgICAgICAgPENhcmQgXG4gICAgICAgICAgICAgICAga2V5PXt0cmlwLmlkfSBcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgaG92ZXI6LXRyYW5zbGF0ZS15LTEgZ3JvdXBcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdFRyaXAodHJpcC5pZCl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBmbGV4IGZsZXgtY29sIGdhcC0zIGgtZnVsbCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD17dHJpcC5zdGF0dXMgPyB0cmlwLnN0YXR1cy50b0xvd2VyQ2FzZSgpIDogJ2luZm8nfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0KGB0cmlwLnN0YXR1cy4ke3RyaXAuc3RhdHVzfWAsIHRyaXAuc3RhdHVzKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW0gZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAje3RyaXAuam9pbkNvZGV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGdyb3VwLWhvdmVyOnRleHQtaW5kaWdvLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBsaW5lLWNsYW1wLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7dHJpcC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntmb3JtYXREYXRlKHRyaXAuY3JlYXRlZEF0KX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICAgKSlcbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi1mdWxsXCI+XG4gICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTE2IHB4LTQgYmctZ3JhZGllbnQtdG8tYiBmcm9tLXdoaXRlIHRvLXNsYXRlLTUwXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgcm91bmRlZC0yeGwgYmctaW5kaWdvLTUwIHRleHQtaW5kaWdvLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTQgYm9yZGVyIGJvcmRlci1pbmRpZ28tMTAwIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgICAgPExheWVycyBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgbWItMlwiPkNoxrBhIGPDsyBDaHV54bq/biDEkWkgbsOgbzwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBtYXgtdy1tZCBteC1hdXRvIG1iLTZcIj5cbiAgICAgICAgICAgICAgICAgIHt0KFxuICAgICAgICAgICAgICAgICAgICAndHJpcC5lbXB0eScsXG4gICAgICAgICAgICAgICAgICAgICdC4bqhbiBjaMawYSB0aGFtIGdpYSBjaHV54bq/biDEkWkgbsOgby4gSMOjeSB04bqhbyBjaHV54bq/biDEkWkgbeG7m2kgaG/hurdjIHRoYW0gZ2lhIGLhurFuZyBtw6MgY29kZSEnXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgaWNvbj17S2V5Um91bmR9IG9uQ2xpY2s9eygpID0+IHNldElzSm9pbk1vZGFsT3Blbih0cnVlKX0+XG4gICAgICAgICAgICAgICAgICAgIFRoYW0gZ2lhIGLhurFuZyBjb2RlXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b24gaWNvbj17UGx1c30gb25DbGljaz17KCkgPT4gc2V0SXNDcmVhdGVNb2RhbE9wZW4odHJ1ZSl9PlxuICAgICAgICAgICAgICAgICAgICBU4bqhbyBjaHV54bq/biDEkWkgbeG7m2lcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNb2RhbHMgKi99XG4gICAgICA8Q3JlYXRlVHJpcE1vZGFsXG4gICAgICAgIGlzT3Blbj17aXNDcmVhdGVNb2RhbE9wZW59XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzQ3JlYXRlTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgIC8+XG4gICAgICA8Sm9pblRyaXBNb2RhbFxuICAgICAgICBpc09wZW49e2lzSm9pbk1vZGFsT3Blbn1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNKb2luTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19