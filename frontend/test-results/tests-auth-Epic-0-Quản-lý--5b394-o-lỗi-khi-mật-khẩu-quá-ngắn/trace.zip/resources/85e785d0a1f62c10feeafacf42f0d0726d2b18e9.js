import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Badge.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/Badge.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
export const Badge = ({ children, variant = "info", size = "md", className = "" }) => {
	const baseStyles = "inline-flex items-center gap-1.5 font-semibold rounded-full select-none";
	const variants = {
		planning: "bg-amber-50 text-amber-700 border border-amber-200/60",
		ongoing: "bg-emerald-50 text-emerald-700 border border-emerald-200/60",
		settled: "bg-indigo-50 text-indigo-700 border border-indigo-200/60",
		closed: "bg-slate-100 text-slate-600 border border-slate-200/60",
		leader: "bg-purple-50 text-purple-700 border border-purple-200/60",
		member: "bg-blue-50 text-blue-700 border border-blue-200/60",
		positive: "bg-emerald-50 text-emerald-700 border border-emerald-200/60",
		negative: "bg-rose-50 text-rose-700 border border-rose-200/60",
		info: "bg-sky-50 text-sky-700 border border-sky-200/60"
	};
	const sizes = {
		sm: "px-2 py-0.5 text-[11px]",
		md: "px-2.5 py-1 text-xs",
		lg: "px-3.5 py-1.5 text-sm"
	};
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `${baseStyles} ${variants[variant] || variants.info} ${sizes[size] || sizes.md} ${className}`,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 5
	}, this);
};
_c = Badge;
var _c;
$RefreshReg$(_c, "Badge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Badge.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/Badge.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/Badge.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/Badge.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFFbEIsT0FBTyxNQUFNLFNBQVMsRUFBRSxVQUFVLFVBQVUsUUFBUSxPQUFPLE1BQU0sWUFBWSxTQUFTO0NBQ3BGLE1BQU0sYUFBYTtDQUVuQixNQUFNLFdBQVc7RUFDZixVQUFVO0VBQ1YsU0FBUztFQUNULFNBQVM7RUFDVCxRQUFRO0VBQ1IsUUFBUTtFQUNSLFFBQVE7RUFDUixVQUFVO0VBQ1YsVUFBVTtFQUNWLE1BQU07Q0FDUjtDQUVBLE1BQU0sUUFBUTtFQUNaLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtDQUNOO0NBRUEsT0FDRSx3QkFBQyxRQUFEO0VBQ0UsV0FBVyxHQUFHLFdBQVcsR0FBRyxTQUFTLFlBQVksU0FBUyxLQUFLLEdBQUcsTUFBTSxTQUFTLE1BQU0sR0FBRyxHQUFHO0VBRTVGO0NBQ0c7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQmFkZ2UuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBCYWRnZSA9ICh7IGNoaWxkcmVuLCB2YXJpYW50ID0gJ2luZm8nLCBzaXplID0gJ21kJywgY2xhc3NOYW1lID0gJycgfSkgPT4ge1xuICBjb25zdCBiYXNlU3R5bGVzID0gJ2lubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsIHNlbGVjdC1ub25lJztcblxuICBjb25zdCB2YXJpYW50cyA9IHtcbiAgICBwbGFubmluZzogJ2JnLWFtYmVyLTUwIHRleHQtYW1iZXItNzAwIGJvcmRlciBib3JkZXItYW1iZXItMjAwLzYwJyxcbiAgICBvbmdvaW5nOiAnYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAvNjAnLFxuICAgIHNldHRsZWQ6ICdiZy1pbmRpZ28tNTAgdGV4dC1pbmRpZ28tNzAwIGJvcmRlciBib3JkZXItaW5kaWdvLTIwMC82MCcsXG4gICAgY2xvc2VkOiAnYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNjAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzYwJyxcbiAgICBsZWFkZXI6ICdiZy1wdXJwbGUtNTAgdGV4dC1wdXJwbGUtNzAwIGJvcmRlciBib3JkZXItcHVycGxlLTIwMC82MCcsXG4gICAgbWVtYmVyOiAnYmctYmx1ZS01MCB0ZXh0LWJsdWUtNzAwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAvNjAnLFxuICAgIHBvc2l0aXZlOiAnYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAvNjAnLFxuICAgIG5lZ2F0aXZlOiAnYmctcm9zZS01MCB0ZXh0LXJvc2UtNzAwIGJvcmRlciBib3JkZXItcm9zZS0yMDAvNjAnLFxuICAgIGluZm86ICdiZy1za3ktNTAgdGV4dC1za3ktNzAwIGJvcmRlciBib3JkZXItc2t5LTIwMC82MCcsXG4gIH07XG5cbiAgY29uc3Qgc2l6ZXMgPSB7XG4gICAgc206ICdweC0yIHB5LTAuNSB0ZXh0LVsxMXB4XScsXG4gICAgbWQ6ICdweC0yLjUgcHktMSB0ZXh0LXhzJyxcbiAgICBsZzogJ3B4LTMuNSBweS0xLjUgdGV4dC1zbScsXG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8c3BhblxuICAgICAgY2xhc3NOYW1lPXtgJHtiYXNlU3R5bGVzfSAke3ZhcmlhbnRzW3ZhcmlhbnRdIHx8IHZhcmlhbnRzLmluZm99ICR7c2l6ZXNbc2l6ZV0gfHwgc2l6ZXMubWR9ICR7Y2xhc3NOYW1lfWB9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvc3Bhbj5cbiAgKTtcbn07XG4iXX0=