import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/LoginPage.jsx");const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useNavigate, useLocation, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=aa845dd0";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Compass, Mail, Lock, LogIn, Loader2, Globe } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import api from "/src/services/api.js";
import { useUserStore } from "/src/store/useUserStore.js";
import { Alert } from "/src/components/Alert.jsx";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/auth/LoginPage.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const LoginPage = () => {
	_s();
	const { t, i18n } = useTranslation();
	const navigate = useNavigate();
	const location = useLocation();
	const { setAuth } = useUserStore();
	const [formData, setFormData] = useState({
		email: "",
		password: ""
	});
	const [loading, setLoading] = useState(false);
	const [errorMessage, setErrorMessage] = useState("");
	const from = location.state?.from?.pathname || "/";
	const handleChange = (e) => {
		setFormData({
			...formData,
			[e.target.name]: e.target.value
		});
		if (errorMessage) setErrorMessage("");
	};
	const toggleLanguage = () => {
		const nextLang = i18n.language === "vi" ? "en" : "vi";
		i18n.changeLanguage(nextLang);
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		setErrorMessage("");
		setLoading(true);
		try {
			const response = await api.post("/auth/login", formData);
			if (response && response.success && response.data) {
				const { accessToken, user } = response.data;
				setAuth(accessToken, user);
				navigate(from, { replace: true });
			} else {
				setErrorMessage(response?.message || t("auth.login_failed"));
			}
		} catch (err) {
			setErrorMessage(err.message || t("auth.login_failed"));
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute -top-40 -left-40 w-96 h-96 bg-indigo-600/30 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute -bottom-40 -right-40 w-96 h-96 bg-violet-600/30 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute top-4 right-4 z-10",
				children: /* @__PURE__ */ _jsxDEV("button", {
					onClick: toggleLanguage,
					className: "flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-300 hover:text-white bg-slate-800/80 border border-slate-700 rounded-xl transition-colors min-h-[44px]",
					children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-4 h-4 text-indigo-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "uppercase",
						children: i18n.language || "VI"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "sm:mx-auto sm:w-full sm:max-w-md z-10",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-center items-center gap-3 mb-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-500 to-violet-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30",
							children: /* @__PURE__ */ _jsxDEV(Compass, { className: "w-7 h-7" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-3xl font-black bg-gradient-to-r from-indigo-400 via-violet-300 to-white bg-clip-text text-transparent tracking-tight",
							children: "TripMate"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-center text-2xl font-bold tracking-tight text-white mt-2",
						children: t("auth.login_title")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-center text-sm text-slate-400",
						children: t("auth.login_subtitle")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-8 sm:mx-auto sm:w-full sm:max-w-md z-10 px-4 sm:px-0",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-800/90 backdrop-blur-xl py-8 px-4 shadow-2xl border border-slate-700/80 sm:rounded-2xl sm:px-10",
					children: [
						errorMessage && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-6",
							children: /* @__PURE__ */ _jsxDEV(Alert, {
								variant: "danger",
								title: t("common.error"),
								children: errorMessage
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							className: "space-y-6",
							onSubmit: handleSubmit,
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-sm font-semibold text-slate-300 mb-2",
									children: t("auth.email_label")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 104,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative rounded-xl shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none",
										children: /* @__PURE__ */ _jsxDEV(Mail, { className: "h-5 w-5 text-slate-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 109,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 108,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "email",
										name: "email",
										required: true,
										value: formData.email,
										onChange: handleChange,
										placeholder: "name@example.com",
										className: "block w-full pl-10 pr-4 py-3 bg-slate-900/90 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all min-h-[44px]"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 111,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-sm font-semibold text-slate-300 mb-2",
									children: t("auth.password_label")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative rounded-xl shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none",
										children: /* @__PURE__ */ _jsxDEV(Lock, { className: "h-5 w-5 text-slate-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 129,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "password",
										name: "password",
										required: true,
										value: formData.password,
										onChange: handleChange,
										placeholder: "••••••••",
										className: "block w-full pl-10 pr-4 py-3 bg-slate-900/90 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all min-h-[44px]"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 131,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: loading,
									className: "w-full flex justify-center items-center gap-2 py-3.5 px-4 border border-transparent rounded-xl shadow-lg shadow-indigo-500/25 text-sm font-bold text-white bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all disabled:opacity-50 min-h-[44px]",
									children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-5 h-5 animate-spin" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 151,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: t("auth.logging_in") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 152,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 150,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(LogIn, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 156,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: t("auth.login_button") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 157,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 155,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 144,
									columnNumber: 15
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-6 pt-6 border-t border-slate-700/80 text-center",
							children: /* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm text-slate-400",
								children: [
									t("auth.no_account"),
									" ",
									/* @__PURE__ */ _jsxDEV(Link, {
										to: "/register",
										className: "font-bold text-indigo-400 hover:text-indigo-300 transition-colors ml-1",
										children: t("auth.register_now")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 167,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 5
	}, this);
};
_s(LoginPage, "KoslX3OQNB+Z7FrPk8+XiCi6aY0=", false, function() {
	return [
		useTranslation,
		useNavigate,
		useLocation,
		useUserStore
	];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/LoginPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/auth/LoginPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/auth/LoginPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/auth/LoginPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGFBQWEsYUFBYSxZQUFZO0FBQy9DLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsU0FBUyxNQUFNLE1BQU0sT0FBTyxTQUFTLGFBQWE7QUFDM0QsT0FBTyxTQUFTO0FBQ2hCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsYUFBYTs7OztBQUV0QixPQUFPLE1BQU0sa0JBQWtCOztDQUM3QixNQUFNLEVBQUUsR0FBRyxTQUFTLGVBQWU7Q0FDbkMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxFQUFFLFlBQVksYUFBYTtDQUVqQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVM7RUFDdkMsT0FBTztFQUNQLFVBQVU7Q0FDWixDQUFDO0NBQ0QsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FDNUMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsRUFBRTtDQUVuRCxNQUFNLE9BQU8sU0FBUyxPQUFPLE1BQU0sWUFBWTtDQUUvQyxNQUFNLGdCQUFnQixNQUFNO0VBQzFCLFlBQVk7R0FDVixHQUFHO0lBQ0YsRUFBRSxPQUFPLE9BQU8sRUFBRSxPQUFPO0VBQzVCLENBQUM7RUFDRCxJQUFJLGNBQWMsZ0JBQWdCLEVBQUU7Q0FDdEM7Q0FFQSxNQUFNLHVCQUF1QjtFQUMzQixNQUFNLFdBQVcsS0FBSyxhQUFhLE9BQU8sT0FBTztFQUNqRCxLQUFLLGVBQWUsUUFBUTtDQUM5QjtDQUVBLE1BQU0sZUFBZSxPQUFPLE1BQU07RUFDaEMsRUFBRSxlQUFlO0VBQ2pCLGdCQUFnQixFQUFFO0VBQ2xCLFdBQVcsSUFBSTtFQUVmLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxJQUFJLEtBQUssZUFBZSxRQUFRO0dBQ3ZELElBQUksWUFBWSxTQUFTLFdBQVcsU0FBUyxNQUFNO0lBQ2pELE1BQU0sRUFBRSxhQUFhLFNBQVMsU0FBUztJQUN2QyxRQUFRLGFBQWEsSUFBSTtJQUN6QixTQUFTLE1BQU0sRUFBRSxTQUFTLEtBQUssQ0FBQztHQUNsQyxPQUFPO0lBQ0wsZ0JBQWdCLFVBQVUsV0FBVyxFQUFFLG1CQUFtQixDQUFDO0dBQzdEO0VBQ0YsU0FBUyxLQUFLO0dBQ1osZ0JBQWdCLElBQUksV0FBVyxFQUFFLG1CQUFtQixDQUFDO0VBQ3ZELFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGlHQUFzRzs7Ozs7R0FDckgsd0JBQUMsT0FBRCxFQUFLLFdBQVUscUdBQTBHOzs7OztHQUd6SCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtlQUZaLENBSUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUsMEJBQTJCOzs7O2VBQzVDLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFhLEtBQUssWUFBWTtLQUFXOzs7O2FBQ25EOzs7Ozs7R0FDTDs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7OztNQUMzQjs7OztnQkFDTCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBNEg7TUFFdEk7Ozs7Y0FDSDs7Ozs7O0tBQ0wsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsRUFBRSxrQkFBa0I7S0FDbkI7Ozs7O0tBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsRUFBRSxxQkFBcUI7S0FDdkI7Ozs7O0lBQ0E7Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNHLGdCQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFBTyxTQUFRO1FBQVMsT0FBTyxFQUFFLGNBQWM7a0JBQzVDO09BQ0k7Ozs7O01BQ0o7Ozs7O01BR1Asd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBWSxVQUFVO2lCQUF0QztRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFDZCxFQUFFLGtCQUFrQjtRQUNoQjs7OztrQkFDUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHlCQUEwQjs7Ozs7U0FDdkM7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxNQUFLO1VBQ0w7VUFDQSxPQUFPLFNBQVM7VUFDaEIsVUFBVTtVQUNWLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O2dCQUNGOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFDZCxFQUFFLHFCQUFxQjtRQUNuQjs7OztrQkFDUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHlCQUEwQjs7Ozs7U0FDdkM7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxNQUFLO1VBQ0w7VUFDQSxPQUFPLFNBQVM7VUFDaEIsVUFBVTtVQUNWLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O2dCQUNGOzs7OztRQUVMLHdCQUFDLE9BQUQsWUFDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFVBQVU7U0FDVixXQUFVO21CQUVULFVBQ0MsZ0RBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsdUJBQXdCOzs7O21CQUMzQyx3QkFBQyxRQUFELFlBQU8sRUFBRSxpQkFBaUIsRUFBUTs7OztpQkFDbEM7Ozs7b0JBRUYsZ0RBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7OzttQkFDNUIsd0JBQUMsUUFBRCxZQUFPLEVBQUUsbUJBQW1CLEVBQVE7Ozs7aUJBQ3BDOzs7OztRQUVFOzs7O2lCQUNMOzs7OztPQUNEOzs7Ozs7TUFFTix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUNHLEVBQUUsaUJBQWlCO1NBQUc7U0FDdkIsd0JBQUMsTUFBRDtVQUNFLElBQUc7VUFDSCxXQUFVO29CQUVULEVBQUUsbUJBQW1CO1NBQ2xCOzs7OztRQUNMOzs7Ozs7TUFDQTs7Ozs7S0FDRjs7Ozs7O0dBQ0Y7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxvZ2luUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZUxvY2F0aW9uLCBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gJ3JlYWN0LWkxOG5leHQnO1xuaW1wb3J0IHsgQ29tcGFzcywgTWFpbCwgTG9jaywgTG9nSW4sIExvYWRlcjIsIEdsb2JlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBhcGkgZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpJztcbmltcG9ydCB7IHVzZVVzZXJTdG9yZSB9IGZyb20gJy4uLy4uL3N0b3JlL3VzZVVzZXJTdG9yZSc7XG5pbXBvcnQgeyBBbGVydCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvQWxlcnQnO1xuXG5leHBvcnQgY29uc3QgTG9naW5QYWdlID0gKCkgPT4ge1xuICBjb25zdCB7IHQsIGkxOG4gfSA9IHVzZVRyYW5zbGF0aW9uKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuICBjb25zdCB7IHNldEF1dGggfSA9IHVzZVVzZXJTdG9yZSgpO1xuXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xuICAgIGVtYWlsOiAnJyxcbiAgICBwYXNzd29yZDogJycsXG4gIH0pO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvck1lc3NhZ2UsIHNldEVycm9yTWVzc2FnZV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgY29uc3QgZnJvbSA9IGxvY2F0aW9uLnN0YXRlPy5mcm9tPy5wYXRobmFtZSB8fCAnLyc7XG5cbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcbiAgICBzZXRGb3JtRGF0YSh7XG4gICAgICAuLi5mb3JtRGF0YSxcbiAgICAgIFtlLnRhcmdldC5uYW1lXTogZS50YXJnZXQudmFsdWUsXG4gICAgfSk7XG4gICAgaWYgKGVycm9yTWVzc2FnZSkgc2V0RXJyb3JNZXNzYWdlKCcnKTtcbiAgfTtcblxuICBjb25zdCB0b2dnbGVMYW5ndWFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuZXh0TGFuZyA9IGkxOG4ubGFuZ3VhZ2UgPT09ICd2aScgPyAnZW4nIDogJ3ZpJztcbiAgICBpMThuLmNoYW5nZUxhbmd1YWdlKG5leHRMYW5nKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRFcnJvck1lc3NhZ2UoJycpO1xuICAgIHNldExvYWRpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdCgnL2F1dGgvbG9naW4nLCBmb3JtRGF0YSk7XG4gICAgICBpZiAocmVzcG9uc2UgJiYgcmVzcG9uc2Uuc3VjY2VzcyAmJiByZXNwb25zZS5kYXRhKSB7XG4gICAgICAgIGNvbnN0IHsgYWNjZXNzVG9rZW4sIHVzZXIgfSA9IHJlc3BvbnNlLmRhdGE7XG4gICAgICAgIHNldEF1dGgoYWNjZXNzVG9rZW4sIHVzZXIpO1xuICAgICAgICBuYXZpZ2F0ZShmcm9tLCB7IHJlcGxhY2U6IHRydWUgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRFcnJvck1lc3NhZ2UocmVzcG9uc2U/Lm1lc3NhZ2UgfHwgdCgnYXV0aC5sb2dpbl9mYWlsZWQnKSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvck1lc3NhZ2UoZXJyLm1lc3NhZ2UgfHwgdCgnYXV0aC5sb2dpbl9mYWlsZWQnKSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTkwMCBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIHB5LTEyIHNtOnB4LTYgbGc6cHgtOCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgIHsvKiBCYWNrZ3JvdW5kIEdsb3cgT3ZlcmxheSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC00MCAtbGVmdC00MCB3LTk2IGgtOTYgYmctaW5kaWdvLTYwMC8zMCByb3VuZGVkLWZ1bGwgYmx1ci0zeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiPjwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTQwIC1yaWdodC00MCB3LTk2IGgtOTYgYmctdmlvbGV0LTYwMC8zMCByb3VuZGVkLWZ1bGwgYmx1ci0zeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiPjwvZGl2PlxuXG4gICAgICB7LyogVG9wIHJpZ2h0IGxhbmd1YWdlIHRvZ2dsZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCB6LTEwXCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVMYW5ndWFnZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlIGJnLXNsYXRlLTgwMC84MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIG1pbi1oLVs0NHB4XVwiXG4gICAgICAgID5cbiAgICAgICAgICA8R2xvYmUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWluZGlnby00MDBcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVwcGVyY2FzZVwiPntpMThuLmxhbmd1YWdlIHx8ICdWSSd9PC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOm14LWF1dG8gc206dy1mdWxsIHNtOm1heC13LW1kIHotMTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBnYXAtMyBtYi0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS1pbmRpZ28tNTAwIHRvLXZpb2xldC01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctbGcgc2hhZG93LWluZGlnby01MDAvMzBcIj5cbiAgICAgICAgICAgIDxDb21wYXNzIGNsYXNzTmFtZT1cInctNyBoLTdcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYmxhY2sgYmctZ3JhZGllbnQtdG8tciBmcm9tLWluZGlnby00MDAgdmlhLXZpb2xldC0zMDAgdG8td2hpdGUgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnQgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgIFRyaXBNYXRlXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LXdoaXRlIG10LTJcIj5cbiAgICAgICAgICB7dCgnYXV0aC5sb2dpbl90aXRsZScpfVxuICAgICAgICA8L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICB7dCgnYXV0aC5sb2dpbl9zdWJ0aXRsZScpfVxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHNtOm14LWF1dG8gc206dy1mdWxsIHNtOm1heC13LW1kIHotMTAgcHgtNCBzbTpweC0wXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtODAwLzkwIGJhY2tkcm9wLWJsdXIteGwgcHktOCBweC00IHNoYWRvdy0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAvODAgc206cm91bmRlZC0yeGwgc206cHgtMTBcIj5cbiAgICAgICAgICB7ZXJyb3JNZXNzYWdlICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxuICAgICAgICAgICAgICA8QWxlcnQgdmFyaWFudD1cImRhbmdlclwiIHRpdGxlPXt0KCdjb21tb24uZXJyb3InKX0+XG4gICAgICAgICAgICAgICAge2Vycm9yTWVzc2FnZX1cbiAgICAgICAgICAgICAgPC9BbGVydD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDAgbWItMlwiPlxuICAgICAgICAgICAgICAgIHt0KCdhdXRoLmVtYWlsX2xhYmVsJyl9XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC14bCBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcGwtMy41IGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cbiAgICAgICAgICAgICAgICAgIDxNYWlsIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1zbGF0ZS01MDBcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmVtYWlsfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwibmFtZUBleGFtcGxlLmNvbVwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcGwtMTAgcHItNCBweS0zIGJnLXNsYXRlLTkwMC85MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNTAwIHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tYWxsIG1pbi1oLVs0NHB4XVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTMwMCBtYi0yXCI+XG4gICAgICAgICAgICAgICAge3QoJ2F1dGgucGFzc3dvcmRfbGFiZWwnKX1cbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSByb3VuZGVkLXhsIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC0zLjUgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LXNsYXRlLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKJcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHBsLTEwIHByLTQgcHktMyBiZy1zbGF0ZS05MDAvOTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWFsbCBtaW4taC1bNDRweF1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTIgcHktMy41IHB4LTQgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctaW5kaWdvLTUwMC8yNSB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1pbmRpZ28tNjAwIHRvLXZpb2xldC02MDAgaG92ZXI6ZnJvbS1pbmRpZ28tNTAwIGhvdmVyOnRvLXZpb2xldC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLW9mZnNldC0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMCB0cmFuc2l0aW9uLWFsbCBkaXNhYmxlZDpvcGFjaXR5LTUwIG1pbi1oLVs0NHB4XVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNSBoLTUgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3QoJ2F1dGgubG9nZ2luZ19pbicpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8TG9nSW4gY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt0KCdhdXRoLmxvZ2luX2J1dHRvbicpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTcwMC84MCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICB7dCgnYXV0aC5ub19hY2NvdW50Jyl9eycgJ31cbiAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICB0bz1cIi9yZWdpc3RlclwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtaW5kaWdvLTQwMCBob3Zlcjp0ZXh0LWluZGlnby0zMDAgdHJhbnNpdGlvbi1jb2xvcnMgbWwtMVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7dCgnYXV0aC5yZWdpc3Rlcl9ub3cnKX1cbiAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==