import { r as __toESM, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=17cc0a66";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=f167c130";
import { keyFromSelector as keysFromSelector } from "/node_modules/.vite/deps/i18next.js?v=e1b77a9c";
//#region node_modules/html-parse-stringify/dist/esm/html-parse-stringify.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var voidElements = {
	area: true,
	base: true,
	br: true,
	col: true,
	embed: true,
	hr: true,
	img: true,
	input: true,
	link: true,
	meta: true,
	param: true,
	source: true,
	track: true,
	wbr: true,
	"!doctype": true,
	"!DOCTYPE": true
};
var attrRE = /\s([^'"/\s><]+?)[\s/>]|([^\s=]+)=\s?("[^"]*"|'[^']*')/g;
function parseTag(tag) {
	const res = {
		type: "tag",
		name: "",
		voidElement: false,
		attrs: {},
		children: []
	};
	const tagMatch = tag.match(/<\/?([^\s]+?)[/\s>]/);
	if (tagMatch) {
		res.name = tagMatch[1];
		if (voidElements[tagMatch[1]] || tag.charAt(tag.length - 2) === "/") res.voidElement = true;
		if (res.name.startsWith("!--")) {
			const endIndex = tag.indexOf("-->");
			return {
				type: "comment",
				comment: endIndex !== -1 ? tag.slice(4, endIndex) : ""
			};
		}
	}
	const reg = new RegExp(attrRE);
	let result = null;
	for (;;) {
		result = reg.exec(tag);
		if (result === null) break;
		if (!result[0].trim()) continue;
		if (result[1]) {
			const attr = result[1].trim();
			let arr = [attr, null];
			const eq = attr.indexOf("=");
			if (eq > -1) arr = [attr.slice(0, eq), attr.slice(eq + 1)];
			res.attrs[arr[0]] = arr[1];
			reg.lastIndex--;
		} else if (result[2]) res.attrs[result[2]] = result[3].trim().substring(1, result[3].length - 1);
	}
	return res;
}
var tagRE = /<!--[\s\S]*?-->|<[a-zA-Z0-9\-!/](?:"[^"]*"|'[^']*'|[^'">])*>/g;
var tagNameRE = /<\/?([^\s]+?)[/\s>]/;
var whitespaceRE = /^\s*$/;
var rawTextRE = /^(script|style)$/i;
var sentinel = "\0";
var empty = Object.create(null);
function restoreSentinels(nodes) {
	nodes.forEach(function(node) {
		if (node.type === "text") {
			node.content = node.content.split(sentinel).join("<");
			return;
		}
		if (node.type === "comment") {
			node.comment = node.comment.split(sentinel).join("<");
			return;
		}
		for (const key in node.attrs) {
			const value = node.attrs[key];
			if (typeof value === "string" && value.indexOf(sentinel) > -1) node.attrs[key] = value.split(sentinel).join("<");
		}
		if (node.children.length) restoreSentinels(node.children);
	});
}
function parse(html, options) {
	const components = options && options.components || empty;
	const allowedTags = options && options.allowedTags;
	let restoreNeeded = false;
	if (allowedTags) {
		const isAllowed = typeof allowedTags === "function" ? allowedTags : function(name) {
			return allowedTags.indexOf(name) > -1;
		};
		let out = "";
		let pos = 0;
		tagRE.lastIndex = 0;
		let am;
		while (am = tagRE.exec(html)) {
			const tag = am[0];
			out += html.slice(pos, am.index);
			const nameMatch = tag.match(tagNameRE);
			if (tag.startsWith("<!--") || nameMatch && isAllowed(nameMatch[1])) {
				out += tag;
				pos = am.index + tag.length;
			} else {
				restoreNeeded = true;
				out += sentinel;
				pos = am.index + 1;
				tagRE.lastIndex = pos;
			}
		}
		html = out + html.slice(pos);
	}
	const result = [];
	const arr = [];
	let current;
	let level = -1;
	let inComponent = false;
	let rawUntil = 0;
	let htmlLower;
	if (html.indexOf("<") !== 0) {
		const end = html.indexOf("<");
		result.push({
			type: "text",
			content: end === -1 ? html : html.substring(0, end)
		});
	}
	const matches = [];
	let m;
	while (m = tagRE.exec(html)) matches.push(m);
	matches.forEach(function(match, i) {
		const tag = match[0];
		if (!tag) return;
		if (tag.startsWith("<!--")) return;
		let lts = 0;
		let gts = 0;
		let secondLt = -1;
		let quote = null;
		for (let j = 0; j < tag.length; j++) {
			const c = tag.charAt(j);
			if (quote) {
				if (c === quote) quote = null;
			} else if (c === "\"" || c === "'") quote = c;
			else if (c === "<") {
				lts++;
				if (lts === 2) secondLt = j;
			} else if (c === ">") gts++;
		}
		const validSplit = secondLt > -1 && /[a-zA-Z0-9\-!/]/.test(tag.charAt(secondLt + 1));
		if (lts > gts && validSplit) {
			const firstPart = tag.substring(0, secondLt);
			const secondPart = tag.substring(firstPart.length);
			matches[i][0] = secondPart;
			matches[i].index += firstPart.length;
		}
	});
	matches.forEach(function(match, i) {
		const tag = match[0];
		if (!tag) return;
		const index = match.index;
		if (index < rawUntil) return;
		if (inComponent) if (tag !== "</" + current.name + ">") return;
		else inComponent = false;
		const isOpen = tag.charAt(1) !== "/";
		const isComment = tag.startsWith("<!--");
		const start = index + tag.length;
		const nextChar = html.charAt(start);
		const nextMatch = matches[i + 1];
		let isText;
		if (nextChar === "<" && nextMatch) {
			const nextTag = html.substring(start, nextMatch.index);
			isText = nextTag.split("<").length > nextTag.split(">").length;
		}
		let parent;
		if (isComment) {
			const comment = parseTag(tag);
			if (level < 0) {
				result.push(comment);
				return result;
			}
			parent = arr[level];
			parent.children.push(comment);
			const text = html.slice(start, nextMatch ? nextMatch.index : void 0);
			if (text.length > 0) parent.children.push({
				type: "text",
				content: text
			});
			return result;
		}
		if (isOpen) {
			level++;
			current = parseTag(tag);
			if (current.type === "tag" && components[current.name]) {
				current.type = "component";
				inComponent = true;
			}
			let isRawText = false;
			if (!inComponent && !current.voidElement && rawTextRE.test(current.name)) {
				isRawText = true;
				htmlLower || (htmlLower = html.toLowerCase());
				const closeIndex = htmlLower.indexOf("</" + current.name.toLowerCase() + ">", start);
				const contentEnd = closeIndex === -1 ? html.length : closeIndex;
				const content = html.slice(start, contentEnd);
				if (content) current.children.push({
					type: "text",
					content
				});
				rawUntil = contentEnd;
			}
			if (!current.voidElement && !inComponent && !isRawText && nextChar && nextChar !== "<") current.children.push({
				type: "text",
				content: html.slice(start, nextMatch ? nextMatch.index : void 0)
			});
			if (level === 0) result.push(current);
			parent = arr[level - 1];
			if (parent) parent.children.push(current);
			arr[level] = current;
		}
		if (!isOpen || current.voidElement) {
			if (level > -1 && (current.voidElement || current.name === tag.slice(2, -1))) {
				level--;
				current = level === -1 ? result : arr[level];
			}
			if (!inComponent && (nextChar !== "<" || isText) && nextChar) {
				parent = level === -1 ? result : arr[level].children;
				const end = nextMatch ? nextMatch.index : -1;
				let content = html.slice(start, end === -1 ? void 0 : end);
				if (whitespaceRE.test(content)) content = " ";
				if (end > -1 && level + parent.length >= 0 || content !== " ") parent.push({
					type: "text",
					content
				});
			}
		}
	});
	if (restoreNeeded) restoreSentinels(result);
	return result;
}
function attrString(attrs) {
	const buff = [];
	for (const key in attrs) if (attrs[key] === null) buff.push(key);
	else buff.push(key + "=\"" + String(attrs[key]).replace(/"/g, "&quot;") + "\"");
	if (!buff.length) return "";
	return " " + buff.join(" ");
}
function stringifyNode(buff, doc) {
	switch (doc.type) {
		case "text": return buff + doc.content;
		case "tag": {
			const tagEnd = doc.voidElement && doc.name.toLowerCase() !== "!doctype" ? "/>" : ">";
			buff += "<" + doc.name + (doc.attrs ? attrString(doc.attrs) : "") + tagEnd;
			if (doc.voidElement) return buff;
			return buff + doc.children.reduce(stringifyNode, "") + "</" + doc.name + ">";
		}
		case "comment":
			buff += "<!--" + doc.comment + "-->";
			return buff;
	}
}
function stringify(doc) {
	return doc.reduce(function(token, rootEl) {
		return token + stringifyNode("", rootEl);
	}, "");
}
var index = {
	parse,
	stringify
};
//#endregion
//#region node_modules/react-i18next/dist/es/utils.js
var warn = (i18n, code, msg, rest) => {
	const args = [msg, {
		code,
		...rest || {}
	}];
	if (i18n?.services?.logger?.forward) return i18n.services.logger.forward(args, "warn", "react-i18next::", true);
	if (isString(args[0])) args[0] = `react-i18next:: ${args[0]}`;
	if (i18n?.services?.logger?.warn) i18n.services.logger.warn(...args);
	else if (console?.warn) console.warn(...args);
};
var alreadyWarned = {};
var warnOnce = (i18n, code, msg, rest) => {
	if (isString(msg) && alreadyWarned[msg]) return;
	if (isString(msg)) alreadyWarned[msg] = /* @__PURE__ */ new Date();
	warn(i18n, code, msg, rest);
};
var loadedClb = (i18n, cb) => () => {
	if (i18n.isInitialized) cb();
	else {
		const initialized = () => {
			setTimeout(() => {
				i18n.off("initialized", initialized);
			}, 0);
			cb();
		};
		i18n.on("initialized", initialized);
	}
};
var loadNamespaces = (i18n, ns, cb) => {
	i18n.loadNamespaces(ns, loadedClb(i18n, cb));
};
var loadLanguages = (i18n, lng, ns, cb) => {
	if (isString(ns)) ns = [ns];
	if (i18n.options.preload && i18n.options.preload.indexOf(lng) > -1) return loadNamespaces(i18n, ns, cb);
	ns.forEach((n) => {
		if (i18n.options.ns.indexOf(n) < 0) i18n.options.ns.push(n);
	});
	i18n.loadLanguages(lng, loadedClb(i18n, cb));
};
var hasLoadedNamespace = (ns, i18n, options = {}) => {
	if (!i18n.languages || !i18n.languages.length) {
		warnOnce(i18n, "NO_LANGUAGES", "i18n.languages were undefined or empty", { languages: i18n.languages });
		return true;
	}
	return i18n.hasLoadedNamespace(ns, {
		lng: options.lng,
		precheck: (i18nInstance, loadNotPending) => {
			if (options.bindI18n && options.bindI18n.indexOf("languageChanging") > -1 && i18nInstance.services.backendConnector.backend && i18nInstance.isLanguageChangingTo && !loadNotPending(i18nInstance.isLanguageChangingTo, ns)) return false;
		}
	});
};
var getDisplayName = (Component) => Component.displayName || Component.name || (isString(Component) && Component.length > 0 ? Component : "Unknown");
var isString = (obj) => typeof obj === "string";
var isObject = (obj) => typeof obj === "object" && obj !== null;
//#endregion
//#region node_modules/react-i18next/dist/es/unescape.js
var matchHtmlEntity = /&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g;
var htmlEntities = {
	"&amp;": "&",
	"&#38;": "&",
	"&lt;": "<",
	"&#60;": "<",
	"&gt;": ">",
	"&#62;": ">",
	"&apos;": "'",
	"&#39;": "'",
	"&quot;": "\"",
	"&#34;": "\"",
	"&nbsp;": " ",
	"&#160;": " ",
	"&copy;": "©",
	"&#169;": "©",
	"&reg;": "®",
	"&#174;": "®",
	"&hellip;": "…",
	"&#8230;": "…",
	"&#x2F;": "/",
	"&#47;": "/"
};
var unescapeHtmlEntity = (m) => htmlEntities[m];
var unescape = (text) => text.replace(matchHtmlEntity, unescapeHtmlEntity);
//#endregion
//#region node_modules/react-i18next/dist/es/defaults.js
var defaultOptions = {
	bindI18n: "languageChanged",
	bindI18nStore: "",
	transEmptyNodeValue: "",
	transSupportBasicHtmlNodes: true,
	transWrapTextNodes: "",
	transKeepBasicHtmlNodesFor: [
		"br",
		"strong",
		"i",
		"p"
	],
	useSuspense: true,
	unescape,
	transDefaultProps: void 0
};
var setDefaults = (options = {}) => {
	defaultOptions = {
		...defaultOptions,
		...options
	};
};
var getDefaults = () => defaultOptions;
//#endregion
//#region node_modules/react-i18next/dist/es/i18nInstance.js
var i18nInstance;
var setI18n = (instance) => {
	i18nInstance = instance;
};
var getI18n = () => i18nInstance;
//#endregion
//#region node_modules/react-i18next/dist/es/TransWithoutContext.js
var hasChildren = (node, checkLength) => {
	if (!node) return false;
	const base = node.props?.children ?? node.children;
	if (checkLength) return base.length > 0;
	return !!base;
};
var getChildren = (node) => {
	if (!node) return [];
	const children = node.props?.children ?? node.children;
	return node.props?.i18nIsDynamicList ? getAsArray(children) : children;
};
var hasValidReactChildren = (children) => Array.isArray(children) && children.every(import_react.isValidElement);
var getAsArray = (data) => Array.isArray(data) ? data : [data];
var mergeProps = (source, target) => {
	const newTarget = { ...target };
	newTarget.props = {
		...target.props,
		...source.props
	};
	return newTarget;
};
var getValuesFromChildren = (children) => {
	const values = {};
	if (!children) return values;
	const getData = (childs) => {
		getAsArray(childs).forEach((child) => {
			if (isString(child)) return;
			if (hasChildren(child)) getData(getChildren(child));
			else if (isObject(child) && !(0, import_react.isValidElement)(child)) Object.assign(values, child);
		});
	};
	getData(children);
	return values;
};
var nodesToString = (children, i18nOptions, i18n, i18nKey) => {
	if (!children) return "";
	let stringNode = "";
	const childrenArray = getAsArray(children);
	const keepArray = i18nOptions?.transSupportBasicHtmlNodes ? i18nOptions.transKeepBasicHtmlNodesFor ?? [] : [];
	childrenArray.forEach((child, childIndex) => {
		if (isString(child)) {
			stringNode += `${child}`;
			return;
		}
		if ((0, import_react.isValidElement)(child)) {
			const { props, type } = child;
			const childPropsCount = Object.keys(props).length;
			const shouldKeepChild = keepArray.indexOf(type) > -1;
			const childChildren = props.children;
			if (!childChildren && shouldKeepChild && !childPropsCount) {
				stringNode += `<${type}/>`;
				return;
			}
			if (!childChildren && (!shouldKeepChild || childPropsCount) || props.i18nIsDynamicList) {
				stringNode += `<${childIndex}></${childIndex}>`;
				return;
			}
			if (shouldKeepChild && childPropsCount <= 1) {
				const cnt = isString(childChildren) ? childChildren : nodesToString(childChildren, i18nOptions, i18n, i18nKey);
				stringNode += `<${type}>${cnt}</${type}>`;
				return;
			}
			const content = nodesToString(childChildren, i18nOptions, i18n, i18nKey);
			stringNode += `<${childIndex}>${content}</${childIndex}>`;
			return;
		}
		if (child === null) {
			warn(i18n, "TRANS_NULL_VALUE", `Passed in a null value as child`, { i18nKey });
			return;
		}
		if (isObject(child)) {
			const { format, ...clone } = child;
			const keys = Object.keys(clone);
			if (keys.length === 1) {
				const value = format ? `${keys[0]}, ${format}` : keys[0];
				stringNode += `{{${value}}}`;
				return;
			}
			warn(i18n, "TRANS_INVALID_OBJ", `Invalid child - Object should only have keys {{ value, format }} (format is optional).`, {
				i18nKey,
				child
			});
			return;
		}
		warn(i18n, "TRANS_INVALID_VAR", `Passed in a variable like {number} - pass variables for interpolation as full objects like {{number}}.`, {
			i18nKey,
			child
		});
	});
	return stringNode;
};
var renderNodes = (children, knownComponentsMap, targetString, i18n, i18nOptions, combinedTOpts, shouldUnescape) => {
	if (targetString === "") return [];
	const keepArray = i18nOptions.transKeepBasicHtmlNodesFor || [];
	const emptyChildrenButNeedsHandling = targetString && new RegExp(keepArray.map((keep) => `<${keep}`).join("|")).test(targetString);
	if (!children && !knownComponentsMap && !emptyChildrenButNeedsHandling && !shouldUnescape) return [targetString];
	const data = knownComponentsMap ?? {};
	const getData = (childs) => {
		getAsArray(childs).forEach((child) => {
			if (isString(child)) return;
			if (hasChildren(child)) getData(getChildren(child));
			else if (isObject(child) && !(0, import_react.isValidElement)(child)) Object.assign(data, child);
		});
	};
	getData(children);
	const knownNames = Object.keys(data);
	const allowedTags = (name) => /^\d+$/.test(name) || keepArray.indexOf(name) > -1 || knownNames.indexOf(name) > -1;
	const ast = index.parse(`<0>${targetString}</0>`, { allowedTags });
	const opts = {
		...data,
		...combinedTOpts
	};
	const renderInner = (child, node, rootReactNode) => {
		const childs = getChildren(child);
		const mappedChildren = mapAST(childs, node.children, rootReactNode);
		return hasValidReactChildren(childs) && mappedChildren.length === 0 || child.props?.i18nIsDynamicList ? childs : mappedChildren;
	};
	const pushTranslatedJSX = (child, inner, mem, i, isVoid) => {
		if (child.dummy) {
			child.children = inner;
			mem.push((0, import_react.cloneElement)(child, { key: i }, isVoid ? void 0 : inner));
		} else mem.push(...import_react.Children.map([child], (c) => {
			if (c.type === import_react.Fragment || c.props?.i18nIsDynamicList !== void 0) {
				const freshProps = { key: i };
				if (c && c.props) Object.keys(c.props).forEach((k) => {
					if (k === "children" || k === "i18nIsDynamicList") return;
					freshProps[k] = c.props[k];
				});
				return (0, import_react.createElement)(c.type, freshProps, isVoid ? null : inner);
			}
			const override = { key: i };
			if (c && c.props) Object.keys(c.props).forEach((k) => {
				if (k === "ref" || k === "children") return;
				override[k] = c.props[k];
			});
			return (0, import_react.cloneElement)(c, override, isVoid ? null : inner);
		}));
	};
	const mapAST = (reactNode, astNode, rootReactNode) => {
		const reactNodes = getAsArray(reactNode);
		const astNodes = getAsArray(astNode);
		const keepTagOccurrence = {};
		return astNodes.reduce((mem, node, i) => {
			const translationContent = node.children?.[0]?.content && i18n.services.interpolator.interpolate(node.children[0].content, opts, i18n.language);
			if (node.type === "tag") {
				let tmp = reactNodes[parseInt(node.name, 10)];
				if (!tmp && knownComponentsMap) tmp = knownComponentsMap[node.name];
				if (rootReactNode.length === 1 && !tmp) tmp = rootReactNode[0][node.name];
				if (!tmp) tmp = {};
				const props = { ...node.attrs };
				if (shouldUnescape) Object.keys(props).forEach((p) => {
					const val = props[p];
					if (isString(val)) props[p] = unescape(val);
				});
				const child = Object.keys(props).length !== 0 ? mergeProps({ props }, tmp) : tmp;
				const isElement = (0, import_react.isValidElement)(child);
				const isValidTranslationWithChildren = isElement && hasChildren(node, true) && !node.voidElement;
				const isEmptyTransWithHTML = emptyChildrenButNeedsHandling && isObject(child) && child.dummy && !isElement;
				const isKnownComponent = isObject(knownComponentsMap) && Object.hasOwnProperty.call(knownComponentsMap, node.name);
				if (isString(child)) {
					const value = i18n.services.interpolator.interpolate(child, opts, i18n.language);
					mem.push(value);
				} else if (hasChildren(child) || isValidTranslationWithChildren) {
					const inner = renderInner(child, node, rootReactNode);
					pushTranslatedJSX(child, inner, mem, i);
				} else if (isEmptyTransWithHTML) {
					const inner = mapAST(reactNodes, node.children, rootReactNode);
					pushTranslatedJSX(child, inner, mem, i);
				} else if (Number.isNaN(parseFloat(node.name))) if (isKnownComponent) {
					const inner = renderInner(child, node, rootReactNode);
					pushTranslatedJSX(child, inner, mem, i, node.voidElement);
				} else if (i18nOptions.transSupportBasicHtmlNodes && keepArray.indexOf(node.name) > -1) if (node.voidElement) mem.push((0, import_react.createElement)(node.name, { key: `${node.name}-${i}` }));
				else {
					const occurrence = keepTagOccurrence[node.name] || 0;
					keepTagOccurrence[node.name] = occurrence + 1;
					let matched;
					let seen = 0;
					for (let r = 0; r < reactNodes.length; r += 1) {
						const rn = reactNodes[r];
						if ((0, import_react.isValidElement)(rn) && rn.type === node.name) {
							if (seen === occurrence) {
								matched = rn;
								break;
							}
							seen += 1;
						}
					}
					const innerScope = matched ? getAsArray(getChildren(matched)) : reactNodes;
					const inner = mapAST(innerScope, node.children, rootReactNode);
					mem.push((0, import_react.createElement)(node.name, { key: `${node.name}-${i}` }, inner));
				}
				else if (node.voidElement) mem.push(`<${node.name} />`);
				else {
					const inner = mapAST(reactNodes, node.children, rootReactNode);
					mem.push(`<${node.name}>${inner}</${node.name}>`);
				}
				else if (isObject(child) && !isElement) {
					const content = node.children[0] ? translationContent : null;
					if (content) mem.push(content);
				} else pushTranslatedJSX(child, translationContent, mem, i, node.children.length !== 1 || !translationContent);
			} else if (node.type === "text") {
				const wrapTextNodes = i18nOptions.transWrapTextNodes;
				const unescapeFn = typeof i18nOptions.unescape === "function" ? i18nOptions.unescape : getDefaults().unescape;
				const content = shouldUnescape ? unescapeFn(i18n.services.interpolator.interpolate(node.content, opts, i18n.language)) : i18n.services.interpolator.interpolate(node.content, opts, i18n.language);
				if (wrapTextNodes) mem.push((0, import_react.createElement)(wrapTextNodes, { key: `${node.name}-${i}` }, content));
				else mem.push(content);
			}
			return mem;
		}, []);
	};
	return getChildren(mapAST([{
		dummy: true,
		children: children || []
	}], ast, getAsArray(children || []))[0]);
};
var fixComponentProps = (component, index, translation) => {
	const componentKey = component.key || index;
	const comp = (0, import_react.cloneElement)(component, { key: componentKey });
	if (!comp.props || !comp.props.children || translation.indexOf(`${index}/>`) < 0 && translation.indexOf(`${index} />`) < 0) return comp;
	function Componentized() {
		return (0, import_react.createElement)(import_react.Fragment, null, comp);
	}
	return (0, import_react.createElement)(Componentized, { key: componentKey });
};
var generateArrayComponents = (components, translation) => components.map((c, index) => fixComponentProps(c, index, translation));
var generateObjectComponents = (components, translation) => {
	const componentMap = {};
	Object.keys(components).forEach((c) => {
		Object.assign(componentMap, { [c]: fixComponentProps(components[c], c, translation) });
	});
	return componentMap;
};
var generateComponents = (components, translation, i18n, i18nKey) => {
	if (!components) return null;
	if (Array.isArray(components)) return generateArrayComponents(components, translation);
	if (isObject(components)) return generateObjectComponents(components, translation);
	warnOnce(i18n, "TRANS_INVALID_COMPONENTS", `<Trans /> "components" prop expects an object or array`, { i18nKey });
	return null;
};
var isComponentsMap = (object) => {
	if (!isObject(object)) return false;
	if (Array.isArray(object)) return false;
	return Object.keys(object).reduce((acc, key) => acc && Number.isNaN(Number.parseFloat(key)), true);
};
function Trans$1({ children, count, parent, i18nKey, context, tOptions = {}, values, defaults, components, ns, i18n: i18nFromProps, t: tFromProps, shouldUnescape, ...additionalProps }) {
	const i18n = i18nFromProps || getI18n();
	if (!i18n) {
		warnOnce(i18n, "NO_I18NEXT_INSTANCE", `Trans: You need to pass in an i18next instance using initReactI18next or by passing it via props or context. In monorepo setups, make sure there is only one instance of react-i18next.`, { i18nKey });
		return children;
	}
	const t = tFromProps || i18n.t.bind(i18n) || ((k) => k);
	const reactI18nextOptions = {
		...getDefaults(),
		...i18n.options?.react
	};
	let namespaces = ns || t.ns || i18n.options?.defaultNS;
	namespaces = isString(namespaces) ? [namespaces] : namespaces || ["translation"];
	const { transDefaultProps } = reactI18nextOptions;
	const mergedTOptions = transDefaultProps?.tOptions ? {
		...transDefaultProps.tOptions,
		...tOptions
	} : tOptions;
	const mergedShouldUnescape = shouldUnescape ?? transDefaultProps?.shouldUnescape;
	const mergedValues = transDefaultProps?.values ? {
		...transDefaultProps.values,
		...values
	} : values;
	const mergedComponents = transDefaultProps?.components ? {
		...transDefaultProps.components,
		...components
	} : components;
	const nodeAsString = nodesToString(children, reactI18nextOptions, i18n, i18nKey);
	const defaultValue = defaults || mergedTOptions?.defaultValue || nodeAsString || reactI18nextOptions.transEmptyNodeValue || (typeof i18nKey === "function" ? keysFromSelector(i18nKey) : i18nKey);
	const { hashTransKey } = reactI18nextOptions;
	const key = i18nKey || (hashTransKey ? hashTransKey(nodeAsString || defaultValue) : nodeAsString || defaultValue);
	if (i18n.options?.interpolation?.defaultVariables) values = mergedValues && Object.keys(mergedValues).length > 0 ? {
		...mergedValues,
		...i18n.options.interpolation.defaultVariables
	} : { ...i18n.options.interpolation.defaultVariables };
	else values = mergedValues;
	const valuesFromChildren = getValuesFromChildren(children);
	if (valuesFromChildren && typeof valuesFromChildren.count === "number" && count === void 0) count = valuesFromChildren.count;
	const interpolationOverride = values || count !== void 0 && !i18n.options?.interpolation?.alwaysFormat || !children ? mergedTOptions.interpolation : { interpolation: {
		...mergedTOptions.interpolation,
		prefix: "#$?",
		suffix: "?$#"
	} };
	const combinedTOpts = {
		...mergedTOptions,
		context: context || mergedTOptions.context,
		count,
		...values,
		...interpolationOverride,
		defaultValue,
		ns: namespaces
	};
	let translation = key ? t(key, combinedTOpts) : defaultValue;
	if (translation === key && defaultValue) translation = defaultValue;
	const generatedComponents = generateComponents(mergedComponents, translation, i18n, i18nKey);
	let indexedChildren = generatedComponents || children;
	let componentsMap = null;
	if (isComponentsMap(generatedComponents)) {
		componentsMap = generatedComponents;
		indexedChildren = children;
	}
	const content = renderNodes(indexedChildren, componentsMap, translation, i18n, reactI18nextOptions, combinedTOpts, mergedShouldUnescape);
	const useAsParent = parent ?? reactI18nextOptions.defaultTransParent;
	return useAsParent ? (0, import_react.createElement)(useAsParent, additionalProps, content) : content;
}
//#endregion
//#region node_modules/react-i18next/dist/es/initReactI18next.js
var initReactI18next = {
	type: "3rdParty",
	init(instance) {
		setDefaults(instance.options.react);
		setI18n(instance);
	}
};
//#endregion
//#region node_modules/react-i18next/dist/es/context.js
var I18nContext = (0, import_react.createContext)();
var ReportNamespaces = class {
	constructor() {
		this.usedNamespaces = {};
	}
	addUsedNamespaces(namespaces) {
		namespaces.forEach((ns) => {
			if (!this.usedNamespaces[ns]) this.usedNamespaces[ns] = true;
		});
	}
	getUsedNamespaces() {
		return Object.keys(this.usedNamespaces);
	}
};
var composeInitialProps = (ForComponent) => async (ctx) => {
	const componentsInitialProps = await ForComponent.getInitialProps?.(ctx) ?? {};
	const i18nInitialProps = getInitialProps();
	return {
		...componentsInitialProps,
		...i18nInitialProps
	};
};
var getInitialProps = () => {
	const i18n = getI18n();
	if (!i18n) {
		console.warn("react-i18next:: getInitialProps: You will need to pass in an i18next instance by using initReactI18next");
		return {};
	}
	const namespaces = i18n.reportNamespaces?.getUsedNamespaces() ?? [];
	const ret = {};
	const initialI18nStore = {};
	i18n.languages.forEach((l) => {
		initialI18nStore[l] = {};
		namespaces.forEach((ns) => {
			initialI18nStore[l][ns] = i18n.getResourceBundle(l, ns) || {};
		});
	});
	ret.initialI18nStore = initialI18nStore;
	ret.initialLanguage = i18n.language;
	return ret;
};
//#endregion
//#region node_modules/react-i18next/dist/es/Trans.js
function Trans({ children, count, parent, i18nKey, context, tOptions = {}, values, defaults, components, ns, i18n: i18nFromProps, t: tFromProps, shouldUnescape, ...additionalProps }) {
	const { i18n: i18nFromContext, defaultNS: defaultNSFromContext } = (0, import_react.useContext)(I18nContext) || {};
	const i18n = i18nFromProps || i18nFromContext || getI18n();
	const t = tFromProps || i18n?.t.bind(i18n);
	return Trans$1({
		children,
		count,
		parent,
		i18nKey,
		context,
		tOptions,
		values,
		defaults,
		components,
		ns: ns || t?.ns || defaultNSFromContext || i18n?.options?.defaultNS,
		i18n,
		t: tFromProps,
		shouldUnescape,
		...additionalProps
	});
}
//#endregion
//#region node_modules/react-i18next/dist/es/IcuTransUtils/TranslationParserError.js
var TranslationParserError = class TranslationParserError extends Error {
	constructor(message, position, translationString) {
		super(message);
		this.name = "TranslationParserError";
		this.position = position;
		this.translationString = translationString;
		if (Error.captureStackTrace) Error.captureStackTrace(this, TranslationParserError);
	}
};
//#endregion
//#region node_modules/react-i18next/dist/es/IcuTransUtils/htmlEntityDecoder.js
var commonEntities = {
	"&nbsp;": "\xA0",
	"&amp;": "&",
	"&lt;": "<",
	"&gt;": ">",
	"&quot;": "\"",
	"&apos;": "'",
	"&copy;": "©",
	"&reg;": "®",
	"&trade;": "™",
	"&hellip;": "…",
	"&ndash;": "–",
	"&mdash;": "—",
	"&lsquo;": "‘",
	"&rsquo;": "’",
	"&sbquo;": "‚",
	"&ldquo;": "“",
	"&rdquo;": "”",
	"&bdquo;": "„",
	"&dagger;": "†",
	"&Dagger;": "‡",
	"&bull;": "•",
	"&prime;": "′",
	"&Prime;": "″",
	"&lsaquo;": "‹",
	"&rsaquo;": "›",
	"&sect;": "§",
	"&para;": "¶",
	"&middot;": "·",
	"&ensp;": " ",
	"&emsp;": " ",
	"&thinsp;": " ",
	"&euro;": "€",
	"&pound;": "£",
	"&yen;": "¥",
	"&cent;": "¢",
	"&curren;": "¤",
	"&times;": "×",
	"&divide;": "÷",
	"&minus;": "−",
	"&plusmn;": "±",
	"&ne;": "≠",
	"&le;": "≤",
	"&ge;": "≥",
	"&asymp;": "≈",
	"&equiv;": "≡",
	"&infin;": "∞",
	"&int;": "∫",
	"&sum;": "∑",
	"&prod;": "∏",
	"&radic;": "√",
	"&part;": "∂",
	"&permil;": "‰",
	"&deg;": "°",
	"&micro;": "µ",
	"&larr;": "←",
	"&uarr;": "↑",
	"&rarr;": "→",
	"&darr;": "↓",
	"&harr;": "↔",
	"&crarr;": "↵",
	"&lArr;": "⇐",
	"&uArr;": "⇑",
	"&rArr;": "⇒",
	"&dArr;": "⇓",
	"&hArr;": "⇔",
	"&alpha;": "α",
	"&beta;": "β",
	"&gamma;": "γ",
	"&delta;": "δ",
	"&epsilon;": "ε",
	"&zeta;": "ζ",
	"&eta;": "η",
	"&theta;": "θ",
	"&iota;": "ι",
	"&kappa;": "κ",
	"&lambda;": "λ",
	"&mu;": "μ",
	"&nu;": "ν",
	"&xi;": "ξ",
	"&omicron;": "ο",
	"&pi;": "π",
	"&rho;": "ρ",
	"&sigma;": "σ",
	"&tau;": "τ",
	"&upsilon;": "υ",
	"&phi;": "φ",
	"&chi;": "χ",
	"&psi;": "ψ",
	"&omega;": "ω",
	"&Alpha;": "Α",
	"&Beta;": "Β",
	"&Gamma;": "Γ",
	"&Delta;": "Δ",
	"&Epsilon;": "Ε",
	"&Zeta;": "Ζ",
	"&Eta;": "Η",
	"&Theta;": "Θ",
	"&Iota;": "Ι",
	"&Kappa;": "Κ",
	"&Lambda;": "Λ",
	"&Mu;": "Μ",
	"&Nu;": "Ν",
	"&Xi;": "Ξ",
	"&Omicron;": "Ο",
	"&Pi;": "Π",
	"&Rho;": "Ρ",
	"&Sigma;": "Σ",
	"&Tau;": "Τ",
	"&Upsilon;": "Υ",
	"&Phi;": "Φ",
	"&Chi;": "Χ",
	"&Psi;": "Ψ",
	"&Omega;": "Ω",
	"&Agrave;": "À",
	"&Aacute;": "Á",
	"&Acirc;": "Â",
	"&Atilde;": "Ã",
	"&Auml;": "Ä",
	"&Aring;": "Å",
	"&AElig;": "Æ",
	"&Ccedil;": "Ç",
	"&Egrave;": "È",
	"&Eacute;": "É",
	"&Ecirc;": "Ê",
	"&Euml;": "Ë",
	"&Igrave;": "Ì",
	"&Iacute;": "Í",
	"&Icirc;": "Î",
	"&Iuml;": "Ï",
	"&ETH;": "Ð",
	"&Ntilde;": "Ñ",
	"&Ograve;": "Ò",
	"&Oacute;": "Ó",
	"&Ocirc;": "Ô",
	"&Otilde;": "Õ",
	"&Ouml;": "Ö",
	"&Oslash;": "Ø",
	"&Ugrave;": "Ù",
	"&Uacute;": "Ú",
	"&Ucirc;": "Û",
	"&Uuml;": "Ü",
	"&Yacute;": "Ý",
	"&THORN;": "Þ",
	"&szlig;": "ß",
	"&agrave;": "à",
	"&aacute;": "á",
	"&acirc;": "â",
	"&atilde;": "ã",
	"&auml;": "ä",
	"&aring;": "å",
	"&aelig;": "æ",
	"&ccedil;": "ç",
	"&egrave;": "è",
	"&eacute;": "é",
	"&ecirc;": "ê",
	"&euml;": "ë",
	"&igrave;": "ì",
	"&iacute;": "í",
	"&icirc;": "î",
	"&iuml;": "ï",
	"&eth;": "ð",
	"&ntilde;": "ñ",
	"&ograve;": "ò",
	"&oacute;": "ó",
	"&ocirc;": "ô",
	"&otilde;": "õ",
	"&ouml;": "ö",
	"&oslash;": "ø",
	"&ugrave;": "ù",
	"&uacute;": "ú",
	"&ucirc;": "û",
	"&uuml;": "ü",
	"&yacute;": "ý",
	"&thorn;": "þ",
	"&yuml;": "ÿ",
	"&iexcl;": "¡",
	"&iquest;": "¿",
	"&fnof;": "ƒ",
	"&circ;": "ˆ",
	"&tilde;": "˜",
	"&OElig;": "Œ",
	"&oelig;": "œ",
	"&Scaron;": "Š",
	"&scaron;": "š",
	"&Yuml;": "Ÿ",
	"&ordf;": "ª",
	"&ordm;": "º",
	"&macr;": "¯",
	"&acute;": "´",
	"&cedil;": "¸",
	"&sup1;": "¹",
	"&sup2;": "²",
	"&sup3;": "³",
	"&frac14;": "¼",
	"&frac12;": "½",
	"&frac34;": "¾",
	"&spades;": "♠",
	"&clubs;": "♣",
	"&hearts;": "♥",
	"&diams;": "♦",
	"&loz;": "◊",
	"&oline;": "‾",
	"&frasl;": "⁄",
	"&weierp;": "℘",
	"&image;": "ℑ",
	"&real;": "ℜ",
	"&alefsym;": "ℵ"
};
var entityPattern = new RegExp(Object.keys(commonEntities).map((entity) => entity.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|"), "g");
var decodeHtmlEntities = (text) => text.replace(entityPattern, (match) => commonEntities[match]).replace(/&#(\d+);/g, (_, num) => String.fromCharCode(parseInt(num, 10))).replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
//#endregion
//#region node_modules/react-i18next/dist/es/IcuTransUtils/tokenizer.js
var tokenize = (translation) => {
	const tokens = [];
	let position = 0;
	let currentText = "";
	const flushText = () => {
		if (currentText) {
			tokens.push({
				type: "Text",
				value: currentText,
				position: position - currentText.length
			});
			currentText = "";
		}
	};
	while (position < translation.length) {
		const char = translation[position];
		if (char === "<") {
			const tagMatch = translation.slice(position).match(/^<(\d+)>/);
			if (tagMatch) {
				flushText();
				tokens.push({
					type: "TagOpen",
					value: tagMatch[0],
					position,
					tagNumber: parseInt(tagMatch[1], 10)
				});
				position += tagMatch[0].length;
			} else {
				const closeTagMatch = translation.slice(position).match(/^<\/(\d+)>/);
				if (closeTagMatch) {
					flushText();
					tokens.push({
						type: "TagClose",
						value: closeTagMatch[0],
						position,
						tagNumber: parseInt(closeTagMatch[1], 10)
					});
					position += closeTagMatch[0].length;
				} else {
					currentText += char;
					position += 1;
				}
			}
		} else {
			currentText += char;
			position += 1;
		}
	}
	flushText();
	return tokens;
};
//#endregion
//#region node_modules/react-i18next/dist/es/IcuTransUtils/renderTranslation.js
var renderDeclarationNode = (declaration, children, childDeclarations) => {
	const { type, props = {} } = declaration;
	if (props.children && Array.isArray(props.children) && childDeclarations) {
		const { children: _childrenToRemove, ...propsWithoutChildren } = props;
		return import_react.createElement(type, propsWithoutChildren, ...children);
	}
	if (children.length === 0) return import_react.createElement(type, props);
	if (children.length === 1) return import_react.createElement(type, props, children[0]);
	return import_react.createElement(type, props, ...children);
};
var renderTranslation = (translation, declarations = []) => {
	if (!translation) return [];
	const tokens = tokenize(translation);
	const result = [];
	const stack = [];
	const literalTagNumbers = /* @__PURE__ */ new Set();
	const getCurrentDeclarations = () => {
		if (stack.length === 0) return declarations;
		const parentFrame = stack[stack.length - 1];
		if (parentFrame.declaration.props?.children && Array.isArray(parentFrame.declaration.props.children)) return parentFrame.declaration.props.children;
		return parentFrame.declarations;
	};
	tokens.forEach((token) => {
		switch (token.type) {
			case "Text":
				{
					const decoded = decodeHtmlEntities(token.value);
					(stack.length > 0 ? stack[stack.length - 1].children : result).push(decoded);
				}
				break;
			case "TagOpen":
				{
					const { tagNumber } = token;
					const currentDeclarations = getCurrentDeclarations();
					const declaration = currentDeclarations[tagNumber];
					if (!declaration) {
						literalTagNumbers.add(tagNumber);
						const literalText = `<${tagNumber}>`;
						(stack.length > 0 ? stack[stack.length - 1].children : result).push(literalText);
						break;
					}
					stack.push({
						tagNumber,
						children: [],
						position: token.position,
						declaration,
						declarations: currentDeclarations
					});
				}
				break;
			case "TagClose": {
				const { tagNumber } = token;
				if (literalTagNumbers.has(tagNumber)) {
					const literalText = `</${tagNumber}>`;
					(stack.length > 0 ? stack[stack.length - 1].children : result).push(literalText);
					literalTagNumbers.delete(tagNumber);
					break;
				}
				if (stack.length === 0) throw new TranslationParserError(`Unexpected closing tag </${tagNumber}> at position ${token.position}`, token.position, translation);
				const frame = stack.pop();
				if (frame.tagNumber !== tagNumber) throw new TranslationParserError(`Mismatched tags: expected </${frame.tagNumber}> but got </${tagNumber}> at position ${token.position}`, token.position, translation);
				const element = renderDeclarationNode(frame.declaration, frame.children, frame.declarations);
				(stack.length > 0 ? stack[stack.length - 1].children : result).push(element);
			}
		}
	});
	if (stack.length > 0) {
		const unclosed = stack[stack.length - 1];
		throw new TranslationParserError(`Unclosed tag <${unclosed.tagNumber}> at position ${unclosed.position}`, unclosed.position, translation);
	}
	return result;
};
//#endregion
//#region node_modules/react-i18next/dist/es/IcuTransWithoutContext.js
function IcuTransWithoutContext({ i18nKey, defaultTranslation, content, ns, values = {}, i18n: i18nFromProps, t: tFromProps }) {
	const i18n = i18nFromProps || getI18n();
	if (!i18n) {
		warnOnce(i18n, "NO_I18NEXT_INSTANCE", `IcuTrans: You need to pass in an i18next instance using i18nextReactModule`, { i18nKey });
		return import_react.createElement(import_react.Fragment, {}, defaultTranslation);
	}
	const t = tFromProps || i18n.t?.bind(i18n) || ((k) => k);
	let namespaces = ns || t.ns || i18n.options?.defaultNS;
	namespaces = isString(namespaces) ? [namespaces] : namespaces || ["translation"];
	let mergedValues = values;
	if (i18n.options?.interpolation?.defaultVariables) mergedValues = values && Object.keys(values).length > 0 ? {
		...values,
		...i18n.options.interpolation.defaultVariables
	} : { ...i18n.options.interpolation.defaultVariables };
	const translation = t(i18nKey, {
		defaultValue: defaultTranslation,
		...mergedValues,
		ns: namespaces
	});
	try {
		const rendered = renderTranslation(translation, content);
		return import_react.createElement(import_react.Fragment, {}, ...rendered);
	} catch (error) {
		warn(i18n, "ICU_TRANS_RENDER_ERROR", `IcuTrans component error for key "${i18nKey}": ${error.message}`, {
			i18nKey,
			error
		});
		return import_react.createElement(import_react.Fragment, {}, translation);
	}
}
IcuTransWithoutContext.displayName = "IcuTransWithoutContext";
//#endregion
//#region node_modules/react-i18next/dist/es/IcuTrans.js
function IcuTrans({ i18nKey, defaultTranslation, content, ns, values = {}, i18n: i18nFromProps, t: tFromProps }) {
	const { i18n: i18nFromContext, defaultNS: defaultNSFromContext } = (0, import_react.useContext)(I18nContext) || {};
	const i18n = i18nFromProps || i18nFromContext || getI18n();
	const t = tFromProps || i18n?.t.bind(i18n);
	return IcuTransWithoutContext({
		i18nKey,
		defaultTranslation,
		content,
		ns: ns || t?.ns || defaultNSFromContext || i18n?.options?.defaultNS,
		values,
		i18n,
		t: tFromProps
	});
}
IcuTrans.displayName = "IcuTrans";
//#endregion
//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js
/**
* @license React
* use-sync-external-store-shim.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_use_sync_external_store_shim_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		function useSyncExternalStore$2(subscribe, getSnapshot) {
			didWarnOld18Alpha || void 0 === React.startTransition || (didWarnOld18Alpha = !0, console.error("You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."));
			var value = getSnapshot();
			if (!didWarnUncachedGetSnapshot) {
				var cachedValue = getSnapshot();
				objectIs(value, cachedValue) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), didWarnUncachedGetSnapshot = !0);
			}
			cachedValue = useState({ inst: {
				value,
				getSnapshot
			} });
			var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
			useLayoutEffect(function() {
				inst.value = value;
				inst.getSnapshot = getSnapshot;
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
			}, [
				subscribe,
				value,
				getSnapshot
			]);
			useEffect(function() {
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				return subscribe(function() {
					checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				});
			}, [subscribe]);
			useDebugValue(value);
			return value;
		}
		function checkIfSnapshotChanged(inst) {
			var latestGetSnapshot = inst.getSnapshot;
			inst = inst.value;
			try {
				var nextValue = latestGetSnapshot();
				return !objectIs(inst, nextValue);
			} catch (error) {
				return !0;
			}
		}
		function useSyncExternalStore$1(subscribe, getSnapshot) {
			return getSnapshot();
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react(), objectIs = "function" === typeof Object.is ? Object.is : is, useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue, didWarnOld18Alpha = !1, didWarnUncachedGetSnapshot = !1, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
		exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
//#endregion
//#region node_modules/react-i18next/dist/es/useTranslation.js
var import_shim = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_use_sync_external_store_shim_development();
})))();
var notReadyT = (k, optsOrDefaultValue) => {
	if (isString(optsOrDefaultValue)) return optsOrDefaultValue;
	if (isObject(optsOrDefaultValue) && isString(optsOrDefaultValue.defaultValue)) return optsOrDefaultValue.defaultValue;
	if (typeof k === "function") return "";
	if (Array.isArray(k)) {
		const last = k[k.length - 1];
		return typeof last === "function" ? "" : last;
	}
	return k;
};
var notReadySnapshot = {
	t: notReadyT,
	ready: false
};
var dummySubscribe = () => () => {};
var useTranslation = (ns, props = {}) => {
	const { i18n: i18nFromProps } = props;
	const { i18n: i18nFromContext, defaultNS: defaultNSFromContext } = (0, import_react.useContext)(I18nContext) || {};
	const i18n = i18nFromProps || i18nFromContext || getI18n();
	if (i18n && !i18n.reportNamespaces) i18n.reportNamespaces = new ReportNamespaces();
	if (!i18n) warnOnce(i18n, "NO_I18NEXT_INSTANCE", "useTranslation: You will need to pass in an i18next instance by using initReactI18next or by passing it via props or context. In monorepo setups, make sure there is only one instance of react-i18next.");
	const i18nOptions = (0, import_react.useMemo)(() => ({
		...getDefaults(),
		...i18n?.options?.react,
		...props
	}), [i18n, props]);
	const { useSuspense, keyPrefix } = i18nOptions;
	const nsOrContext = ns || defaultNSFromContext || i18n?.options?.defaultNS;
	const unstableNamespaces = isString(nsOrContext) ? [nsOrContext] : nsOrContext || ["translation"];
	const namespaces = (0, import_react.useMemo)(() => unstableNamespaces, unstableNamespaces);
	i18n?.reportNamespaces?.addUsedNamespaces?.(namespaces);
	const revisionRef = (0, import_react.useRef)(0);
	const subscribe = (0, import_react.useCallback)((callback) => {
		if (!i18n) return dummySubscribe;
		const { bindI18n, bindI18nStore } = i18nOptions;
		const wrappedCallback = () => {
			revisionRef.current += 1;
			callback();
		};
		if (bindI18n) i18n.on(bindI18n, wrappedCallback);
		if (bindI18nStore) i18n.store.on(bindI18nStore, wrappedCallback);
		return () => {
			if (bindI18n) bindI18n.split(" ").forEach((e) => i18n.off(e, wrappedCallback));
			if (bindI18nStore) bindI18nStore.split(" ").forEach((e) => i18n.store.off(e, wrappedCallback));
		};
	}, [i18n, i18nOptions]);
	const snapshotRef = (0, import_react.useRef)();
	const getSnapshot = (0, import_react.useCallback)(() => {
		if (!i18n) return notReadySnapshot;
		const calculatedReady = !!(i18n.isInitialized || i18n.initializedStoreOnce) && namespaces.every((n) => hasLoadedNamespace(n, i18n, i18nOptions));
		const currentLng = props.lng || i18n.language;
		const currentRevision = revisionRef.current;
		const lastSnapshot = snapshotRef.current;
		if (lastSnapshot && lastSnapshot.ready === calculatedReady && lastSnapshot.lng === currentLng && lastSnapshot.keyPrefix === keyPrefix && lastSnapshot.revision === currentRevision) return lastSnapshot;
		const newSnapshot = {
			t: i18n.getFixedT(currentLng, i18nOptions.nsMode === "fallback" ? namespaces : namespaces[0], keyPrefix, { scopeNs: namespaces }),
			ready: calculatedReady,
			lng: currentLng,
			keyPrefix,
			revision: currentRevision
		};
		snapshotRef.current = newSnapshot;
		return newSnapshot;
	}, [
		i18n,
		namespaces,
		keyPrefix,
		i18nOptions,
		props.lng
	]);
	const [loadCount, setLoadCount] = (0, import_react.useState)(0);
	const { t, ready } = (0, import_shim.useSyncExternalStore)(subscribe, getSnapshot, getSnapshot);
	(0, import_react.useEffect)(() => {
		if (i18n && !ready && !useSuspense) {
			const onLoaded = () => setLoadCount((c) => c + 1);
			if (props.lng) loadLanguages(i18n, props.lng, namespaces, onLoaded);
			else loadNamespaces(i18n, namespaces, onLoaded);
		}
	}, [
		i18n,
		props.lng,
		namespaces,
		ready,
		useSuspense,
		loadCount
	]);
	const finalI18n = i18n || {};
	const wrapperRef = (0, import_react.useRef)(null);
	const wrapperLangRef = (0, import_react.useRef)();
	const createI18nWrapper = (original) => {
		const descriptors = Object.getOwnPropertyDescriptors(original);
		if (descriptors.__original) delete descriptors.__original;
		const wrapper = Object.create(Object.getPrototypeOf(original), descriptors);
		if (!Object.prototype.hasOwnProperty.call(wrapper, "__original")) try {
			Object.defineProperty(wrapper, "__original", {
				value: original,
				writable: false,
				enumerable: false,
				configurable: false
			});
		} catch (_) {}
		return wrapper;
	};
	const ret = (0, import_react.useMemo)(() => {
		const original = finalI18n;
		const lang = original?.language;
		let i18nWrapper = original;
		if (original) if (wrapperRef.current && wrapperRef.current.__original === original) if (wrapperLangRef.current !== lang) {
			i18nWrapper = createI18nWrapper(original);
			wrapperRef.current = i18nWrapper;
			wrapperLangRef.current = lang;
		} else i18nWrapper = wrapperRef.current;
		else {
			i18nWrapper = createI18nWrapper(original);
			wrapperRef.current = i18nWrapper;
			wrapperLangRef.current = lang;
		}
		const effectiveT = !ready && !useSuspense ? (...args) => {
			warnOnce(i18n, "USE_T_BEFORE_READY", "useTranslation: t was called before ready. When using useSuspense: false, make sure to check the ready flag before using t.");
			return t(...args);
		} : t;
		const arr = [
			effectiveT,
			i18nWrapper,
			ready
		];
		arr.t = effectiveT;
		arr.i18n = i18nWrapper;
		arr.ready = ready;
		return arr;
	}, [
		t,
		finalI18n,
		ready,
		finalI18n.resolvedLanguage,
		finalI18n.language,
		finalI18n.languages
	]);
	if (i18n && useSuspense && !ready) {
		let inDevelopment = false;
		try {
			inDevelopment = true;
		} catch (e) {}
		if (inDevelopment) warnOnce(i18n, "SUSPENDED_WHILE_LOADING", "useTranslation: suspended while translations are loading (useSuspense is true by default). Add a <Suspense> boundary above this component, or set react.useSuspense: false in the i18next init options. https://react.i18next.com/latest/usetranslation-hook");
		throw new Promise((resolve) => {
			const onLoaded = () => resolve();
			if (props.lng) loadLanguages(i18n, props.lng, namespaces, onLoaded);
			else loadNamespaces(i18n, namespaces, onLoaded);
		});
	}
	return ret;
};
//#endregion
//#region node_modules/react-i18next/dist/es/withTranslation.js
var withTranslation = (ns, options = {}) => function Extend(WrappedComponent) {
	function I18nextWithTranslation({ forwardedRef, ...rest }) {
		const [t, i18n, ready] = useTranslation(ns, {
			...rest,
			keyPrefix: options.keyPrefix
		});
		const passDownProps = {
			...rest,
			t,
			i18n,
			tReady: ready
		};
		if (options.withRef && forwardedRef) passDownProps.ref = forwardedRef;
		else if (!options.withRef && forwardedRef) passDownProps.forwardedRef = forwardedRef;
		return (0, import_react.createElement)(WrappedComponent, passDownProps);
	}
	I18nextWithTranslation.displayName = `withI18nextTranslation(${getDisplayName(WrappedComponent)})`;
	I18nextWithTranslation.WrappedComponent = WrappedComponent;
	const forwardRef = (props, ref) => (0, import_react.createElement)(I18nextWithTranslation, Object.assign({}, props, { forwardedRef: ref }));
	return options.withRef ? (0, import_react.forwardRef)(forwardRef) : I18nextWithTranslation;
};
//#endregion
//#region node_modules/react-i18next/dist/es/Translation.js
var Translation = ({ ns, children, ...options }) => {
	const [t, i18n, ready] = useTranslation(ns, options);
	return children(t, {
		i18n,
		lng: i18n?.language
	}, ready);
};
//#endregion
//#region node_modules/react-i18next/dist/es/I18nextProvider.js
function I18nextProvider({ i18n, defaultNS, children }) {
	const value = (0, import_react.useMemo)(() => ({
		i18n,
		defaultNS
	}), [i18n, defaultNS]);
	return (0, import_react.createElement)(I18nContext.Provider, { value }, children);
}
//#endregion
//#region node_modules/react-i18next/dist/es/useSSR.js
var useSSR = (initialI18nStore, initialLanguage, props = {}) => {
	const { i18n: i18nFromProps } = props;
	const { i18n: i18nFromContext } = (0, import_react.useContext)(I18nContext) || {};
	const i18n = i18nFromProps || i18nFromContext || getI18n();
	if (!i18n) {
		warnOnce(i18n, "NO_I18NEXT_INSTANCE", "useSSR: You will need to pass in an i18next instance by using initReactI18next or by passing it via props or context. In monorepo setups, make sure there is only one instance of react-i18next.");
		return;
	}
	if (i18n.options?.isClone) return;
	if (initialI18nStore && !i18n.initializedStoreOnce) {
		if (!i18n.services?.resourceStore) {
			warnOnce(i18n, "I18N_NOT_INITIALIZED", "useSSR: i18n instance was found but not initialized (services.resourceStore is missing). Make sure you call i18next.init() before using useSSR — e.g. at module level, not only in getStaticProps/getServerSideProps.");
			return;
		}
		i18n.services.resourceStore.data = initialI18nStore;
		i18n.options.ns = Object.values(initialI18nStore).reduce((mem, lngResources) => {
			Object.keys(lngResources).forEach((ns) => {
				if (mem.indexOf(ns) < 0) mem.push(ns);
			});
			return mem;
		}, i18n.options.ns);
		i18n.initializedStoreOnce = true;
		i18n.isInitialized = true;
	}
	if (initialLanguage && !i18n.initializedLanguageOnce) {
		i18n.changeLanguage(initialLanguage);
		i18n.initializedLanguageOnce = true;
	}
};
//#endregion
//#region node_modules/react-i18next/dist/es/withSSR.js
var withSSR = () => function Extend(WrappedComponent) {
	function I18nextWithSSR({ initialI18nStore, initialLanguage, ...rest }) {
		useSSR(initialI18nStore, initialLanguage);
		return (0, import_react.createElement)(WrappedComponent, { ...rest });
	}
	I18nextWithSSR.getInitialProps = composeInitialProps(WrappedComponent);
	I18nextWithSSR.displayName = `withI18nextSSR(${getDisplayName(WrappedComponent)})`;
	I18nextWithSSR.WrappedComponent = WrappedComponent;
	return I18nextWithSSR;
};
//#endregion
//#region node_modules/react-i18next/dist/es/index.js
var date = () => "";
var time = () => "";
var number = () => "";
var select = () => "";
var plural = () => "";
var selectOrdinal = () => "";
//#endregion
export { I18nContext, I18nextProvider, IcuTrans, IcuTransWithoutContext, Trans, Trans$1 as TransWithoutContext, Translation, composeInitialProps, date, getDefaults, getI18n, getInitialProps, initReactI18next, nodesToString, number, plural, select, selectOrdinal, setDefaults, setI18n, time, useSSR, useTranslation, withSSR, withTranslation };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtaTE4bmV4dC5qcyIsIm5hbWVzIjpbImlzVmFsaWRFbGVtZW50IiwiSFRNTCIsImNsb25lRWxlbWVudCIsIkNoaWxkcmVuIiwiRnJhZ21lbnQiLCJjcmVhdGVFbGVtZW50IiwiVHJhbnMiLCJrZXlGcm9tU2VsZWN0b3IiLCJjcmVhdGVDb250ZXh0IiwidXNlQ29udGV4dCIsIlRyYW5zV2l0aG91dENvbnRleHQiLCJ1c2VDb250ZXh0IiwidXNlQ29udGV4dCIsInVzZU1lbW8iLCJ1c2VSZWYiLCJ1c2VDYWxsYmFjayIsInVzZVN0YXRlIiwidXNlU3luY0V4dGVybmFsU3RvcmUiLCJjcmVhdGVFbGVtZW50IiwiZm9yd2FyZFJlZlJlYWN0IiwidXNlTWVtbyIsImNyZWF0ZUVsZW1lbnQiLCJ1c2VDb250ZXh0IiwiY3JlYXRlRWxlbWVudCJdLCJzb3VyY2VzIjpbIi4uLy4uL2h0bWwtcGFyc2Utc3RyaW5naWZ5L2Rpc3QvZXNtL2h0bWwtcGFyc2Utc3RyaW5naWZ5LmpzIiwiLi4vLi4vcmVhY3QtaTE4bmV4dC9kaXN0L2VzL3V0aWxzLmpzIiwiLi4vLi4vcmVhY3QtaTE4bmV4dC9kaXN0L2VzL3VuZXNjYXBlLmpzIiwiLi4vLi4vcmVhY3QtaTE4bmV4dC9kaXN0L2VzL2RlZmF1bHRzLmpzIiwiLi4vLi4vcmVhY3QtaTE4bmV4dC9kaXN0L2VzL2kxOG5JbnN0YW5jZS5qcyIsIi4uLy4uL3JlYWN0LWkxOG5leHQvZGlzdC9lcy9UcmFuc1dpdGhvdXRDb250ZXh0LmpzIiwiLi4vLi4vcmVhY3QtaTE4bmV4dC9kaXN0L2VzL2luaXRSZWFjdEkxOG5leHQuanMiLCIuLi8uLi9yZWFjdC1pMThuZXh0L2Rpc3QvZXMvY29udGV4dC5qcyIsIi4uLy4uL3JlYWN0LWkxOG5leHQvZGlzdC9lcy9UcmFucy5qcyIsIi4uLy4uL3JlYWN0LWkxOG5leHQvZGlzdC9lcy9JY3VUcmFuc1V0aWxzL1RyYW5zbGF0aW9uUGFyc2VyRXJyb3IuanMiLCIuLi8uLi9yZWFjdC1pMThuZXh0L2Rpc3QvZXMvSWN1VHJhbnNVdGlscy9odG1sRW50aXR5RGVjb2Rlci5qcyIsIi4uLy4uL3JlYWN0LWkxOG5leHQvZGlzdC9lcy9JY3VUcmFuc1V0aWxzL3Rva2VuaXplci5qcyIsIi4uLy4uL3JlYWN0LWkxOG5leHQvZGlzdC9lcy9JY3VUcmFuc1V0aWxzL3JlbmRlclRyYW5zbGF0aW9uLmpzIiwiLi4vLi4vcmVhY3QtaTE4bmV4dC9kaXN0L2VzL0ljdVRyYW5zV2l0aG91dENvbnRleHQuanMiLCIuLi8uLi9yZWFjdC1pMThuZXh0L2Rpc3QvZXMvSWN1VHJhbnMuanMiLCIuLi8uLi91c2Utc3luYy1leHRlcm5hbC1zdG9yZS9janMvdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtc2hpbS5kZXZlbG9wbWVudC5qcyIsIi4uLy4uL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlL3NoaW0vaW5kZXguanMiLCIuLi8uLi9yZWFjdC1pMThuZXh0L2Rpc3QvZXMvdXNlVHJhbnNsYXRpb24uanMiLCIuLi8uLi9yZWFjdC1pMThuZXh0L2Rpc3QvZXMvd2l0aFRyYW5zbGF0aW9uLmpzIiwiLi4vLi4vcmVhY3QtaTE4bmV4dC9kaXN0L2VzL1RyYW5zbGF0aW9uLmpzIiwiLi4vLi4vcmVhY3QtaTE4bmV4dC9kaXN0L2VzL0kxOG5leHRQcm92aWRlci5qcyIsIi4uLy4uL3JlYWN0LWkxOG5leHQvZGlzdC9lcy91c2VTU1IuanMiLCIuLi8uLi9yZWFjdC1pMThuZXh0L2Rpc3QvZXMvd2l0aFNTUi5qcyIsIi4uLy4uL3JlYWN0LWkxOG5leHQvZGlzdC9lcy9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpbmxpbmVkIGZyb20gdGhlIGZvcm1lciBgdm9pZC1lbGVtZW50c2AgZGVwZW5kZW5jeSwgc28gdGhlIHBhY2thZ2UgaGFzXG4vLyB6ZXJvIHJ1bnRpbWUgZGVwZW5kZW5jaWVzLiBgIWRvY3R5cGVgL2AhRE9DVFlQRWAgYXJlIHRyZWF0ZWQgYXMgdm9pZCBzbyBhXG4vLyBkb2N0eXBlIHBhcnNlcyBhcyBhIGNoaWxkbGVzcyBub2RlIGluc3RlYWQgb2Ygc3dhbGxvd2luZyB0aGUgZG9jdW1lbnQuXG5jb25zdCB2b2lkRWxlbWVudHMgPSB7XG4gIGFyZWE6IHRydWUsXG4gIGJhc2U6IHRydWUsXG4gIGJyOiB0cnVlLFxuICBjb2w6IHRydWUsXG4gIGVtYmVkOiB0cnVlLFxuICBocjogdHJ1ZSxcbiAgaW1nOiB0cnVlLFxuICBpbnB1dDogdHJ1ZSxcbiAgbGluazogdHJ1ZSxcbiAgbWV0YTogdHJ1ZSxcbiAgcGFyYW06IHRydWUsXG4gIHNvdXJjZTogdHJ1ZSxcbiAgdHJhY2s6IHRydWUsXG4gIHdicjogdHJ1ZSxcbiAgJyFkb2N0eXBlJzogdHJ1ZSxcbiAgJyFET0NUWVBFJzogdHJ1ZSxcbn07XG5cbmNvbnN0IGF0dHJSRSA9IC9cXHMoW14nXCIvXFxzPjxdKz8pW1xccy8+XXwoW15cXHM9XSspPVxccz8oXCJbXlwiXSpcInwnW14nXSonKS9nO1xuXG5mdW5jdGlvbiBwYXJzZVRhZyh0YWcpIHtcbiAgY29uc3QgcmVzID0ge1xuICAgIHR5cGU6ICd0YWcnLFxuICAgIG5hbWU6ICcnLFxuICAgIHZvaWRFbGVtZW50OiBmYWxzZSxcbiAgICBhdHRyczoge30sXG4gICAgY2hpbGRyZW46IFtdLFxuICB9O1xuXG4gIGNvbnN0IHRhZ01hdGNoID0gdGFnLm1hdGNoKC88XFwvPyhbXlxcc10rPylbL1xccz5dLyk7XG4gIGlmICh0YWdNYXRjaCkge1xuICAgIHJlcy5uYW1lID0gdGFnTWF0Y2hbMV07XG4gICAgLy8gdm9pZC1lbGVtZW50IGxvb2t1cCBzdGF5cyBjYXNlIHNlbnNpdGl2ZSBvbiBwdXJwb3NlOiByZWFjdC1pMThuZXh0XG4gICAgLy8gcmVsaWVzIG9uIGA8QnI+YCBOT1QgYmVpbmcgdHJlYXRlZCBhcyBhIHZvaWQgYDxicj5gIChzZWUgMWRmMGY5ZClcbiAgICBpZiAodm9pZEVsZW1lbnRzW3RhZ01hdGNoWzFdXSB8fCB0YWcuY2hhckF0KHRhZy5sZW5ndGggLSAyKSA9PT0gJy8nKSB7XG4gICAgICByZXMudm9pZEVsZW1lbnQgPSB0cnVlO1xuICAgIH1cblxuICAgIC8vIGhhbmRsZSBjb21tZW50IHRhZ1xuICAgIGlmIChyZXMubmFtZS5zdGFydHNXaXRoKCchLS0nKSkge1xuICAgICAgY29uc3QgZW5kSW5kZXggPSB0YWcuaW5kZXhPZignLS0+Jyk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiAnY29tbWVudCcsXG4gICAgICAgIGNvbW1lbnQ6IGVuZEluZGV4ICE9PSAtMSA/IHRhZy5zbGljZSg0LCBlbmRJbmRleCkgOiAnJyxcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdCByZWcgPSBuZXcgUmVnRXhwKGF0dHJSRSk7XG4gIGxldCByZXN1bHQgPSBudWxsO1xuICBmb3IgKDs7KSB7XG4gICAgcmVzdWx0ID0gcmVnLmV4ZWModGFnKTtcblxuICAgIGlmIChyZXN1bHQgPT09IG51bGwpIHtcbiAgICAgIGJyZWFrXG4gICAgfVxuXG4gICAgaWYgKCFyZXN1bHRbMF0udHJpbSgpKSB7XG4gICAgICBjb250aW51ZVxuICAgIH1cblxuICAgIGlmIChyZXN1bHRbMV0pIHtcbiAgICAgIGNvbnN0IGF0dHIgPSByZXN1bHRbMV0udHJpbSgpO1xuICAgICAgLy8gYm9vbGVhbiBhdHRyaWJ1dGVzIGNhcnJ5IGBudWxsYCBzbyBzdHJpbmdpZnkgY2FuIHJlbmRlciB0aGVtIGJhcmVcbiAgICAgIC8vIChgPGlucHV0IGRpc2FibGVkLz5gIGluc3RlYWQgb2YgYDxpbnB1dCBkaXNhYmxlZD1cIlwiLz5gKVxuICAgICAgbGV0IGFyciA9IFthdHRyLCBudWxsXTtcblxuICAgICAgY29uc3QgZXEgPSBhdHRyLmluZGV4T2YoJz0nKTtcbiAgICAgIGlmIChlcSA+IC0xKSB7XG4gICAgICAgIC8vIHNwbGl0IGF0IHRoZSBmaXJzdCBgPWAgb25seSwgc28gYGRhdGEteD1hPWJgIGtlZXBzIGl0cyBmdWxsIHZhbHVlXG4gICAgICAgIGFyciA9IFthdHRyLnNsaWNlKDAsIGVxKSwgYXR0ci5zbGljZShlcSArIDEpXTtcbiAgICAgIH1cblxuICAgICAgcmVzLmF0dHJzW2FyclswXV0gPSBhcnJbMV07XG4gICAgICByZWcubGFzdEluZGV4LS07XG4gICAgfSBlbHNlIGlmIChyZXN1bHRbMl0pIHtcbiAgICAgIHJlcy5hdHRyc1tyZXN1bHRbMl1dID0gcmVzdWx0WzNdLnRyaW0oKS5zdWJzdHJpbmcoMSwgcmVzdWx0WzNdLmxlbmd0aCAtIDEpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiByZXNcbn1cblxuLy8gY29tbWVudHMgYXJlIG1hdGNoZWQgYXMgYSB3aG9sZSAoc28gYD5gIGluc2lkZSB0aGVtIGlzIGZpbmUpLCBldmVyeXRoaW5nXG4vLyBlbHNlIHRhZy1zaGFwZWQgaXMgbWF0Y2hlZCBieSB0aGUgc2Vjb25kIGFsdGVybmF0aXZlXG5jb25zdCB0YWdSRSA9IC88IS0tW1xcc1xcU10qPy0tPnw8W2EtekEtWjAtOVxcLSEvXSg/OlwiW15cIl0qXCJ8J1teJ10qJ3xbXidcIj5dKSo+L2c7XG5jb25zdCB0YWdOYW1lUkUgPSAvPFxcLz8oW15cXHNdKz8pWy9cXHM+XS87XG5jb25zdCB3aGl0ZXNwYWNlUkUgPSAvXlxccyokLztcbi8vIHRhZ3Mgd2hvc2UgY29udGVudCBpcyByYXcgdGV4dDogbm90aGluZyBpbnNpZGUgdGhlbSBpcyBtYXJrdXBcbmNvbnN0IHJhd1RleHRSRSA9IC9eKHNjcmlwdHxzdHlsZSkkL2k7XG5cbi8vIHBsYWNlaG9sZGVyIGZvciBgPGAgb2YgdGFncyByZWplY3RlZCBieSBvcHRpb25zLmFsbG93ZWRUYWdzOyByZXN0b3JlZCB0byBhXG4vLyBsaXRlcmFsIGA8YCBpbiB0ZXh0L2F0dHIvY29tbWVudCBjb250ZW50IGFmdGVyIHBhcnNpbmcgKFUrMDAwMCBjYW5ub3QgYXBwZWFyXG4vLyBpbiBzYW5lIGlucHV0LCBhbmQgYSBjb2xsaXNpb24gd291bGQgbWVyZWx5IHJlbmRlciBhcyBhbiBleHRyYSBgPGApXG5jb25zdCBzZW50aW5lbCA9ICdcXHUwMDAwJztcblxuLy8gcmUtdXNlZCBvYmogZm9yIHF1aWNrIGxvb2t1cHMgb2YgY29tcG9uZW50c1xuY29uc3QgZW1wdHkgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXG5mdW5jdGlvbiByZXN0b3JlU2VudGluZWxzKG5vZGVzKSB7XG4gIG5vZGVzLmZvckVhY2goZnVuY3Rpb24gKG5vZGUpIHtcbiAgICBpZiAobm9kZS50eXBlID09PSAndGV4dCcpIHtcbiAgICAgIG5vZGUuY29udGVudCA9IG5vZGUuY29udGVudC5zcGxpdChzZW50aW5lbCkuam9pbignPCcpO1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIGlmIChub2RlLnR5cGUgPT09ICdjb21tZW50Jykge1xuICAgICAgbm9kZS5jb21tZW50ID0gbm9kZS5jb21tZW50LnNwbGl0KHNlbnRpbmVsKS5qb2luKCc8Jyk7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgaW4gbm9kZS5hdHRycykge1xuICAgICAgY29uc3QgdmFsdWUgPSBub2RlLmF0dHJzW2tleV07XG4gICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiB2YWx1ZS5pbmRleE9mKHNlbnRpbmVsKSA+IC0xKSB7XG4gICAgICAgIG5vZGUuYXR0cnNba2V5XSA9IHZhbHVlLnNwbGl0KHNlbnRpbmVsKS5qb2luKCc8Jyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChub2RlLmNoaWxkcmVuLmxlbmd0aCkge1xuICAgICAgcmVzdG9yZVNlbnRpbmVscyhub2RlLmNoaWxkcmVuKTtcbiAgICB9XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBwYXJzZShodG1sLCBvcHRpb25zKSB7XG4gIGNvbnN0IGNvbXBvbmVudHMgPSAob3B0aW9ucyAmJiBvcHRpb25zLmNvbXBvbmVudHMpIHx8IGVtcHR5O1xuICBjb25zdCBhbGxvd2VkVGFncyA9IG9wdGlvbnMgJiYgb3B0aW9ucy5hbGxvd2VkVGFncztcbiAgbGV0IHJlc3RvcmVOZWVkZWQgPSBmYWxzZTtcbiAgaWYgKGFsbG93ZWRUYWdzKSB7XG4gICAgY29uc3QgaXNBbGxvd2VkID1cbiAgICAgIHR5cGVvZiBhbGxvd2VkVGFncyA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgICA/IGFsbG93ZWRUYWdzXG4gICAgICAgIDogZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgICAgICAgIHJldHVybiBhbGxvd2VkVGFncy5pbmRleE9mKG5hbWUpID4gLTFcbiAgICAgICAgICB9O1xuICAgIC8vIG5ldXRyYWxpemUgdGFncyB3aG9zZSBuYW1lIGlzIG5vdCBhbGxvd2VkLCBzbyB0aGV5IHBhcnNlIGFzIHRleHQuXG4gICAgLy8gb24gYSBkaXNhbGxvd2VkIG1hdGNoIG9ubHkgdGhlIGxlYWRpbmcgYDxgIGlzIGVzY2FwZWQgYW5kIHNjYW5uaW5nXG4gICAgLy8gcmVzdW1lcyByaWdodCBhZnRlciBpdCwgc28gYSB2YWxpZCB0YWcgZ2x1ZWQgaW50byB0aGUgc2FtZSBtYXRjaFxuICAgIC8vIChlLmcuIGA8Ym9sZD5gIGluc2lkZSBgPDEwLCA8MjAsIGFuZCA8Ym9sZD5gKSBzdGlsbCBnZXRzIHJlY29nbml6ZWRcbiAgICBsZXQgb3V0ID0gJyc7XG4gICAgbGV0IHBvcyA9IDA7XG4gICAgdGFnUkUubGFzdEluZGV4ID0gMDtcbiAgICBsZXQgYW07XG4gICAgd2hpbGUgKChhbSA9IHRhZ1JFLmV4ZWMoaHRtbCkpKSB7XG4gICAgICBjb25zdCB0YWcgPSBhbVswXTtcbiAgICAgIG91dCArPSBodG1sLnNsaWNlKHBvcywgYW0uaW5kZXgpO1xuICAgICAgY29uc3QgbmFtZU1hdGNoID0gdGFnLm1hdGNoKHRhZ05hbWVSRSk7XG4gICAgICBpZiAodGFnLnN0YXJ0c1dpdGgoJzwhLS0nKSB8fCAobmFtZU1hdGNoICYmIGlzQWxsb3dlZChuYW1lTWF0Y2hbMV0pKSkge1xuICAgICAgICBvdXQgKz0gdGFnO1xuICAgICAgICBwb3MgPSBhbS5pbmRleCArIHRhZy5sZW5ndGg7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXN0b3JlTmVlZGVkID0gdHJ1ZTtcbiAgICAgICAgb3V0ICs9IHNlbnRpbmVsO1xuICAgICAgICBwb3MgPSBhbS5pbmRleCArIDE7XG4gICAgICAgIHRhZ1JFLmxhc3RJbmRleCA9IHBvcztcbiAgICAgIH1cbiAgICB9XG4gICAgaHRtbCA9IG91dCArIGh0bWwuc2xpY2UocG9zKTtcbiAgfVxuICBjb25zdCByZXN1bHQgPSBbXTtcbiAgY29uc3QgYXJyID0gW107XG4gIGxldCBjdXJyZW50O1xuICBsZXQgbGV2ZWwgPSAtMTtcbiAgbGV0IGluQ29tcG9uZW50ID0gZmFsc2U7XG4gIC8vIHdoaWxlIHBhcnNpbmcgcmF3LXRleHQgY29udGVudCAoc2NyaXB0L3N0eWxlKSwgdGFnLWxvb2tpbmcgbWF0Y2hlc1xuICAvLyBiZWZvcmUgdGhpcyBpbmRleCBiZWxvbmcgdG8gdGhlIGNvbnRlbnQgYW5kIG11c3QgYmUgc2tpcHBlZFxuICBsZXQgcmF3VW50aWwgPSAwO1xuICAvLyBsYXppbHkgY3JlYXRlZCBsb3dlcmNhc2UgY29weSBmb3IgY2FzZS1pbnNlbnNpdGl2ZSByYXctdGV4dCBjbG9zZS10YWcgc2VhcmNoXG4gIGxldCBodG1sTG93ZXI7XG5cbiAgLy8gaGFuZGxlIHRleHQgYXQgdG9wIGxldmVsXG4gIGlmIChodG1sLmluZGV4T2YoJzwnKSAhPT0gMCkge1xuICAgIGNvbnN0IGVuZCA9IGh0bWwuaW5kZXhPZignPCcpO1xuICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgIGNvbnRlbnQ6IGVuZCA9PT0gLTEgPyBodG1sIDogaHRtbC5zdWJzdHJpbmcoMCwgZW5kKSxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIGNvbGxlY3QgbWF0Y2hlcyB3aXRoIGFuIGV4ZWMgbG9vcCBpbnN0ZWFkIG9mIG1hdGNoQWxsIHRvIGtlZXAgRVM1IEFQSSBjb21wYXRcbiAgY29uc3QgbWF0Y2hlcyA9IFtdO1xuICBsZXQgbTtcbiAgd2hpbGUgKChtID0gdGFnUkUuZXhlYyhodG1sKSkpIHtcbiAgICBtYXRjaGVzLnB1c2gobSk7XG4gIH1cbiAgbWF0Y2hlcy5mb3JFYWNoKGZ1bmN0aW9uIChtYXRjaCwgaSkge1xuICAgIGNvbnN0IHRhZyA9IG1hdGNoWzBdO1xuICAgIGlmICghdGFnKSByZXR1cm5cbiAgICAvLyBjb21tZW50cyBtYXRjaCBhcyBhIHdob2xlOyB0aGVpciBjb250ZW50IG11c3Qgbm90IHRyaWdnZXIgdGhlXG4gICAgLy8gbWlzbWF0Y2hlZC1icmFja2V0IHNwbGl0IGJlbG93XG4gICAgaWYgKHRhZy5zdGFydHNXaXRoKCc8IS0tJykpIHJldHVyblxuICAgIC8vIGNvdW50IGJyYWNrZXRzIG91dHNpZGUgcXVvdGVkIGF0dHJpYnV0ZSB2YWx1ZXMsIHNvIGA8YCBpbnNpZGUgYW5cbiAgICAvLyBhdHRyaWJ1dGUgKGUuZy4gdGl0bGU9XCIxIDwgMlwiKSBjYW4ndCB0cmlnZ2VyIGEgYm9ndXMgc3BsaXRcbiAgICBsZXQgbHRzID0gMDtcbiAgICBsZXQgZ3RzID0gMDtcbiAgICBsZXQgc2Vjb25kTHQgPSAtMTtcbiAgICBsZXQgcXVvdGUgPSBudWxsO1xuICAgIGZvciAobGV0IGogPSAwOyBqIDwgdGFnLmxlbmd0aDsgaisrKSB7XG4gICAgICBjb25zdCBjID0gdGFnLmNoYXJBdChqKTtcbiAgICAgIGlmIChxdW90ZSkge1xuICAgICAgICBpZiAoYyA9PT0gcXVvdGUpIHF1b3RlID0gbnVsbDtcbiAgICAgIH0gZWxzZSBpZiAoYyA9PT0gJ1wiJyB8fCBjID09PSBcIidcIikge1xuICAgICAgICBxdW90ZSA9IGM7XG4gICAgICB9IGVsc2UgaWYgKGMgPT09ICc8Jykge1xuICAgICAgICBsdHMrKztcbiAgICAgICAgaWYgKGx0cyA9PT0gMikgc2Vjb25kTHQgPSBqO1xuICAgICAgfSBlbHNlIGlmIChjID09PSAnPicpIHtcbiAgICAgICAgZ3RzKys7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIG9ubHkgc3BsaXQgd2hlbiB0aGUgcmVtYWluZGVyIGlzIGl0c2VsZiBhIHZhbGlkIHRhZyBzdGFydDsgb3RoZXJ3aXNlXG4gICAgLy8gYSBmcmFnbWVudCBsaWtlIGA8IDwhLS0+YCBkZXN5bmNzIHRoZSBzdHJpbmctbGV2ZWwgaXNDb21tZW50IGNoZWNrXG4gICAgLy8gZnJvbSBwYXJzZVRhZydzIG5hbWUtYmFzZWQgY29tbWVudCBkZXRlY3Rpb24gYW5kIGNyYXNoZXMgdGhlIHdhbGtlclxuICAgIGNvbnN0IHZhbGlkU3BsaXQgPVxuICAgICAgc2Vjb25kTHQgPiAtMSAmJiAvW2EtekEtWjAtOVxcLSEvXS8udGVzdCh0YWcuY2hhckF0KHNlY29uZEx0ICsgMSkpO1xuICAgIGlmIChsdHMgPiBndHMgJiYgdmFsaWRTcGxpdCkge1xuICAgICAgY29uc3QgZmlyc3RQYXJ0ID0gdGFnLnN1YnN0cmluZygwLCBzZWNvbmRMdCk7XG4gICAgICBjb25zdCBzZWNvbmRQYXJ0ID0gdGFnLnN1YnN0cmluZyhmaXJzdFBhcnQubGVuZ3RoKTtcbiAgICAgIG1hdGNoZXNbaV1bMF0gPSBzZWNvbmRQYXJ0O1xuICAgICAgbWF0Y2hlc1tpXS5pbmRleCArPSBmaXJzdFBhcnQubGVuZ3RoO1xuICAgIH1cbiAgfSk7XG4gIG1hdGNoZXMuZm9yRWFjaChmdW5jdGlvbiAobWF0Y2gsIGkpIHtcbiAgICBjb25zdCB0YWcgPSBtYXRjaFswXTtcbiAgICBpZiAoIXRhZykgcmV0dXJuXG4gICAgY29uc3QgaW5kZXggPSBtYXRjaC5pbmRleDtcbiAgICBpZiAoaW5kZXggPCByYXdVbnRpbCkgcmV0dXJuXG4gICAgaWYgKGluQ29tcG9uZW50KSB7XG4gICAgICBpZiAodGFnICE9PSAnPC8nICsgY3VycmVudC5uYW1lICsgJz4nKSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaW5Db21wb25lbnQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgaXNPcGVuID0gdGFnLmNoYXJBdCgxKSAhPT0gJy8nO1xuICAgIGNvbnN0IGlzQ29tbWVudCA9IHRhZy5zdGFydHNXaXRoKCc8IS0tJyk7XG4gICAgY29uc3Qgc3RhcnQgPSBpbmRleCArIHRhZy5sZW5ndGg7XG4gICAgY29uc3QgbmV4dENoYXIgPSBodG1sLmNoYXJBdChzdGFydCk7XG4gICAgY29uc3QgbmV4dE1hdGNoID0gbWF0Y2hlc1tpICsgMV07XG4gICAgbGV0IGlzVGV4dDtcbiAgICBpZiAobmV4dENoYXIgPT09ICc8JyAmJiBuZXh0TWF0Y2gpIHtcbiAgICAgIGNvbnN0IG5leHRUYWcgPSBodG1sLnN1YnN0cmluZyhzdGFydCwgbmV4dE1hdGNoLmluZGV4KTtcbiAgICAgIGlzVGV4dCA9IG5leHRUYWcuc3BsaXQoJzwnKS5sZW5ndGggPiBuZXh0VGFnLnNwbGl0KCc+JykubGVuZ3RoO1xuICAgIH1cblxuICAgIGxldCBwYXJlbnQ7XG5cbiAgICBpZiAoaXNDb21tZW50KSB7XG4gICAgICBjb25zdCBjb21tZW50ID0gcGFyc2VUYWcodGFnKTtcblxuICAgICAgLy8gaWYgd2UncmUgYXQgcm9vdCwgcHVzaCBuZXcgYmFzZSBub2RlXG4gICAgICBpZiAobGV2ZWwgPCAwKSB7XG4gICAgICAgIHJlc3VsdC5wdXNoKGNvbW1lbnQpO1xuICAgICAgICByZXR1cm4gcmVzdWx0XG4gICAgICB9XG4gICAgICBwYXJlbnQgPSBhcnJbbGV2ZWxdO1xuICAgICAgcGFyZW50LmNoaWxkcmVuLnB1c2goY29tbWVudCk7XG5cbiAgICAgIGNvbnN0IHRleHQgPSBodG1sLnNsaWNlKHN0YXJ0LCBuZXh0TWF0Y2ggPyBuZXh0TWF0Y2guaW5kZXggOiB1bmRlZmluZWQpO1xuICAgICAgaWYgKHRleHQubGVuZ3RoID4gMCkge1xuICAgICAgICBwYXJlbnQuY2hpbGRyZW4ucHVzaCh7XG4gICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgIGNvbnRlbnQ6IHRleHQsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdFxuICAgIH1cblxuICAgIGlmIChpc09wZW4pIHtcbiAgICAgIGxldmVsKys7XG5cbiAgICAgIGN1cnJlbnQgPSBwYXJzZVRhZyh0YWcpO1xuICAgICAgaWYgKGN1cnJlbnQudHlwZSA9PT0gJ3RhZycgJiYgY29tcG9uZW50c1tjdXJyZW50Lm5hbWVdKSB7XG4gICAgICAgIGN1cnJlbnQudHlwZSA9ICdjb21wb25lbnQnO1xuICAgICAgICBpbkNvbXBvbmVudCA9IHRydWU7XG4gICAgICB9XG5cbiAgICAgIGxldCBpc1Jhd1RleHQgPSBmYWxzZTtcbiAgICAgIGlmIChcbiAgICAgICAgIWluQ29tcG9uZW50ICYmXG4gICAgICAgICFjdXJyZW50LnZvaWRFbGVtZW50ICYmXG4gICAgICAgIHJhd1RleHRSRS50ZXN0KGN1cnJlbnQubmFtZSlcbiAgICAgICkge1xuICAgICAgICAvLyByYXctdGV4dCBlbGVtZW50OiBldmVyeXRoaW5nIHVwIHRvIHRoZSBtYXRjaGluZyBjbG9zZSB0YWcgaXMgb25lXG4gICAgICAgIC8vIHRleHQgY2hpbGQsIHJlZ2FyZGxlc3Mgb2Ygd2hhdCBpdCBsb29rcyBsaWtlXG4gICAgICAgIGlzUmF3VGV4dCA9IHRydWU7XG4gICAgICAgIGh0bWxMb3dlciB8fCAoaHRtbExvd2VyID0gaHRtbC50b0xvd2VyQ2FzZSgpKTtcbiAgICAgICAgY29uc3QgY2xvc2VJbmRleCA9IGh0bWxMb3dlci5pbmRleE9mKFxuICAgICAgICAgICc8LycgKyBjdXJyZW50Lm5hbWUudG9Mb3dlckNhc2UoKSArICc+JyxcbiAgICAgICAgICBzdGFydCxcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgY29udGVudEVuZCA9IGNsb3NlSW5kZXggPT09IC0xID8gaHRtbC5sZW5ndGggOiBjbG9zZUluZGV4O1xuICAgICAgICBjb25zdCBjb250ZW50ID0gaHRtbC5zbGljZShzdGFydCwgY29udGVudEVuZCk7XG4gICAgICAgIGlmIChjb250ZW50KSB7XG4gICAgICAgICAgY3VycmVudC5jaGlsZHJlbi5wdXNoKHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICAgIGNvbnRlbnQsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmF3VW50aWwgPSBjb250ZW50RW5kO1xuICAgICAgfVxuXG4gICAgICBpZiAoXG4gICAgICAgICFjdXJyZW50LnZvaWRFbGVtZW50ICYmXG4gICAgICAgICFpbkNvbXBvbmVudCAmJlxuICAgICAgICAhaXNSYXdUZXh0ICYmXG4gICAgICAgIG5leHRDaGFyICYmXG4gICAgICAgIG5leHRDaGFyICE9PSAnPCdcbiAgICAgICkge1xuICAgICAgICAvLyB0ZXh0IGNvbnRlbnQgcnVucyB0byB0aGUgbmV4dCBhY3R1YWwgdGFnIG1hdGNoOyBzdHJheSBgPGBcbiAgICAgICAgLy8gY2hhcmFjdGVycyBpbiBiZXR3ZWVuIGFyZSBwYXJ0IG9mIHRoZSB0ZXh0XG4gICAgICAgIGN1cnJlbnQuY2hpbGRyZW4ucHVzaCh7XG4gICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgIGNvbnRlbnQ6IGh0bWwuc2xpY2Uoc3RhcnQsIG5leHRNYXRjaCA/IG5leHRNYXRjaC5pbmRleCA6IHVuZGVmaW5lZCksXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICAvLyBpZiB3ZSdyZSBhdCByb290LCBwdXNoIG5ldyBiYXNlIG5vZGVcbiAgICAgIGlmIChsZXZlbCA9PT0gMCkge1xuICAgICAgICByZXN1bHQucHVzaChjdXJyZW50KTtcbiAgICAgIH1cblxuICAgICAgcGFyZW50ID0gYXJyW2xldmVsIC0gMV07XG5cbiAgICAgIGlmIChwYXJlbnQpIHtcbiAgICAgICAgcGFyZW50LmNoaWxkcmVuLnB1c2goY3VycmVudCk7XG4gICAgICB9XG5cbiAgICAgIGFycltsZXZlbF0gPSBjdXJyZW50O1xuICAgIH1cblxuICAgIGlmICghaXNPcGVuIHx8IGN1cnJlbnQudm9pZEVsZW1lbnQpIHtcbiAgICAgIGlmIChcbiAgICAgICAgbGV2ZWwgPiAtMSAmJlxuICAgICAgICAoY3VycmVudC52b2lkRWxlbWVudCB8fCBjdXJyZW50Lm5hbWUgPT09IHRhZy5zbGljZSgyLCAtMSkpXG4gICAgICApIHtcbiAgICAgICAgbGV2ZWwtLTtcbiAgICAgICAgLy8gbW92ZSBjdXJyZW50IHVwIGEgbGV2ZWwgdG8gbWF0Y2ggdGhlIGVuZCB0YWdcbiAgICAgICAgY3VycmVudCA9IGxldmVsID09PSAtMSA/IHJlc3VsdCA6IGFycltsZXZlbF07XG4gICAgICB9XG4gICAgICBpZiAoIWluQ29tcG9uZW50ICYmIChuZXh0Q2hhciAhPT0gJzwnIHx8IGlzVGV4dCkgJiYgbmV4dENoYXIpIHtcbiAgICAgICAgLy8gdHJhaWxpbmcgdGV4dCBub2RlXG4gICAgICAgIC8vIGlmIHdlJ3JlIGF0IHRoZSByb290LCBwdXNoIGEgYmFzZSB0ZXh0IG5vZGUuIG90aGVyd2lzZSBhZGQgYXNcbiAgICAgICAgLy8gYSBjaGlsZCB0byB0aGUgY3VycmVudCBub2RlLlxuICAgICAgICBwYXJlbnQgPSBsZXZlbCA9PT0gLTEgPyByZXN1bHQgOiBhcnJbbGV2ZWxdLmNoaWxkcmVuO1xuXG4gICAgICAgIC8vIHRoZSB0ZXh0IG5vZGUgcnVucyB0byB0aGUgbmV4dCBhY3R1YWwgdGFnIG1hdGNoOyAtMSBtZWFuc1xuICAgICAgICAvLyB0aGVyZSdzIG5vIHRhZyBhZnRlciBpdCAodHJhaWxpbmcgdGV4dClcbiAgICAgICAgY29uc3QgZW5kID0gbmV4dE1hdGNoID8gbmV4dE1hdGNoLmluZGV4IDogLTE7XG4gICAgICAgIGxldCBjb250ZW50ID0gaHRtbC5zbGljZShzdGFydCwgZW5kID09PSAtMSA/IHVuZGVmaW5lZCA6IGVuZCk7XG4gICAgICAgIC8vIGlmIGEgbm9kZSBpcyBub3RoaW5nIGJ1dCB3aGl0ZXNwYWNlLCBjb2xsYXBzZSBpdCBhcyB0aGUgc3BlYyBzdGF0ZXM6XG4gICAgICAgIC8vIGh0dHBzOi8vd3d3LnczLm9yZy9UUi9odG1sNC9zdHJ1Y3QvdGV4dC5odG1sI2gtOS4xXG4gICAgICAgIGlmICh3aGl0ZXNwYWNlUkUudGVzdChjb250ZW50KSkge1xuICAgICAgICAgIGNvbnRlbnQgPSAnICc7XG4gICAgICAgIH1cbiAgICAgICAgLy8gZG9uJ3QgYWRkIHdoaXRlc3BhY2Utb25seSB0ZXh0IG5vZGVzIGlmIHRoZXkgd291bGQgYmUgdHJhaWxpbmcgdGV4dCBub2Rlc1xuICAgICAgICAvLyBvciBpZiB0aGV5IHdvdWxkIGJlIGxlYWRpbmcgd2hpdGVzcGFjZS1vbmx5IHRleHQgbm9kZXM6XG4gICAgICAgIC8vICAqIGVuZCA+IC0xIGluZGljYXRlcyB0aGlzIGlzIG5vdCBhIHRyYWlsaW5nIHRleHQgbm9kZVxuICAgICAgICAvLyAgKiBsZWFkaW5nIG5vZGUgaXMgd2hlbiBsZXZlbCBpcyAtMSBhbmQgcGFyZW50IGhhcyBsZW5ndGggMFxuICAgICAgICBpZiAoKGVuZCA+IC0xICYmIGxldmVsICsgcGFyZW50Lmxlbmd0aCA+PSAwKSB8fCBjb250ZW50ICE9PSAnICcpIHtcbiAgICAgICAgICBwYXJlbnQucHVzaCh7XG4gICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgICBjb250ZW50LFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9KTtcblxuICBpZiAocmVzdG9yZU5lZWRlZCkge1xuICAgIHJlc3RvcmVTZW50aW5lbHMocmVzdWx0KTtcbiAgfVxuXG4gIHJldHVybiByZXN1bHRcbn1cblxuZnVuY3Rpb24gYXR0clN0cmluZyhhdHRycykge1xuICBjb25zdCBidWZmID0gW107XG4gIGZvciAoY29uc3Qga2V5IGluIGF0dHJzKSB7XG4gICAgaWYgKGF0dHJzW2tleV0gPT09IG51bGwpIHtcbiAgICAgIC8vIGJvb2xlYW4gYXR0cmlidXRlLCByZW5kZXIgYmFyZVxuICAgICAgYnVmZi5wdXNoKGtleSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIGVzY2FwZSBkb3VibGUgcXVvdGVzIHNvIHZhbHVlcyBwYXJzZWQgZnJvbSBzaW5nbGUtcXVvdGVkIG9yXG4gICAgICAvLyBtdWx0aWxpbmUgYXR0cmlidXRlcyBjYW4ndCBicmVhayBvdXQgb2YgdGhlIGdlbmVyYXRlZCBtYXJrdXBcbiAgICAgIGJ1ZmYucHVzaChrZXkgKyAnPVwiJyArIFN0cmluZyhhdHRyc1trZXldKS5yZXBsYWNlKC9cIi9nLCAnJnF1b3Q7JykgKyAnXCInKTtcbiAgICB9XG4gIH1cbiAgaWYgKCFidWZmLmxlbmd0aCkge1xuICAgIHJldHVybiAnJ1xuICB9XG4gIHJldHVybiAnICcgKyBidWZmLmpvaW4oJyAnKVxufVxuXG5mdW5jdGlvbiBzdHJpbmdpZnlOb2RlKGJ1ZmYsIGRvYykge1xuICBzd2l0Y2ggKGRvYy50eXBlKSB7XG4gICAgY2FzZSAndGV4dCc6XG4gICAgICByZXR1cm4gYnVmZiArIGRvYy5jb250ZW50XG4gICAgY2FzZSAndGFnJzoge1xuICAgICAgLy8gYSBkb2N0eXBlIGlzIHZvaWQgYnV0IG11c3Qgbm90IHNlbGYtY2xvc2U6IGA8IURPQ1RZUEUgaHRtbD5gIG5vdCBgPCFET0NUWVBFIGh0bWwvPmBcbiAgICAgIGNvbnN0IHRhZ0VuZCA9XG4gICAgICAgIGRvYy52b2lkRWxlbWVudCAmJiBkb2MubmFtZS50b0xvd2VyQ2FzZSgpICE9PSAnIWRvY3R5cGUnID8gJy8+JyA6ICc+JztcbiAgICAgIGJ1ZmYgKz0gJzwnICsgZG9jLm5hbWUgKyAoZG9jLmF0dHJzID8gYXR0clN0cmluZyhkb2MuYXR0cnMpIDogJycpICsgdGFnRW5kO1xuICAgICAgaWYgKGRvYy52b2lkRWxlbWVudCkge1xuICAgICAgICByZXR1cm4gYnVmZlxuICAgICAgfVxuICAgICAgcmV0dXJuIChcbiAgICAgICAgYnVmZiArIGRvYy5jaGlsZHJlbi5yZWR1Y2Uoc3RyaW5naWZ5Tm9kZSwgJycpICsgJzwvJyArIGRvYy5uYW1lICsgJz4nXG4gICAgICApXG4gICAgfVxuICAgIGNhc2UgJ2NvbW1lbnQnOlxuICAgICAgYnVmZiArPSAnPCEtLScgKyBkb2MuY29tbWVudCArICctLT4nO1xuICAgICAgcmV0dXJuIGJ1ZmZcbiAgfVxufVxuXG5mdW5jdGlvbiBzdHJpbmdpZnkoZG9jKSB7XG4gIHJldHVybiBkb2MucmVkdWNlKGZ1bmN0aW9uICh0b2tlbiwgcm9vdEVsKSB7XG4gICAgcmV0dXJuIHRva2VuICsgc3RyaW5naWZ5Tm9kZSgnJywgcm9vdEVsKVxuICB9LCAnJylcbn1cblxudmFyIGluZGV4ID0ge1xuICBwYXJzZSxcbiAgc3RyaW5naWZ5LFxufTtcblxuZXhwb3J0IHsgaW5kZXggYXMgZGVmYXVsdCwgcGFyc2UsIHN0cmluZ2lmeSB9O1xuIiwiZXhwb3J0IGNvbnN0IHdhcm4gPSAoaTE4biwgY29kZSwgbXNnLCByZXN0KSA9PiB7XG4gIGNvbnN0IGFyZ3MgPSBbbXNnLCB7XG4gICAgY29kZSxcbiAgICAuLi4ocmVzdCB8fCB7fSlcbiAgfV07XG4gIGlmIChpMThuPy5zZXJ2aWNlcz8ubG9nZ2VyPy5mb3J3YXJkKSB7XG4gICAgcmV0dXJuIGkxOG4uc2VydmljZXMubG9nZ2VyLmZvcndhcmQoYXJncywgJ3dhcm4nLCAncmVhY3QtaTE4bmV4dDo6JywgdHJ1ZSk7XG4gIH1cbiAgaWYgKGlzU3RyaW5nKGFyZ3NbMF0pKSBhcmdzWzBdID0gYHJlYWN0LWkxOG5leHQ6OiAke2FyZ3NbMF19YDtcbiAgaWYgKGkxOG4/LnNlcnZpY2VzPy5sb2dnZXI/Lndhcm4pIHtcbiAgICBpMThuLnNlcnZpY2VzLmxvZ2dlci53YXJuKC4uLmFyZ3MpO1xuICB9IGVsc2UgaWYgKGNvbnNvbGU/Lndhcm4pIHtcbiAgICBjb25zb2xlLndhcm4oLi4uYXJncyk7XG4gIH1cbn07XG5jb25zdCBhbHJlYWR5V2FybmVkID0ge307XG5leHBvcnQgY29uc3Qgd2Fybk9uY2UgPSAoaTE4biwgY29kZSwgbXNnLCByZXN0KSA9PiB7XG4gIGlmIChpc1N0cmluZyhtc2cpICYmIGFscmVhZHlXYXJuZWRbbXNnXSkgcmV0dXJuO1xuICBpZiAoaXNTdHJpbmcobXNnKSkgYWxyZWFkeVdhcm5lZFttc2ddID0gbmV3IERhdGUoKTtcbiAgd2FybihpMThuLCBjb2RlLCBtc2csIHJlc3QpO1xufTtcbmNvbnN0IGxvYWRlZENsYiA9IChpMThuLCBjYikgPT4gKCkgPT4ge1xuICBpZiAoaTE4bi5pc0luaXRpYWxpemVkKSB7XG4gICAgY2IoKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBpbml0aWFsaXplZCA9ICgpID0+IHtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBpMThuLm9mZignaW5pdGlhbGl6ZWQnLCBpbml0aWFsaXplZCk7XG4gICAgICB9LCAwKTtcbiAgICAgIGNiKCk7XG4gICAgfTtcbiAgICBpMThuLm9uKCdpbml0aWFsaXplZCcsIGluaXRpYWxpemVkKTtcbiAgfVxufTtcbmV4cG9ydCBjb25zdCBsb2FkTmFtZXNwYWNlcyA9IChpMThuLCBucywgY2IpID0+IHtcbiAgaTE4bi5sb2FkTmFtZXNwYWNlcyhucywgbG9hZGVkQ2xiKGkxOG4sIGNiKSk7XG59O1xuZXhwb3J0IGNvbnN0IGxvYWRMYW5ndWFnZXMgPSAoaTE4biwgbG5nLCBucywgY2IpID0+IHtcbiAgaWYgKGlzU3RyaW5nKG5zKSkgbnMgPSBbbnNdO1xuICBpZiAoaTE4bi5vcHRpb25zLnByZWxvYWQgJiYgaTE4bi5vcHRpb25zLnByZWxvYWQuaW5kZXhPZihsbmcpID4gLTEpIHJldHVybiBsb2FkTmFtZXNwYWNlcyhpMThuLCBucywgY2IpO1xuICBucy5mb3JFYWNoKG4gPT4ge1xuICAgIGlmIChpMThuLm9wdGlvbnMubnMuaW5kZXhPZihuKSA8IDApIGkxOG4ub3B0aW9ucy5ucy5wdXNoKG4pO1xuICB9KTtcbiAgaTE4bi5sb2FkTGFuZ3VhZ2VzKGxuZywgbG9hZGVkQ2xiKGkxOG4sIGNiKSk7XG59O1xuZXhwb3J0IGNvbnN0IGhhc0xvYWRlZE5hbWVzcGFjZSA9IChucywgaTE4biwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gIGlmICghaTE4bi5sYW5ndWFnZXMgfHwgIWkxOG4ubGFuZ3VhZ2VzLmxlbmd0aCkge1xuICAgIHdhcm5PbmNlKGkxOG4sICdOT19MQU5HVUFHRVMnLCAnaTE4bi5sYW5ndWFnZXMgd2VyZSB1bmRlZmluZWQgb3IgZW1wdHknLCB7XG4gICAgICBsYW5ndWFnZXM6IGkxOG4ubGFuZ3VhZ2VzXG4gICAgfSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGkxOG4uaGFzTG9hZGVkTmFtZXNwYWNlKG5zLCB7XG4gICAgbG5nOiBvcHRpb25zLmxuZyxcbiAgICBwcmVjaGVjazogKGkxOG5JbnN0YW5jZSwgbG9hZE5vdFBlbmRpbmcpID0+IHtcbiAgICAgIGlmIChvcHRpb25zLmJpbmRJMThuICYmIG9wdGlvbnMuYmluZEkxOG4uaW5kZXhPZignbGFuZ3VhZ2VDaGFuZ2luZycpID4gLTEgJiYgaTE4bkluc3RhbmNlLnNlcnZpY2VzLmJhY2tlbmRDb25uZWN0b3IuYmFja2VuZCAmJiBpMThuSW5zdGFuY2UuaXNMYW5ndWFnZUNoYW5naW5nVG8gJiYgIWxvYWROb3RQZW5kaW5nKGkxOG5JbnN0YW5jZS5pc0xhbmd1YWdlQ2hhbmdpbmdUbywgbnMpKSByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9KTtcbn07XG5leHBvcnQgY29uc3QgZ2V0RGlzcGxheU5hbWUgPSBDb21wb25lbnQgPT4gQ29tcG9uZW50LmRpc3BsYXlOYW1lIHx8IENvbXBvbmVudC5uYW1lIHx8IChpc1N0cmluZyhDb21wb25lbnQpICYmIENvbXBvbmVudC5sZW5ndGggPiAwID8gQ29tcG9uZW50IDogJ1Vua25vd24nKTtcbmV4cG9ydCBjb25zdCBpc1N0cmluZyA9IG9iaiA9PiB0eXBlb2Ygb2JqID09PSAnc3RyaW5nJztcbmV4cG9ydCBjb25zdCBpc09iamVjdCA9IG9iaiA9PiB0eXBlb2Ygb2JqID09PSAnb2JqZWN0JyAmJiBvYmogIT09IG51bGw7IiwiY29uc3QgbWF0Y2hIdG1sRW50aXR5ID0gLyYoPzphbXB8IzM4fGx0fCM2MHxndHwjNjJ8YXBvc3wjMzl8cXVvdHwjMzR8bmJzcHwjMTYwfGNvcHl8IzE2OXxyZWd8IzE3NHxoZWxsaXB8IzgyMzB8I3gyRnwjNDcpOy9nO1xuY29uc3QgaHRtbEVudGl0aWVzID0ge1xuICAnJmFtcDsnOiAnJicsXG4gICcmIzM4Oyc6ICcmJyxcbiAgJyZsdDsnOiAnPCcsXG4gICcmIzYwOyc6ICc8JyxcbiAgJyZndDsnOiAnPicsXG4gICcmIzYyOyc6ICc+JyxcbiAgJyZhcG9zOyc6IFwiJ1wiLFxuICAnJiMzOTsnOiBcIidcIixcbiAgJyZxdW90Oyc6ICdcIicsXG4gICcmIzM0Oyc6ICdcIicsXG4gICcmbmJzcDsnOiAnICcsXG4gICcmIzE2MDsnOiAnICcsXG4gICcmY29weTsnOiAnwqknLFxuICAnJiMxNjk7JzogJ8KpJyxcbiAgJyZyZWc7JzogJ8KuJyxcbiAgJyYjMTc0Oyc6ICfCricsXG4gICcmaGVsbGlwOyc6ICfigKYnLFxuICAnJiM4MjMwOyc6ICfigKYnLFxuICAnJiN4MkY7JzogJy8nLFxuICAnJiM0NzsnOiAnLydcbn07XG5jb25zdCB1bmVzY2FwZUh0bWxFbnRpdHkgPSBtID0+IGh0bWxFbnRpdGllc1ttXTtcbmV4cG9ydCBjb25zdCB1bmVzY2FwZSA9IHRleHQgPT4gdGV4dC5yZXBsYWNlKG1hdGNoSHRtbEVudGl0eSwgdW5lc2NhcGVIdG1sRW50aXR5KTsiLCJpbXBvcnQgeyB1bmVzY2FwZSB9IGZyb20gJy4vdW5lc2NhcGUuanMnO1xubGV0IGRlZmF1bHRPcHRpb25zID0ge1xuICBiaW5kSTE4bjogJ2xhbmd1YWdlQ2hhbmdlZCcsXG4gIGJpbmRJMThuU3RvcmU6ICcnLFxuICB0cmFuc0VtcHR5Tm9kZVZhbHVlOiAnJyxcbiAgdHJhbnNTdXBwb3J0QmFzaWNIdG1sTm9kZXM6IHRydWUsXG4gIHRyYW5zV3JhcFRleHROb2RlczogJycsXG4gIHRyYW5zS2VlcEJhc2ljSHRtbE5vZGVzRm9yOiBbJ2JyJywgJ3N0cm9uZycsICdpJywgJ3AnXSxcbiAgdXNlU3VzcGVuc2U6IHRydWUsXG4gIHVuZXNjYXBlLFxuICB0cmFuc0RlZmF1bHRQcm9wczogdW5kZWZpbmVkXG59O1xuZXhwb3J0IGNvbnN0IHNldERlZmF1bHRzID0gKG9wdGlvbnMgPSB7fSkgPT4ge1xuICBkZWZhdWx0T3B0aW9ucyA9IHtcbiAgICAuLi5kZWZhdWx0T3B0aW9ucyxcbiAgICAuLi5vcHRpb25zXG4gIH07XG59O1xuZXhwb3J0IGNvbnN0IGdldERlZmF1bHRzID0gKCkgPT4gZGVmYXVsdE9wdGlvbnM7IiwibGV0IGkxOG5JbnN0YW5jZTtcbmV4cG9ydCBjb25zdCBzZXRJMThuID0gaW5zdGFuY2UgPT4ge1xuICBpMThuSW5zdGFuY2UgPSBpbnN0YW5jZTtcbn07XG5leHBvcnQgY29uc3QgZ2V0STE4biA9ICgpID0+IGkxOG5JbnN0YW5jZTsiLCJpbXBvcnQgeyBGcmFnbWVudCwgaXNWYWxpZEVsZW1lbnQsIGNsb25lRWxlbWVudCwgY3JlYXRlRWxlbWVudCwgQ2hpbGRyZW4gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBrZXlGcm9tU2VsZWN0b3IgfSBmcm9tICdpMThuZXh0JztcbmltcG9ydCBIVE1MIGZyb20gJ2h0bWwtcGFyc2Utc3RyaW5naWZ5JztcbmltcG9ydCB7IGlzT2JqZWN0LCBpc1N0cmluZywgd2Fybiwgd2Fybk9uY2UgfSBmcm9tICcuL3V0aWxzLmpzJztcbmltcG9ydCB7IGdldERlZmF1bHRzIH0gZnJvbSAnLi9kZWZhdWx0cy5qcyc7XG5pbXBvcnQgeyBnZXRJMThuIH0gZnJvbSAnLi9pMThuSW5zdGFuY2UuanMnO1xuaW1wb3J0IHsgdW5lc2NhcGUgfSBmcm9tICcuL3VuZXNjYXBlLmpzJztcbmNvbnN0IGhhc0NoaWxkcmVuID0gKG5vZGUsIGNoZWNrTGVuZ3RoKSA9PiB7XG4gIGlmICghbm9kZSkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBiYXNlID0gbm9kZS5wcm9wcz8uY2hpbGRyZW4gPz8gbm9kZS5jaGlsZHJlbjtcbiAgaWYgKGNoZWNrTGVuZ3RoKSByZXR1cm4gYmFzZS5sZW5ndGggPiAwO1xuICByZXR1cm4gISFiYXNlO1xufTtcbmNvbnN0IGdldENoaWxkcmVuID0gbm9kZSA9PiB7XG4gIGlmICghbm9kZSkgcmV0dXJuIFtdO1xuICBjb25zdCBjaGlsZHJlbiA9IG5vZGUucHJvcHM/LmNoaWxkcmVuID8/IG5vZGUuY2hpbGRyZW47XG4gIHJldHVybiBub2RlLnByb3BzPy5pMThuSXNEeW5hbWljTGlzdCA/IGdldEFzQXJyYXkoY2hpbGRyZW4pIDogY2hpbGRyZW47XG59O1xuY29uc3QgaGFzVmFsaWRSZWFjdENoaWxkcmVuID0gY2hpbGRyZW4gPT4gQXJyYXkuaXNBcnJheShjaGlsZHJlbikgJiYgY2hpbGRyZW4uZXZlcnkoaXNWYWxpZEVsZW1lbnQpO1xuY29uc3QgZ2V0QXNBcnJheSA9IGRhdGEgPT4gQXJyYXkuaXNBcnJheShkYXRhKSA/IGRhdGEgOiBbZGF0YV07XG5jb25zdCBtZXJnZVByb3BzID0gKHNvdXJjZSwgdGFyZ2V0KSA9PiB7XG4gIGNvbnN0IG5ld1RhcmdldCA9IHtcbiAgICAuLi50YXJnZXRcbiAgfTtcbiAgbmV3VGFyZ2V0LnByb3BzID0ge1xuICAgIC4uLnRhcmdldC5wcm9wcyxcbiAgICAuLi5zb3VyY2UucHJvcHNcbiAgfTtcbiAgcmV0dXJuIG5ld1RhcmdldDtcbn07XG5jb25zdCBnZXRWYWx1ZXNGcm9tQ2hpbGRyZW4gPSBjaGlsZHJlbiA9PiB7XG4gIGNvbnN0IHZhbHVlcyA9IHt9O1xuICBpZiAoIWNoaWxkcmVuKSByZXR1cm4gdmFsdWVzO1xuICBjb25zdCBnZXREYXRhID0gY2hpbGRzID0+IHtcbiAgICBjb25zdCBjaGlsZHJlbkFycmF5ID0gZ2V0QXNBcnJheShjaGlsZHMpO1xuICAgIGNoaWxkcmVuQXJyYXkuZm9yRWFjaChjaGlsZCA9PiB7XG4gICAgICBpZiAoaXNTdHJpbmcoY2hpbGQpKSByZXR1cm47XG4gICAgICBpZiAoaGFzQ2hpbGRyZW4oY2hpbGQpKSBnZXREYXRhKGdldENoaWxkcmVuKGNoaWxkKSk7ZWxzZSBpZiAoaXNPYmplY3QoY2hpbGQpICYmICFpc1ZhbGlkRWxlbWVudChjaGlsZCkpIE9iamVjdC5hc3NpZ24odmFsdWVzLCBjaGlsZCk7XG4gICAgfSk7XG4gIH07XG4gIGdldERhdGEoY2hpbGRyZW4pO1xuICByZXR1cm4gdmFsdWVzO1xufTtcbmV4cG9ydCBjb25zdCBub2Rlc1RvU3RyaW5nID0gKGNoaWxkcmVuLCBpMThuT3B0aW9ucywgaTE4biwgaTE4bktleSkgPT4ge1xuICBpZiAoIWNoaWxkcmVuKSByZXR1cm4gJyc7XG4gIGxldCBzdHJpbmdOb2RlID0gJyc7XG4gIGNvbnN0IGNoaWxkcmVuQXJyYXkgPSBnZXRBc0FycmF5KGNoaWxkcmVuKTtcbiAgY29uc3Qga2VlcEFycmF5ID0gaTE4bk9wdGlvbnM/LnRyYW5zU3VwcG9ydEJhc2ljSHRtbE5vZGVzID8gaTE4bk9wdGlvbnMudHJhbnNLZWVwQmFzaWNIdG1sTm9kZXNGb3IgPz8gW10gOiBbXTtcbiAgY2hpbGRyZW5BcnJheS5mb3JFYWNoKChjaGlsZCwgY2hpbGRJbmRleCkgPT4ge1xuICAgIGlmIChpc1N0cmluZyhjaGlsZCkpIHtcbiAgICAgIHN0cmluZ05vZGUgKz0gYCR7Y2hpbGR9YDtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGlzVmFsaWRFbGVtZW50KGNoaWxkKSkge1xuICAgICAgY29uc3Qge1xuICAgICAgICBwcm9wcyxcbiAgICAgICAgdHlwZVxuICAgICAgfSA9IGNoaWxkO1xuICAgICAgY29uc3QgY2hpbGRQcm9wc0NvdW50ID0gT2JqZWN0LmtleXMocHJvcHMpLmxlbmd0aDtcbiAgICAgIGNvbnN0IHNob3VsZEtlZXBDaGlsZCA9IGtlZXBBcnJheS5pbmRleE9mKHR5cGUpID4gLTE7XG4gICAgICBjb25zdCBjaGlsZENoaWxkcmVuID0gcHJvcHMuY2hpbGRyZW47XG4gICAgICBpZiAoIWNoaWxkQ2hpbGRyZW4gJiYgc2hvdWxkS2VlcENoaWxkICYmICFjaGlsZFByb3BzQ291bnQpIHtcbiAgICAgICAgc3RyaW5nTm9kZSArPSBgPCR7dHlwZX0vPmA7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICghY2hpbGRDaGlsZHJlbiAmJiAoIXNob3VsZEtlZXBDaGlsZCB8fCBjaGlsZFByb3BzQ291bnQpIHx8IHByb3BzLmkxOG5Jc0R5bmFtaWNMaXN0KSB7XG4gICAgICAgIHN0cmluZ05vZGUgKz0gYDwke2NoaWxkSW5kZXh9PjwvJHtjaGlsZEluZGV4fT5gO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoc2hvdWxkS2VlcENoaWxkICYmIGNoaWxkUHJvcHNDb3VudCA8PSAxKSB7XG4gICAgICAgIGNvbnN0IGNudCA9IGlzU3RyaW5nKGNoaWxkQ2hpbGRyZW4pID8gY2hpbGRDaGlsZHJlbiA6IG5vZGVzVG9TdHJpbmcoY2hpbGRDaGlsZHJlbiwgaTE4bk9wdGlvbnMsIGkxOG4sIGkxOG5LZXkpO1xuICAgICAgICBzdHJpbmdOb2RlICs9IGA8JHt0eXBlfT4ke2NudH08LyR7dHlwZX0+YDtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgY29udGVudCA9IG5vZGVzVG9TdHJpbmcoY2hpbGRDaGlsZHJlbiwgaTE4bk9wdGlvbnMsIGkxOG4sIGkxOG5LZXkpO1xuICAgICAgc3RyaW5nTm9kZSArPSBgPCR7Y2hpbGRJbmRleH0+JHtjb250ZW50fTwvJHtjaGlsZEluZGV4fT5gO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY2hpbGQgPT09IG51bGwpIHtcbiAgICAgIHdhcm4oaTE4biwgJ1RSQU5TX05VTExfVkFMVUUnLCBgUGFzc2VkIGluIGEgbnVsbCB2YWx1ZSBhcyBjaGlsZGAsIHtcbiAgICAgICAgaTE4bktleVxuICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChpc09iamVjdChjaGlsZCkpIHtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgZm9ybWF0LFxuICAgICAgICAuLi5jbG9uZVxuICAgICAgfSA9IGNoaWxkO1xuICAgICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKGNsb25lKTtcbiAgICAgIGlmIChrZXlzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGZvcm1hdCA/IGAke2tleXNbMF19LCAke2Zvcm1hdH1gIDoga2V5c1swXTtcbiAgICAgICAgc3RyaW5nTm9kZSArPSBge3ske3ZhbHVlfX19YDtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgd2FybihpMThuLCAnVFJBTlNfSU5WQUxJRF9PQkonLCBgSW52YWxpZCBjaGlsZCAtIE9iamVjdCBzaG91bGQgb25seSBoYXZlIGtleXMge3sgdmFsdWUsIGZvcm1hdCB9fSAoZm9ybWF0IGlzIG9wdGlvbmFsKS5gLCB7XG4gICAgICAgIGkxOG5LZXksXG4gICAgICAgIGNoaWxkXG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgd2FybihpMThuLCAnVFJBTlNfSU5WQUxJRF9WQVInLCBgUGFzc2VkIGluIGEgdmFyaWFibGUgbGlrZSB7bnVtYmVyfSAtIHBhc3MgdmFyaWFibGVzIGZvciBpbnRlcnBvbGF0aW9uIGFzIGZ1bGwgb2JqZWN0cyBsaWtlIHt7bnVtYmVyfX0uYCwge1xuICAgICAgaTE4bktleSxcbiAgICAgIGNoaWxkXG4gICAgfSk7XG4gIH0pO1xuICByZXR1cm4gc3RyaW5nTm9kZTtcbn07XG5jb25zdCByZW5kZXJOb2RlcyA9IChjaGlsZHJlbiwga25vd25Db21wb25lbnRzTWFwLCB0YXJnZXRTdHJpbmcsIGkxOG4sIGkxOG5PcHRpb25zLCBjb21iaW5lZFRPcHRzLCBzaG91bGRVbmVzY2FwZSkgPT4ge1xuICBpZiAodGFyZ2V0U3RyaW5nID09PSAnJykgcmV0dXJuIFtdO1xuICBjb25zdCBrZWVwQXJyYXkgPSBpMThuT3B0aW9ucy50cmFuc0tlZXBCYXNpY0h0bWxOb2Rlc0ZvciB8fCBbXTtcbiAgY29uc3QgZW1wdHlDaGlsZHJlbkJ1dE5lZWRzSGFuZGxpbmcgPSB0YXJnZXRTdHJpbmcgJiYgbmV3IFJlZ0V4cChrZWVwQXJyYXkubWFwKGtlZXAgPT4gYDwke2tlZXB9YCkuam9pbignfCcpKS50ZXN0KHRhcmdldFN0cmluZyk7XG4gIGlmICghY2hpbGRyZW4gJiYgIWtub3duQ29tcG9uZW50c01hcCAmJiAhZW1wdHlDaGlsZHJlbkJ1dE5lZWRzSGFuZGxpbmcgJiYgIXNob3VsZFVuZXNjYXBlKSByZXR1cm4gW3RhcmdldFN0cmluZ107XG4gIGNvbnN0IGRhdGEgPSBrbm93bkNvbXBvbmVudHNNYXAgPz8ge307XG4gIGNvbnN0IGdldERhdGEgPSBjaGlsZHMgPT4ge1xuICAgIGNvbnN0IGNoaWxkcmVuQXJyYXkgPSBnZXRBc0FycmF5KGNoaWxkcyk7XG4gICAgY2hpbGRyZW5BcnJheS5mb3JFYWNoKGNoaWxkID0+IHtcbiAgICAgIGlmIChpc1N0cmluZyhjaGlsZCkpIHJldHVybjtcbiAgICAgIGlmIChoYXNDaGlsZHJlbihjaGlsZCkpIGdldERhdGEoZ2V0Q2hpbGRyZW4oY2hpbGQpKTtlbHNlIGlmIChpc09iamVjdChjaGlsZCkgJiYgIWlzVmFsaWRFbGVtZW50KGNoaWxkKSkgT2JqZWN0LmFzc2lnbihkYXRhLCBjaGlsZCk7XG4gICAgfSk7XG4gIH07XG4gIGdldERhdGEoY2hpbGRyZW4pO1xuICBjb25zdCBrbm93bk5hbWVzID0gT2JqZWN0LmtleXMoZGF0YSk7XG4gIGNvbnN0IGFsbG93ZWRUYWdzID0gbmFtZSA9PiAvXlxcZCskLy50ZXN0KG5hbWUpIHx8IGtlZXBBcnJheS5pbmRleE9mKG5hbWUpID4gLTEgfHwga25vd25OYW1lcy5pbmRleE9mKG5hbWUpID4gLTE7XG4gIGNvbnN0IGFzdCA9IEhUTUwucGFyc2UoYDwwPiR7dGFyZ2V0U3RyaW5nfTwvMD5gLCB7XG4gICAgYWxsb3dlZFRhZ3NcbiAgfSk7XG4gIGNvbnN0IG9wdHMgPSB7XG4gICAgLi4uZGF0YSxcbiAgICAuLi5jb21iaW5lZFRPcHRzXG4gIH07XG4gIGNvbnN0IHJlbmRlcklubmVyID0gKGNoaWxkLCBub2RlLCByb290UmVhY3ROb2RlKSA9PiB7XG4gICAgY29uc3QgY2hpbGRzID0gZ2V0Q2hpbGRyZW4oY2hpbGQpO1xuICAgIGNvbnN0IG1hcHBlZENoaWxkcmVuID0gbWFwQVNUKGNoaWxkcywgbm9kZS5jaGlsZHJlbiwgcm9vdFJlYWN0Tm9kZSk7XG4gICAgcmV0dXJuIGhhc1ZhbGlkUmVhY3RDaGlsZHJlbihjaGlsZHMpICYmIG1hcHBlZENoaWxkcmVuLmxlbmd0aCA9PT0gMCB8fCBjaGlsZC5wcm9wcz8uaTE4bklzRHluYW1pY0xpc3QgPyBjaGlsZHMgOiBtYXBwZWRDaGlsZHJlbjtcbiAgfTtcbiAgY29uc3QgcHVzaFRyYW5zbGF0ZWRKU1ggPSAoY2hpbGQsIGlubmVyLCBtZW0sIGksIGlzVm9pZCkgPT4ge1xuICAgIGlmIChjaGlsZC5kdW1teSkge1xuICAgICAgY2hpbGQuY2hpbGRyZW4gPSBpbm5lcjtcbiAgICAgIG1lbS5wdXNoKGNsb25lRWxlbWVudChjaGlsZCwge1xuICAgICAgICBrZXk6IGlcbiAgICAgIH0sIGlzVm9pZCA/IHVuZGVmaW5lZCA6IGlubmVyKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG1lbS5wdXNoKC4uLkNoaWxkcmVuLm1hcChbY2hpbGRdLCBjID0+IHtcbiAgICAgICAgaWYgKGMudHlwZSA9PT0gRnJhZ21lbnQgfHwgYy5wcm9wcz8uaTE4bklzRHluYW1pY0xpc3QgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGNvbnN0IGZyZXNoUHJvcHMgPSB7XG4gICAgICAgICAgICBrZXk6IGlcbiAgICAgICAgICB9O1xuICAgICAgICAgIGlmIChjICYmIGMucHJvcHMpIHtcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKGMucHJvcHMpLmZvckVhY2goayA9PiB7XG4gICAgICAgICAgICAgIGlmIChrID09PSAnY2hpbGRyZW4nIHx8IGsgPT09ICdpMThuSXNEeW5hbWljTGlzdCcpIHJldHVybjtcbiAgICAgICAgICAgICAgZnJlc2hQcm9wc1trXSA9IGMucHJvcHNba107XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGNyZWF0ZUVsZW1lbnQoYy50eXBlLCBmcmVzaFByb3BzLCBpc1ZvaWQgPyBudWxsIDogaW5uZXIpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG92ZXJyaWRlID0ge1xuICAgICAgICAgIGtleTogaVxuICAgICAgICB9O1xuICAgICAgICBpZiAoYyAmJiBjLnByb3BzKSB7XG4gICAgICAgICAgT2JqZWN0LmtleXMoYy5wcm9wcykuZm9yRWFjaChrID0+IHtcbiAgICAgICAgICAgIGlmIChrID09PSAncmVmJyB8fCBrID09PSAnY2hpbGRyZW4nKSByZXR1cm47XG4gICAgICAgICAgICBvdmVycmlkZVtrXSA9IGMucHJvcHNba107XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNsb25lRWxlbWVudChjLCBvdmVycmlkZSwgaXNWb2lkID8gbnVsbCA6IGlubmVyKTtcbiAgICAgIH0pKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IG1hcEFTVCA9IChyZWFjdE5vZGUsIGFzdE5vZGUsIHJvb3RSZWFjdE5vZGUpID0+IHtcbiAgICBjb25zdCByZWFjdE5vZGVzID0gZ2V0QXNBcnJheShyZWFjdE5vZGUpO1xuICAgIGNvbnN0IGFzdE5vZGVzID0gZ2V0QXNBcnJheShhc3ROb2RlKTtcbiAgICBjb25zdCBrZWVwVGFnT2NjdXJyZW5jZSA9IHt9O1xuICAgIHJldHVybiBhc3ROb2Rlcy5yZWR1Y2UoKG1lbSwgbm9kZSwgaSkgPT4ge1xuICAgICAgY29uc3QgdHJhbnNsYXRpb25Db250ZW50ID0gbm9kZS5jaGlsZHJlbj8uWzBdPy5jb250ZW50ICYmIGkxOG4uc2VydmljZXMuaW50ZXJwb2xhdG9yLmludGVycG9sYXRlKG5vZGUuY2hpbGRyZW5bMF0uY29udGVudCwgb3B0cywgaTE4bi5sYW5ndWFnZSk7XG4gICAgICBpZiAobm9kZS50eXBlID09PSAndGFnJykge1xuICAgICAgICBsZXQgdG1wID0gcmVhY3ROb2Rlc1twYXJzZUludChub2RlLm5hbWUsIDEwKV07XG4gICAgICAgIGlmICghdG1wICYmIGtub3duQ29tcG9uZW50c01hcCkgdG1wID0ga25vd25Db21wb25lbnRzTWFwW25vZGUubmFtZV07XG4gICAgICAgIGlmIChyb290UmVhY3ROb2RlLmxlbmd0aCA9PT0gMSAmJiAhdG1wKSB0bXAgPSByb290UmVhY3ROb2RlWzBdW25vZGUubmFtZV07XG4gICAgICAgIGlmICghdG1wKSB0bXAgPSB7fTtcbiAgICAgICAgY29uc3QgcHJvcHMgPSB7XG4gICAgICAgICAgLi4ubm9kZS5hdHRyc1xuICAgICAgICB9O1xuICAgICAgICBpZiAoc2hvdWxkVW5lc2NhcGUpIHtcbiAgICAgICAgICBPYmplY3Qua2V5cyhwcm9wcykuZm9yRWFjaChwID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHZhbCA9IHByb3BzW3BdO1xuICAgICAgICAgICAgaWYgKGlzU3RyaW5nKHZhbCkpIHtcbiAgICAgICAgICAgICAgcHJvcHNbcF0gPSB1bmVzY2FwZSh2YWwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNoaWxkID0gT2JqZWN0LmtleXMocHJvcHMpLmxlbmd0aCAhPT0gMCA/IG1lcmdlUHJvcHMoe1xuICAgICAgICAgIHByb3BzXG4gICAgICAgIH0sIHRtcCkgOiB0bXA7XG4gICAgICAgIGNvbnN0IGlzRWxlbWVudCA9IGlzVmFsaWRFbGVtZW50KGNoaWxkKTtcbiAgICAgICAgY29uc3QgaXNWYWxpZFRyYW5zbGF0aW9uV2l0aENoaWxkcmVuID0gaXNFbGVtZW50ICYmIGhhc0NoaWxkcmVuKG5vZGUsIHRydWUpICYmICFub2RlLnZvaWRFbGVtZW50O1xuICAgICAgICBjb25zdCBpc0VtcHR5VHJhbnNXaXRoSFRNTCA9IGVtcHR5Q2hpbGRyZW5CdXROZWVkc0hhbmRsaW5nICYmIGlzT2JqZWN0KGNoaWxkKSAmJiBjaGlsZC5kdW1teSAmJiAhaXNFbGVtZW50O1xuICAgICAgICBjb25zdCBpc0tub3duQ29tcG9uZW50ID0gaXNPYmplY3Qoa25vd25Db21wb25lbnRzTWFwKSAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChrbm93bkNvbXBvbmVudHNNYXAsIG5vZGUubmFtZSk7XG4gICAgICAgIGlmIChpc1N0cmluZyhjaGlsZCkpIHtcbiAgICAgICAgICBjb25zdCB2YWx1ZSA9IGkxOG4uc2VydmljZXMuaW50ZXJwb2xhdG9yLmludGVycG9sYXRlKGNoaWxkLCBvcHRzLCBpMThuLmxhbmd1YWdlKTtcbiAgICAgICAgICBtZW0ucHVzaCh2YWx1ZSk7XG4gICAgICAgIH0gZWxzZSBpZiAoaGFzQ2hpbGRyZW4oY2hpbGQpIHx8IGlzVmFsaWRUcmFuc2xhdGlvbldpdGhDaGlsZHJlbikge1xuICAgICAgICAgIGNvbnN0IGlubmVyID0gcmVuZGVySW5uZXIoY2hpbGQsIG5vZGUsIHJvb3RSZWFjdE5vZGUpO1xuICAgICAgICAgIHB1c2hUcmFuc2xhdGVkSlNYKGNoaWxkLCBpbm5lciwgbWVtLCBpKTtcbiAgICAgICAgfSBlbHNlIGlmIChpc0VtcHR5VHJhbnNXaXRoSFRNTCkge1xuICAgICAgICAgIGNvbnN0IGlubmVyID0gbWFwQVNUKHJlYWN0Tm9kZXMsIG5vZGUuY2hpbGRyZW4sIHJvb3RSZWFjdE5vZGUpO1xuICAgICAgICAgIHB1c2hUcmFuc2xhdGVkSlNYKGNoaWxkLCBpbm5lciwgbWVtLCBpKTtcbiAgICAgICAgfSBlbHNlIGlmIChOdW1iZXIuaXNOYU4ocGFyc2VGbG9hdChub2RlLm5hbWUpKSkge1xuICAgICAgICAgIGlmIChpc0tub3duQ29tcG9uZW50KSB7XG4gICAgICAgICAgICBjb25zdCBpbm5lciA9IHJlbmRlcklubmVyKGNoaWxkLCBub2RlLCByb290UmVhY3ROb2RlKTtcbiAgICAgICAgICAgIHB1c2hUcmFuc2xhdGVkSlNYKGNoaWxkLCBpbm5lciwgbWVtLCBpLCBub2RlLnZvaWRFbGVtZW50KTtcbiAgICAgICAgICB9IGVsc2UgaWYgKGkxOG5PcHRpb25zLnRyYW5zU3VwcG9ydEJhc2ljSHRtbE5vZGVzICYmIGtlZXBBcnJheS5pbmRleE9mKG5vZGUubmFtZSkgPiAtMSkge1xuICAgICAgICAgICAgaWYgKG5vZGUudm9pZEVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgbWVtLnB1c2goY3JlYXRlRWxlbWVudChub2RlLm5hbWUsIHtcbiAgICAgICAgICAgICAgICBrZXk6IGAke25vZGUubmFtZX0tJHtpfWBcbiAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgY29uc3Qgb2NjdXJyZW5jZSA9IGtlZXBUYWdPY2N1cnJlbmNlW25vZGUubmFtZV0gfHwgMDtcbiAgICAgICAgICAgICAga2VlcFRhZ09jY3VycmVuY2Vbbm9kZS5uYW1lXSA9IG9jY3VycmVuY2UgKyAxO1xuICAgICAgICAgICAgICBsZXQgbWF0Y2hlZDtcbiAgICAgICAgICAgICAgbGV0IHNlZW4gPSAwO1xuICAgICAgICAgICAgICBmb3IgKGxldCByID0gMDsgciA8IHJlYWN0Tm9kZXMubGVuZ3RoOyByICs9IDEpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBybiA9IHJlYWN0Tm9kZXNbcl07XG4gICAgICAgICAgICAgICAgaWYgKGlzVmFsaWRFbGVtZW50KHJuKSAmJiBybi50eXBlID09PSBub2RlLm5hbWUpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChzZWVuID09PSBvY2N1cnJlbmNlKSB7XG4gICAgICAgICAgICAgICAgICAgIG1hdGNoZWQgPSBybjtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBzZWVuICs9IDE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGNvbnN0IGlubmVyU2NvcGUgPSBtYXRjaGVkID8gZ2V0QXNBcnJheShnZXRDaGlsZHJlbihtYXRjaGVkKSkgOiByZWFjdE5vZGVzO1xuICAgICAgICAgICAgICBjb25zdCBpbm5lciA9IG1hcEFTVChpbm5lclNjb3BlLCBub2RlLmNoaWxkcmVuLCByb290UmVhY3ROb2RlKTtcbiAgICAgICAgICAgICAgbWVtLnB1c2goY3JlYXRlRWxlbWVudChub2RlLm5hbWUsIHtcbiAgICAgICAgICAgICAgICBrZXk6IGAke25vZGUubmFtZX0tJHtpfWBcbiAgICAgICAgICAgICAgfSwgaW5uZXIpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2UgaWYgKG5vZGUudm9pZEVsZW1lbnQpIHtcbiAgICAgICAgICAgIG1lbS5wdXNoKGA8JHtub2RlLm5hbWV9IC8+YCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGlubmVyID0gbWFwQVNUKHJlYWN0Tm9kZXMsIG5vZGUuY2hpbGRyZW4sIHJvb3RSZWFjdE5vZGUpO1xuICAgICAgICAgICAgbWVtLnB1c2goYDwke25vZGUubmFtZX0+JHtpbm5lcn08LyR7bm9kZS5uYW1lfT5gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoaXNPYmplY3QoY2hpbGQpICYmICFpc0VsZW1lbnQpIHtcbiAgICAgICAgICBjb25zdCBjb250ZW50ID0gbm9kZS5jaGlsZHJlblswXSA/IHRyYW5zbGF0aW9uQ29udGVudCA6IG51bGw7XG4gICAgICAgICAgaWYgKGNvbnRlbnQpIG1lbS5wdXNoKGNvbnRlbnQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHB1c2hUcmFuc2xhdGVkSlNYKGNoaWxkLCB0cmFuc2xhdGlvbkNvbnRlbnQsIG1lbSwgaSwgbm9kZS5jaGlsZHJlbi5sZW5ndGggIT09IDEgfHwgIXRyYW5zbGF0aW9uQ29udGVudCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAobm9kZS50eXBlID09PSAndGV4dCcpIHtcbiAgICAgICAgY29uc3Qgd3JhcFRleHROb2RlcyA9IGkxOG5PcHRpb25zLnRyYW5zV3JhcFRleHROb2RlcztcbiAgICAgICAgY29uc3QgdW5lc2NhcGVGbiA9IHR5cGVvZiBpMThuT3B0aW9ucy51bmVzY2FwZSA9PT0gJ2Z1bmN0aW9uJyA/IGkxOG5PcHRpb25zLnVuZXNjYXBlIDogZ2V0RGVmYXVsdHMoKS51bmVzY2FwZTtcbiAgICAgICAgY29uc3QgY29udGVudCA9IHNob3VsZFVuZXNjYXBlID8gdW5lc2NhcGVGbihpMThuLnNlcnZpY2VzLmludGVycG9sYXRvci5pbnRlcnBvbGF0ZShub2RlLmNvbnRlbnQsIG9wdHMsIGkxOG4ubGFuZ3VhZ2UpKSA6IGkxOG4uc2VydmljZXMuaW50ZXJwb2xhdG9yLmludGVycG9sYXRlKG5vZGUuY29udGVudCwgb3B0cywgaTE4bi5sYW5ndWFnZSk7XG4gICAgICAgIGlmICh3cmFwVGV4dE5vZGVzKSB7XG4gICAgICAgICAgbWVtLnB1c2goY3JlYXRlRWxlbWVudCh3cmFwVGV4dE5vZGVzLCB7XG4gICAgICAgICAgICBrZXk6IGAke25vZGUubmFtZX0tJHtpfWBcbiAgICAgICAgICB9LCBjb250ZW50KSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbWVtLnB1c2goY29udGVudCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBtZW07XG4gICAgfSwgW10pO1xuICB9O1xuICBjb25zdCByZXN1bHQgPSBtYXBBU1QoW3tcbiAgICBkdW1teTogdHJ1ZSxcbiAgICBjaGlsZHJlbjogY2hpbGRyZW4gfHwgW11cbiAgfV0sIGFzdCwgZ2V0QXNBcnJheShjaGlsZHJlbiB8fCBbXSkpO1xuICByZXR1cm4gZ2V0Q2hpbGRyZW4ocmVzdWx0WzBdKTtcbn07XG5jb25zdCBmaXhDb21wb25lbnRQcm9wcyA9IChjb21wb25lbnQsIGluZGV4LCB0cmFuc2xhdGlvbikgPT4ge1xuICBjb25zdCBjb21wb25lbnRLZXkgPSBjb21wb25lbnQua2V5IHx8IGluZGV4O1xuICBjb25zdCBjb21wID0gY2xvbmVFbGVtZW50KGNvbXBvbmVudCwge1xuICAgIGtleTogY29tcG9uZW50S2V5XG4gIH0pO1xuICBpZiAoIWNvbXAucHJvcHMgfHwgIWNvbXAucHJvcHMuY2hpbGRyZW4gfHwgdHJhbnNsYXRpb24uaW5kZXhPZihgJHtpbmRleH0vPmApIDwgMCAmJiB0cmFuc2xhdGlvbi5pbmRleE9mKGAke2luZGV4fSAvPmApIDwgMCkge1xuICAgIHJldHVybiBjb21wO1xuICB9XG4gIGZ1bmN0aW9uIENvbXBvbmVudGl6ZWQoKSB7XG4gICAgcmV0dXJuIGNyZWF0ZUVsZW1lbnQoRnJhZ21lbnQsIG51bGwsIGNvbXApO1xuICB9XG4gIHJldHVybiBjcmVhdGVFbGVtZW50KENvbXBvbmVudGl6ZWQsIHtcbiAgICBrZXk6IGNvbXBvbmVudEtleVxuICB9KTtcbn07XG5jb25zdCBnZW5lcmF0ZUFycmF5Q29tcG9uZW50cyA9IChjb21wb25lbnRzLCB0cmFuc2xhdGlvbikgPT4gY29tcG9uZW50cy5tYXAoKGMsIGluZGV4KSA9PiBmaXhDb21wb25lbnRQcm9wcyhjLCBpbmRleCwgdHJhbnNsYXRpb24pKTtcbmNvbnN0IGdlbmVyYXRlT2JqZWN0Q29tcG9uZW50cyA9IChjb21wb25lbnRzLCB0cmFuc2xhdGlvbikgPT4ge1xuICBjb25zdCBjb21wb25lbnRNYXAgPSB7fTtcbiAgT2JqZWN0LmtleXMoY29tcG9uZW50cykuZm9yRWFjaChjID0+IHtcbiAgICBPYmplY3QuYXNzaWduKGNvbXBvbmVudE1hcCwge1xuICAgICAgW2NdOiBmaXhDb21wb25lbnRQcm9wcyhjb21wb25lbnRzW2NdLCBjLCB0cmFuc2xhdGlvbilcbiAgICB9KTtcbiAgfSk7XG4gIHJldHVybiBjb21wb25lbnRNYXA7XG59O1xuY29uc3QgZ2VuZXJhdGVDb21wb25lbnRzID0gKGNvbXBvbmVudHMsIHRyYW5zbGF0aW9uLCBpMThuLCBpMThuS2V5KSA9PiB7XG4gIGlmICghY29tcG9uZW50cykgcmV0dXJuIG51bGw7XG4gIGlmIChBcnJheS5pc0FycmF5KGNvbXBvbmVudHMpKSB7XG4gICAgcmV0dXJuIGdlbmVyYXRlQXJyYXlDb21wb25lbnRzKGNvbXBvbmVudHMsIHRyYW5zbGF0aW9uKTtcbiAgfVxuICBpZiAoaXNPYmplY3QoY29tcG9uZW50cykpIHtcbiAgICByZXR1cm4gZ2VuZXJhdGVPYmplY3RDb21wb25lbnRzKGNvbXBvbmVudHMsIHRyYW5zbGF0aW9uKTtcbiAgfVxuICB3YXJuT25jZShpMThuLCAnVFJBTlNfSU5WQUxJRF9DT01QT05FTlRTJywgYDxUcmFucyAvPiBcImNvbXBvbmVudHNcIiBwcm9wIGV4cGVjdHMgYW4gb2JqZWN0IG9yIGFycmF5YCwge1xuICAgIGkxOG5LZXlcbiAgfSk7XG4gIHJldHVybiBudWxsO1xufTtcbmNvbnN0IGlzQ29tcG9uZW50c01hcCA9IG9iamVjdCA9PiB7XG4gIGlmICghaXNPYmplY3Qob2JqZWN0KSkgcmV0dXJuIGZhbHNlO1xuICBpZiAoQXJyYXkuaXNBcnJheShvYmplY3QpKSByZXR1cm4gZmFsc2U7XG4gIHJldHVybiBPYmplY3Qua2V5cyhvYmplY3QpLnJlZHVjZSgoYWNjLCBrZXkpID0+IGFjYyAmJiBOdW1iZXIuaXNOYU4oTnVtYmVyLnBhcnNlRmxvYXQoa2V5KSksIHRydWUpO1xufTtcbmV4cG9ydCBmdW5jdGlvbiBUcmFucyh7XG4gIGNoaWxkcmVuLFxuICBjb3VudCxcbiAgcGFyZW50LFxuICBpMThuS2V5LFxuICBjb250ZXh0LFxuICB0T3B0aW9ucyA9IHt9LFxuICB2YWx1ZXMsXG4gIGRlZmF1bHRzLFxuICBjb21wb25lbnRzLFxuICBucyxcbiAgaTE4bjogaTE4bkZyb21Qcm9wcyxcbiAgdDogdEZyb21Qcm9wcyxcbiAgc2hvdWxkVW5lc2NhcGUsXG4gIC4uLmFkZGl0aW9uYWxQcm9wc1xufSkge1xuICBjb25zdCBpMThuID0gaTE4bkZyb21Qcm9wcyB8fCBnZXRJMThuKCk7XG4gIGlmICghaTE4bikge1xuICAgIHdhcm5PbmNlKGkxOG4sICdOT19JMThORVhUX0lOU1RBTkNFJywgYFRyYW5zOiBZb3UgbmVlZCB0byBwYXNzIGluIGFuIGkxOG5leHQgaW5zdGFuY2UgdXNpbmcgaW5pdFJlYWN0STE4bmV4dCBvciBieSBwYXNzaW5nIGl0IHZpYSBwcm9wcyBvciBjb250ZXh0LiBJbiBtb25vcmVwbyBzZXR1cHMsIG1ha2Ugc3VyZSB0aGVyZSBpcyBvbmx5IG9uZSBpbnN0YW5jZSBvZiByZWFjdC1pMThuZXh0LmAsIHtcbiAgICAgIGkxOG5LZXlcbiAgICB9KTtcbiAgICByZXR1cm4gY2hpbGRyZW47XG4gIH1cbiAgY29uc3QgdCA9IHRGcm9tUHJvcHMgfHwgaTE4bi50LmJpbmQoaTE4bikgfHwgKGsgPT4gayk7XG4gIGNvbnN0IHJlYWN0STE4bmV4dE9wdGlvbnMgPSB7XG4gICAgLi4uZ2V0RGVmYXVsdHMoKSxcbiAgICAuLi5pMThuLm9wdGlvbnM/LnJlYWN0XG4gIH07XG4gIGxldCBuYW1lc3BhY2VzID0gbnMgfHwgdC5ucyB8fCBpMThuLm9wdGlvbnM/LmRlZmF1bHROUztcbiAgbmFtZXNwYWNlcyA9IGlzU3RyaW5nKG5hbWVzcGFjZXMpID8gW25hbWVzcGFjZXNdIDogbmFtZXNwYWNlcyB8fCBbJ3RyYW5zbGF0aW9uJ107XG4gIGNvbnN0IHtcbiAgICB0cmFuc0RlZmF1bHRQcm9wc1xuICB9ID0gcmVhY3RJMThuZXh0T3B0aW9ucztcbiAgY29uc3QgbWVyZ2VkVE9wdGlvbnMgPSB0cmFuc0RlZmF1bHRQcm9wcz8udE9wdGlvbnMgPyB7XG4gICAgLi4udHJhbnNEZWZhdWx0UHJvcHMudE9wdGlvbnMsXG4gICAgLi4udE9wdGlvbnNcbiAgfSA6IHRPcHRpb25zO1xuICBjb25zdCBtZXJnZWRTaG91bGRVbmVzY2FwZSA9IHNob3VsZFVuZXNjYXBlID8/IHRyYW5zRGVmYXVsdFByb3BzPy5zaG91bGRVbmVzY2FwZTtcbiAgY29uc3QgbWVyZ2VkVmFsdWVzID0gdHJhbnNEZWZhdWx0UHJvcHM/LnZhbHVlcyA/IHtcbiAgICAuLi50cmFuc0RlZmF1bHRQcm9wcy52YWx1ZXMsXG4gICAgLi4udmFsdWVzXG4gIH0gOiB2YWx1ZXM7XG4gIGNvbnN0IG1lcmdlZENvbXBvbmVudHMgPSB0cmFuc0RlZmF1bHRQcm9wcz8uY29tcG9uZW50cyA/IHtcbiAgICAuLi50cmFuc0RlZmF1bHRQcm9wcy5jb21wb25lbnRzLFxuICAgIC4uLmNvbXBvbmVudHNcbiAgfSA6IGNvbXBvbmVudHM7XG4gIGNvbnN0IG5vZGVBc1N0cmluZyA9IG5vZGVzVG9TdHJpbmcoY2hpbGRyZW4sIHJlYWN0STE4bmV4dE9wdGlvbnMsIGkxOG4sIGkxOG5LZXkpO1xuICBjb25zdCBkZWZhdWx0VmFsdWUgPSBkZWZhdWx0cyB8fCBtZXJnZWRUT3B0aW9ucz8uZGVmYXVsdFZhbHVlIHx8IG5vZGVBc1N0cmluZyB8fCByZWFjdEkxOG5leHRPcHRpb25zLnRyYW5zRW1wdHlOb2RlVmFsdWUgfHwgKHR5cGVvZiBpMThuS2V5ID09PSAnZnVuY3Rpb24nID8ga2V5RnJvbVNlbGVjdG9yKGkxOG5LZXkpIDogaTE4bktleSk7XG4gIGNvbnN0IHtcbiAgICBoYXNoVHJhbnNLZXlcbiAgfSA9IHJlYWN0STE4bmV4dE9wdGlvbnM7XG4gIGNvbnN0IGtleSA9IGkxOG5LZXkgfHwgKGhhc2hUcmFuc0tleSA/IGhhc2hUcmFuc0tleShub2RlQXNTdHJpbmcgfHwgZGVmYXVsdFZhbHVlKSA6IG5vZGVBc1N0cmluZyB8fCBkZWZhdWx0VmFsdWUpO1xuICBpZiAoaTE4bi5vcHRpb25zPy5pbnRlcnBvbGF0aW9uPy5kZWZhdWx0VmFyaWFibGVzKSB7XG4gICAgdmFsdWVzID0gbWVyZ2VkVmFsdWVzICYmIE9iamVjdC5rZXlzKG1lcmdlZFZhbHVlcykubGVuZ3RoID4gMCA/IHtcbiAgICAgIC4uLm1lcmdlZFZhbHVlcyxcbiAgICAgIC4uLmkxOG4ub3B0aW9ucy5pbnRlcnBvbGF0aW9uLmRlZmF1bHRWYXJpYWJsZXNcbiAgICB9IDoge1xuICAgICAgLi4uaTE4bi5vcHRpb25zLmludGVycG9sYXRpb24uZGVmYXVsdFZhcmlhYmxlc1xuICAgIH07XG4gIH0gZWxzZSB7XG4gICAgdmFsdWVzID0gbWVyZ2VkVmFsdWVzO1xuICB9XG4gIGNvbnN0IHZhbHVlc0Zyb21DaGlsZHJlbiA9IGdldFZhbHVlc0Zyb21DaGlsZHJlbihjaGlsZHJlbik7XG4gIGlmICh2YWx1ZXNGcm9tQ2hpbGRyZW4gJiYgdHlwZW9mIHZhbHVlc0Zyb21DaGlsZHJlbi5jb3VudCA9PT0gJ251bWJlcicgJiYgY291bnQgPT09IHVuZGVmaW5lZCkge1xuICAgIGNvdW50ID0gdmFsdWVzRnJvbUNoaWxkcmVuLmNvdW50O1xuICB9XG4gIGNvbnN0IGludGVycG9sYXRpb25PdmVycmlkZSA9IHZhbHVlcyB8fCBjb3VudCAhPT0gdW5kZWZpbmVkICYmICFpMThuLm9wdGlvbnM/LmludGVycG9sYXRpb24/LmFsd2F5c0Zvcm1hdCB8fCAhY2hpbGRyZW4gPyBtZXJnZWRUT3B0aW9ucy5pbnRlcnBvbGF0aW9uIDoge1xuICAgIGludGVycG9sYXRpb246IHtcbiAgICAgIC4uLm1lcmdlZFRPcHRpb25zLmludGVycG9sYXRpb24sXG4gICAgICBwcmVmaXg6ICcjJD8nLFxuICAgICAgc3VmZml4OiAnPyQjJ1xuICAgIH1cbiAgfTtcbiAgY29uc3QgY29tYmluZWRUT3B0cyA9IHtcbiAgICAuLi5tZXJnZWRUT3B0aW9ucyxcbiAgICBjb250ZXh0OiBjb250ZXh0IHx8IG1lcmdlZFRPcHRpb25zLmNvbnRleHQsXG4gICAgY291bnQsXG4gICAgLi4udmFsdWVzLFxuICAgIC4uLmludGVycG9sYXRpb25PdmVycmlkZSxcbiAgICBkZWZhdWx0VmFsdWUsXG4gICAgbnM6IG5hbWVzcGFjZXNcbiAgfTtcbiAgbGV0IHRyYW5zbGF0aW9uID0ga2V5ID8gdChrZXksIGNvbWJpbmVkVE9wdHMpIDogZGVmYXVsdFZhbHVlO1xuICBpZiAodHJhbnNsYXRpb24gPT09IGtleSAmJiBkZWZhdWx0VmFsdWUpIHRyYW5zbGF0aW9uID0gZGVmYXVsdFZhbHVlO1xuICBjb25zdCBnZW5lcmF0ZWRDb21wb25lbnRzID0gZ2VuZXJhdGVDb21wb25lbnRzKG1lcmdlZENvbXBvbmVudHMsIHRyYW5zbGF0aW9uLCBpMThuLCBpMThuS2V5KTtcbiAgbGV0IGluZGV4ZWRDaGlsZHJlbiA9IGdlbmVyYXRlZENvbXBvbmVudHMgfHwgY2hpbGRyZW47XG4gIGxldCBjb21wb25lbnRzTWFwID0gbnVsbDtcbiAgaWYgKGlzQ29tcG9uZW50c01hcChnZW5lcmF0ZWRDb21wb25lbnRzKSkge1xuICAgIGNvbXBvbmVudHNNYXAgPSBnZW5lcmF0ZWRDb21wb25lbnRzO1xuICAgIGluZGV4ZWRDaGlsZHJlbiA9IGNoaWxkcmVuO1xuICB9XG4gIGNvbnN0IGNvbnRlbnQgPSByZW5kZXJOb2RlcyhpbmRleGVkQ2hpbGRyZW4sIGNvbXBvbmVudHNNYXAsIHRyYW5zbGF0aW9uLCBpMThuLCByZWFjdEkxOG5leHRPcHRpb25zLCBjb21iaW5lZFRPcHRzLCBtZXJnZWRTaG91bGRVbmVzY2FwZSk7XG4gIGNvbnN0IHVzZUFzUGFyZW50ID0gcGFyZW50ID8/IHJlYWN0STE4bmV4dE9wdGlvbnMuZGVmYXVsdFRyYW5zUGFyZW50O1xuICByZXR1cm4gdXNlQXNQYXJlbnQgPyBjcmVhdGVFbGVtZW50KHVzZUFzUGFyZW50LCBhZGRpdGlvbmFsUHJvcHMsIGNvbnRlbnQpIDogY29udGVudDtcbn0iLCJpbXBvcnQgeyBzZXREZWZhdWx0cyB9IGZyb20gJy4vZGVmYXVsdHMuanMnO1xuaW1wb3J0IHsgc2V0STE4biB9IGZyb20gJy4vaTE4bkluc3RhbmNlLmpzJztcbmV4cG9ydCBjb25zdCBpbml0UmVhY3RJMThuZXh0ID0ge1xuICB0eXBlOiAnM3JkUGFydHknLFxuICBpbml0KGluc3RhbmNlKSB7XG4gICAgc2V0RGVmYXVsdHMoaW5zdGFuY2Uub3B0aW9ucy5yZWFjdCk7XG4gICAgc2V0STE4bihpbnN0YW5jZSk7XG4gIH1cbn07IiwiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGdldERlZmF1bHRzLCBzZXREZWZhdWx0cyB9IGZyb20gJy4vZGVmYXVsdHMuanMnO1xuaW1wb3J0IHsgZ2V0STE4biwgc2V0STE4biB9IGZyb20gJy4vaTE4bkluc3RhbmNlLmpzJztcbmltcG9ydCB7IGluaXRSZWFjdEkxOG5leHQgfSBmcm9tICcuL2luaXRSZWFjdEkxOG5leHQuanMnO1xuZXhwb3J0IHsgZ2V0RGVmYXVsdHMsIHNldERlZmF1bHRzLCBnZXRJMThuLCBzZXRJMThuLCBpbml0UmVhY3RJMThuZXh0IH07XG5leHBvcnQgY29uc3QgSTE4bkNvbnRleHQgPSBjcmVhdGVDb250ZXh0KCk7XG5leHBvcnQgY2xhc3MgUmVwb3J0TmFtZXNwYWNlcyB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMudXNlZE5hbWVzcGFjZXMgPSB7fTtcbiAgfVxuICBhZGRVc2VkTmFtZXNwYWNlcyhuYW1lc3BhY2VzKSB7XG4gICAgbmFtZXNwYWNlcy5mb3JFYWNoKG5zID0+IHtcbiAgICAgIGlmICghdGhpcy51c2VkTmFtZXNwYWNlc1tuc10pIHRoaXMudXNlZE5hbWVzcGFjZXNbbnNdID0gdHJ1ZTtcbiAgICB9KTtcbiAgfVxuICBnZXRVc2VkTmFtZXNwYWNlcygpIHtcbiAgICByZXR1cm4gT2JqZWN0LmtleXModGhpcy51c2VkTmFtZXNwYWNlcyk7XG4gIH1cbn1cbmV4cG9ydCBjb25zdCBjb21wb3NlSW5pdGlhbFByb3BzID0gRm9yQ29tcG9uZW50ID0+IGFzeW5jIGN0eCA9PiB7XG4gIGNvbnN0IGNvbXBvbmVudHNJbml0aWFsUHJvcHMgPSAoYXdhaXQgRm9yQ29tcG9uZW50LmdldEluaXRpYWxQcm9wcz8uKGN0eCkpID8/IHt9O1xuICBjb25zdCBpMThuSW5pdGlhbFByb3BzID0gZ2V0SW5pdGlhbFByb3BzKCk7XG4gIHJldHVybiB7XG4gICAgLi4uY29tcG9uZW50c0luaXRpYWxQcm9wcyxcbiAgICAuLi5pMThuSW5pdGlhbFByb3BzXG4gIH07XG59O1xuZXhwb3J0IGNvbnN0IGdldEluaXRpYWxQcm9wcyA9ICgpID0+IHtcbiAgY29uc3QgaTE4biA9IGdldEkxOG4oKTtcbiAgaWYgKCFpMThuKSB7XG4gICAgY29uc29sZS53YXJuKCdyZWFjdC1pMThuZXh0OjogZ2V0SW5pdGlhbFByb3BzOiBZb3Ugd2lsbCBuZWVkIHRvIHBhc3MgaW4gYW4gaTE4bmV4dCBpbnN0YW5jZSBieSB1c2luZyBpbml0UmVhY3RJMThuZXh0Jyk7XG4gICAgcmV0dXJuIHt9O1xuICB9XG4gIGNvbnN0IG5hbWVzcGFjZXMgPSBpMThuLnJlcG9ydE5hbWVzcGFjZXM/LmdldFVzZWROYW1lc3BhY2VzKCkgPz8gW107XG4gIGNvbnN0IHJldCA9IHt9O1xuICBjb25zdCBpbml0aWFsSTE4blN0b3JlID0ge307XG4gIGkxOG4ubGFuZ3VhZ2VzLmZvckVhY2gobCA9PiB7XG4gICAgaW5pdGlhbEkxOG5TdG9yZVtsXSA9IHt9O1xuICAgIG5hbWVzcGFjZXMuZm9yRWFjaChucyA9PiB7XG4gICAgICBpbml0aWFsSTE4blN0b3JlW2xdW25zXSA9IGkxOG4uZ2V0UmVzb3VyY2VCdW5kbGUobCwgbnMpIHx8IHt9O1xuICAgIH0pO1xuICB9KTtcbiAgcmV0LmluaXRpYWxJMThuU3RvcmUgPSBpbml0aWFsSTE4blN0b3JlO1xuICByZXQuaW5pdGlhbExhbmd1YWdlID0gaTE4bi5sYW5ndWFnZTtcbiAgcmV0dXJuIHJldDtcbn07IiwiaW1wb3J0IHsgdXNlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG5vZGVzVG9TdHJpbmcsIFRyYW5zIGFzIFRyYW5zV2l0aG91dENvbnRleHQgfSBmcm9tICcuL1RyYW5zV2l0aG91dENvbnRleHQuanMnO1xuaW1wb3J0IHsgZ2V0STE4biwgSTE4bkNvbnRleHQgfSBmcm9tICcuL2NvbnRleHQuanMnO1xuZXhwb3J0IHsgbm9kZXNUb1N0cmluZyB9O1xuZXhwb3J0IGZ1bmN0aW9uIFRyYW5zKHtcbiAgY2hpbGRyZW4sXG4gIGNvdW50LFxuICBwYXJlbnQsXG4gIGkxOG5LZXksXG4gIGNvbnRleHQsXG4gIHRPcHRpb25zID0ge30sXG4gIHZhbHVlcyxcbiAgZGVmYXVsdHMsXG4gIGNvbXBvbmVudHMsXG4gIG5zLFxuICBpMThuOiBpMThuRnJvbVByb3BzLFxuICB0OiB0RnJvbVByb3BzLFxuICBzaG91bGRVbmVzY2FwZSxcbiAgLi4uYWRkaXRpb25hbFByb3BzXG59KSB7XG4gIGNvbnN0IHtcbiAgICBpMThuOiBpMThuRnJvbUNvbnRleHQsXG4gICAgZGVmYXVsdE5TOiBkZWZhdWx0TlNGcm9tQ29udGV4dFxuICB9ID0gdXNlQ29udGV4dChJMThuQ29udGV4dCkgfHwge307XG4gIGNvbnN0IGkxOG4gPSBpMThuRnJvbVByb3BzIHx8IGkxOG5Gcm9tQ29udGV4dCB8fCBnZXRJMThuKCk7XG4gIGNvbnN0IHQgPSB0RnJvbVByb3BzIHx8IGkxOG4/LnQuYmluZChpMThuKTtcbiAgcmV0dXJuIFRyYW5zV2l0aG91dENvbnRleHQoe1xuICAgIGNoaWxkcmVuLFxuICAgIGNvdW50LFxuICAgIHBhcmVudCxcbiAgICBpMThuS2V5LFxuICAgIGNvbnRleHQsXG4gICAgdE9wdGlvbnMsXG4gICAgdmFsdWVzLFxuICAgIGRlZmF1bHRzLFxuICAgIGNvbXBvbmVudHMsXG4gICAgbnM6IG5zIHx8IHQ/Lm5zIHx8IGRlZmF1bHROU0Zyb21Db250ZXh0IHx8IGkxOG4/Lm9wdGlvbnM/LmRlZmF1bHROUyxcbiAgICBpMThuLFxuICAgIHQ6IHRGcm9tUHJvcHMsXG4gICAgc2hvdWxkVW5lc2NhcGUsXG4gICAgLi4uYWRkaXRpb25hbFByb3BzXG4gIH0pO1xufSIsImV4cG9ydCBjbGFzcyBUcmFuc2xhdGlvblBhcnNlckVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBwb3NpdGlvbiwgdHJhbnNsYXRpb25TdHJpbmcpIHtcbiAgICBzdXBlcihtZXNzYWdlKTtcbiAgICB0aGlzLm5hbWUgPSAnVHJhbnNsYXRpb25QYXJzZXJFcnJvcic7XG4gICAgdGhpcy5wb3NpdGlvbiA9IHBvc2l0aW9uO1xuICAgIHRoaXMudHJhbnNsYXRpb25TdHJpbmcgPSB0cmFuc2xhdGlvblN0cmluZztcbiAgICBpZiAoRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2UpIHtcbiAgICAgIEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKHRoaXMsIFRyYW5zbGF0aW9uUGFyc2VyRXJyb3IpO1xuICAgIH1cbiAgfVxufSIsImNvbnN0IGNvbW1vbkVudGl0aWVzID0ge1xuICAnJm5ic3A7JzogJ1xcdTAwQTAnLFxuICAnJmFtcDsnOiAnJicsXG4gICcmbHQ7JzogJzwnLFxuICAnJmd0Oyc6ICc+JyxcbiAgJyZxdW90Oyc6ICdcIicsXG4gICcmYXBvczsnOiBcIidcIixcbiAgJyZjb3B5Oyc6ICfCqScsXG4gICcmcmVnOyc6ICfCricsXG4gICcmdHJhZGU7JzogJ+KEoicsXG4gICcmaGVsbGlwOyc6ICfigKYnLFxuICAnJm5kYXNoOyc6ICfigJMnLFxuICAnJm1kYXNoOyc6ICfigJQnLFxuICAnJmxzcXVvOyc6ICdcXHUyMDE4JyxcbiAgJyZyc3F1bzsnOiAnXFx1MjAxOScsXG4gICcmc2JxdW87JzogJ1xcdTIwMUEnLFxuICAnJmxkcXVvOyc6ICdcXHUyMDFDJyxcbiAgJyZyZHF1bzsnOiAnXFx1MjAxRCcsXG4gICcmYmRxdW87JzogJ1xcdTIwMUUnLFxuICAnJmRhZ2dlcjsnOiAn4oCgJyxcbiAgJyZEYWdnZXI7JzogJ+KAoScsXG4gICcmYnVsbDsnOiAn4oCiJyxcbiAgJyZwcmltZTsnOiAn4oCyJyxcbiAgJyZQcmltZTsnOiAn4oCzJyxcbiAgJyZsc2FxdW87JzogJ+KAuScsXG4gICcmcnNhcXVvOyc6ICfigLonLFxuICAnJnNlY3Q7JzogJ8KnJyxcbiAgJyZwYXJhOyc6ICfCticsXG4gICcmbWlkZG90Oyc6ICfCtycsXG4gICcmZW5zcDsnOiAnXFx1MjAwMicsXG4gICcmZW1zcDsnOiAnXFx1MjAwMycsXG4gICcmdGhpbnNwOyc6ICdcXHUyMDA5JyxcbiAgJyZldXJvOyc6ICfigqwnLFxuICAnJnBvdW5kOyc6ICfCoycsXG4gICcmeWVuOyc6ICfCpScsXG4gICcmY2VudDsnOiAnwqInLFxuICAnJmN1cnJlbjsnOiAnwqQnLFxuICAnJnRpbWVzOyc6ICfDlycsXG4gICcmZGl2aWRlOyc6ICfDtycsXG4gICcmbWludXM7JzogJ+KIkicsXG4gICcmcGx1c21uOyc6ICfCsScsXG4gICcmbmU7JzogJ+KJoCcsXG4gICcmbGU7JzogJ+KJpCcsXG4gICcmZ2U7JzogJ+KJpScsXG4gICcmYXN5bXA7JzogJ+KJiCcsXG4gICcmZXF1aXY7JzogJ+KJoScsXG4gICcmaW5maW47JzogJ+KInicsXG4gICcmaW50Oyc6ICfiiKsnLFxuICAnJnN1bTsnOiAn4oiRJyxcbiAgJyZwcm9kOyc6ICfiiI8nLFxuICAnJnJhZGljOyc6ICfiiJonLFxuICAnJnBhcnQ7JzogJ+KIgicsXG4gICcmcGVybWlsOyc6ICfigLAnLFxuICAnJmRlZzsnOiAnwrAnLFxuICAnJm1pY3JvOyc6ICfCtScsXG4gICcmbGFycjsnOiAn4oaQJyxcbiAgJyZ1YXJyOyc6ICfihpEnLFxuICAnJnJhcnI7JzogJ+KGkicsXG4gICcmZGFycjsnOiAn4oaTJyxcbiAgJyZoYXJyOyc6ICfihpQnLFxuICAnJmNyYXJyOyc6ICfihrUnLFxuICAnJmxBcnI7JzogJ+KHkCcsXG4gICcmdUFycjsnOiAn4oeRJyxcbiAgJyZyQXJyOyc6ICfih5InLFxuICAnJmRBcnI7JzogJ+KHkycsXG4gICcmaEFycjsnOiAn4oeUJyxcbiAgJyZhbHBoYTsnOiAnzrEnLFxuICAnJmJldGE7JzogJ86yJyxcbiAgJyZnYW1tYTsnOiAnzrMnLFxuICAnJmRlbHRhOyc6ICfOtCcsXG4gICcmZXBzaWxvbjsnOiAnzrUnLFxuICAnJnpldGE7JzogJ862JyxcbiAgJyZldGE7JzogJ863JyxcbiAgJyZ0aGV0YTsnOiAnzrgnLFxuICAnJmlvdGE7JzogJ865JyxcbiAgJyZrYXBwYTsnOiAnzronLFxuICAnJmxhbWJkYTsnOiAnzrsnLFxuICAnJm11Oyc6ICfOvCcsXG4gICcmbnU7JzogJ869JyxcbiAgJyZ4aTsnOiAnzr4nLFxuICAnJm9taWNyb247JzogJ86/JyxcbiAgJyZwaTsnOiAnz4AnLFxuICAnJnJobzsnOiAnz4EnLFxuICAnJnNpZ21hOyc6ICfPgycsXG4gICcmdGF1Oyc6ICfPhCcsXG4gICcmdXBzaWxvbjsnOiAnz4UnLFxuICAnJnBoaTsnOiAnz4YnLFxuICAnJmNoaTsnOiAnz4cnLFxuICAnJnBzaTsnOiAnz4gnLFxuICAnJm9tZWdhOyc6ICfPiScsXG4gICcmQWxwaGE7JzogJ86RJyxcbiAgJyZCZXRhOyc6ICfOkicsXG4gICcmR2FtbWE7JzogJ86TJyxcbiAgJyZEZWx0YTsnOiAnzpQnLFxuICAnJkVwc2lsb247JzogJ86VJyxcbiAgJyZaZXRhOyc6ICfOlicsXG4gICcmRXRhOyc6ICfOlycsXG4gICcmVGhldGE7JzogJ86YJyxcbiAgJyZJb3RhOyc6ICfOmScsXG4gICcmS2FwcGE7JzogJ86aJyxcbiAgJyZMYW1iZGE7JzogJ86bJyxcbiAgJyZNdTsnOiAnzpwnLFxuICAnJk51Oyc6ICfOnScsXG4gICcmWGk7JzogJ86eJyxcbiAgJyZPbWljcm9uOyc6ICfOnycsXG4gICcmUGk7JzogJ86gJyxcbiAgJyZSaG87JzogJ86hJyxcbiAgJyZTaWdtYTsnOiAnzqMnLFxuICAnJlRhdTsnOiAnzqQnLFxuICAnJlVwc2lsb247JzogJ86lJyxcbiAgJyZQaGk7JzogJ86mJyxcbiAgJyZDaGk7JzogJ86nJyxcbiAgJyZQc2k7JzogJ86oJyxcbiAgJyZPbWVnYTsnOiAnzqknLFxuICAnJkFncmF2ZTsnOiAnw4AnLFxuICAnJkFhY3V0ZTsnOiAnw4EnLFxuICAnJkFjaXJjOyc6ICfDgicsXG4gICcmQXRpbGRlOyc6ICfDgycsXG4gICcmQXVtbDsnOiAnw4QnLFxuICAnJkFyaW5nOyc6ICfDhScsXG4gICcmQUVsaWc7JzogJ8OGJyxcbiAgJyZDY2VkaWw7JzogJ8OHJyxcbiAgJyZFZ3JhdmU7JzogJ8OIJyxcbiAgJyZFYWN1dGU7JzogJ8OJJyxcbiAgJyZFY2lyYzsnOiAnw4onLFxuICAnJkV1bWw7JzogJ8OLJyxcbiAgJyZJZ3JhdmU7JzogJ8OMJyxcbiAgJyZJYWN1dGU7JzogJ8ONJyxcbiAgJyZJY2lyYzsnOiAnw44nLFxuICAnJkl1bWw7JzogJ8OPJyxcbiAgJyZFVEg7JzogJ8OQJyxcbiAgJyZOdGlsZGU7JzogJ8ORJyxcbiAgJyZPZ3JhdmU7JzogJ8OSJyxcbiAgJyZPYWN1dGU7JzogJ8OTJyxcbiAgJyZPY2lyYzsnOiAnw5QnLFxuICAnJk90aWxkZTsnOiAnw5UnLFxuICAnJk91bWw7JzogJ8OWJyxcbiAgJyZPc2xhc2g7JzogJ8OYJyxcbiAgJyZVZ3JhdmU7JzogJ8OZJyxcbiAgJyZVYWN1dGU7JzogJ8OaJyxcbiAgJyZVY2lyYzsnOiAnw5snLFxuICAnJlV1bWw7JzogJ8OcJyxcbiAgJyZZYWN1dGU7JzogJ8OdJyxcbiAgJyZUSE9STjsnOiAnw54nLFxuICAnJnN6bGlnOyc6ICfDnycsXG4gICcmYWdyYXZlOyc6ICfDoCcsXG4gICcmYWFjdXRlOyc6ICfDoScsXG4gICcmYWNpcmM7JzogJ8OiJyxcbiAgJyZhdGlsZGU7JzogJ8OjJyxcbiAgJyZhdW1sOyc6ICfDpCcsXG4gICcmYXJpbmc7JzogJ8OlJyxcbiAgJyZhZWxpZzsnOiAnw6YnLFxuICAnJmNjZWRpbDsnOiAnw6cnLFxuICAnJmVncmF2ZTsnOiAnw6gnLFxuICAnJmVhY3V0ZTsnOiAnw6knLFxuICAnJmVjaXJjOyc6ICfDqicsXG4gICcmZXVtbDsnOiAnw6snLFxuICAnJmlncmF2ZTsnOiAnw6wnLFxuICAnJmlhY3V0ZTsnOiAnw60nLFxuICAnJmljaXJjOyc6ICfDricsXG4gICcmaXVtbDsnOiAnw68nLFxuICAnJmV0aDsnOiAnw7AnLFxuICAnJm50aWxkZTsnOiAnw7EnLFxuICAnJm9ncmF2ZTsnOiAnw7InLFxuICAnJm9hY3V0ZTsnOiAnw7MnLFxuICAnJm9jaXJjOyc6ICfDtCcsXG4gICcmb3RpbGRlOyc6ICfDtScsXG4gICcmb3VtbDsnOiAnw7YnLFxuICAnJm9zbGFzaDsnOiAnw7gnLFxuICAnJnVncmF2ZTsnOiAnw7knLFxuICAnJnVhY3V0ZTsnOiAnw7onLFxuICAnJnVjaXJjOyc6ICfDuycsXG4gICcmdXVtbDsnOiAnw7wnLFxuICAnJnlhY3V0ZTsnOiAnw70nLFxuICAnJnRob3JuOyc6ICfDvicsXG4gICcmeXVtbDsnOiAnw78nLFxuICAnJmlleGNsOyc6ICfCoScsXG4gICcmaXF1ZXN0Oyc6ICfCvycsXG4gICcmZm5vZjsnOiAnxpInLFxuICAnJmNpcmM7JzogJ8uGJyxcbiAgJyZ0aWxkZTsnOiAny5wnLFxuICAnJk9FbGlnOyc6ICfFkicsXG4gICcmb2VsaWc7JzogJ8WTJyxcbiAgJyZTY2Fyb247JzogJ8WgJyxcbiAgJyZzY2Fyb247JzogJ8WhJyxcbiAgJyZZdW1sOyc6ICfFuCcsXG4gICcmb3JkZjsnOiAnwqonLFxuICAnJm9yZG07JzogJ8K6JyxcbiAgJyZtYWNyOyc6ICfCrycsXG4gICcmYWN1dGU7JzogJ8K0JyxcbiAgJyZjZWRpbDsnOiAnwrgnLFxuICAnJnN1cDE7JzogJ8K5JyxcbiAgJyZzdXAyOyc6ICfCsicsXG4gICcmc3VwMzsnOiAnwrMnLFxuICAnJmZyYWMxNDsnOiAnwrwnLFxuICAnJmZyYWMxMjsnOiAnwr0nLFxuICAnJmZyYWMzNDsnOiAnwr4nLFxuICAnJnNwYWRlczsnOiAn4pmgJyxcbiAgJyZjbHViczsnOiAn4pmjJyxcbiAgJyZoZWFydHM7JzogJ+KZpScsXG4gICcmZGlhbXM7JzogJ+KZpicsXG4gICcmbG96Oyc6ICfil4onLFxuICAnJm9saW5lOyc6ICfigL4nLFxuICAnJmZyYXNsOyc6ICfigYQnLFxuICAnJndlaWVycDsnOiAn4oSYJyxcbiAgJyZpbWFnZTsnOiAn4oSRJyxcbiAgJyZyZWFsOyc6ICfihJwnLFxuICAnJmFsZWZzeW07JzogJ+KEtSdcbn07XG5jb25zdCBlbnRpdHlQYXR0ZXJuID0gbmV3IFJlZ0V4cChPYmplY3Qua2V5cyhjb21tb25FbnRpdGllcykubWFwKGVudGl0eSA9PiBlbnRpdHkucmVwbGFjZSgvWy4qKz9eJHt9KCl8W1xcXVxcXFxdL2csICdcXFxcJCYnKSkuam9pbignfCcpLCAnZycpO1xuZXhwb3J0IGNvbnN0IGRlY29kZUh0bWxFbnRpdGllcyA9IHRleHQgPT4gdGV4dC5yZXBsYWNlKGVudGl0eVBhdHRlcm4sIG1hdGNoID0+IGNvbW1vbkVudGl0aWVzW21hdGNoXSkucmVwbGFjZSgvJiMoXFxkKyk7L2csIChfLCBudW0pID0+IFN0cmluZy5mcm9tQ2hhckNvZGUocGFyc2VJbnQobnVtLCAxMCkpKS5yZXBsYWNlKC8mI3goWzAtOWEtZkEtRl0rKTsvZywgKF8sIGhleCkgPT4gU3RyaW5nLmZyb21DaGFyQ29kZShwYXJzZUludChoZXgsIDE2KSkpOyIsImV4cG9ydCBjb25zdCB0b2tlbml6ZSA9IHRyYW5zbGF0aW9uID0+IHtcbiAgY29uc3QgdG9rZW5zID0gW107XG4gIGxldCBwb3NpdGlvbiA9IDA7XG4gIGxldCBjdXJyZW50VGV4dCA9ICcnO1xuICBjb25zdCBmbHVzaFRleHQgPSAoKSA9PiB7XG4gICAgaWYgKGN1cnJlbnRUZXh0KSB7XG4gICAgICB0b2tlbnMucHVzaCh7XG4gICAgICAgIHR5cGU6ICdUZXh0JyxcbiAgICAgICAgdmFsdWU6IGN1cnJlbnRUZXh0LFxuICAgICAgICBwb3NpdGlvbjogcG9zaXRpb24gLSBjdXJyZW50VGV4dC5sZW5ndGhcbiAgICAgIH0pO1xuICAgICAgY3VycmVudFRleHQgPSAnJztcbiAgICB9XG4gIH07XG4gIHdoaWxlIChwb3NpdGlvbiA8IHRyYW5zbGF0aW9uLmxlbmd0aCkge1xuICAgIGNvbnN0IGNoYXIgPSB0cmFuc2xhdGlvbltwb3NpdGlvbl07XG4gICAgaWYgKGNoYXIgPT09ICc8Jykge1xuICAgICAgY29uc3QgdGFnTWF0Y2ggPSB0cmFuc2xhdGlvbi5zbGljZShwb3NpdGlvbikubWF0Y2goL148KFxcZCspPi8pO1xuICAgICAgaWYgKHRhZ01hdGNoKSB7XG4gICAgICAgIGZsdXNoVGV4dCgpO1xuICAgICAgICB0b2tlbnMucHVzaCh7XG4gICAgICAgICAgdHlwZTogJ1RhZ09wZW4nLFxuICAgICAgICAgIHZhbHVlOiB0YWdNYXRjaFswXSxcbiAgICAgICAgICBwb3NpdGlvbixcbiAgICAgICAgICB0YWdOdW1iZXI6IHBhcnNlSW50KHRhZ01hdGNoWzFdLCAxMClcbiAgICAgICAgfSk7XG4gICAgICAgIHBvc2l0aW9uICs9IHRhZ01hdGNoWzBdLmxlbmd0aDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGNsb3NlVGFnTWF0Y2ggPSB0cmFuc2xhdGlvbi5zbGljZShwb3NpdGlvbikubWF0Y2goL148XFwvKFxcZCspPi8pO1xuICAgICAgICBpZiAoY2xvc2VUYWdNYXRjaCkge1xuICAgICAgICAgIGZsdXNoVGV4dCgpO1xuICAgICAgICAgIHRva2Vucy5wdXNoKHtcbiAgICAgICAgICAgIHR5cGU6ICdUYWdDbG9zZScsXG4gICAgICAgICAgICB2YWx1ZTogY2xvc2VUYWdNYXRjaFswXSxcbiAgICAgICAgICAgIHBvc2l0aW9uLFxuICAgICAgICAgICAgdGFnTnVtYmVyOiBwYXJzZUludChjbG9zZVRhZ01hdGNoWzFdLCAxMClcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBwb3NpdGlvbiArPSBjbG9zZVRhZ01hdGNoWzBdLmxlbmd0aDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjdXJyZW50VGV4dCArPSBjaGFyO1xuICAgICAgICAgIHBvc2l0aW9uICs9IDE7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY3VycmVudFRleHQgKz0gY2hhcjtcbiAgICAgIHBvc2l0aW9uICs9IDE7XG4gICAgfVxuICB9XG4gIGZsdXNoVGV4dCgpO1xuICByZXR1cm4gdG9rZW5zO1xufTsiLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgVHJhbnNsYXRpb25QYXJzZXJFcnJvciB9IGZyb20gJy4vVHJhbnNsYXRpb25QYXJzZXJFcnJvci5qcyc7XG5pbXBvcnQgeyB0b2tlbml6ZSB9IGZyb20gJy4vdG9rZW5pemVyLmpzJztcbmltcG9ydCB7IGRlY29kZUh0bWxFbnRpdGllcyB9IGZyb20gJy4vaHRtbEVudGl0eURlY29kZXIuanMnO1xuY29uc3QgcmVuZGVyRGVjbGFyYXRpb25Ob2RlID0gKGRlY2xhcmF0aW9uLCBjaGlsZHJlbiwgY2hpbGREZWNsYXJhdGlvbnMpID0+IHtcbiAgY29uc3Qge1xuICAgIHR5cGUsXG4gICAgcHJvcHMgPSB7fVxuICB9ID0gZGVjbGFyYXRpb247XG4gIGlmIChwcm9wcy5jaGlsZHJlbiAmJiBBcnJheS5pc0FycmF5KHByb3BzLmNoaWxkcmVuKSAmJiBjaGlsZERlY2xhcmF0aW9ucykge1xuICAgIGNvbnN0IHtcbiAgICAgIGNoaWxkcmVuOiBfY2hpbGRyZW5Ub1JlbW92ZSxcbiAgICAgIC4uLnByb3BzV2l0aG91dENoaWxkcmVuXG4gICAgfSA9IHByb3BzO1xuICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KHR5cGUsIHByb3BzV2l0aG91dENoaWxkcmVuLCAuLi5jaGlsZHJlbik7XG4gIH1cbiAgaWYgKGNoaWxkcmVuLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KHR5cGUsIHByb3BzKTtcbiAgfVxuICBpZiAoY2hpbGRyZW4ubGVuZ3RoID09PSAxKSB7XG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQodHlwZSwgcHJvcHMsIGNoaWxkcmVuWzBdKTtcbiAgfVxuICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudCh0eXBlLCBwcm9wcywgLi4uY2hpbGRyZW4pO1xufTtcbmV4cG9ydCBjb25zdCByZW5kZXJUcmFuc2xhdGlvbiA9ICh0cmFuc2xhdGlvbiwgZGVjbGFyYXRpb25zID0gW10pID0+IHtcbiAgaWYgKCF0cmFuc2xhdGlvbikge1xuICAgIHJldHVybiBbXTtcbiAgfVxuICBjb25zdCB0b2tlbnMgPSB0b2tlbml6ZSh0cmFuc2xhdGlvbik7XG4gIGNvbnN0IHJlc3VsdCA9IFtdO1xuICBjb25zdCBzdGFjayA9IFtdO1xuICBjb25zdCBsaXRlcmFsVGFnTnVtYmVycyA9IG5ldyBTZXQoKTtcbiAgY29uc3QgZ2V0Q3VycmVudERlY2xhcmF0aW9ucyA9ICgpID0+IHtcbiAgICBpZiAoc3RhY2subGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gZGVjbGFyYXRpb25zO1xuICAgIH1cbiAgICBjb25zdCBwYXJlbnRGcmFtZSA9IHN0YWNrW3N0YWNrLmxlbmd0aCAtIDFdO1xuICAgIGlmIChwYXJlbnRGcmFtZS5kZWNsYXJhdGlvbi5wcm9wcz8uY2hpbGRyZW4gJiYgQXJyYXkuaXNBcnJheShwYXJlbnRGcmFtZS5kZWNsYXJhdGlvbi5wcm9wcy5jaGlsZHJlbikpIHtcbiAgICAgIHJldHVybiBwYXJlbnRGcmFtZS5kZWNsYXJhdGlvbi5wcm9wcy5jaGlsZHJlbjtcbiAgICB9XG4gICAgcmV0dXJuIHBhcmVudEZyYW1lLmRlY2xhcmF0aW9ucztcbiAgfTtcbiAgdG9rZW5zLmZvckVhY2godG9rZW4gPT4ge1xuICAgIHN3aXRjaCAodG9rZW4udHlwZSkge1xuICAgICAgY2FzZSAnVGV4dCc6XG4gICAgICAgIHtcbiAgICAgICAgICBjb25zdCBkZWNvZGVkID0gZGVjb2RlSHRtbEVudGl0aWVzKHRva2VuLnZhbHVlKTtcbiAgICAgICAgICBjb25zdCB0YXJnZXRBcnJheSA9IHN0YWNrLmxlbmd0aCA+IDAgPyBzdGFja1tzdGFjay5sZW5ndGggLSAxXS5jaGlsZHJlbiA6IHJlc3VsdDtcbiAgICAgICAgICB0YXJnZXRBcnJheS5wdXNoKGRlY29kZWQpO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnVGFnT3Blbic6XG4gICAgICAgIHtcbiAgICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICB0YWdOdW1iZXJcbiAgICAgICAgICB9ID0gdG9rZW47XG4gICAgICAgICAgY29uc3QgY3VycmVudERlY2xhcmF0aW9ucyA9IGdldEN1cnJlbnREZWNsYXJhdGlvbnMoKTtcbiAgICAgICAgICBjb25zdCBkZWNsYXJhdGlvbiA9IGN1cnJlbnREZWNsYXJhdGlvbnNbdGFnTnVtYmVyXTtcbiAgICAgICAgICBpZiAoIWRlY2xhcmF0aW9uKSB7XG4gICAgICAgICAgICBsaXRlcmFsVGFnTnVtYmVycy5hZGQodGFnTnVtYmVyKTtcbiAgICAgICAgICAgIGNvbnN0IGxpdGVyYWxUZXh0ID0gYDwke3RhZ051bWJlcn0+YDtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldEFycmF5ID0gc3RhY2subGVuZ3RoID4gMCA/IHN0YWNrW3N0YWNrLmxlbmd0aCAtIDFdLmNoaWxkcmVuIDogcmVzdWx0O1xuICAgICAgICAgICAgdGFyZ2V0QXJyYXkucHVzaChsaXRlcmFsVGV4dCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgICAgc3RhY2sucHVzaCh7XG4gICAgICAgICAgICB0YWdOdW1iZXIsXG4gICAgICAgICAgICBjaGlsZHJlbjogW10sXG4gICAgICAgICAgICBwb3NpdGlvbjogdG9rZW4ucG9zaXRpb24sXG4gICAgICAgICAgICBkZWNsYXJhdGlvbixcbiAgICAgICAgICAgIGRlY2xhcmF0aW9uczogY3VycmVudERlY2xhcmF0aW9uc1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnVGFnQ2xvc2UnOlxuICAgICAgICB7XG4gICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgdGFnTnVtYmVyXG4gICAgICAgICAgfSA9IHRva2VuO1xuICAgICAgICAgIGlmIChsaXRlcmFsVGFnTnVtYmVycy5oYXModGFnTnVtYmVyKSkge1xuICAgICAgICAgICAgY29uc3QgbGl0ZXJhbFRleHQgPSBgPC8ke3RhZ051bWJlcn0+YDtcbiAgICAgICAgICAgIGNvbnN0IGxpdGVyYWxUYXJnZXRBcnJheSA9IHN0YWNrLmxlbmd0aCA+IDAgPyBzdGFja1tzdGFjay5sZW5ndGggLSAxXS5jaGlsZHJlbiA6IHJlc3VsdDtcbiAgICAgICAgICAgIGxpdGVyYWxUYXJnZXRBcnJheS5wdXNoKGxpdGVyYWxUZXh0KTtcbiAgICAgICAgICAgIGxpdGVyYWxUYWdOdW1iZXJzLmRlbGV0ZSh0YWdOdW1iZXIpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChzdGFjay5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBUcmFuc2xhdGlvblBhcnNlckVycm9yKGBVbmV4cGVjdGVkIGNsb3NpbmcgdGFnIDwvJHt0YWdOdW1iZXJ9PiBhdCBwb3NpdGlvbiAke3Rva2VuLnBvc2l0aW9ufWAsIHRva2VuLnBvc2l0aW9uLCB0cmFuc2xhdGlvbik7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IGZyYW1lID0gc3RhY2sucG9wKCk7XG4gICAgICAgICAgaWYgKGZyYW1lLnRhZ051bWJlciAhPT0gdGFnTnVtYmVyKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVHJhbnNsYXRpb25QYXJzZXJFcnJvcihgTWlzbWF0Y2hlZCB0YWdzOiBleHBlY3RlZCA8LyR7ZnJhbWUudGFnTnVtYmVyfT4gYnV0IGdvdCA8LyR7dGFnTnVtYmVyfT4gYXQgcG9zaXRpb24gJHt0b2tlbi5wb3NpdGlvbn1gLCB0b2tlbi5wb3NpdGlvbiwgdHJhbnNsYXRpb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBlbGVtZW50ID0gcmVuZGVyRGVjbGFyYXRpb25Ob2RlKGZyYW1lLmRlY2xhcmF0aW9uLCBmcmFtZS5jaGlsZHJlbiwgZnJhbWUuZGVjbGFyYXRpb25zKTtcbiAgICAgICAgICBjb25zdCBlbGVtZW50VGFyZ2V0QXJyYXkgPSBzdGFjay5sZW5ndGggPiAwID8gc3RhY2tbc3RhY2subGVuZ3RoIC0gMV0uY2hpbGRyZW4gOiByZXN1bHQ7XG4gICAgICAgICAgZWxlbWVudFRhcmdldEFycmF5LnB1c2goZWxlbWVudCk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICB9KTtcbiAgaWYgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCB1bmNsb3NlZCA9IHN0YWNrW3N0YWNrLmxlbmd0aCAtIDFdO1xuICAgIHRocm93IG5ldyBUcmFuc2xhdGlvblBhcnNlckVycm9yKGBVbmNsb3NlZCB0YWcgPCR7dW5jbG9zZWQudGFnTnVtYmVyfT4gYXQgcG9zaXRpb24gJHt1bmNsb3NlZC5wb3NpdGlvbn1gLCB1bmNsb3NlZC5wb3NpdGlvbiwgdHJhbnNsYXRpb24pO1xuICB9XG4gIHJldHVybiByZXN1bHQ7XG59OyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB3YXJuLCB3YXJuT25jZSwgaXNTdHJpbmcgfSBmcm9tICcuL3V0aWxzLmpzJztcbmltcG9ydCB7IGdldEkxOG4gfSBmcm9tICcuL2kxOG5JbnN0YW5jZS5qcyc7XG5pbXBvcnQgeyByZW5kZXJUcmFuc2xhdGlvbiB9IGZyb20gJy4vSWN1VHJhbnNVdGlscy9pbmRleC5qcyc7XG5leHBvcnQgZnVuY3Rpb24gSWN1VHJhbnNXaXRob3V0Q29udGV4dCh7XG4gIGkxOG5LZXksXG4gIGRlZmF1bHRUcmFuc2xhdGlvbixcbiAgY29udGVudCxcbiAgbnMsXG4gIHZhbHVlcyA9IHt9LFxuICBpMThuOiBpMThuRnJvbVByb3BzLFxuICB0OiB0RnJvbVByb3BzXG59KSB7XG4gIGNvbnN0IGkxOG4gPSBpMThuRnJvbVByb3BzIHx8IGdldEkxOG4oKTtcbiAgaWYgKCFpMThuKSB7XG4gICAgd2Fybk9uY2UoaTE4biwgJ05PX0kxOE5FWFRfSU5TVEFOQ0UnLCBgSWN1VHJhbnM6IFlvdSBuZWVkIHRvIHBhc3MgaW4gYW4gaTE4bmV4dCBpbnN0YW5jZSB1c2luZyBpMThuZXh0UmVhY3RNb2R1bGVgLCB7XG4gICAgICBpMThuS2V5XG4gICAgfSk7XG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIHt9LCBkZWZhdWx0VHJhbnNsYXRpb24pO1xuICB9XG4gIGNvbnN0IHQgPSB0RnJvbVByb3BzIHx8IGkxOG4udD8uYmluZChpMThuKSB8fCAoayA9PiBrKTtcbiAgbGV0IG5hbWVzcGFjZXMgPSBucyB8fCB0Lm5zIHx8IGkxOG4ub3B0aW9ucz8uZGVmYXVsdE5TO1xuICBuYW1lc3BhY2VzID0gaXNTdHJpbmcobmFtZXNwYWNlcykgPyBbbmFtZXNwYWNlc10gOiBuYW1lc3BhY2VzIHx8IFsndHJhbnNsYXRpb24nXTtcbiAgbGV0IG1lcmdlZFZhbHVlcyA9IHZhbHVlcztcbiAgaWYgKGkxOG4ub3B0aW9ucz8uaW50ZXJwb2xhdGlvbj8uZGVmYXVsdFZhcmlhYmxlcykge1xuICAgIG1lcmdlZFZhbHVlcyA9IHZhbHVlcyAmJiBPYmplY3Qua2V5cyh2YWx1ZXMpLmxlbmd0aCA+IDAgPyB7XG4gICAgICAuLi52YWx1ZXMsXG4gICAgICAuLi5pMThuLm9wdGlvbnMuaW50ZXJwb2xhdGlvbi5kZWZhdWx0VmFyaWFibGVzXG4gICAgfSA6IHtcbiAgICAgIC4uLmkxOG4ub3B0aW9ucy5pbnRlcnBvbGF0aW9uLmRlZmF1bHRWYXJpYWJsZXNcbiAgICB9O1xuICB9XG4gIGNvbnN0IHRyYW5zbGF0aW9uID0gdChpMThuS2V5LCB7XG4gICAgZGVmYXVsdFZhbHVlOiBkZWZhdWx0VHJhbnNsYXRpb24sXG4gICAgLi4ubWVyZ2VkVmFsdWVzLFxuICAgIG5zOiBuYW1lc3BhY2VzXG4gIH0pO1xuICB0cnkge1xuICAgIGNvbnN0IHJlbmRlcmVkID0gcmVuZGVyVHJhbnNsYXRpb24odHJhbnNsYXRpb24sIGNvbnRlbnQpO1xuICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LkZyYWdtZW50LCB7fSwgLi4ucmVuZGVyZWQpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHdhcm4oaTE4biwgJ0lDVV9UUkFOU19SRU5ERVJfRVJST1InLCBgSWN1VHJhbnMgY29tcG9uZW50IGVycm9yIGZvciBrZXkgXCIke2kxOG5LZXl9XCI6ICR7ZXJyb3IubWVzc2FnZX1gLCB7XG4gICAgICBpMThuS2V5LFxuICAgICAgZXJyb3JcbiAgICB9KTtcbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwge30sIHRyYW5zbGF0aW9uKTtcbiAgfVxufVxuSWN1VHJhbnNXaXRob3V0Q29udGV4dC5kaXNwbGF5TmFtZSA9ICdJY3VUcmFuc1dpdGhvdXRDb250ZXh0JzsiLCJpbXBvcnQgeyB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgSWN1VHJhbnNXaXRob3V0Q29udGV4dCB9IGZyb20gJy4vSWN1VHJhbnNXaXRob3V0Q29udGV4dC5qcyc7XG5pbXBvcnQgeyBnZXRJMThuLCBJMThuQ29udGV4dCB9IGZyb20gJy4vY29udGV4dC5qcyc7XG5leHBvcnQgZnVuY3Rpb24gSWN1VHJhbnMoe1xuICBpMThuS2V5LFxuICBkZWZhdWx0VHJhbnNsYXRpb24sXG4gIGNvbnRlbnQsXG4gIG5zLFxuICB2YWx1ZXMgPSB7fSxcbiAgaTE4bjogaTE4bkZyb21Qcm9wcyxcbiAgdDogdEZyb21Qcm9wc1xufSkge1xuICBjb25zdCB7XG4gICAgaTE4bjogaTE4bkZyb21Db250ZXh0LFxuICAgIGRlZmF1bHROUzogZGVmYXVsdE5TRnJvbUNvbnRleHRcbiAgfSA9IHVzZUNvbnRleHQoSTE4bkNvbnRleHQpIHx8IHt9O1xuICBjb25zdCBpMThuID0gaTE4bkZyb21Qcm9wcyB8fCBpMThuRnJvbUNvbnRleHQgfHwgZ2V0STE4bigpO1xuICBjb25zdCB0ID0gdEZyb21Qcm9wcyB8fCBpMThuPy50LmJpbmQoaTE4bik7XG4gIHJldHVybiBJY3VUcmFuc1dpdGhvdXRDb250ZXh0KHtcbiAgICBpMThuS2V5LFxuICAgIGRlZmF1bHRUcmFuc2xhdGlvbixcbiAgICBjb250ZW50LFxuICAgIG5zOiBucyB8fCB0Py5ucyB8fCBkZWZhdWx0TlNGcm9tQ29udGV4dCB8fCBpMThuPy5vcHRpb25zPy5kZWZhdWx0TlMsXG4gICAgdmFsdWVzLFxuICAgIGkxOG4sXG4gICAgdDogdEZyb21Qcm9wc1xuICB9KTtcbn1cbkljdVRyYW5zLmRpc3BsYXlOYW1lID0gJ0ljdVRyYW5zJzsiLCIvKipcbiAqIEBsaWNlbnNlIFJlYWN0XG4gKiB1c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltLmRldmVsb3BtZW50LmpzXG4gKlxuICogQ29weXJpZ2h0IChjKSBNZXRhIFBsYXRmb3JtcywgSW5jLiBhbmQgYWZmaWxpYXRlcy5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG5cInVzZSBzdHJpY3RcIjtcblwicHJvZHVjdGlvblwiICE9PSBwcm9jZXNzLmVudi5OT0RFX0VOViAmJlxuICAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIGlzKHgsIHkpIHtcbiAgICAgIHJldHVybiAoeCA9PT0geSAmJiAoMCAhPT0geCB8fCAxIC8geCA9PT0gMSAvIHkpKSB8fCAoeCAhPT0geCAmJiB5ICE9PSB5KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gdXNlU3luY0V4dGVybmFsU3RvcmUkMihzdWJzY3JpYmUsIGdldFNuYXBzaG90KSB7XG4gICAgICBkaWRXYXJuT2xkMThBbHBoYSB8fFxuICAgICAgICB2b2lkIDAgPT09IFJlYWN0LnN0YXJ0VHJhbnNpdGlvbiB8fFxuICAgICAgICAoKGRpZFdhcm5PbGQxOEFscGhhID0gITApLFxuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwiWW91IGFyZSB1c2luZyBhbiBvdXRkYXRlZCwgcHJlLXJlbGVhc2UgYWxwaGEgb2YgUmVhY3QgMTggdGhhdCBkb2VzIG5vdCBzdXBwb3J0IHVzZVN5bmNFeHRlcm5hbFN0b3JlLiBUaGUgdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUgc2hpbSB3aWxsIG5vdCB3b3JrIGNvcnJlY3RseS4gVXBncmFkZSB0byBhIG5ld2VyIHByZS1yZWxlYXNlLlwiXG4gICAgICAgICkpO1xuICAgICAgdmFyIHZhbHVlID0gZ2V0U25hcHNob3QoKTtcbiAgICAgIGlmICghZGlkV2FyblVuY2FjaGVkR2V0U25hcHNob3QpIHtcbiAgICAgICAgdmFyIGNhY2hlZFZhbHVlID0gZ2V0U25hcHNob3QoKTtcbiAgICAgICAgb2JqZWN0SXModmFsdWUsIGNhY2hlZFZhbHVlKSB8fFxuICAgICAgICAgIChjb25zb2xlLmVycm9yKFxuICAgICAgICAgICAgXCJUaGUgcmVzdWx0IG9mIGdldFNuYXBzaG90IHNob3VsZCBiZSBjYWNoZWQgdG8gYXZvaWQgYW4gaW5maW5pdGUgbG9vcFwiXG4gICAgICAgICAgKSxcbiAgICAgICAgICAoZGlkV2FyblVuY2FjaGVkR2V0U25hcHNob3QgPSAhMCkpO1xuICAgICAgfVxuICAgICAgY2FjaGVkVmFsdWUgPSB1c2VTdGF0ZSh7XG4gICAgICAgIGluc3Q6IHsgdmFsdWU6IHZhbHVlLCBnZXRTbmFwc2hvdDogZ2V0U25hcHNob3QgfVxuICAgICAgfSk7XG4gICAgICB2YXIgaW5zdCA9IGNhY2hlZFZhbHVlWzBdLmluc3QsXG4gICAgICAgIGZvcmNlVXBkYXRlID0gY2FjaGVkVmFsdWVbMV07XG4gICAgICB1c2VMYXlvdXRFZmZlY3QoXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpbnN0LnZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgaW5zdC5nZXRTbmFwc2hvdCA9IGdldFNuYXBzaG90O1xuICAgICAgICAgIGNoZWNrSWZTbmFwc2hvdENoYW5nZWQoaW5zdCkgJiYgZm9yY2VVcGRhdGUoeyBpbnN0OiBpbnN0IH0pO1xuICAgICAgICB9LFxuICAgICAgICBbc3Vic2NyaWJlLCB2YWx1ZSwgZ2V0U25hcHNob3RdXG4gICAgICApO1xuICAgICAgdXNlRWZmZWN0KFxuICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgY2hlY2tJZlNuYXBzaG90Q2hhbmdlZChpbnN0KSAmJiBmb3JjZVVwZGF0ZSh7IGluc3Q6IGluc3QgfSk7XG4gICAgICAgICAgcmV0dXJuIHN1YnNjcmliZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjaGVja0lmU25hcHNob3RDaGFuZ2VkKGluc3QpICYmIGZvcmNlVXBkYXRlKHsgaW5zdDogaW5zdCB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSxcbiAgICAgICAgW3N1YnNjcmliZV1cbiAgICAgICk7XG4gICAgICB1c2VEZWJ1Z1ZhbHVlKHZhbHVlKTtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY2hlY2tJZlNuYXBzaG90Q2hhbmdlZChpbnN0KSB7XG4gICAgICB2YXIgbGF0ZXN0R2V0U25hcHNob3QgPSBpbnN0LmdldFNuYXBzaG90O1xuICAgICAgaW5zdCA9IGluc3QudmFsdWU7XG4gICAgICB0cnkge1xuICAgICAgICB2YXIgbmV4dFZhbHVlID0gbGF0ZXN0R2V0U25hcHNob3QoKTtcbiAgICAgICAgcmV0dXJuICFvYmplY3RJcyhpbnN0LCBuZXh0VmFsdWUpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuICEwO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiB1c2VTeW5jRXh0ZXJuYWxTdG9yZSQxKHN1YnNjcmliZSwgZ2V0U25hcHNob3QpIHtcbiAgICAgIHJldHVybiBnZXRTbmFwc2hvdCgpO1xuICAgIH1cbiAgICBcInVuZGVmaW5lZFwiICE9PSB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fICYmXG4gICAgICBcImZ1bmN0aW9uXCIgPT09XG4gICAgICAgIHR5cGVvZiBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0YXJ0ICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0YXJ0KEVycm9yKCkpO1xuICAgIHZhciBSZWFjdCA9IHJlcXVpcmUoXCJyZWFjdFwiKSxcbiAgICAgIG9iamVjdElzID0gXCJmdW5jdGlvblwiID09PSB0eXBlb2YgT2JqZWN0LmlzID8gT2JqZWN0LmlzIDogaXMsXG4gICAgICB1c2VTdGF0ZSA9IFJlYWN0LnVzZVN0YXRlLFxuICAgICAgdXNlRWZmZWN0ID0gUmVhY3QudXNlRWZmZWN0LFxuICAgICAgdXNlTGF5b3V0RWZmZWN0ID0gUmVhY3QudXNlTGF5b3V0RWZmZWN0LFxuICAgICAgdXNlRGVidWdWYWx1ZSA9IFJlYWN0LnVzZURlYnVnVmFsdWUsXG4gICAgICBkaWRXYXJuT2xkMThBbHBoYSA9ICExLFxuICAgICAgZGlkV2FyblVuY2FjaGVkR2V0U25hcHNob3QgPSAhMSxcbiAgICAgIHNoaW0gPVxuICAgICAgICBcInVuZGVmaW5lZFwiID09PSB0eXBlb2Ygd2luZG93IHx8XG4gICAgICAgIFwidW5kZWZpbmVkXCIgPT09IHR5cGVvZiB3aW5kb3cuZG9jdW1lbnQgfHxcbiAgICAgICAgXCJ1bmRlZmluZWRcIiA9PT0gdHlwZW9mIHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50XG4gICAgICAgICAgPyB1c2VTeW5jRXh0ZXJuYWxTdG9yZSQxXG4gICAgICAgICAgOiB1c2VTeW5jRXh0ZXJuYWxTdG9yZSQyO1xuICAgIGV4cG9ydHMudXNlU3luY0V4dGVybmFsU3RvcmUgPVxuICAgICAgdm9pZCAwICE9PSBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZSA/IFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlIDogc2hpbTtcbiAgICBcInVuZGVmaW5lZFwiICE9PSB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fICYmXG4gICAgICBcImZ1bmN0aW9uXCIgPT09XG4gICAgICAgIHR5cGVvZiBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0b3AgJiZcbiAgICAgIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXy5yZWdpc3RlckludGVybmFsTW9kdWxlU3RvcChFcnJvcigpKTtcbiAgfSkoKTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAncHJvZHVjdGlvbicpIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuLi9janMvdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtc2hpbS5wcm9kdWN0aW9uLmpzJyk7XG59IGVsc2Uge1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4uL2Nqcy91c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltLmRldmVsb3BtZW50LmpzJyk7XG59XG4iLCJpbXBvcnQgeyB1c2VDb250ZXh0LCB1c2VDYWxsYmFjaywgdXNlTWVtbywgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlU3luY0V4dGVybmFsU3RvcmUgfSBmcm9tICd1c2Utc3luYy1leHRlcm5hbC1zdG9yZS9zaGltJztcbmltcG9ydCB7IGdldEkxOG4sIGdldERlZmF1bHRzLCBSZXBvcnROYW1lc3BhY2VzLCBJMThuQ29udGV4dCB9IGZyb20gJy4vY29udGV4dC5qcyc7XG5pbXBvcnQgeyB3YXJuT25jZSwgbG9hZE5hbWVzcGFjZXMsIGxvYWRMYW5ndWFnZXMsIGhhc0xvYWRlZE5hbWVzcGFjZSwgaXNTdHJpbmcsIGlzT2JqZWN0IH0gZnJvbSAnLi91dGlscy5qcyc7XG5jb25zdCBub3RSZWFkeVQgPSAoaywgb3B0c09yRGVmYXVsdFZhbHVlKSA9PiB7XG4gIGlmIChpc1N0cmluZyhvcHRzT3JEZWZhdWx0VmFsdWUpKSByZXR1cm4gb3B0c09yRGVmYXVsdFZhbHVlO1xuICBpZiAoaXNPYmplY3Qob3B0c09yRGVmYXVsdFZhbHVlKSAmJiBpc1N0cmluZyhvcHRzT3JEZWZhdWx0VmFsdWUuZGVmYXVsdFZhbHVlKSkgcmV0dXJuIG9wdHNPckRlZmF1bHRWYWx1ZS5kZWZhdWx0VmFsdWU7XG4gIGlmICh0eXBlb2YgayA9PT0gJ2Z1bmN0aW9uJykgcmV0dXJuICcnO1xuICBpZiAoQXJyYXkuaXNBcnJheShrKSkge1xuICAgIGNvbnN0IGxhc3QgPSBrW2subGVuZ3RoIC0gMV07XG4gICAgcmV0dXJuIHR5cGVvZiBsYXN0ID09PSAnZnVuY3Rpb24nID8gJycgOiBsYXN0O1xuICB9XG4gIHJldHVybiBrO1xufTtcbmNvbnN0IG5vdFJlYWR5U25hcHNob3QgPSB7XG4gIHQ6IG5vdFJlYWR5VCxcbiAgcmVhZHk6IGZhbHNlXG59O1xuY29uc3QgZHVtbXlTdWJzY3JpYmUgPSAoKSA9PiAoKSA9PiB7fTtcbmV4cG9ydCBjb25zdCB1c2VUcmFuc2xhdGlvbiA9IChucywgcHJvcHMgPSB7fSkgPT4ge1xuICBjb25zdCB7XG4gICAgaTE4bjogaTE4bkZyb21Qcm9wc1xuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHtcbiAgICBpMThuOiBpMThuRnJvbUNvbnRleHQsXG4gICAgZGVmYXVsdE5TOiBkZWZhdWx0TlNGcm9tQ29udGV4dFxuICB9ID0gdXNlQ29udGV4dChJMThuQ29udGV4dCkgfHwge307XG4gIGNvbnN0IGkxOG4gPSBpMThuRnJvbVByb3BzIHx8IGkxOG5Gcm9tQ29udGV4dCB8fCBnZXRJMThuKCk7XG4gIGlmIChpMThuICYmICFpMThuLnJlcG9ydE5hbWVzcGFjZXMpIGkxOG4ucmVwb3J0TmFtZXNwYWNlcyA9IG5ldyBSZXBvcnROYW1lc3BhY2VzKCk7XG4gIGlmICghaTE4bikge1xuICAgIHdhcm5PbmNlKGkxOG4sICdOT19JMThORVhUX0lOU1RBTkNFJywgJ3VzZVRyYW5zbGF0aW9uOiBZb3Ugd2lsbCBuZWVkIHRvIHBhc3MgaW4gYW4gaTE4bmV4dCBpbnN0YW5jZSBieSB1c2luZyBpbml0UmVhY3RJMThuZXh0IG9yIGJ5IHBhc3NpbmcgaXQgdmlhIHByb3BzIG9yIGNvbnRleHQuIEluIG1vbm9yZXBvIHNldHVwcywgbWFrZSBzdXJlIHRoZXJlIGlzIG9ubHkgb25lIGluc3RhbmNlIG9mIHJlYWN0LWkxOG5leHQuJyk7XG4gIH1cbiAgY29uc3QgaTE4bk9wdGlvbnMgPSB1c2VNZW1vKCgpID0+ICh7XG4gICAgLi4uZ2V0RGVmYXVsdHMoKSxcbiAgICAuLi5pMThuPy5vcHRpb25zPy5yZWFjdCxcbiAgICAuLi5wcm9wc1xuICB9KSwgW2kxOG4sIHByb3BzXSk7XG4gIGNvbnN0IHtcbiAgICB1c2VTdXNwZW5zZSxcbiAgICBrZXlQcmVmaXhcbiAgfSA9IGkxOG5PcHRpb25zO1xuICBjb25zdCBuc09yQ29udGV4dCA9IG5zIHx8IGRlZmF1bHROU0Zyb21Db250ZXh0IHx8IGkxOG4/Lm9wdGlvbnM/LmRlZmF1bHROUztcbiAgY29uc3QgdW5zdGFibGVOYW1lc3BhY2VzID0gaXNTdHJpbmcobnNPckNvbnRleHQpID8gW25zT3JDb250ZXh0XSA6IG5zT3JDb250ZXh0IHx8IFsndHJhbnNsYXRpb24nXTtcbiAgY29uc3QgbmFtZXNwYWNlcyA9IHVzZU1lbW8oKCkgPT4gdW5zdGFibGVOYW1lc3BhY2VzLCB1bnN0YWJsZU5hbWVzcGFjZXMpO1xuICBpMThuPy5yZXBvcnROYW1lc3BhY2VzPy5hZGRVc2VkTmFtZXNwYWNlcz8uKG5hbWVzcGFjZXMpO1xuICBjb25zdCByZXZpc2lvblJlZiA9IHVzZVJlZigwKTtcbiAgY29uc3Qgc3Vic2NyaWJlID0gdXNlQ2FsbGJhY2soY2FsbGJhY2sgPT4ge1xuICAgIGlmICghaTE4bikgcmV0dXJuIGR1bW15U3Vic2NyaWJlO1xuICAgIGNvbnN0IHtcbiAgICAgIGJpbmRJMThuLFxuICAgICAgYmluZEkxOG5TdG9yZVxuICAgIH0gPSBpMThuT3B0aW9ucztcbiAgICBjb25zdCB3cmFwcGVkQ2FsbGJhY2sgPSAoKSA9PiB7XG4gICAgICByZXZpc2lvblJlZi5jdXJyZW50ICs9IDE7XG4gICAgICBjYWxsYmFjaygpO1xuICAgIH07XG4gICAgaWYgKGJpbmRJMThuKSBpMThuLm9uKGJpbmRJMThuLCB3cmFwcGVkQ2FsbGJhY2spO1xuICAgIGlmIChiaW5kSTE4blN0b3JlKSBpMThuLnN0b3JlLm9uKGJpbmRJMThuU3RvcmUsIHdyYXBwZWRDYWxsYmFjayk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmIChiaW5kSTE4bikgYmluZEkxOG4uc3BsaXQoJyAnKS5mb3JFYWNoKGUgPT4gaTE4bi5vZmYoZSwgd3JhcHBlZENhbGxiYWNrKSk7XG4gICAgICBpZiAoYmluZEkxOG5TdG9yZSkgYmluZEkxOG5TdG9yZS5zcGxpdCgnICcpLmZvckVhY2goZSA9PiBpMThuLnN0b3JlLm9mZihlLCB3cmFwcGVkQ2FsbGJhY2spKTtcbiAgICB9O1xuICB9LCBbaTE4biwgaTE4bk9wdGlvbnNdKTtcbiAgY29uc3Qgc25hcHNob3RSZWYgPSB1c2VSZWYoKTtcbiAgY29uc3QgZ2V0U25hcHNob3QgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKCFpMThuKSB7XG4gICAgICByZXR1cm4gbm90UmVhZHlTbmFwc2hvdDtcbiAgICB9XG4gICAgY29uc3QgY2FsY3VsYXRlZFJlYWR5ID0gISEoaTE4bi5pc0luaXRpYWxpemVkIHx8IGkxOG4uaW5pdGlhbGl6ZWRTdG9yZU9uY2UpICYmIG5hbWVzcGFjZXMuZXZlcnkobiA9PiBoYXNMb2FkZWROYW1lc3BhY2UobiwgaTE4biwgaTE4bk9wdGlvbnMpKTtcbiAgICBjb25zdCBjdXJyZW50TG5nID0gcHJvcHMubG5nIHx8IGkxOG4ubGFuZ3VhZ2U7XG4gICAgY29uc3QgY3VycmVudFJldmlzaW9uID0gcmV2aXNpb25SZWYuY3VycmVudDtcbiAgICBjb25zdCBsYXN0U25hcHNob3QgPSBzbmFwc2hvdFJlZi5jdXJyZW50O1xuICAgIGlmIChsYXN0U25hcHNob3QgJiYgbGFzdFNuYXBzaG90LnJlYWR5ID09PSBjYWxjdWxhdGVkUmVhZHkgJiYgbGFzdFNuYXBzaG90LmxuZyA9PT0gY3VycmVudExuZyAmJiBsYXN0U25hcHNob3Qua2V5UHJlZml4ID09PSBrZXlQcmVmaXggJiYgbGFzdFNuYXBzaG90LnJldmlzaW9uID09PSBjdXJyZW50UmV2aXNpb24pIHtcbiAgICAgIHJldHVybiBsYXN0U25hcHNob3Q7XG4gICAgfVxuICAgIGNvbnN0IGNhbGN1bGF0ZWRUID0gaTE4bi5nZXRGaXhlZFQoY3VycmVudExuZywgaTE4bk9wdGlvbnMubnNNb2RlID09PSAnZmFsbGJhY2snID8gbmFtZXNwYWNlcyA6IG5hbWVzcGFjZXNbMF0sIGtleVByZWZpeCwge1xuICAgICAgc2NvcGVOczogbmFtZXNwYWNlc1xuICAgIH0pO1xuICAgIGNvbnN0IG5ld1NuYXBzaG90ID0ge1xuICAgICAgdDogY2FsY3VsYXRlZFQsXG4gICAgICByZWFkeTogY2FsY3VsYXRlZFJlYWR5LFxuICAgICAgbG5nOiBjdXJyZW50TG5nLFxuICAgICAga2V5UHJlZml4LFxuICAgICAgcmV2aXNpb246IGN1cnJlbnRSZXZpc2lvblxuICAgIH07XG4gICAgc25hcHNob3RSZWYuY3VycmVudCA9IG5ld1NuYXBzaG90O1xuICAgIHJldHVybiBuZXdTbmFwc2hvdDtcbiAgfSwgW2kxOG4sIG5hbWVzcGFjZXMsIGtleVByZWZpeCwgaTE4bk9wdGlvbnMsIHByb3BzLmxuZ10pO1xuICBjb25zdCBbbG9hZENvdW50LCBzZXRMb2FkQ291bnRdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IHtcbiAgICB0LFxuICAgIHJlYWR5XG4gIH0gPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdWJzY3JpYmUsIGdldFNuYXBzaG90LCBnZXRTbmFwc2hvdCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGkxOG4gJiYgIXJlYWR5ICYmICF1c2VTdXNwZW5zZSkge1xuICAgICAgY29uc3Qgb25Mb2FkZWQgPSAoKSA9PiBzZXRMb2FkQ291bnQoYyA9PiBjICsgMSk7XG4gICAgICBpZiAocHJvcHMubG5nKSB7XG4gICAgICAgIGxvYWRMYW5ndWFnZXMoaTE4biwgcHJvcHMubG5nLCBuYW1lc3BhY2VzLCBvbkxvYWRlZCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsb2FkTmFtZXNwYWNlcyhpMThuLCBuYW1lc3BhY2VzLCBvbkxvYWRlZCk7XG4gICAgICB9XG4gICAgfVxuICB9LCBbaTE4biwgcHJvcHMubG5nLCBuYW1lc3BhY2VzLCByZWFkeSwgdXNlU3VzcGVuc2UsIGxvYWRDb3VudF0pO1xuICBjb25zdCBmaW5hbEkxOG4gPSBpMThuIHx8IHt9O1xuICBjb25zdCB3cmFwcGVyUmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCB3cmFwcGVyTGFuZ1JlZiA9IHVzZVJlZigpO1xuICBjb25zdCBjcmVhdGVJMThuV3JhcHBlciA9IG9yaWdpbmFsID0+IHtcbiAgICBjb25zdCBkZXNjcmlwdG9ycyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKG9yaWdpbmFsKTtcbiAgICBpZiAoZGVzY3JpcHRvcnMuX19vcmlnaW5hbCkgZGVsZXRlIGRlc2NyaXB0b3JzLl9fb3JpZ2luYWw7XG4gICAgY29uc3Qgd3JhcHBlciA9IE9iamVjdC5jcmVhdGUoT2JqZWN0LmdldFByb3RvdHlwZU9mKG9yaWdpbmFsKSwgZGVzY3JpcHRvcnMpO1xuICAgIGlmICghT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHdyYXBwZXIsICdfX29yaWdpbmFsJykpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh3cmFwcGVyLCAnX19vcmlnaW5hbCcsIHtcbiAgICAgICAgICB2YWx1ZTogb3JpZ2luYWwsXG4gICAgICAgICAgd3JpdGFibGU6IGZhbHNlLFxuICAgICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICAgIGNvbmZpZ3VyYWJsZTogZmFsc2VcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChfKSB7fVxuICAgIH1cbiAgICByZXR1cm4gd3JhcHBlcjtcbiAgfTtcbiAgY29uc3QgcmV0ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3Qgb3JpZ2luYWwgPSBmaW5hbEkxOG47XG4gICAgY29uc3QgbGFuZyA9IG9yaWdpbmFsPy5sYW5ndWFnZTtcbiAgICBsZXQgaTE4bldyYXBwZXIgPSBvcmlnaW5hbDtcbiAgICBpZiAob3JpZ2luYWwpIHtcbiAgICAgIGlmICh3cmFwcGVyUmVmLmN1cnJlbnQgJiYgd3JhcHBlclJlZi5jdXJyZW50Ll9fb3JpZ2luYWwgPT09IG9yaWdpbmFsKSB7XG4gICAgICAgIGlmICh3cmFwcGVyTGFuZ1JlZi5jdXJyZW50ICE9PSBsYW5nKSB7XG4gICAgICAgICAgaTE4bldyYXBwZXIgPSBjcmVhdGVJMThuV3JhcHBlcihvcmlnaW5hbCk7XG4gICAgICAgICAgd3JhcHBlclJlZi5jdXJyZW50ID0gaTE4bldyYXBwZXI7XG4gICAgICAgICAgd3JhcHBlckxhbmdSZWYuY3VycmVudCA9IGxhbmc7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaTE4bldyYXBwZXIgPSB3cmFwcGVyUmVmLmN1cnJlbnQ7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGkxOG5XcmFwcGVyID0gY3JlYXRlSTE4bldyYXBwZXIob3JpZ2luYWwpO1xuICAgICAgICB3cmFwcGVyUmVmLmN1cnJlbnQgPSBpMThuV3JhcHBlcjtcbiAgICAgICAgd3JhcHBlckxhbmdSZWYuY3VycmVudCA9IGxhbmc7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGVmZmVjdGl2ZVQgPSAhcmVhZHkgJiYgIXVzZVN1c3BlbnNlID8gKC4uLmFyZ3MpID0+IHtcbiAgICAgIHdhcm5PbmNlKGkxOG4sICdVU0VfVF9CRUZPUkVfUkVBRFknLCAndXNlVHJhbnNsYXRpb246IHQgd2FzIGNhbGxlZCBiZWZvcmUgcmVhZHkuIFdoZW4gdXNpbmcgdXNlU3VzcGVuc2U6IGZhbHNlLCBtYWtlIHN1cmUgdG8gY2hlY2sgdGhlIHJlYWR5IGZsYWcgYmVmb3JlIHVzaW5nIHQuJyk7XG4gICAgICByZXR1cm4gdCguLi5hcmdzKTtcbiAgICB9IDogdDtcbiAgICBjb25zdCBhcnIgPSBbZWZmZWN0aXZlVCwgaTE4bldyYXBwZXIsIHJlYWR5XTtcbiAgICBhcnIudCA9IGVmZmVjdGl2ZVQ7XG4gICAgYXJyLmkxOG4gPSBpMThuV3JhcHBlcjtcbiAgICBhcnIucmVhZHkgPSByZWFkeTtcbiAgICByZXR1cm4gYXJyO1xuICB9LCBbdCwgZmluYWxJMThuLCByZWFkeSwgZmluYWxJMThuLnJlc29sdmVkTGFuZ3VhZ2UsIGZpbmFsSTE4bi5sYW5ndWFnZSwgZmluYWxJMThuLmxhbmd1YWdlc10pO1xuICBpZiAoaTE4biAmJiB1c2VTdXNwZW5zZSAmJiAhcmVhZHkpIHtcbiAgICBsZXQgaW5EZXZlbG9wbWVudCA9IGZhbHNlO1xuICAgIHRyeSB7XG4gICAgICBpbkRldmVsb3BtZW50ID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJztcbiAgICB9IGNhdGNoIChlKSB7fVxuICAgIGlmIChpbkRldmVsb3BtZW50KSB7XG4gICAgICB3YXJuT25jZShpMThuLCAnU1VTUEVOREVEX1dISUxFX0xPQURJTkcnLCAndXNlVHJhbnNsYXRpb246IHN1c3BlbmRlZCB3aGlsZSB0cmFuc2xhdGlvbnMgYXJlIGxvYWRpbmcgKHVzZVN1c3BlbnNlIGlzIHRydWUgYnkgZGVmYXVsdCkuIEFkZCBhIDxTdXNwZW5zZT4gYm91bmRhcnkgYWJvdmUgdGhpcyBjb21wb25lbnQsIG9yIHNldCByZWFjdC51c2VTdXNwZW5zZTogZmFsc2UgaW4gdGhlIGkxOG5leHQgaW5pdCBvcHRpb25zLiBodHRwczovL3JlYWN0LmkxOG5leHQuY29tL2xhdGVzdC91c2V0cmFuc2xhdGlvbi1ob29rJyk7XG4gICAgfVxuICAgIHRocm93IG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xuICAgICAgY29uc3Qgb25Mb2FkZWQgPSAoKSA9PiByZXNvbHZlKCk7XG4gICAgICBpZiAocHJvcHMubG5nKSB7XG4gICAgICAgIGxvYWRMYW5ndWFnZXMoaTE4biwgcHJvcHMubG5nLCBuYW1lc3BhY2VzLCBvbkxvYWRlZCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsb2FkTmFtZXNwYWNlcyhpMThuLCBuYW1lc3BhY2VzLCBvbkxvYWRlZCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIHJldDtcbn07IiwiaW1wb3J0IHsgY3JlYXRlRWxlbWVudCwgZm9yd2FyZFJlZiBhcyBmb3J3YXJkUmVmUmVhY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gJy4vdXNlVHJhbnNsYXRpb24uanMnO1xuaW1wb3J0IHsgZ2V0RGlzcGxheU5hbWUgfSBmcm9tICcuL3V0aWxzLmpzJztcbmV4cG9ydCBjb25zdCB3aXRoVHJhbnNsYXRpb24gPSAobnMsIG9wdGlvbnMgPSB7fSkgPT4gZnVuY3Rpb24gRXh0ZW5kKFdyYXBwZWRDb21wb25lbnQpIHtcbiAgZnVuY3Rpb24gSTE4bmV4dFdpdGhUcmFuc2xhdGlvbih7XG4gICAgZm9yd2FyZGVkUmVmLFxuICAgIC4uLnJlc3RcbiAgfSkge1xuICAgIGNvbnN0IFt0LCBpMThuLCByZWFkeV0gPSB1c2VUcmFuc2xhdGlvbihucywge1xuICAgICAgLi4ucmVzdCxcbiAgICAgIGtleVByZWZpeDogb3B0aW9ucy5rZXlQcmVmaXhcbiAgICB9KTtcbiAgICBjb25zdCBwYXNzRG93blByb3BzID0ge1xuICAgICAgLi4ucmVzdCxcbiAgICAgIHQsXG4gICAgICBpMThuLFxuICAgICAgdFJlYWR5OiByZWFkeVxuICAgIH07XG4gICAgaWYgKG9wdGlvbnMud2l0aFJlZiAmJiBmb3J3YXJkZWRSZWYpIHtcbiAgICAgIHBhc3NEb3duUHJvcHMucmVmID0gZm9yd2FyZGVkUmVmO1xuICAgIH0gZWxzZSBpZiAoIW9wdGlvbnMud2l0aFJlZiAmJiBmb3J3YXJkZWRSZWYpIHtcbiAgICAgIHBhc3NEb3duUHJvcHMuZm9yd2FyZGVkUmVmID0gZm9yd2FyZGVkUmVmO1xuICAgIH1cbiAgICByZXR1cm4gY3JlYXRlRWxlbWVudChXcmFwcGVkQ29tcG9uZW50LCBwYXNzRG93blByb3BzKTtcbiAgfVxuICBJMThuZXh0V2l0aFRyYW5zbGF0aW9uLmRpc3BsYXlOYW1lID0gYHdpdGhJMThuZXh0VHJhbnNsYXRpb24oJHtnZXREaXNwbGF5TmFtZShXcmFwcGVkQ29tcG9uZW50KX0pYDtcbiAgSTE4bmV4dFdpdGhUcmFuc2xhdGlvbi5XcmFwcGVkQ29tcG9uZW50ID0gV3JhcHBlZENvbXBvbmVudDtcbiAgY29uc3QgZm9yd2FyZFJlZiA9IChwcm9wcywgcmVmKSA9PiBjcmVhdGVFbGVtZW50KEkxOG5leHRXaXRoVHJhbnNsYXRpb24sIE9iamVjdC5hc3NpZ24oe30sIHByb3BzLCB7XG4gICAgZm9yd2FyZGVkUmVmOiByZWZcbiAgfSkpO1xuICByZXR1cm4gb3B0aW9ucy53aXRoUmVmID8gZm9yd2FyZFJlZlJlYWN0KGZvcndhcmRSZWYpIDogSTE4bmV4dFdpdGhUcmFuc2xhdGlvbjtcbn07IiwiaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tICcuL3VzZVRyYW5zbGF0aW9uLmpzJztcbmV4cG9ydCBjb25zdCBUcmFuc2xhdGlvbiA9ICh7XG4gIG5zLFxuICBjaGlsZHJlbixcbiAgLi4ub3B0aW9uc1xufSkgPT4ge1xuICBjb25zdCBbdCwgaTE4biwgcmVhZHldID0gdXNlVHJhbnNsYXRpb24obnMsIG9wdGlvbnMpO1xuICByZXR1cm4gY2hpbGRyZW4odCwge1xuICAgIGkxOG4sXG4gICAgbG5nOiBpMThuPy5sYW5ndWFnZVxuICB9LCByZWFkeSk7XG59OyIsImltcG9ydCB7IGNyZWF0ZUVsZW1lbnQsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBJMThuQ29udGV4dCB9IGZyb20gJy4vY29udGV4dC5qcyc7XG5leHBvcnQgZnVuY3Rpb24gSTE4bmV4dFByb3ZpZGVyKHtcbiAgaTE4bixcbiAgZGVmYXVsdE5TLFxuICBjaGlsZHJlblxufSkge1xuICBjb25zdCB2YWx1ZSA9IHVzZU1lbW8oKCkgPT4gKHtcbiAgICBpMThuLFxuICAgIGRlZmF1bHROU1xuICB9KSwgW2kxOG4sIGRlZmF1bHROU10pO1xuICByZXR1cm4gY3JlYXRlRWxlbWVudChJMThuQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlXG4gIH0sIGNoaWxkcmVuKTtcbn0iLCJpbXBvcnQgeyB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZ2V0STE4biwgSTE4bkNvbnRleHQgfSBmcm9tICcuL2NvbnRleHQuanMnO1xuaW1wb3J0IHsgd2Fybk9uY2UgfSBmcm9tICcuL3V0aWxzLmpzJztcbmV4cG9ydCBjb25zdCB1c2VTU1IgPSAoaW5pdGlhbEkxOG5TdG9yZSwgaW5pdGlhbExhbmd1YWdlLCBwcm9wcyA9IHt9KSA9PiB7XG4gIGNvbnN0IHtcbiAgICBpMThuOiBpMThuRnJvbVByb3BzXG4gIH0gPSBwcm9wcztcbiAgY29uc3Qge1xuICAgIGkxOG46IGkxOG5Gcm9tQ29udGV4dFxuICB9ID0gdXNlQ29udGV4dChJMThuQ29udGV4dCkgfHwge307XG4gIGNvbnN0IGkxOG4gPSBpMThuRnJvbVByb3BzIHx8IGkxOG5Gcm9tQ29udGV4dCB8fCBnZXRJMThuKCk7XG4gIGlmICghaTE4bikge1xuICAgIHdhcm5PbmNlKGkxOG4sICdOT19JMThORVhUX0lOU1RBTkNFJywgJ3VzZVNTUjogWW91IHdpbGwgbmVlZCB0byBwYXNzIGluIGFuIGkxOG5leHQgaW5zdGFuY2UgYnkgdXNpbmcgaW5pdFJlYWN0STE4bmV4dCBvciBieSBwYXNzaW5nIGl0IHZpYSBwcm9wcyBvciBjb250ZXh0LiBJbiBtb25vcmVwbyBzZXR1cHMsIG1ha2Ugc3VyZSB0aGVyZSBpcyBvbmx5IG9uZSBpbnN0YW5jZSBvZiByZWFjdC1pMThuZXh0LicpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoaTE4bi5vcHRpb25zPy5pc0Nsb25lKSByZXR1cm47XG4gIGlmIChpbml0aWFsSTE4blN0b3JlICYmICFpMThuLmluaXRpYWxpemVkU3RvcmVPbmNlKSB7XG4gICAgaWYgKCFpMThuLnNlcnZpY2VzPy5yZXNvdXJjZVN0b3JlKSB7XG4gICAgICB3YXJuT25jZShpMThuLCAnSTE4Tl9OT1RfSU5JVElBTElaRUQnLCAndXNlU1NSOiBpMThuIGluc3RhbmNlIHdhcyBmb3VuZCBidXQgbm90IGluaXRpYWxpemVkIChzZXJ2aWNlcy5yZXNvdXJjZVN0b3JlIGlzIG1pc3NpbmcpLiBNYWtlIHN1cmUgeW91IGNhbGwgaTE4bmV4dC5pbml0KCkgYmVmb3JlIHVzaW5nIHVzZVNTUiDigJQgZS5nLiBhdCBtb2R1bGUgbGV2ZWwsIG5vdCBvbmx5IGluIGdldFN0YXRpY1Byb3BzL2dldFNlcnZlclNpZGVQcm9wcy4nKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaTE4bi5zZXJ2aWNlcy5yZXNvdXJjZVN0b3JlLmRhdGEgPSBpbml0aWFsSTE4blN0b3JlO1xuICAgIGkxOG4ub3B0aW9ucy5ucyA9IE9iamVjdC52YWx1ZXMoaW5pdGlhbEkxOG5TdG9yZSkucmVkdWNlKChtZW0sIGxuZ1Jlc291cmNlcykgPT4ge1xuICAgICAgT2JqZWN0LmtleXMobG5nUmVzb3VyY2VzKS5mb3JFYWNoKG5zID0+IHtcbiAgICAgICAgaWYgKG1lbS5pbmRleE9mKG5zKSA8IDApIG1lbS5wdXNoKG5zKTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIG1lbTtcbiAgICB9LCBpMThuLm9wdGlvbnMubnMpO1xuICAgIGkxOG4uaW5pdGlhbGl6ZWRTdG9yZU9uY2UgPSB0cnVlO1xuICAgIGkxOG4uaXNJbml0aWFsaXplZCA9IHRydWU7XG4gIH1cbiAgaWYgKGluaXRpYWxMYW5ndWFnZSAmJiAhaTE4bi5pbml0aWFsaXplZExhbmd1YWdlT25jZSkge1xuICAgIGkxOG4uY2hhbmdlTGFuZ3VhZ2UoaW5pdGlhbExhbmd1YWdlKTtcbiAgICBpMThuLmluaXRpYWxpemVkTGFuZ3VhZ2VPbmNlID0gdHJ1ZTtcbiAgfVxufTsiLCJpbXBvcnQgeyBjcmVhdGVFbGVtZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlU1NSIH0gZnJvbSAnLi91c2VTU1IuanMnO1xuaW1wb3J0IHsgY29tcG9zZUluaXRpYWxQcm9wcyB9IGZyb20gJy4vY29udGV4dC5qcyc7XG5pbXBvcnQgeyBnZXREaXNwbGF5TmFtZSB9IGZyb20gJy4vdXRpbHMuanMnO1xuZXhwb3J0IGNvbnN0IHdpdGhTU1IgPSAoKSA9PiBmdW5jdGlvbiBFeHRlbmQoV3JhcHBlZENvbXBvbmVudCkge1xuICBmdW5jdGlvbiBJMThuZXh0V2l0aFNTUih7XG4gICAgaW5pdGlhbEkxOG5TdG9yZSxcbiAgICBpbml0aWFsTGFuZ3VhZ2UsXG4gICAgLi4ucmVzdFxuICB9KSB7XG4gICAgdXNlU1NSKGluaXRpYWxJMThuU3RvcmUsIGluaXRpYWxMYW5ndWFnZSk7XG4gICAgcmV0dXJuIGNyZWF0ZUVsZW1lbnQoV3JhcHBlZENvbXBvbmVudCwge1xuICAgICAgLi4ucmVzdFxuICAgIH0pO1xuICB9XG4gIEkxOG5leHRXaXRoU1NSLmdldEluaXRpYWxQcm9wcyA9IGNvbXBvc2VJbml0aWFsUHJvcHMoV3JhcHBlZENvbXBvbmVudCk7XG4gIEkxOG5leHRXaXRoU1NSLmRpc3BsYXlOYW1lID0gYHdpdGhJMThuZXh0U1NSKCR7Z2V0RGlzcGxheU5hbWUoV3JhcHBlZENvbXBvbmVudCl9KWA7XG4gIEkxOG5leHRXaXRoU1NSLldyYXBwZWRDb21wb25lbnQgPSBXcmFwcGVkQ29tcG9uZW50O1xuICByZXR1cm4gSTE4bmV4dFdpdGhTU1I7XG59OyIsImV4cG9ydCB7IFRyYW5zIH0gZnJvbSAnLi9UcmFucy5qcyc7XG5leHBvcnQgeyBUcmFucyBhcyBUcmFuc1dpdGhvdXRDb250ZXh0IH0gZnJvbSAnLi9UcmFuc1dpdGhvdXRDb250ZXh0LmpzJztcbmV4cG9ydCB7IEljdVRyYW5zIH0gZnJvbSAnLi9JY3VUcmFucy5qcyc7XG5leHBvcnQgeyBJY3VUcmFuc1dpdGhvdXRDb250ZXh0IH0gZnJvbSAnLi9JY3VUcmFuc1dpdGhvdXRDb250ZXh0LmpzJztcbmV4cG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSAnLi91c2VUcmFuc2xhdGlvbi5qcyc7XG5leHBvcnQgeyB3aXRoVHJhbnNsYXRpb24gfSBmcm9tICcuL3dpdGhUcmFuc2xhdGlvbi5qcyc7XG5leHBvcnQgeyBUcmFuc2xhdGlvbiB9IGZyb20gJy4vVHJhbnNsYXRpb24uanMnO1xuZXhwb3J0IHsgSTE4bmV4dFByb3ZpZGVyIH0gZnJvbSAnLi9JMThuZXh0UHJvdmlkZXIuanMnO1xuZXhwb3J0IHsgd2l0aFNTUiB9IGZyb20gJy4vd2l0aFNTUi5qcyc7XG5leHBvcnQgeyB1c2VTU1IgfSBmcm9tICcuL3VzZVNTUi5qcyc7XG5leHBvcnQgeyBpbml0UmVhY3RJMThuZXh0IH0gZnJvbSAnLi9pbml0UmVhY3RJMThuZXh0LmpzJztcbmV4cG9ydCB7IHNldERlZmF1bHRzLCBnZXREZWZhdWx0cyB9IGZyb20gJy4vZGVmYXVsdHMuanMnO1xuZXhwb3J0IHsgc2V0STE4biwgZ2V0STE4biB9IGZyb20gJy4vaTE4bkluc3RhbmNlLmpzJztcbmV4cG9ydCB7IG5vZGVzVG9TdHJpbmcgfSBmcm9tICcuL1RyYW5zLmpzJztcbmV4cG9ydCB7IEkxOG5Db250ZXh0LCBjb21wb3NlSW5pdGlhbFByb3BzLCBnZXRJbml0aWFsUHJvcHMgfSBmcm9tICcuL2NvbnRleHQuanMnO1xuZXhwb3J0IGNvbnN0IGRhdGUgPSAoKSA9PiAnJztcbmV4cG9ydCBjb25zdCB0aW1lID0gKCkgPT4gJyc7XG5leHBvcnQgY29uc3QgbnVtYmVyID0gKCkgPT4gJyc7XG5leHBvcnQgY29uc3Qgc2VsZWN0ID0gKCkgPT4gJyc7XG5leHBvcnQgY29uc3QgcGx1cmFsID0gKCkgPT4gJyc7XG5leHBvcnQgY29uc3Qgc2VsZWN0T3JkaW5hbCA9ICgpID0+ICcnOyJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFHQSxJQUFNLGVBQWU7Q0FDbkIsTUFBTTtDQUNOLE1BQU07Q0FDTixJQUFJO0NBQ0osS0FBSztDQUNMLE9BQU87Q0FDUCxJQUFJO0NBQ0osS0FBSztDQUNMLE9BQU87Q0FDUCxNQUFNO0NBQ04sTUFBTTtDQUNOLE9BQU87Q0FDUCxRQUFRO0NBQ1IsT0FBTztDQUNQLEtBQUs7Q0FDTCxZQUFZO0NBQ1osWUFBWTtBQUNkO0FBRUEsSUFBTSxTQUFTO0FBRWYsU0FBUyxTQUFTLEtBQUs7Q0FDckIsTUFBTSxNQUFNO0VBQ1YsTUFBTTtFQUNOLE1BQU07RUFDTixhQUFhO0VBQ2IsT0FBTyxDQUFDO0VBQ1IsVUFBVSxDQUFDO0NBQ2I7Q0FFQSxNQUFNLFdBQVcsSUFBSSxNQUFNLHFCQUFxQjtDQUNoRCxJQUFJLFVBQVU7RUFDWixJQUFJLE9BQU8sU0FBUztFQUdwQixJQUFJLGFBQWEsU0FBUyxPQUFPLElBQUksT0FBTyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEtBQzlELElBQUksY0FBYztFQUlwQixJQUFJLElBQUksS0FBSyxXQUFXLEtBQUssR0FBRztHQUM5QixNQUFNLFdBQVcsSUFBSSxRQUFRLEtBQUs7R0FDbEMsT0FBTztJQUNMLE1BQU07SUFDTixTQUFTLGFBQWEsS0FBSyxJQUFJLE1BQU0sR0FBRyxRQUFRLElBQUk7R0FDdEQ7RUFDRjtDQUNGO0NBRUEsTUFBTSxNQUFNLElBQUksT0FBTyxNQUFNO0NBQzdCLElBQUksU0FBUztDQUNiLFNBQVM7RUFDUCxTQUFTLElBQUksS0FBSyxHQUFHO0VBRXJCLElBQUksV0FBVyxNQUNiO0VBR0YsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLEtBQUssR0FDbEI7RUFHRixJQUFJLE9BQU8sSUFBSTtHQUNiLE1BQU0sT0FBTyxPQUFPLEVBQUUsQ0FBQyxLQUFLO0dBRzVCLElBQUksTUFBTSxDQUFDLE1BQU0sSUFBSTtHQUVyQixNQUFNLEtBQUssS0FBSyxRQUFRLEdBQUc7R0FDM0IsSUFBSSxLQUFLLElBRVAsTUFBTSxDQUFDLEtBQUssTUFBTSxHQUFHLEVBQUUsR0FBRyxLQUFLLE1BQU0sS0FBSyxDQUFDLENBQUM7R0FHOUMsSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJO0dBQ3hCLElBQUk7RUFDTixPQUFPLElBQUksT0FBTyxJQUNoQixJQUFJLE1BQU0sT0FBTyxNQUFNLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsR0FBRyxPQUFPLEVBQUUsQ0FBQyxTQUFTLENBQUM7Q0FFN0U7Q0FFQSxPQUFPO0FBQ1Q7QUFJQSxJQUFNLFFBQVE7QUFDZCxJQUFNLFlBQVk7QUFDbEIsSUFBTSxlQUFlO0FBRXJCLElBQU0sWUFBWTtBQUtsQixJQUFNLFdBQVc7QUFHakIsSUFBTSxRQUFRLE9BQU8sT0FBTyxJQUFJO0FBRWhDLFNBQVMsaUJBQWlCLE9BQU87Q0FDL0IsTUFBTSxRQUFRLFNBQVUsTUFBTTtFQUM1QixJQUFJLEtBQUssU0FBUyxRQUFRO0dBQ3hCLEtBQUssVUFBVSxLQUFLLFFBQVEsTUFBTSxRQUFRLENBQUMsQ0FBQyxLQUFLLEdBQUc7R0FDcEQ7RUFDRjtFQUNBLElBQUksS0FBSyxTQUFTLFdBQVc7R0FDM0IsS0FBSyxVQUFVLEtBQUssUUFBUSxNQUFNLFFBQVEsQ0FBQyxDQUFDLEtBQUssR0FBRztHQUNwRDtFQUNGO0VBQ0EsS0FBSyxNQUFNLE9BQU8sS0FBSyxPQUFPO0dBQzVCLE1BQU0sUUFBUSxLQUFLLE1BQU07R0FDekIsSUFBSSxPQUFPLFVBQVUsWUFBWSxNQUFNLFFBQVEsUUFBUSxJQUFJLElBQ3pELEtBQUssTUFBTSxPQUFPLE1BQU0sTUFBTSxRQUFRLENBQUMsQ0FBQyxLQUFLLEdBQUc7RUFFcEQ7RUFDQSxJQUFJLEtBQUssU0FBUyxRQUNoQixpQkFBaUIsS0FBSyxRQUFRO0NBRWxDLENBQUM7QUFDSDtBQUVBLFNBQVMsTUFBTSxNQUFNLFNBQVM7Q0FDNUIsTUFBTSxhQUFjLFdBQVcsUUFBUSxjQUFlO0NBQ3RELE1BQU0sY0FBYyxXQUFXLFFBQVE7Q0FDdkMsSUFBSSxnQkFBZ0I7Q0FDcEIsSUFBSSxhQUFhO0VBQ2YsTUFBTSxZQUNKLE9BQU8sZ0JBQWdCLGFBQ25CLGNBQ0EsU0FBVSxNQUFNO0dBQ2QsT0FBTyxZQUFZLFFBQVEsSUFBSSxJQUFJO0VBQ3JDO0VBS04sSUFBSSxNQUFNO0VBQ1YsSUFBSSxNQUFNO0VBQ1YsTUFBTSxZQUFZO0VBQ2xCLElBQUk7RUFDSixPQUFRLEtBQUssTUFBTSxLQUFLLElBQUksR0FBSTtHQUM5QixNQUFNLE1BQU0sR0FBRztHQUNmLE9BQU8sS0FBSyxNQUFNLEtBQUssR0FBRyxLQUFLO0dBQy9CLE1BQU0sWUFBWSxJQUFJLE1BQU0sU0FBUztHQUNyQyxJQUFJLElBQUksV0FBVyxNQUFNLEtBQU0sYUFBYSxVQUFVLFVBQVUsRUFBRSxHQUFJO0lBQ3BFLE9BQU87SUFDUCxNQUFNLEdBQUcsUUFBUSxJQUFJO0dBQ3ZCLE9BQU87SUFDTCxnQkFBZ0I7SUFDaEIsT0FBTztJQUNQLE1BQU0sR0FBRyxRQUFRO0lBQ2pCLE1BQU0sWUFBWTtHQUNwQjtFQUNGO0VBQ0EsT0FBTyxNQUFNLEtBQUssTUFBTSxHQUFHO0NBQzdCO0NBQ0EsTUFBTSxTQUFTLENBQUM7Q0FDaEIsTUFBTSxNQUFNLENBQUM7Q0FDYixJQUFJO0NBQ0osSUFBSSxRQUFRO0NBQ1osSUFBSSxjQUFjO0NBR2xCLElBQUksV0FBVztDQUVmLElBQUk7Q0FHSixJQUFJLEtBQUssUUFBUSxHQUFHLE1BQU0sR0FBRztFQUMzQixNQUFNLE1BQU0sS0FBSyxRQUFRLEdBQUc7RUFDNUIsT0FBTyxLQUFLO0dBQ1YsTUFBTTtHQUNOLFNBQVMsUUFBUSxLQUFLLE9BQU8sS0FBSyxVQUFVLEdBQUcsR0FBRztFQUNwRCxDQUFDO0NBQ0g7Q0FHQSxNQUFNLFVBQVUsQ0FBQztDQUNqQixJQUFJO0NBQ0osT0FBUSxJQUFJLE1BQU0sS0FBSyxJQUFJLEdBQ3pCLFFBQVEsS0FBSyxDQUFDO0NBRWhCLFFBQVEsUUFBUSxTQUFVLE9BQU8sR0FBRztFQUNsQyxNQUFNLE1BQU0sTUFBTTtFQUNsQixJQUFJLENBQUMsS0FBSztFQUdWLElBQUksSUFBSSxXQUFXLE1BQU0sR0FBRztFQUc1QixJQUFJLE1BQU07RUFDVixJQUFJLE1BQU07RUFDVixJQUFJLFdBQVc7RUFDZixJQUFJLFFBQVE7RUFDWixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7R0FDbkMsTUFBTSxJQUFJLElBQUksT0FBTyxDQUFDO0dBQ3RCLElBQUksT0FDRTtRQUFBLE1BQU0sT0FBTyxRQUFRO0dBQUEsT0FDcEIsSUFBSSxNQUFNLFFBQU8sTUFBTSxLQUM1QixRQUFRO1FBQ0gsSUFBSSxNQUFNLEtBQUs7SUFDcEI7SUFDQSxJQUFJLFFBQVEsR0FBRyxXQUFXO0dBQzVCLE9BQU8sSUFBSSxNQUFNLEtBQ2Y7RUFFSjtFQUlBLE1BQU0sYUFDSixXQUFXLE1BQU0sa0JBQWtCLEtBQUssSUFBSSxPQUFPLFdBQVcsQ0FBQyxDQUFDO0VBQ2xFLElBQUksTUFBTSxPQUFPLFlBQVk7R0FDM0IsTUFBTSxZQUFZLElBQUksVUFBVSxHQUFHLFFBQVE7R0FDM0MsTUFBTSxhQUFhLElBQUksVUFBVSxVQUFVLE1BQU07R0FDakQsUUFBUSxFQUFFLENBQUMsS0FBSztHQUNoQixRQUFRLEVBQUUsQ0FBQyxTQUFTLFVBQVU7RUFDaEM7Q0FDRixDQUFDO0NBQ0QsUUFBUSxRQUFRLFNBQVUsT0FBTyxHQUFHO0VBQ2xDLE1BQU0sTUFBTSxNQUFNO0VBQ2xCLElBQUksQ0FBQyxLQUFLO0VBQ1YsTUFBTSxRQUFRLE1BQU07RUFDcEIsSUFBSSxRQUFRLFVBQVU7RUFDdEIsSUFBSSxhQUNGLElBQUksUUFBUSxPQUFPLFFBQVEsT0FBTyxLQUNoQztPQUVBLGNBQWM7RUFHbEIsTUFBTSxTQUFTLElBQUksT0FBTyxDQUFDLE1BQU07RUFDakMsTUFBTSxZQUFZLElBQUksV0FBVyxNQUFNO0VBQ3ZDLE1BQU0sUUFBUSxRQUFRLElBQUk7RUFDMUIsTUFBTSxXQUFXLEtBQUssT0FBTyxLQUFLO0VBQ2xDLE1BQU0sWUFBWSxRQUFRLElBQUk7RUFDOUIsSUFBSTtFQUNKLElBQUksYUFBYSxPQUFPLFdBQVc7R0FDakMsTUFBTSxVQUFVLEtBQUssVUFBVSxPQUFPLFVBQVUsS0FBSztHQUNyRCxTQUFTLFFBQVEsTUFBTSxHQUFHLENBQUMsQ0FBQyxTQUFTLFFBQVEsTUFBTSxHQUFHLENBQUMsQ0FBQztFQUMxRDtFQUVBLElBQUk7RUFFSixJQUFJLFdBQVc7R0FDYixNQUFNLFVBQVUsU0FBUyxHQUFHO0dBRzVCLElBQUksUUFBUSxHQUFHO0lBQ2IsT0FBTyxLQUFLLE9BQU87SUFDbkIsT0FBTztHQUNUO0dBQ0EsU0FBUyxJQUFJO0dBQ2IsT0FBTyxTQUFTLEtBQUssT0FBTztHQUU1QixNQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sWUFBWSxVQUFVLFFBQVEsS0FBQSxDQUFTO0dBQ3RFLElBQUksS0FBSyxTQUFTLEdBQ2hCLE9BQU8sU0FBUyxLQUFLO0lBQ25CLE1BQU07SUFDTixTQUFTO0dBQ1gsQ0FBQztHQUVILE9BQU87RUFDVDtFQUVBLElBQUksUUFBUTtHQUNWO0dBRUEsVUFBVSxTQUFTLEdBQUc7R0FDdEIsSUFBSSxRQUFRLFNBQVMsU0FBUyxXQUFXLFFBQVEsT0FBTztJQUN0RCxRQUFRLE9BQU87SUFDZixjQUFjO0dBQ2hCO0dBRUEsSUFBSSxZQUFZO0dBQ2hCLElBQ0UsQ0FBQyxlQUNELENBQUMsUUFBUSxlQUNULFVBQVUsS0FBSyxRQUFRLElBQUksR0FDM0I7SUFHQSxZQUFZO0lBQ1osY0FBYyxZQUFZLEtBQUssWUFBWTtJQUMzQyxNQUFNLGFBQWEsVUFBVSxRQUMzQixPQUFPLFFBQVEsS0FBSyxZQUFZLElBQUksS0FDcEMsS0FDRjtJQUNBLE1BQU0sYUFBYSxlQUFlLEtBQUssS0FBSyxTQUFTO0lBQ3JELE1BQU0sVUFBVSxLQUFLLE1BQU0sT0FBTyxVQUFVO0lBQzVDLElBQUksU0FDRixRQUFRLFNBQVMsS0FBSztLQUNwQixNQUFNO0tBQ047SUFDRixDQUFDO0lBRUgsV0FBVztHQUNiO0dBRUEsSUFDRSxDQUFDLFFBQVEsZUFDVCxDQUFDLGVBQ0QsQ0FBQyxhQUNELFlBQ0EsYUFBYSxLQUliLFFBQVEsU0FBUyxLQUFLO0lBQ3BCLE1BQU07SUFDTixTQUFTLEtBQUssTUFBTSxPQUFPLFlBQVksVUFBVSxRQUFRLEtBQUEsQ0FBUztHQUNwRSxDQUFDO0dBSUgsSUFBSSxVQUFVLEdBQ1osT0FBTyxLQUFLLE9BQU87R0FHckIsU0FBUyxJQUFJLFFBQVE7R0FFckIsSUFBSSxRQUNGLE9BQU8sU0FBUyxLQUFLLE9BQU87R0FHOUIsSUFBSSxTQUFTO0VBQ2Y7RUFFQSxJQUFJLENBQUMsVUFBVSxRQUFRLGFBQWE7R0FDbEMsSUFDRSxRQUFRLE9BQ1AsUUFBUSxlQUFlLFFBQVEsU0FBUyxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQ3hEO0lBQ0E7SUFFQSxVQUFVLFVBQVUsS0FBSyxTQUFTLElBQUk7R0FDeEM7R0FDQSxJQUFJLENBQUMsZ0JBQWdCLGFBQWEsT0FBTyxXQUFXLFVBQVU7SUFJNUQsU0FBUyxVQUFVLEtBQUssU0FBUyxJQUFJLE1BQU0sQ0FBQztJQUk1QyxNQUFNLE1BQU0sWUFBWSxVQUFVLFFBQVE7SUFDMUMsSUFBSSxVQUFVLEtBQUssTUFBTSxPQUFPLFFBQVEsS0FBSyxLQUFBLElBQVksR0FBRztJQUc1RCxJQUFJLGFBQWEsS0FBSyxPQUFPLEdBQzNCLFVBQVU7SUFNWixJQUFLLE1BQU0sTUFBTSxRQUFRLE9BQU8sVUFBVSxLQUFNLFlBQVksS0FDMUQsT0FBTyxLQUFLO0tBQ1YsTUFBTTtLQUNOO0lBQ0YsQ0FBQztHQUVMO0VBQ0Y7Q0FDRixDQUFDO0NBRUQsSUFBSSxlQUNGLGlCQUFpQixNQUFNO0NBR3pCLE9BQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxPQUFPO0NBQ3pCLE1BQU0sT0FBTyxDQUFDO0NBQ2QsS0FBSyxNQUFNLE9BQU8sT0FDaEIsSUFBSSxNQUFNLFNBQVMsTUFFakIsS0FBSyxLQUFLLEdBQUc7TUFJYixLQUFLLEtBQUssTUFBTSxRQUFPLE9BQU8sTUFBTSxJQUFJLENBQUMsQ0FBQyxRQUFRLE1BQU0sUUFBUSxJQUFJLElBQUc7Q0FHM0UsSUFBSSxDQUFDLEtBQUssUUFDUixPQUFPO0NBRVQsT0FBTyxNQUFNLEtBQUssS0FBSyxHQUFHO0FBQzVCO0FBRUEsU0FBUyxjQUFjLE1BQU0sS0FBSztDQUNoQyxRQUFRLElBQUksTUFBWjtFQUNFLEtBQUssUUFDSCxPQUFPLE9BQU8sSUFBSTtFQUNwQixLQUFLLE9BQU87R0FFVixNQUFNLFNBQ0osSUFBSSxlQUFlLElBQUksS0FBSyxZQUFZLE1BQU0sYUFBYSxPQUFPO0dBQ3BFLFFBQVEsTUFBTSxJQUFJLFFBQVEsSUFBSSxRQUFRLFdBQVcsSUFBSSxLQUFLLElBQUksTUFBTTtHQUNwRSxJQUFJLElBQUksYUFDTixPQUFPO0dBRVQsT0FDRSxPQUFPLElBQUksU0FBUyxPQUFPLGVBQWUsRUFBRSxJQUFJLE9BQU8sSUFBSSxPQUFPO0VBRXRFO0VBQ0EsS0FBSztHQUNILFFBQVEsU0FBUyxJQUFJLFVBQVU7R0FDL0IsT0FBTztDQUNYO0FBQ0Y7QUFFQSxTQUFTLFVBQVUsS0FBSztDQUN0QixPQUFPLElBQUksT0FBTyxTQUFVLE9BQU8sUUFBUTtFQUN6QyxPQUFPLFFBQVEsY0FBYyxJQUFJLE1BQU07Q0FDekMsR0FBRyxFQUFFO0FBQ1A7QUFFQSxJQUFJLFFBQVE7Q0FDVjtDQUNBO0FBQ0Y7OztBQzFhQSxJQUFhLFFBQVEsTUFBTSxNQUFNLEtBQUssU0FBUztDQUM3QyxNQUFNLE9BQU8sQ0FBQyxLQUFLO0VBQ2pCO0VBQ0EsR0FBSSxRQUFRLENBQUM7Q0FDZixDQUFDO0NBQ0QsSUFBSSxNQUFNLFVBQVUsUUFBUSxTQUMxQixPQUFPLEtBQUssU0FBUyxPQUFPLFFBQVEsTUFBTSxRQUFRLG1CQUFtQixJQUFJO0NBRTNFLElBQUksU0FBUyxLQUFLLEVBQUUsR0FBRyxLQUFLLEtBQUssbUJBQW1CLEtBQUs7Q0FDekQsSUFBSSxNQUFNLFVBQVUsUUFBUSxNQUMxQixLQUFLLFNBQVMsT0FBTyxLQUFLLEdBQUcsSUFBSTtNQUM1QixJQUFJLFNBQVMsTUFDbEIsUUFBUSxLQUFLLEdBQUcsSUFBSTtBQUV4QjtBQUNBLElBQU0sZ0JBQWdCLENBQUM7QUFDdkIsSUFBYSxZQUFZLE1BQU0sTUFBTSxLQUFLLFNBQVM7Q0FDakQsSUFBSSxTQUFTLEdBQUcsS0FBSyxjQUFjLE1BQU07Q0FDekMsSUFBSSxTQUFTLEdBQUcsR0FBRyxjQUFjLHVCQUFPLElBQUksS0FBSztDQUNqRCxLQUFLLE1BQU0sTUFBTSxLQUFLLElBQUk7QUFDNUI7QUFDQSxJQUFNLGFBQWEsTUFBTSxhQUFhO0NBQ3BDLElBQUksS0FBSyxlQUNQLEdBQUc7TUFDRTtFQUNMLE1BQU0sb0JBQW9CO0dBQ3hCLGlCQUFpQjtJQUNmLEtBQUssSUFBSSxlQUFlLFdBQVc7R0FDckMsR0FBRyxDQUFDO0dBQ0osR0FBRztFQUNMO0VBQ0EsS0FBSyxHQUFHLGVBQWUsV0FBVztDQUNwQztBQUNGO0FBQ0EsSUFBYSxrQkFBa0IsTUFBTSxJQUFJLE9BQU87Q0FDOUMsS0FBSyxlQUFlLElBQUksVUFBVSxNQUFNLEVBQUUsQ0FBQztBQUM3QztBQUNBLElBQWEsaUJBQWlCLE1BQU0sS0FBSyxJQUFJLE9BQU87Q0FDbEQsSUFBSSxTQUFTLEVBQUUsR0FBRyxLQUFLLENBQUMsRUFBRTtDQUMxQixJQUFJLEtBQUssUUFBUSxXQUFXLEtBQUssUUFBUSxRQUFRLFFBQVEsR0FBRyxJQUFJLElBQUksT0FBTyxlQUFlLE1BQU0sSUFBSSxFQUFFO0NBQ3RHLEdBQUcsU0FBUSxNQUFLO0VBQ2QsSUFBSSxLQUFLLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxHQUFHLEtBQUssUUFBUSxHQUFHLEtBQUssQ0FBQztDQUM1RCxDQUFDO0NBQ0QsS0FBSyxjQUFjLEtBQUssVUFBVSxNQUFNLEVBQUUsQ0FBQztBQUM3QztBQUNBLElBQWEsc0JBQXNCLElBQUksTUFBTSxVQUFVLENBQUMsTUFBTTtDQUM1RCxJQUFJLENBQUMsS0FBSyxhQUFhLENBQUMsS0FBSyxVQUFVLFFBQVE7RUFDN0MsU0FBUyxNQUFNLGdCQUFnQiwwQ0FBMEMsRUFDdkUsV0FBVyxLQUFLLFVBQ2xCLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLEtBQUssbUJBQW1CLElBQUk7RUFDakMsS0FBSyxRQUFRO0VBQ2IsV0FBVyxjQUFjLG1CQUFtQjtHQUMxQyxJQUFJLFFBQVEsWUFBWSxRQUFRLFNBQVMsUUFBUSxrQkFBa0IsSUFBSSxNQUFNLGFBQWEsU0FBUyxpQkFBaUIsV0FBVyxhQUFhLHdCQUF3QixDQUFDLGVBQWUsYUFBYSxzQkFBc0IsRUFBRSxHQUFHLE9BQU87RUFDck87Q0FDRixDQUFDO0FBQ0g7QUFDQSxJQUFhLGtCQUFpQixjQUFhLFVBQVUsZUFBZSxVQUFVLFNBQVMsU0FBUyxTQUFTLEtBQUssVUFBVSxTQUFTLElBQUksWUFBWTtBQUNqSixJQUFhLFlBQVcsUUFBTyxPQUFPLFFBQVE7QUFDOUMsSUFBYSxZQUFXLFFBQU8sT0FBTyxRQUFRLFlBQVksUUFBUTs7O0FDN0RsRSxJQUFNLGtCQUFrQjtBQUN4QixJQUFNLGVBQWU7Q0FDbkIsU0FBUztDQUNULFNBQVM7Q0FDVCxRQUFRO0NBQ1IsU0FBUztDQUNULFFBQVE7Q0FDUixTQUFTO0NBQ1QsVUFBVTtDQUNWLFNBQVM7Q0FDVCxVQUFVO0NBQ1YsU0FBUztDQUNULFVBQVU7Q0FDVixVQUFVO0NBQ1YsVUFBVTtDQUNWLFVBQVU7Q0FDVixTQUFTO0NBQ1QsVUFBVTtDQUNWLFlBQVk7Q0FDWixXQUFXO0NBQ1gsVUFBVTtDQUNWLFNBQVM7QUFDWDtBQUNBLElBQU0sc0JBQXFCLE1BQUssYUFBYTtBQUM3QyxJQUFhLFlBQVcsU0FBUSxLQUFLLFFBQVEsaUJBQWlCLGtCQUFrQjs7O0FDdkJoRixJQUFJLGlCQUFpQjtDQUNuQixVQUFVO0NBQ1YsZUFBZTtDQUNmLHFCQUFxQjtDQUNyQiw0QkFBNEI7Q0FDNUIsb0JBQW9CO0NBQ3BCLDRCQUE0QjtFQUFDO0VBQU07RUFBVTtFQUFLO0NBQUc7Q0FDckQsYUFBYTtDQUNiO0NBQ0EsbUJBQW1CLEtBQUE7QUFDckI7QUFDQSxJQUFhLGVBQWUsVUFBVSxDQUFDLE1BQU07Q0FDM0MsaUJBQWlCO0VBQ2YsR0FBRztFQUNILEdBQUc7Q0FDTDtBQUNGO0FBQ0EsSUFBYSxvQkFBb0I7OztBQ2xCakMsSUFBSTtBQUNKLElBQWEsV0FBVSxhQUFZO0NBQ2pDLGVBQWU7QUFDakI7QUFDQSxJQUFhLGdCQUFnQjs7O0FDRzdCLElBQU0sZUFBZSxNQUFNLGdCQUFnQjtDQUN6QyxJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLE1BQU0sT0FBTyxLQUFLLE9BQU8sWUFBWSxLQUFLO0NBQzFDLElBQUksYUFBYSxPQUFPLEtBQUssU0FBUztDQUN0QyxPQUFPLENBQUMsQ0FBQztBQUNYO0FBQ0EsSUFBTSxlQUFjLFNBQVE7Q0FDMUIsSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDO0NBQ25CLE1BQU0sV0FBVyxLQUFLLE9BQU8sWUFBWSxLQUFLO0NBQzlDLE9BQU8sS0FBSyxPQUFPLG9CQUFvQixXQUFXLFFBQVEsSUFBSTtBQUNoRTtBQUNBLElBQU0seUJBQXdCLGFBQVksTUFBTSxRQUFRLFFBQVEsS0FBSyxTQUFTLE1BQU1BLGFBQUFBLGNBQWM7QUFDbEcsSUFBTSxjQUFhLFNBQVEsTUFBTSxRQUFRLElBQUksSUFBSSxPQUFPLENBQUMsSUFBSTtBQUM3RCxJQUFNLGNBQWMsUUFBUSxXQUFXO0NBQ3JDLE1BQU0sWUFBWSxFQUNoQixHQUFHLE9BQ0w7Q0FDQSxVQUFVLFFBQVE7RUFDaEIsR0FBRyxPQUFPO0VBQ1YsR0FBRyxPQUFPO0NBQ1o7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxJQUFNLHlCQUF3QixhQUFZO0NBQ3hDLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLElBQUksQ0FBQyxVQUFVLE9BQU87Q0FDdEIsTUFBTSxXQUFVLFdBQVU7RUFFeEIsV0FEaUMsTUFDckIsQ0FBQyxDQUFDLFNBQVEsVUFBUztHQUM3QixJQUFJLFNBQVMsS0FBSyxHQUFHO0dBQ3JCLElBQUksWUFBWSxLQUFLLEdBQUcsUUFBUSxZQUFZLEtBQUssQ0FBQztRQUFPLElBQUksU0FBUyxLQUFLLEtBQUssRUFBQSxHQUFDQSxhQUFBQSxlQUFBQSxDQUFlLEtBQUssR0FBRyxPQUFPLE9BQU8sUUFBUSxLQUFLO0VBQ3JJLENBQUM7Q0FDSDtDQUNBLFFBQVEsUUFBUTtDQUNoQixPQUFPO0FBQ1Q7QUFDQSxJQUFhLGlCQUFpQixVQUFVLGFBQWEsTUFBTSxZQUFZO0NBQ3JFLElBQUksQ0FBQyxVQUFVLE9BQU87Q0FDdEIsSUFBSSxhQUFhO0NBQ2pCLE1BQU0sZ0JBQWdCLFdBQVcsUUFBUTtDQUN6QyxNQUFNLFlBQVksYUFBYSw2QkFBNkIsWUFBWSw4QkFBOEIsQ0FBQyxJQUFJLENBQUM7Q0FDNUcsY0FBYyxTQUFTLE9BQU8sZUFBZTtFQUMzQyxJQUFJLFNBQVMsS0FBSyxHQUFHO0dBQ25CLGNBQWMsR0FBRztHQUNqQjtFQUNGO0VBQ0EsS0FBQSxHQUFJQSxhQUFBQSxlQUFBQSxDQUFlLEtBQUssR0FBRztHQUN6QixNQUFNLEVBQ0osT0FDQSxTQUNFO0dBQ0osTUFBTSxrQkFBa0IsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0dBQzNDLE1BQU0sa0JBQWtCLFVBQVUsUUFBUSxJQUFJLElBQUk7R0FDbEQsTUFBTSxnQkFBZ0IsTUFBTTtHQUM1QixJQUFJLENBQUMsaUJBQWlCLG1CQUFtQixDQUFDLGlCQUFpQjtJQUN6RCxjQUFjLElBQUksS0FBSztJQUN2QjtHQUNGO0dBQ0EsSUFBSSxDQUFDLGtCQUFrQixDQUFDLG1CQUFtQixvQkFBb0IsTUFBTSxtQkFBbUI7SUFDdEYsY0FBYyxJQUFJLFdBQVcsS0FBSyxXQUFXO0lBQzdDO0dBQ0Y7R0FDQSxJQUFJLG1CQUFtQixtQkFBbUIsR0FBRztJQUMzQyxNQUFNLE1BQU0sU0FBUyxhQUFhLElBQUksZ0JBQWdCLGNBQWMsZUFBZSxhQUFhLE1BQU0sT0FBTztJQUM3RyxjQUFjLElBQUksS0FBSyxHQUFHLElBQUksSUFBSSxLQUFLO0lBQ3ZDO0dBQ0Y7R0FDQSxNQUFNLFVBQVUsY0FBYyxlQUFlLGFBQWEsTUFBTSxPQUFPO0dBQ3ZFLGNBQWMsSUFBSSxXQUFXLEdBQUcsUUFBUSxJQUFJLFdBQVc7R0FDdkQ7RUFDRjtFQUNBLElBQUksVUFBVSxNQUFNO0dBQ2xCLEtBQUssTUFBTSxvQkFBb0IsbUNBQW1DLEVBQ2hFLFFBQ0YsQ0FBQztHQUNEO0VBQ0Y7RUFDQSxJQUFJLFNBQVMsS0FBSyxHQUFHO0dBQ25CLE1BQU0sRUFDSixRQUNBLEdBQUcsVUFDRDtHQUNKLE1BQU0sT0FBTyxPQUFPLEtBQUssS0FBSztHQUM5QixJQUFJLEtBQUssV0FBVyxHQUFHO0lBQ3JCLE1BQU0sUUFBUSxTQUFTLEdBQUcsS0FBSyxHQUFHLElBQUksV0FBVyxLQUFLO0lBQ3RELGNBQWMsS0FBSyxNQUFNO0lBQ3pCO0dBQ0Y7R0FDQSxLQUFLLE1BQU0scUJBQXFCLDBGQUEwRjtJQUN4SDtJQUNBO0dBQ0YsQ0FBQztHQUNEO0VBQ0Y7RUFDQSxLQUFLLE1BQU0scUJBQXFCLDBHQUEwRztHQUN4STtHQUNBO0VBQ0YsQ0FBQztDQUNILENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxJQUFNLGVBQWUsVUFBVSxvQkFBb0IsY0FBYyxNQUFNLGFBQWEsZUFBZSxtQkFBbUI7Q0FDcEgsSUFBSSxpQkFBaUIsSUFBSSxPQUFPLENBQUM7Q0FDakMsTUFBTSxZQUFZLFlBQVksOEJBQThCLENBQUM7Q0FDN0QsTUFBTSxnQ0FBZ0MsZ0JBQWdCLElBQUksT0FBTyxVQUFVLEtBQUksU0FBUSxJQUFJLE1BQU0sQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLFlBQVk7Q0FDL0gsSUFBSSxDQUFDLFlBQVksQ0FBQyxzQkFBc0IsQ0FBQyxpQ0FBaUMsQ0FBQyxnQkFBZ0IsT0FBTyxDQUFDLFlBQVk7Q0FDL0csTUFBTSxPQUFPLHNCQUFzQixDQUFDO0NBQ3BDLE1BQU0sV0FBVSxXQUFVO0VBRXhCLFdBRGlDLE1BQ3JCLENBQUMsQ0FBQyxTQUFRLFVBQVM7R0FDN0IsSUFBSSxTQUFTLEtBQUssR0FBRztHQUNyQixJQUFJLFlBQVksS0FBSyxHQUFHLFFBQVEsWUFBWSxLQUFLLENBQUM7UUFBTyxJQUFJLFNBQVMsS0FBSyxLQUFLLEVBQUEsR0FBQ0EsYUFBQUEsZUFBQUEsQ0FBZSxLQUFLLEdBQUcsT0FBTyxPQUFPLE1BQU0sS0FBSztFQUNuSSxDQUFDO0NBQ0g7Q0FDQSxRQUFRLFFBQVE7Q0FDaEIsTUFBTSxhQUFhLE9BQU8sS0FBSyxJQUFJO0NBQ25DLE1BQU0sZUFBYyxTQUFRLFFBQVEsS0FBSyxJQUFJLEtBQUssVUFBVSxRQUFRLElBQUksSUFBSSxNQUFNLFdBQVcsUUFBUSxJQUFJLElBQUk7Q0FDN0csTUFBTSxNQUFNQyxNQUFLLE1BQU0sTUFBTSxhQUFhLE9BQU8sRUFDL0MsWUFDRixDQUFDO0NBQ0QsTUFBTSxPQUFPO0VBQ1gsR0FBRztFQUNILEdBQUc7Q0FDTDtDQUNBLE1BQU0sZUFBZSxPQUFPLE1BQU0sa0JBQWtCO0VBQ2xELE1BQU0sU0FBUyxZQUFZLEtBQUs7RUFDaEMsTUFBTSxpQkFBaUIsT0FBTyxRQUFRLEtBQUssVUFBVSxhQUFhO0VBQ2xFLE9BQU8sc0JBQXNCLE1BQU0sS0FBSyxlQUFlLFdBQVcsS0FBSyxNQUFNLE9BQU8sb0JBQW9CLFNBQVM7Q0FDbkg7Q0FDQSxNQUFNLHFCQUFxQixPQUFPLE9BQU8sS0FBSyxHQUFHLFdBQVc7RUFDMUQsSUFBSSxNQUFNLE9BQU87R0FDZixNQUFNLFdBQVc7R0FDakIsSUFBSSxNQUFBLEdBQUtDLGFBQUFBLGFBQUFBLENBQWEsT0FBTyxFQUMzQixLQUFLLEVBQ1AsR0FBRyxTQUFTLEtBQUEsSUFBWSxLQUFLLENBQUM7RUFDaEMsT0FDRSxJQUFJLEtBQUssR0FBR0MsYUFBQUEsU0FBUyxJQUFJLENBQUMsS0FBSyxJQUFHLE1BQUs7R0FDckMsSUFBSSxFQUFFLFNBQVNDLGFBQUFBLFlBQVksRUFBRSxPQUFPLHNCQUFzQixLQUFBLEdBQVc7SUFDbkUsTUFBTSxhQUFhLEVBQ2pCLEtBQUssRUFDUDtJQUNBLElBQUksS0FBSyxFQUFFLE9BQ1QsT0FBTyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsU0FBUSxNQUFLO0tBQ2hDLElBQUksTUFBTSxjQUFjLE1BQU0scUJBQXFCO0tBQ25ELFdBQVcsS0FBSyxFQUFFLE1BQU07SUFDMUIsQ0FBQztJQUVILFFBQUEsR0FBT0MsYUFBQUEsY0FBQUEsQ0FBYyxFQUFFLE1BQU0sWUFBWSxTQUFTLE9BQU8sS0FBSztHQUNoRTtHQUNBLE1BQU0sV0FBVyxFQUNmLEtBQUssRUFDUDtHQUNBLElBQUksS0FBSyxFQUFFLE9BQ1QsT0FBTyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsU0FBUSxNQUFLO0lBQ2hDLElBQUksTUFBTSxTQUFTLE1BQU0sWUFBWTtJQUNyQyxTQUFTLEtBQUssRUFBRSxNQUFNO0dBQ3hCLENBQUM7R0FFSCxRQUFBLEdBQU9ILGFBQUFBLGFBQUFBLENBQWEsR0FBRyxVQUFVLFNBQVMsT0FBTyxLQUFLO0VBQ3hELENBQUMsQ0FBQztDQUVOO0NBQ0EsTUFBTSxVQUFVLFdBQVcsU0FBUyxrQkFBa0I7RUFDcEQsTUFBTSxhQUFhLFdBQVcsU0FBUztFQUN2QyxNQUFNLFdBQVcsV0FBVyxPQUFPO0VBQ25DLE1BQU0sb0JBQW9CLENBQUM7RUFDM0IsT0FBTyxTQUFTLFFBQVEsS0FBSyxNQUFNLE1BQU07R0FDdkMsTUFBTSxxQkFBcUIsS0FBSyxXQUFXLEVBQUUsRUFBRSxXQUFXLEtBQUssU0FBUyxhQUFhLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQyxTQUFTLE1BQU0sS0FBSyxRQUFRO0dBQzlJLElBQUksS0FBSyxTQUFTLE9BQU87SUFDdkIsSUFBSSxNQUFNLFdBQVcsU0FBUyxLQUFLLE1BQU0sRUFBRTtJQUMzQyxJQUFJLENBQUMsT0FBTyxvQkFBb0IsTUFBTSxtQkFBbUIsS0FBSztJQUM5RCxJQUFJLGNBQWMsV0FBVyxLQUFLLENBQUMsS0FBSyxNQUFNLGNBQWMsRUFBRSxDQUFDLEtBQUs7SUFDcEUsSUFBSSxDQUFDLEtBQUssTUFBTSxDQUFDO0lBQ2pCLE1BQU0sUUFBUSxFQUNaLEdBQUcsS0FBSyxNQUNWO0lBQ0EsSUFBSSxnQkFDRixPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsU0FBUSxNQUFLO0tBQzlCLE1BQU0sTUFBTSxNQUFNO0tBQ2xCLElBQUksU0FBUyxHQUFHLEdBQ2QsTUFBTSxLQUFLLFNBQVMsR0FBRztJQUUzQixDQUFDO0lBRUgsTUFBTSxRQUFRLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxXQUFXLElBQUksV0FBVyxFQUN6RCxNQUNGLEdBQUcsR0FBRyxJQUFJO0lBQ1YsTUFBTSxhQUFBLEdBQVlGLGFBQUFBLGVBQUFBLENBQWUsS0FBSztJQUN0QyxNQUFNLGlDQUFpQyxhQUFhLFlBQVksTUFBTSxJQUFJLEtBQUssQ0FBQyxLQUFLO0lBQ3JGLE1BQU0sdUJBQXVCLGlDQUFpQyxTQUFTLEtBQUssS0FBSyxNQUFNLFNBQVMsQ0FBQztJQUNqRyxNQUFNLG1CQUFtQixTQUFTLGtCQUFrQixLQUFLLE9BQU8sZUFBZSxLQUFLLG9CQUFvQixLQUFLLElBQUk7SUFDakgsSUFBSSxTQUFTLEtBQUssR0FBRztLQUNuQixNQUFNLFFBQVEsS0FBSyxTQUFTLGFBQWEsWUFBWSxPQUFPLE1BQU0sS0FBSyxRQUFRO0tBQy9FLElBQUksS0FBSyxLQUFLO0lBQ2hCLE9BQU8sSUFBSSxZQUFZLEtBQUssS0FBSyxnQ0FBZ0M7S0FDL0QsTUFBTSxRQUFRLFlBQVksT0FBTyxNQUFNLGFBQWE7S0FDcEQsa0JBQWtCLE9BQU8sT0FBTyxLQUFLLENBQUM7SUFDeEMsT0FBTyxJQUFJLHNCQUFzQjtLQUMvQixNQUFNLFFBQVEsT0FBTyxZQUFZLEtBQUssVUFBVSxhQUFhO0tBQzdELGtCQUFrQixPQUFPLE9BQU8sS0FBSyxDQUFDO0lBQ3hDLE9BQU8sSUFBSSxPQUFPLE1BQU0sV0FBVyxLQUFLLElBQUksQ0FBQyxHQUMzQyxJQUFJLGtCQUFrQjtLQUNwQixNQUFNLFFBQVEsWUFBWSxPQUFPLE1BQU0sYUFBYTtLQUNwRCxrQkFBa0IsT0FBTyxPQUFPLEtBQUssR0FBRyxLQUFLLFdBQVc7SUFDMUQsT0FBTyxJQUFJLFlBQVksOEJBQThCLFVBQVUsUUFBUSxLQUFLLElBQUksSUFBSSxJQUNsRixJQUFJLEtBQUssYUFDUCxJQUFJLE1BQUEsR0FBS0ssYUFBQUEsY0FBQUEsQ0FBYyxLQUFLLE1BQU0sRUFDaEMsS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLElBQ3ZCLENBQUMsQ0FBQztTQUNHO0tBQ0wsTUFBTSxhQUFhLGtCQUFrQixLQUFLLFNBQVM7S0FDbkQsa0JBQWtCLEtBQUssUUFBUSxhQUFhO0tBQzVDLElBQUk7S0FDSixJQUFJLE9BQU87S0FDWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksV0FBVyxRQUFRLEtBQUssR0FBRztNQUM3QyxNQUFNLEtBQUssV0FBVztNQUN0QixLQUFBLEdBQUlMLGFBQUFBLGVBQUFBLENBQWUsRUFBRSxLQUFLLEdBQUcsU0FBUyxLQUFLLE1BQU07T0FDL0MsSUFBSSxTQUFTLFlBQVk7UUFDdkIsVUFBVTtRQUNWO09BQ0Y7T0FDQSxRQUFRO01BQ1Y7S0FDRjtLQUNBLE1BQU0sYUFBYSxVQUFVLFdBQVcsWUFBWSxPQUFPLENBQUMsSUFBSTtLQUNoRSxNQUFNLFFBQVEsT0FBTyxZQUFZLEtBQUssVUFBVSxhQUFhO0tBQzdELElBQUksTUFBQSxHQUFLSyxhQUFBQSxjQUFBQSxDQUFjLEtBQUssTUFBTSxFQUNoQyxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsSUFDdkIsR0FBRyxLQUFLLENBQUM7SUFDWDtTQUNLLElBQUksS0FBSyxhQUNkLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJO1NBQ3RCO0tBQ0wsTUFBTSxRQUFRLE9BQU8sWUFBWSxLQUFLLFVBQVUsYUFBYTtLQUM3RCxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssR0FBRyxNQUFNLElBQUksS0FBSyxLQUFLLEVBQUU7SUFDbEQ7U0FDSyxJQUFJLFNBQVMsS0FBSyxLQUFLLENBQUMsV0FBVztLQUN4QyxNQUFNLFVBQVUsS0FBSyxTQUFTLEtBQUsscUJBQXFCO0tBQ3hELElBQUksU0FBUyxJQUFJLEtBQUssT0FBTztJQUMvQixPQUNFLGtCQUFrQixPQUFPLG9CQUFvQixLQUFLLEdBQUcsS0FBSyxTQUFTLFdBQVcsS0FBSyxDQUFDLGtCQUFrQjtHQUUxRyxPQUFPLElBQUksS0FBSyxTQUFTLFFBQVE7SUFDL0IsTUFBTSxnQkFBZ0IsWUFBWTtJQUNsQyxNQUFNLGFBQWEsT0FBTyxZQUFZLGFBQWEsYUFBYSxZQUFZLFdBQVcsWUFBWSxDQUFDLENBQUM7SUFDckcsTUFBTSxVQUFVLGlCQUFpQixXQUFXLEtBQUssU0FBUyxhQUFhLFlBQVksS0FBSyxTQUFTLE1BQU0sS0FBSyxRQUFRLENBQUMsSUFBSSxLQUFLLFNBQVMsYUFBYSxZQUFZLEtBQUssU0FBUyxNQUFNLEtBQUssUUFBUTtJQUNqTSxJQUFJLGVBQ0YsSUFBSSxNQUFBLEdBQUtBLGFBQUFBLGNBQUFBLENBQWMsZUFBZSxFQUNwQyxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsSUFDdkIsR0FBRyxPQUFPLENBQUM7U0FFWCxJQUFJLEtBQUssT0FBTztHQUVwQjtHQUNBLE9BQU87RUFDVCxHQUFHLENBQUMsQ0FBQztDQUNQO0NBS0EsT0FBTyxZQUpRLE9BQU8sQ0FBQztFQUNyQixPQUFPO0VBQ1AsVUFBVSxZQUFZLENBQUM7Q0FDekIsQ0FBQyxHQUFHLEtBQUssV0FBVyxZQUFZLENBQUMsQ0FBQyxDQUNmLENBQUEsQ0FBTyxFQUFFO0FBQzlCO0FBQ0EsSUFBTSxxQkFBcUIsV0FBVyxPQUFPLGdCQUFnQjtDQUMzRCxNQUFNLGVBQWUsVUFBVSxPQUFPO0NBQ3RDLE1BQU0sUUFBQSxHQUFPSCxhQUFBQSxhQUFBQSxDQUFhLFdBQVcsRUFDbkMsS0FBSyxhQUNQLENBQUM7Q0FDRCxJQUFJLENBQUMsS0FBSyxTQUFTLENBQUMsS0FBSyxNQUFNLFlBQVksWUFBWSxRQUFRLEdBQUcsTUFBTSxHQUFHLElBQUksS0FBSyxZQUFZLFFBQVEsR0FBRyxNQUFNLElBQUksSUFBSSxHQUN2SCxPQUFPO0NBRVQsU0FBUyxnQkFBZ0I7RUFDdkIsUUFBQSxHQUFPRyxhQUFBQSxjQUFBQSxDQUFjRCxhQUFBQSxVQUFVLE1BQU0sSUFBSTtDQUMzQztDQUNBLFFBQUEsR0FBT0MsYUFBQUEsY0FBQUEsQ0FBYyxlQUFlLEVBQ2xDLEtBQUssYUFDUCxDQUFDO0FBQ0g7QUFDQSxJQUFNLDJCQUEyQixZQUFZLGdCQUFnQixXQUFXLEtBQUssR0FBRyxVQUFVLGtCQUFrQixHQUFHLE9BQU8sV0FBVyxDQUFDO0FBQ2xJLElBQU0sNEJBQTRCLFlBQVksZ0JBQWdCO0NBQzVELE1BQU0sZUFBZSxDQUFDO0NBQ3RCLE9BQU8sS0FBSyxVQUFVLENBQUMsQ0FBQyxTQUFRLE1BQUs7RUFDbkMsT0FBTyxPQUFPLGNBQWMsR0FDekIsSUFBSSxrQkFBa0IsV0FBVyxJQUFJLEdBQUcsV0FBVyxFQUN0RCxDQUFDO0NBQ0gsQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLElBQU0sc0JBQXNCLFlBQVksYUFBYSxNQUFNLFlBQVk7Q0FDckUsSUFBSSxDQUFDLFlBQVksT0FBTztDQUN4QixJQUFJLE1BQU0sUUFBUSxVQUFVLEdBQzFCLE9BQU8sd0JBQXdCLFlBQVksV0FBVztDQUV4RCxJQUFJLFNBQVMsVUFBVSxHQUNyQixPQUFPLHlCQUF5QixZQUFZLFdBQVc7Q0FFekQsU0FBUyxNQUFNLDRCQUE0QiwwREFBMEQsRUFDbkcsUUFDRixDQUFDO0NBQ0QsT0FBTztBQUNUO0FBQ0EsSUFBTSxtQkFBa0IsV0FBVTtDQUNoQyxJQUFJLENBQUMsU0FBUyxNQUFNLEdBQUcsT0FBTztDQUM5QixJQUFJLE1BQU0sUUFBUSxNQUFNLEdBQUcsT0FBTztDQUNsQyxPQUFPLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxRQUFRLEtBQUssUUFBUSxPQUFPLE9BQU8sTUFBTSxPQUFPLFdBQVcsR0FBRyxDQUFDLEdBQUcsSUFBSTtBQUNuRztBQUNBLFNBQWdCQyxRQUFNLEVBQ3BCLFVBQ0EsT0FDQSxRQUNBLFNBQ0EsU0FDQSxXQUFXLENBQUMsR0FDWixRQUNBLFVBQ0EsWUFDQSxJQUNBLE1BQU0sZUFDTixHQUFHLFlBQ0gsZ0JBQ0EsR0FBRyxtQkFDRjtDQUNELE1BQU0sT0FBTyxpQkFBaUIsUUFBUTtDQUN0QyxJQUFJLENBQUMsTUFBTTtFQUNULFNBQVMsTUFBTSx1QkFBdUIsMkxBQTJMLEVBQy9OLFFBQ0YsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLE1BQU0sSUFBSSxjQUFjLEtBQUssRUFBRSxLQUFLLElBQUksT0FBTSxNQUFLO0NBQ25ELE1BQU0sc0JBQXNCO0VBQzFCLEdBQUcsWUFBWTtFQUNmLEdBQUcsS0FBSyxTQUFTO0NBQ25CO0NBQ0EsSUFBSSxhQUFhLE1BQU0sRUFBRSxNQUFNLEtBQUssU0FBUztDQUM3QyxhQUFhLFNBQVMsVUFBVSxJQUFJLENBQUMsVUFBVSxJQUFJLGNBQWMsQ0FBQyxhQUFhO0NBQy9FLE1BQU0sRUFDSixzQkFDRTtDQUNKLE1BQU0saUJBQWlCLG1CQUFtQixXQUFXO0VBQ25ELEdBQUcsa0JBQWtCO0VBQ3JCLEdBQUc7Q0FDTCxJQUFJO0NBQ0osTUFBTSx1QkFBdUIsa0JBQWtCLG1CQUFtQjtDQUNsRSxNQUFNLGVBQWUsbUJBQW1CLFNBQVM7RUFDL0MsR0FBRyxrQkFBa0I7RUFDckIsR0FBRztDQUNMLElBQUk7Q0FDSixNQUFNLG1CQUFtQixtQkFBbUIsYUFBYTtFQUN2RCxHQUFHLGtCQUFrQjtFQUNyQixHQUFHO0NBQ0wsSUFBSTtDQUNKLE1BQU0sZUFBZSxjQUFjLFVBQVUscUJBQXFCLE1BQU0sT0FBTztDQUMvRSxNQUFNLGVBQWUsWUFBWSxnQkFBZ0IsZ0JBQWdCLGdCQUFnQixvQkFBb0Isd0JBQXdCLE9BQU8sWUFBWSxhQUFhQyxpQkFBZ0IsT0FBTyxJQUFJO0NBQ3hMLE1BQU0sRUFDSixpQkFDRTtDQUNKLE1BQU0sTUFBTSxZQUFZLGVBQWUsYUFBYSxnQkFBZ0IsWUFBWSxJQUFJLGdCQUFnQjtDQUNwRyxJQUFJLEtBQUssU0FBUyxlQUFlLGtCQUMvQixTQUFTLGdCQUFnQixPQUFPLEtBQUssWUFBWSxDQUFDLENBQUMsU0FBUyxJQUFJO0VBQzlELEdBQUc7RUFDSCxHQUFHLEtBQUssUUFBUSxjQUFjO0NBQ2hDLElBQUksRUFDRixHQUFHLEtBQUssUUFBUSxjQUFjLGlCQUNoQztNQUVBLFNBQVM7Q0FFWCxNQUFNLHFCQUFxQixzQkFBc0IsUUFBUTtDQUN6RCxJQUFJLHNCQUFzQixPQUFPLG1CQUFtQixVQUFVLFlBQVksVUFBVSxLQUFBLEdBQ2xGLFFBQVEsbUJBQW1CO0NBRTdCLE1BQU0sd0JBQXdCLFVBQVUsVUFBVSxLQUFBLEtBQWEsQ0FBQyxLQUFLLFNBQVMsZUFBZSxnQkFBZ0IsQ0FBQyxXQUFXLGVBQWUsZ0JBQWdCLEVBQ3RKLGVBQWU7RUFDYixHQUFHLGVBQWU7RUFDbEIsUUFBUTtFQUNSLFFBQVE7Q0FDVixFQUNGO0NBQ0EsTUFBTSxnQkFBZ0I7RUFDcEIsR0FBRztFQUNILFNBQVMsV0FBVyxlQUFlO0VBQ25DO0VBQ0EsR0FBRztFQUNILEdBQUc7RUFDSDtFQUNBLElBQUk7Q0FDTjtDQUNBLElBQUksY0FBYyxNQUFNLEVBQUUsS0FBSyxhQUFhLElBQUk7Q0FDaEQsSUFBSSxnQkFBZ0IsT0FBTyxjQUFjLGNBQWM7Q0FDdkQsTUFBTSxzQkFBc0IsbUJBQW1CLGtCQUFrQixhQUFhLE1BQU0sT0FBTztDQUMzRixJQUFJLGtCQUFrQix1QkFBdUI7Q0FDN0MsSUFBSSxnQkFBZ0I7Q0FDcEIsSUFBSSxnQkFBZ0IsbUJBQW1CLEdBQUc7RUFDeEMsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtDQUNwQjtDQUNBLE1BQU0sVUFBVSxZQUFZLGlCQUFpQixlQUFlLGFBQWEsTUFBTSxxQkFBcUIsZUFBZSxvQkFBb0I7Q0FDdkksTUFBTSxjQUFjLFVBQVUsb0JBQW9CO0NBQ2xELE9BQU8sZUFBQSxHQUFjRixhQUFBQSxjQUFBQSxDQUFjLGFBQWEsaUJBQWlCLE9BQU8sSUFBSTtBQUM5RTs7O0FDclpBLElBQWEsbUJBQW1CO0NBQzlCLE1BQU07Q0FDTixLQUFLLFVBQVU7RUFDYixZQUFZLFNBQVMsUUFBUSxLQUFLO0VBQ2xDLFFBQVEsUUFBUTtDQUNsQjtBQUNGOzs7QUNIQSxJQUFhLGVBQUEsR0FBY0csYUFBQUEsY0FBQUEsQ0FBYztBQUN6QyxJQUFhLG1CQUFiLE1BQThCO0NBQzVCLGNBQWM7RUFDWixLQUFLLGlCQUFpQixDQUFDO0NBQ3pCO0NBQ0Esa0JBQWtCLFlBQVk7RUFDNUIsV0FBVyxTQUFRLE9BQU07R0FDdkIsSUFBSSxDQUFDLEtBQUssZUFBZSxLQUFLLEtBQUssZUFBZSxNQUFNO0VBQzFELENBQUM7Q0FDSDtDQUNBLG9CQUFvQjtFQUNsQixPQUFPLE9BQU8sS0FBSyxLQUFLLGNBQWM7Q0FDeEM7QUFDRjtBQUNBLElBQWEsdUJBQXNCLGlCQUFnQixPQUFNLFFBQU87Q0FDOUQsTUFBTSx5QkFBMEIsTUFBTSxhQUFhLGtCQUFrQixHQUFHLEtBQU0sQ0FBQztDQUMvRSxNQUFNLG1CQUFtQixnQkFBZ0I7Q0FDekMsT0FBTztFQUNMLEdBQUc7RUFDSCxHQUFHO0NBQ0w7QUFDRjtBQUNBLElBQWEsd0JBQXdCO0NBQ25DLE1BQU0sT0FBTyxRQUFRO0NBQ3JCLElBQUksQ0FBQyxNQUFNO0VBQ1QsUUFBUSxLQUFLLHlHQUF5RztFQUN0SCxPQUFPLENBQUM7Q0FDVjtDQUNBLE1BQU0sYUFBYSxLQUFLLGtCQUFrQixrQkFBa0IsS0FBSyxDQUFDO0NBQ2xFLE1BQU0sTUFBTSxDQUFDO0NBQ2IsTUFBTSxtQkFBbUIsQ0FBQztDQUMxQixLQUFLLFVBQVUsU0FBUSxNQUFLO0VBQzFCLGlCQUFpQixLQUFLLENBQUM7RUFDdkIsV0FBVyxTQUFRLE9BQU07R0FDdkIsaUJBQWlCLEVBQUUsQ0FBQyxNQUFNLEtBQUssa0JBQWtCLEdBQUcsRUFBRSxLQUFLLENBQUM7RUFDOUQsQ0FBQztDQUNILENBQUM7Q0FDRCxJQUFJLG1CQUFtQjtDQUN2QixJQUFJLGtCQUFrQixLQUFLO0NBQzNCLE9BQU87QUFDVDs7O0FDekNBLFNBQWdCLE1BQU0sRUFDcEIsVUFDQSxPQUNBLFFBQ0EsU0FDQSxTQUNBLFdBQVcsQ0FBQyxHQUNaLFFBQ0EsVUFDQSxZQUNBLElBQ0EsTUFBTSxlQUNOLEdBQUcsWUFDSCxnQkFDQSxHQUFHLG1CQUNGO0NBQ0QsTUFBTSxFQUNKLE1BQU0saUJBQ04sV0FBVywwQkFBQSxHQUNUQyxhQUFBQSxXQUFBQSxDQUFXLFdBQVcsS0FBSyxDQUFDO0NBQ2hDLE1BQU0sT0FBTyxpQkFBaUIsbUJBQW1CLFFBQVE7Q0FDekQsTUFBTSxJQUFJLGNBQWMsTUFBTSxFQUFFLEtBQUssSUFBSTtDQUN6QyxPQUFPQyxRQUFvQjtFQUN6QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFJLE1BQU0sR0FBRyxNQUFNLHdCQUF3QixNQUFNLFNBQVM7RUFDMUQ7RUFDQSxHQUFHO0VBQ0g7RUFDQSxHQUFHO0NBQ0wsQ0FBQztBQUNIOzs7QUMxQ0EsSUFBYSx5QkFBYixNQUFhLCtCQUErQixNQUFNO0NBQ2hELFlBQVksU0FBUyxVQUFVLG1CQUFtQjtFQUNoRCxNQUFNLE9BQU87RUFDYixLQUFLLE9BQU87RUFDWixLQUFLLFdBQVc7RUFDaEIsS0FBSyxvQkFBb0I7RUFDekIsSUFBSSxNQUFNLG1CQUNSLE1BQU0sa0JBQWtCLE1BQU0sc0JBQXNCO0NBRXhEO0FBQ0Y7OztBQ1ZBLElBQU0saUJBQWlCO0NBQ3JCLFVBQVU7Q0FDVixTQUFTO0NBQ1QsUUFBUTtDQUNSLFFBQVE7Q0FDUixVQUFVO0NBQ1YsVUFBVTtDQUNWLFVBQVU7Q0FDVixTQUFTO0NBQ1QsV0FBVztDQUNYLFlBQVk7Q0FDWixXQUFXO0NBQ1gsV0FBVztDQUNYLFdBQVc7Q0FDWCxXQUFXO0NBQ1gsV0FBVztDQUNYLFdBQVc7Q0FDWCxXQUFXO0NBQ1gsV0FBVztDQUNYLFlBQVk7Q0FDWixZQUFZO0NBQ1osVUFBVTtDQUNWLFdBQVc7Q0FDWCxXQUFXO0NBQ1gsWUFBWTtDQUNaLFlBQVk7Q0FDWixVQUFVO0NBQ1YsVUFBVTtDQUNWLFlBQVk7Q0FDWixVQUFVO0NBQ1YsVUFBVTtDQUNWLFlBQVk7Q0FDWixVQUFVO0NBQ1YsV0FBVztDQUNYLFNBQVM7Q0FDVCxVQUFVO0NBQ1YsWUFBWTtDQUNaLFdBQVc7Q0FDWCxZQUFZO0NBQ1osV0FBVztDQUNYLFlBQVk7Q0FDWixRQUFRO0NBQ1IsUUFBUTtDQUNSLFFBQVE7Q0FDUixXQUFXO0NBQ1gsV0FBVztDQUNYLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsU0FBUztDQUNULFVBQVU7Q0FDVixXQUFXO0NBQ1gsVUFBVTtDQUNWLFlBQVk7Q0FDWixTQUFTO0NBQ1QsV0FBVztDQUNYLFVBQVU7Q0FDVixVQUFVO0NBQ1YsVUFBVTtDQUNWLFVBQVU7Q0FDVixVQUFVO0NBQ1YsV0FBVztDQUNYLFVBQVU7Q0FDVixVQUFVO0NBQ1YsVUFBVTtDQUNWLFVBQVU7Q0FDVixVQUFVO0NBQ1YsV0FBVztDQUNYLFVBQVU7Q0FDVixXQUFXO0NBQ1gsV0FBVztDQUNYLGFBQWE7Q0FDYixVQUFVO0NBQ1YsU0FBUztDQUNULFdBQVc7Q0FDWCxVQUFVO0NBQ1YsV0FBVztDQUNYLFlBQVk7Q0FDWixRQUFRO0NBQ1IsUUFBUTtDQUNSLFFBQVE7Q0FDUixhQUFhO0NBQ2IsUUFBUTtDQUNSLFNBQVM7Q0FDVCxXQUFXO0NBQ1gsU0FBUztDQUNULGFBQWE7Q0FDYixTQUFTO0NBQ1QsU0FBUztDQUNULFNBQVM7Q0FDVCxXQUFXO0NBQ1gsV0FBVztDQUNYLFVBQVU7Q0FDVixXQUFXO0NBQ1gsV0FBVztDQUNYLGFBQWE7Q0FDYixVQUFVO0NBQ1YsU0FBUztDQUNULFdBQVc7Q0FDWCxVQUFVO0NBQ1YsV0FBVztDQUNYLFlBQVk7Q0FDWixRQUFRO0NBQ1IsUUFBUTtDQUNSLFFBQVE7Q0FDUixhQUFhO0NBQ2IsUUFBUTtDQUNSLFNBQVM7Q0FDVCxXQUFXO0NBQ1gsU0FBUztDQUNULGFBQWE7Q0FDYixTQUFTO0NBQ1QsU0FBUztDQUNULFNBQVM7Q0FDVCxXQUFXO0NBQ1gsWUFBWTtDQUNaLFlBQVk7Q0FDWixXQUFXO0NBQ1gsWUFBWTtDQUNaLFVBQVU7Q0FDVixXQUFXO0NBQ1gsV0FBVztDQUNYLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFdBQVc7Q0FDWCxVQUFVO0NBQ1YsWUFBWTtDQUNaLFlBQVk7Q0FDWixXQUFXO0NBQ1gsVUFBVTtDQUNWLFNBQVM7Q0FDVCxZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixXQUFXO0NBQ1gsWUFBWTtDQUNaLFVBQVU7Q0FDVixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixXQUFXO0NBQ1gsVUFBVTtDQUNWLFlBQVk7Q0FDWixXQUFXO0NBQ1gsV0FBVztDQUNYLFlBQVk7Q0FDWixZQUFZO0NBQ1osV0FBVztDQUNYLFlBQVk7Q0FDWixVQUFVO0NBQ1YsV0FBVztDQUNYLFdBQVc7Q0FDWCxZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixXQUFXO0NBQ1gsVUFBVTtDQUNWLFlBQVk7Q0FDWixZQUFZO0NBQ1osV0FBVztDQUNYLFVBQVU7Q0FDVixTQUFTO0NBQ1QsWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osV0FBVztDQUNYLFlBQVk7Q0FDWixVQUFVO0NBQ1YsWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osV0FBVztDQUNYLFVBQVU7Q0FDVixZQUFZO0NBQ1osV0FBVztDQUNYLFVBQVU7Q0FDVixXQUFXO0NBQ1gsWUFBWTtDQUNaLFVBQVU7Q0FDVixVQUFVO0NBQ1YsV0FBVztDQUNYLFdBQVc7Q0FDWCxXQUFXO0NBQ1gsWUFBWTtDQUNaLFlBQVk7Q0FDWixVQUFVO0NBQ1YsVUFBVTtDQUNWLFVBQVU7Q0FDVixVQUFVO0NBQ1YsV0FBVztDQUNYLFdBQVc7Q0FDWCxVQUFVO0NBQ1YsVUFBVTtDQUNWLFVBQVU7Q0FDVixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osV0FBVztDQUNYLFlBQVk7Q0FDWixXQUFXO0NBQ1gsU0FBUztDQUNULFdBQVc7Q0FDWCxXQUFXO0NBQ1gsWUFBWTtDQUNaLFdBQVc7Q0FDWCxVQUFVO0NBQ1YsYUFBYTtBQUNmO0FBQ0EsSUFBTSxnQkFBZ0IsSUFBSSxPQUFPLE9BQU8sS0FBSyxjQUFjLENBQUMsQ0FBQyxLQUFJLFdBQVUsT0FBTyxRQUFRLHVCQUF1QixNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUc7QUFDeEksSUFBYSxzQkFBcUIsU0FBUSxLQUFLLFFBQVEsZ0JBQWUsVUFBUyxlQUFlLE1BQU0sQ0FBQyxDQUFDLFFBQVEsY0FBYyxHQUFHLFFBQVEsT0FBTyxhQUFhLFNBQVMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSx3QkFBd0IsR0FBRyxRQUFRLE9BQU8sYUFBYSxTQUFTLEtBQUssRUFBRSxDQUFDLENBQUM7OztBQ2xOaFEsSUFBYSxZQUFXLGdCQUFlO0NBQ3JDLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLElBQUksV0FBVztDQUNmLElBQUksY0FBYztDQUNsQixNQUFNLGtCQUFrQjtFQUN0QixJQUFJLGFBQWE7R0FDZixPQUFPLEtBQUs7SUFDVixNQUFNO0lBQ04sT0FBTztJQUNQLFVBQVUsV0FBVyxZQUFZO0dBQ25DLENBQUM7R0FDRCxjQUFjO0VBQ2hCO0NBQ0Y7Q0FDQSxPQUFPLFdBQVcsWUFBWSxRQUFRO0VBQ3BDLE1BQU0sT0FBTyxZQUFZO0VBQ3pCLElBQUksU0FBUyxLQUFLO0dBQ2hCLE1BQU0sV0FBVyxZQUFZLE1BQU0sUUFBUSxDQUFDLENBQUMsTUFBTSxVQUFVO0dBQzdELElBQUksVUFBVTtJQUNaLFVBQVU7SUFDVixPQUFPLEtBQUs7S0FDVixNQUFNO0tBQ04sT0FBTyxTQUFTO0tBQ2hCO0tBQ0EsV0FBVyxTQUFTLFNBQVMsSUFBSSxFQUFFO0lBQ3JDLENBQUM7SUFDRCxZQUFZLFNBQVMsRUFBRSxDQUFDO0dBQzFCLE9BQU87SUFDTCxNQUFNLGdCQUFnQixZQUFZLE1BQU0sUUFBUSxDQUFDLENBQUMsTUFBTSxZQUFZO0lBQ3BFLElBQUksZUFBZTtLQUNqQixVQUFVO0tBQ1YsT0FBTyxLQUFLO01BQ1YsTUFBTTtNQUNOLE9BQU8sY0FBYztNQUNyQjtNQUNBLFdBQVcsU0FBUyxjQUFjLElBQUksRUFBRTtLQUMxQyxDQUFDO0tBQ0QsWUFBWSxjQUFjLEVBQUUsQ0FBQztJQUMvQixPQUFPO0tBQ0wsZUFBZTtLQUNmLFlBQVk7SUFDZDtHQUNGO0VBQ0YsT0FBTztHQUNMLGVBQWU7R0FDZixZQUFZO0VBQ2Q7Q0FDRjtDQUNBLFVBQVU7Q0FDVixPQUFPO0FBQ1Q7OztBQzlDQSxJQUFNLHlCQUF5QixhQUFhLFVBQVUsc0JBQXNCO0NBQzFFLE1BQU0sRUFDSixNQUNBLFFBQVEsQ0FBQyxNQUNQO0NBQ0osSUFBSSxNQUFNLFlBQVksTUFBTSxRQUFRLE1BQU0sUUFBUSxLQUFLLG1CQUFtQjtFQUN4RSxNQUFNLEVBQ0osVUFBVSxtQkFDVixHQUFHLHlCQUNEO0VBQ0osT0FBQSxhQUFhLGNBQWMsTUFBTSxzQkFBc0IsR0FBRyxRQUFRO0NBQ3BFO0NBQ0EsSUFBSSxTQUFTLFdBQVcsR0FDdEIsT0FBQSxhQUFhLGNBQWMsTUFBTSxLQUFLO0NBRXhDLElBQUksU0FBUyxXQUFXLEdBQ3RCLE9BQUEsYUFBYSxjQUFjLE1BQU0sT0FBTyxTQUFTLEVBQUU7Q0FFckQsT0FBQSxhQUFhLGNBQWMsTUFBTSxPQUFPLEdBQUcsUUFBUTtBQUNyRDtBQUNBLElBQWEscUJBQXFCLGFBQWEsZUFBZSxDQUFDLE1BQU07Q0FDbkUsSUFBSSxDQUFDLGFBQ0gsT0FBTyxDQUFDO0NBRVYsTUFBTSxTQUFTLFNBQVMsV0FBVztDQUNuQyxNQUFNLFNBQVMsQ0FBQztDQUNoQixNQUFNLFFBQVEsQ0FBQztDQUNmLE1BQU0sb0NBQW9CLElBQUksSUFBSTtDQUNsQyxNQUFNLCtCQUErQjtFQUNuQyxJQUFJLE1BQU0sV0FBVyxHQUNuQixPQUFPO0VBRVQsTUFBTSxjQUFjLE1BQU0sTUFBTSxTQUFTO0VBQ3pDLElBQUksWUFBWSxZQUFZLE9BQU8sWUFBWSxNQUFNLFFBQVEsWUFBWSxZQUFZLE1BQU0sUUFBUSxHQUNqRyxPQUFPLFlBQVksWUFBWSxNQUFNO0VBRXZDLE9BQU8sWUFBWTtDQUNyQjtDQUNBLE9BQU8sU0FBUSxVQUFTO0VBQ3RCLFFBQVEsTUFBTSxNQUFkO0dBQ0UsS0FBSztJQUNIO0tBQ0UsTUFBTSxVQUFVLG1CQUFtQixNQUFNLEtBQUs7S0FFOUMsQ0FEb0IsTUFBTSxTQUFTLElBQUksTUFBTSxNQUFNLFNBQVMsRUFBRSxDQUFDLFdBQVcsT0FBQSxDQUM5RCxLQUFLLE9BQU87SUFDMUI7SUFDQTtHQUNGLEtBQUs7SUFDSDtLQUNFLE1BQU0sRUFDSixjQUNFO0tBQ0osTUFBTSxzQkFBc0IsdUJBQXVCO0tBQ25ELE1BQU0sY0FBYyxvQkFBb0I7S0FDeEMsSUFBSSxDQUFDLGFBQWE7TUFDaEIsa0JBQWtCLElBQUksU0FBUztNQUMvQixNQUFNLGNBQWMsSUFBSSxVQUFVO01BRWxDLENBRG9CLE1BQU0sU0FBUyxJQUFJLE1BQU0sTUFBTSxTQUFTLEVBQUUsQ0FBQyxXQUFXLE9BQUEsQ0FDOUQsS0FBSyxXQUFXO01BQzVCO0tBQ0Y7S0FDQSxNQUFNLEtBQUs7TUFDVDtNQUNBLFVBQVUsQ0FBQztNQUNYLFVBQVUsTUFBTTtNQUNoQjtNQUNBLGNBQWM7S0FDaEIsQ0FBQztJQUNIO0lBQ0E7R0FDRixLQUFLLFlBQ0g7SUFDRSxNQUFNLEVBQ0osY0FDRTtJQUNKLElBQUksa0JBQWtCLElBQUksU0FBUyxHQUFHO0tBQ3BDLE1BQU0sY0FBYyxLQUFLLFVBQVU7S0FFbkMsQ0FEMkIsTUFBTSxTQUFTLElBQUksTUFBTSxNQUFNLFNBQVMsRUFBRSxDQUFDLFdBQVcsT0FBQSxDQUM5RCxLQUFLLFdBQVc7S0FDbkMsa0JBQWtCLE9BQU8sU0FBUztLQUNsQztJQUNGO0lBQ0EsSUFBSSxNQUFNLFdBQVcsR0FDbkIsTUFBTSxJQUFJLHVCQUF1Qiw0QkFBNEIsVUFBVSxnQkFBZ0IsTUFBTSxZQUFZLE1BQU0sVUFBVSxXQUFXO0lBRXRJLE1BQU0sUUFBUSxNQUFNLElBQUk7SUFDeEIsSUFBSSxNQUFNLGNBQWMsV0FDdEIsTUFBTSxJQUFJLHVCQUF1QiwrQkFBK0IsTUFBTSxVQUFVLGNBQWMsVUFBVSxnQkFBZ0IsTUFBTSxZQUFZLE1BQU0sVUFBVSxXQUFXO0lBRXZLLE1BQU0sVUFBVSxzQkFBc0IsTUFBTSxhQUFhLE1BQU0sVUFBVSxNQUFNLFlBQVk7SUFFM0YsQ0FEMkIsTUFBTSxTQUFTLElBQUksTUFBTSxNQUFNLFNBQVMsRUFBRSxDQUFDLFdBQVcsT0FBQSxDQUM5RCxLQUFLLE9BQU87R0FDakM7RUFFSjtDQUNGLENBQUM7Q0FDRCxJQUFJLE1BQU0sU0FBUyxHQUFHO0VBQ3BCLE1BQU0sV0FBVyxNQUFNLE1BQU0sU0FBUztFQUN0QyxNQUFNLElBQUksdUJBQXVCLGlCQUFpQixTQUFTLFVBQVUsZ0JBQWdCLFNBQVMsWUFBWSxTQUFTLFVBQVUsV0FBVztDQUMxSTtDQUNBLE9BQU87QUFDVDs7O0FDckdBLFNBQWdCLHVCQUF1QixFQUNyQyxTQUNBLG9CQUNBLFNBQ0EsSUFDQSxTQUFTLENBQUMsR0FDVixNQUFNLGVBQ04sR0FBRyxjQUNGO0NBQ0QsTUFBTSxPQUFPLGlCQUFpQixRQUFRO0NBQ3RDLElBQUksQ0FBQyxNQUFNO0VBQ1QsU0FBUyxNQUFNLHVCQUF1Qiw4RUFBOEUsRUFDbEgsUUFDRixDQUFDO0VBQ0QsT0FBQSxhQUFhLGNBQUEsYUFBb0IsVUFBVSxDQUFDLEdBQUcsa0JBQWtCO0NBQ25FO0NBQ0EsTUFBTSxJQUFJLGNBQWMsS0FBSyxHQUFHLEtBQUssSUFBSSxPQUFNLE1BQUs7Q0FDcEQsSUFBSSxhQUFhLE1BQU0sRUFBRSxNQUFNLEtBQUssU0FBUztDQUM3QyxhQUFhLFNBQVMsVUFBVSxJQUFJLENBQUMsVUFBVSxJQUFJLGNBQWMsQ0FBQyxhQUFhO0NBQy9FLElBQUksZUFBZTtDQUNuQixJQUFJLEtBQUssU0FBUyxlQUFlLGtCQUMvQixlQUFlLFVBQVUsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFNBQVMsSUFBSTtFQUN4RCxHQUFHO0VBQ0gsR0FBRyxLQUFLLFFBQVEsY0FBYztDQUNoQyxJQUFJLEVBQ0YsR0FBRyxLQUFLLFFBQVEsY0FBYyxpQkFDaEM7Q0FFRixNQUFNLGNBQWMsRUFBRSxTQUFTO0VBQzdCLGNBQWM7RUFDZCxHQUFHO0VBQ0gsSUFBSTtDQUNOLENBQUM7Q0FDRCxJQUFJO0VBQ0YsTUFBTSxXQUFXLGtCQUFrQixhQUFhLE9BQU87RUFDdkQsT0FBQSxhQUFhLGNBQUEsYUFBb0IsVUFBVSxDQUFDLEdBQUcsR0FBRyxRQUFRO0NBQzVELFNBQVMsT0FBTztFQUNkLEtBQUssTUFBTSwwQkFBMEIscUNBQXFDLFFBQVEsS0FBSyxNQUFNLFdBQVc7R0FDdEc7R0FDQTtFQUNGLENBQUM7RUFDRCxPQUFBLGFBQWEsY0FBQSxhQUFvQixVQUFVLENBQUMsR0FBRyxXQUFXO0NBQzVEO0FBQ0Y7QUFDQSx1QkFBdUIsY0FBYzs7O0FDN0NyQyxTQUFnQixTQUFTLEVBQ3ZCLFNBQ0Esb0JBQ0EsU0FDQSxJQUNBLFNBQVMsQ0FBQyxHQUNWLE1BQU0sZUFDTixHQUFHLGNBQ0Y7Q0FDRCxNQUFNLEVBQ0osTUFBTSxpQkFDTixXQUFXLDBCQUFBLEdBQ1RDLGFBQUFBLFdBQUFBLENBQVcsV0FBVyxLQUFLLENBQUM7Q0FDaEMsTUFBTSxPQUFPLGlCQUFpQixtQkFBbUIsUUFBUTtDQUN6RCxNQUFNLElBQUksY0FBYyxNQUFNLEVBQUUsS0FBSyxJQUFJO0NBQ3pDLE9BQU8sdUJBQXVCO0VBQzVCO0VBQ0E7RUFDQTtFQUNBLElBQUksTUFBTSxHQUFHLE1BQU0sd0JBQXdCLE1BQU0sU0FBUztFQUMxRDtFQUNBO0VBQ0EsR0FBRztDQUNMLENBQUM7QUFDSDtBQUNBLFNBQVMsY0FBYzs7Ozs7Ozs7Ozs7OztDQ2pCdkIsQ0FDRyxXQUFZO0VBQ1gsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixPQUFRLE1BQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNLElBQUksTUFBUSxNQUFNLEtBQUssTUFBTTtFQUN4RTtFQUNBLFNBQVMsdUJBQXVCLFdBQVcsYUFBYTtHQUN0RCxxQkFDRSxLQUFLLE1BQU0sTUFBTSxvQkFDZixvQkFBb0IsQ0FBQyxHQUN2QixRQUFRLE1BQ04sZ01BQ0Y7R0FDRixJQUFJLFFBQVEsWUFBWTtHQUN4QixJQUFJLENBQUMsNEJBQTRCO0lBQy9CLElBQUksY0FBYyxZQUFZO0lBQzlCLFNBQVMsT0FBTyxXQUFXLE1BQ3hCLFFBQVEsTUFDUCxzRUFDRixHQUNDLDZCQUE2QixDQUFDO0dBQ25DO0dBQ0EsY0FBYyxTQUFTLEVBQ3JCLE1BQU07SUFBUztJQUFvQjtHQUFZLEVBQ2pELENBQUM7R0FDRCxJQUFJLE9BQU8sWUFBWSxFQUFFLENBQUMsTUFDeEIsY0FBYyxZQUFZO0dBQzVCLGdCQUNFLFdBQVk7SUFDVixLQUFLLFFBQVE7SUFDYixLQUFLLGNBQWM7SUFDbkIsdUJBQXVCLElBQUksS0FBSyxZQUFZLEVBQVEsS0FBSyxDQUFDO0dBQzVELEdBQ0E7SUFBQztJQUFXO0lBQU87R0FBVyxDQUNoQztHQUNBLFVBQ0UsV0FBWTtJQUNWLHVCQUF1QixJQUFJLEtBQUssWUFBWSxFQUFRLEtBQUssQ0FBQztJQUMxRCxPQUFPLFVBQVUsV0FBWTtLQUMzQix1QkFBdUIsSUFBSSxLQUFLLFlBQVksRUFBUSxLQUFLLENBQUM7SUFDNUQsQ0FBQztHQUNILEdBQ0EsQ0FBQyxTQUFTLENBQ1o7R0FDQSxjQUFjLEtBQUs7R0FDbkIsT0FBTztFQUNUO0VBQ0EsU0FBUyx1QkFBdUIsTUFBTTtHQUNwQyxJQUFJLG9CQUFvQixLQUFLO0dBQzdCLE9BQU8sS0FBSztHQUNaLElBQUk7SUFDRixJQUFJLFlBQVksa0JBQWtCO0lBQ2xDLE9BQU8sQ0FBQyxTQUFTLE1BQU0sU0FBUztHQUNsQyxTQUFTLE9BQU87SUFDZCxPQUFPLENBQUM7R0FDVjtFQUNGO0VBQ0EsU0FBUyx1QkFBdUIsV0FBVyxhQUFhO0dBQ3RELE9BQU8sWUFBWTtFQUNyQjtFQUNBLGdCQUFnQixPQUFPLGtDQUNyQixlQUNFLE9BQU8sK0JBQStCLCtCQUN4QywrQkFBK0IsNEJBQTRCLE1BQU0sQ0FBQztFQUNwRSxJQUFJLFFBQUEsY0FBQSxHQUNGLFdBQVcsZUFBZSxPQUFPLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFDekQsV0FBVyxNQUFNLFVBQ2pCLFlBQVksTUFBTSxXQUNsQixrQkFBa0IsTUFBTSxpQkFDeEIsZ0JBQWdCLE1BQU0sZUFDdEIsb0JBQW9CLENBQUMsR0FDckIsNkJBQTZCLENBQUMsR0FDOUIsT0FDRSxnQkFBZ0IsT0FBTyxVQUN2QixnQkFBZ0IsT0FBTyxPQUFPLFlBQzlCLGdCQUFnQixPQUFPLE9BQU8sU0FBUyxnQkFDbkMseUJBQ0E7RUFDUixRQUFRLHVCQUNOLEtBQUssTUFBTSxNQUFNLHVCQUF1QixNQUFNLHVCQUF1QjtFQUN2RSxnQkFBZ0IsT0FBTyxrQ0FDckIsZUFDRSxPQUFPLCtCQUErQiw4QkFDeEMsK0JBQStCLDJCQUEyQixNQUFNLENBQUM7Q0FDckUsRUFBQSxDQUFHOzs7OztDQ3pGSCxPQUFPLFVBQUEsaURBQUE7O0FDRFQsSUFBTSxhQUFhLEdBQUcsdUJBQXVCO0NBQzNDLElBQUksU0FBUyxrQkFBa0IsR0FBRyxPQUFPO0NBQ3pDLElBQUksU0FBUyxrQkFBa0IsS0FBSyxTQUFTLG1CQUFtQixZQUFZLEdBQUcsT0FBTyxtQkFBbUI7Q0FDekcsSUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPO0NBQ3BDLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRztFQUNwQixNQUFNLE9BQU8sRUFBRSxFQUFFLFNBQVM7RUFDMUIsT0FBTyxPQUFPLFNBQVMsYUFBYSxLQUFLO0NBQzNDO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBTSxtQkFBbUI7Q0FDdkIsR0FBRztDQUNILE9BQU87QUFDVDtBQUNBLElBQU0sNkJBQTZCLENBQUM7QUFDcEMsSUFBYSxrQkFBa0IsSUFBSSxRQUFRLENBQUMsTUFBTTtDQUNoRCxNQUFNLEVBQ0osTUFBTSxrQkFDSjtDQUNKLE1BQU0sRUFDSixNQUFNLGlCQUNOLFdBQVcsMEJBQUEsR0FDVEMsYUFBQUEsV0FBQUEsQ0FBVyxXQUFXLEtBQUssQ0FBQztDQUNoQyxNQUFNLE9BQU8saUJBQWlCLG1CQUFtQixRQUFRO0NBQ3pELElBQUksUUFBUSxDQUFDLEtBQUssa0JBQWtCLEtBQUssbUJBQW1CLElBQUksaUJBQWlCO0NBQ2pGLElBQUksQ0FBQyxNQUNILFNBQVMsTUFBTSx1QkFBdUIsME1BQTBNO0NBRWxQLE1BQU0sZUFBQSxHQUFjQyxhQUFBQSxRQUFBQSxRQUFlO0VBQ2pDLEdBQUcsWUFBWTtFQUNmLEdBQUcsTUFBTSxTQUFTO0VBQ2xCLEdBQUc7Q0FDTCxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUM7Q0FDakIsTUFBTSxFQUNKLGFBQ0EsY0FDRTtDQUNKLE1BQU0sY0FBYyxNQUFNLHdCQUF3QixNQUFNLFNBQVM7Q0FDakUsTUFBTSxxQkFBcUIsU0FBUyxXQUFXLElBQUksQ0FBQyxXQUFXLElBQUksZUFBZSxDQUFDLGFBQWE7Q0FDaEcsTUFBTSxjQUFBLEdBQWFBLGFBQUFBLFFBQUFBLE9BQWMsb0JBQW9CLGtCQUFrQjtDQUN2RSxNQUFNLGtCQUFrQixvQkFBb0IsVUFBVTtDQUN0RCxNQUFNLGVBQUEsR0FBY0MsYUFBQUEsT0FBQUEsQ0FBTyxDQUFDO0NBQzVCLE1BQU0sYUFBQSxHQUFZQyxhQUFBQSxZQUFBQSxFQUFZLGFBQVk7RUFDeEMsSUFBSSxDQUFDLE1BQU0sT0FBTztFQUNsQixNQUFNLEVBQ0osVUFDQSxrQkFDRTtFQUNKLE1BQU0sd0JBQXdCO0dBQzVCLFlBQVksV0FBVztHQUN2QixTQUFTO0VBQ1g7RUFDQSxJQUFJLFVBQVUsS0FBSyxHQUFHLFVBQVUsZUFBZTtFQUMvQyxJQUFJLGVBQWUsS0FBSyxNQUFNLEdBQUcsZUFBZSxlQUFlO0VBQy9ELGFBQWE7R0FDWCxJQUFJLFVBQVUsU0FBUyxNQUFNLEdBQUcsQ0FBQyxDQUFDLFNBQVEsTUFBSyxLQUFLLElBQUksR0FBRyxlQUFlLENBQUM7R0FDM0UsSUFBSSxlQUFlLGNBQWMsTUFBTSxHQUFHLENBQUMsQ0FBQyxTQUFRLE1BQUssS0FBSyxNQUFNLElBQUksR0FBRyxlQUFlLENBQUM7RUFDN0Y7Q0FDRixHQUFHLENBQUMsTUFBTSxXQUFXLENBQUM7Q0FDdEIsTUFBTSxlQUFBLEdBQWNELGFBQUFBLE9BQUFBLENBQU87Q0FDM0IsTUFBTSxlQUFBLEdBQWNDLGFBQUFBLFlBQUFBLE9BQWtCO0VBQ3BDLElBQUksQ0FBQyxNQUNILE9BQU87RUFFVCxNQUFNLGtCQUFrQixDQUFDLEVBQUUsS0FBSyxpQkFBaUIsS0FBSyx5QkFBeUIsV0FBVyxPQUFNLE1BQUssbUJBQW1CLEdBQUcsTUFBTSxXQUFXLENBQUM7RUFDN0ksTUFBTSxhQUFhLE1BQU0sT0FBTyxLQUFLO0VBQ3JDLE1BQU0sa0JBQWtCLFlBQVk7RUFDcEMsTUFBTSxlQUFlLFlBQVk7RUFDakMsSUFBSSxnQkFBZ0IsYUFBYSxVQUFVLG1CQUFtQixhQUFhLFFBQVEsY0FBYyxhQUFhLGNBQWMsYUFBYSxhQUFhLGFBQWEsaUJBQ2pLLE9BQU87RUFLVCxNQUFNLGNBQWM7R0FDbEIsR0FKa0IsS0FBSyxVQUFVLFlBQVksWUFBWSxXQUFXLGFBQWEsYUFBYSxXQUFXLElBQUksV0FBVyxFQUN4SCxTQUFTLFdBQ1gsQ0FFZTtHQUNiLE9BQU87R0FDUCxLQUFLO0dBQ0w7R0FDQSxVQUFVO0VBQ1o7RUFDQSxZQUFZLFVBQVU7RUFDdEIsT0FBTztDQUNULEdBQUc7RUFBQztFQUFNO0VBQVk7RUFBVztFQUFhLE1BQU07Q0FBRyxDQUFDO0NBQ3hELE1BQU0sQ0FBQyxXQUFXLGlCQUFBLEdBQWdCQyxhQUFBQSxTQUFBQSxDQUFTLENBQUM7Q0FDNUMsTUFBTSxFQUNKLEdBQ0EsV0FBQSxHQUNFQyxZQUFBQSxxQkFBQUEsQ0FBcUIsV0FBVyxhQUFhLFdBQVc7Q0FDNUQsQ0FBQSxHQUFBLGFBQUEsVUFBQSxPQUFnQjtFQUNkLElBQUksUUFBUSxDQUFDLFNBQVMsQ0FBQyxhQUFhO0dBQ2xDLE1BQU0saUJBQWlCLGNBQWEsTUFBSyxJQUFJLENBQUM7R0FDOUMsSUFBSSxNQUFNLEtBQ1IsY0FBYyxNQUFNLE1BQU0sS0FBSyxZQUFZLFFBQVE7UUFFbkQsZUFBZSxNQUFNLFlBQVksUUFBUTtFQUU3QztDQUNGLEdBQUc7RUFBQztFQUFNLE1BQU07RUFBSztFQUFZO0VBQU87RUFBYTtDQUFTLENBQUM7Q0FDL0QsTUFBTSxZQUFZLFFBQVEsQ0FBQztDQUMzQixNQUFNLGNBQUEsR0FBYUgsYUFBQUEsT0FBQUEsQ0FBTyxJQUFJO0NBQzlCLE1BQU0sa0JBQUEsR0FBaUJBLGFBQUFBLE9BQUFBLENBQU87Q0FDOUIsTUFBTSxxQkFBb0IsYUFBWTtFQUNwQyxNQUFNLGNBQWMsT0FBTywwQkFBMEIsUUFBUTtFQUM3RCxJQUFJLFlBQVksWUFBWSxPQUFPLFlBQVk7RUFDL0MsTUFBTSxVQUFVLE9BQU8sT0FBTyxPQUFPLGVBQWUsUUFBUSxHQUFHLFdBQVc7RUFDMUUsSUFBSSxDQUFDLE9BQU8sVUFBVSxlQUFlLEtBQUssU0FBUyxZQUFZLEdBQzdELElBQUk7R0FDRixPQUFPLGVBQWUsU0FBUyxjQUFjO0lBQzNDLE9BQU87SUFDUCxVQUFVO0lBQ1YsWUFBWTtJQUNaLGNBQWM7R0FDaEIsQ0FBQztFQUNILFNBQVMsR0FBRyxDQUFDO0VBRWYsT0FBTztDQUNUO0NBQ0EsTUFBTSxPQUFBLEdBQU1ELGFBQUFBLFFBQUFBLE9BQWM7RUFDeEIsTUFBTSxXQUFXO0VBQ2pCLE1BQU0sT0FBTyxVQUFVO0VBQ3ZCLElBQUksY0FBYztFQUNsQixJQUFJLFVBQ0YsSUFBSSxXQUFXLFdBQVcsV0FBVyxRQUFRLGVBQWUsVUFDMUQsSUFBSSxlQUFlLFlBQVksTUFBTTtHQUNuQyxjQUFjLGtCQUFrQixRQUFRO0dBQ3hDLFdBQVcsVUFBVTtHQUNyQixlQUFlLFVBQVU7RUFDM0IsT0FDRSxjQUFjLFdBQVc7T0FFdEI7R0FDTCxjQUFjLGtCQUFrQixRQUFRO0dBQ3hDLFdBQVcsVUFBVTtHQUNyQixlQUFlLFVBQVU7RUFDM0I7RUFFRixNQUFNLGFBQWEsQ0FBQyxTQUFTLENBQUMsZUFBZSxHQUFHLFNBQVM7R0FDdkQsU0FBUyxNQUFNLHNCQUFzQiw2SEFBNkg7R0FDbEssT0FBTyxFQUFFLEdBQUcsSUFBSTtFQUNsQixJQUFJO0VBQ0osTUFBTSxNQUFNO0dBQUM7R0FBWTtHQUFhO0VBQUs7RUFDM0MsSUFBSSxJQUFJO0VBQ1IsSUFBSSxPQUFPO0VBQ1gsSUFBSSxRQUFRO0VBQ1osT0FBTztDQUNULEdBQUc7RUFBQztFQUFHO0VBQVc7RUFBTyxVQUFVO0VBQWtCLFVBQVU7RUFBVSxVQUFVO0NBQVMsQ0FBQztDQUM3RixJQUFJLFFBQVEsZUFBZSxDQUFDLE9BQU87RUFDakMsSUFBSSxnQkFBZ0I7RUFDcEIsSUFBSTtHQUNGLGdCQUFnQjtFQUNsQixTQUFTLEdBQUcsQ0FBQztFQUNiLElBQUksZUFDRixTQUFTLE1BQU0sMkJBQTJCLDhQQUE4UDtFQUUxUyxNQUFNLElBQUksU0FBUSxZQUFXO0dBQzNCLE1BQU0saUJBQWlCLFFBQVE7R0FDL0IsSUFBSSxNQUFNLEtBQ1IsY0FBYyxNQUFNLE1BQU0sS0FBSyxZQUFZLFFBQVE7UUFFbkQsZUFBZSxNQUFNLFlBQVksUUFBUTtFQUU3QyxDQUFDO0NBQ0g7Q0FDQSxPQUFPO0FBQ1Q7OztBQ3RLQSxJQUFhLG1CQUFtQixJQUFJLFVBQVUsQ0FBQyxNQUFNLFNBQVMsT0FBTyxrQkFBa0I7Q0FDckYsU0FBUyx1QkFBdUIsRUFDOUIsY0FDQSxHQUFHLFFBQ0Y7RUFDRCxNQUFNLENBQUMsR0FBRyxNQUFNLFNBQVMsZUFBZSxJQUFJO0dBQzFDLEdBQUc7R0FDSCxXQUFXLFFBQVE7RUFDckIsQ0FBQztFQUNELE1BQU0sZ0JBQWdCO0dBQ3BCLEdBQUc7R0FDSDtHQUNBO0dBQ0EsUUFBUTtFQUNWO0VBQ0EsSUFBSSxRQUFRLFdBQVcsY0FDckIsY0FBYyxNQUFNO09BQ2YsSUFBSSxDQUFDLFFBQVEsV0FBVyxjQUM3QixjQUFjLGVBQWU7RUFFL0IsUUFBQSxHQUFPSyxhQUFBQSxjQUFBQSxDQUFjLGtCQUFrQixhQUFhO0NBQ3REO0NBQ0EsdUJBQXVCLGNBQWMsMEJBQTBCLGVBQWUsZ0JBQWdCLEVBQUU7Q0FDaEcsdUJBQXVCLG1CQUFtQjtDQUMxQyxNQUFNLGNBQWMsT0FBTyxTQUFBLEdBQVFBLGFBQUFBLGNBQUFBLENBQWMsd0JBQXdCLE9BQU8sT0FBTyxDQUFDLEdBQUcsT0FBTyxFQUNoRyxjQUFjLElBQ2hCLENBQUMsQ0FBQztDQUNGLE9BQU8sUUFBUSxXQUFBLEdBQVVDLGFBQUFBLFdBQUFBLENBQWdCLFVBQVUsSUFBSTtBQUN6RDs7O0FDOUJBLElBQWEsZUFBZSxFQUMxQixJQUNBLFVBQ0EsR0FBRyxjQUNDO0NBQ0osTUFBTSxDQUFDLEdBQUcsTUFBTSxTQUFTLGVBQWUsSUFBSSxPQUFPO0NBQ25ELE9BQU8sU0FBUyxHQUFHO0VBQ2pCO0VBQ0EsS0FBSyxNQUFNO0NBQ2IsR0FBRyxLQUFLO0FBQ1Y7OztBQ1RBLFNBQWdCLGdCQUFnQixFQUM5QixNQUNBLFdBQ0EsWUFDQztDQUNELE1BQU0sU0FBQSxHQUFRQyxhQUFBQSxRQUFBQSxRQUFlO0VBQzNCO0VBQ0E7Q0FDRixJQUFJLENBQUMsTUFBTSxTQUFTLENBQUM7Q0FDckIsUUFBQSxHQUFPQyxhQUFBQSxjQUFBQSxDQUFjLFlBQVksVUFBVSxFQUN6QyxNQUNGLEdBQUcsUUFBUTtBQUNiOzs7QUNYQSxJQUFhLFVBQVUsa0JBQWtCLGlCQUFpQixRQUFRLENBQUMsTUFBTTtDQUN2RSxNQUFNLEVBQ0osTUFBTSxrQkFDSjtDQUNKLE1BQU0sRUFDSixNQUFNLHFCQUFBLEdBQ0pDLGFBQUFBLFdBQUFBLENBQVcsV0FBVyxLQUFLLENBQUM7Q0FDaEMsTUFBTSxPQUFPLGlCQUFpQixtQkFBbUIsUUFBUTtDQUN6RCxJQUFJLENBQUMsTUFBTTtFQUNULFNBQVMsTUFBTSx1QkFBdUIsa01BQWtNO0VBQ3hPO0NBQ0Y7Q0FDQSxJQUFJLEtBQUssU0FBUyxTQUFTO0NBQzNCLElBQUksb0JBQW9CLENBQUMsS0FBSyxzQkFBc0I7RUFDbEQsSUFBSSxDQUFDLEtBQUssVUFBVSxlQUFlO0dBQ2pDLFNBQVMsTUFBTSx3QkFBd0IsdU5BQXVOO0dBQzlQO0VBQ0Y7RUFDQSxLQUFLLFNBQVMsY0FBYyxPQUFPO0VBQ25DLEtBQUssUUFBUSxLQUFLLE9BQU8sT0FBTyxnQkFBZ0IsQ0FBQyxDQUFDLFFBQVEsS0FBSyxpQkFBaUI7R0FDOUUsT0FBTyxLQUFLLFlBQVksQ0FBQyxDQUFDLFNBQVEsT0FBTTtJQUN0QyxJQUFJLElBQUksUUFBUSxFQUFFLElBQUksR0FBRyxJQUFJLEtBQUssRUFBRTtHQUN0QyxDQUFDO0dBQ0QsT0FBTztFQUNULEdBQUcsS0FBSyxRQUFRLEVBQUU7RUFDbEIsS0FBSyx1QkFBdUI7RUFDNUIsS0FBSyxnQkFBZ0I7Q0FDdkI7Q0FDQSxJQUFJLG1CQUFtQixDQUFDLEtBQUsseUJBQXlCO0VBQ3BELEtBQUssZUFBZSxlQUFlO0VBQ25DLEtBQUssMEJBQTBCO0NBQ2pDO0FBQ0Y7OztBQy9CQSxJQUFhLGdCQUFnQixTQUFTLE9BQU8sa0JBQWtCO0NBQzdELFNBQVMsZUFBZSxFQUN0QixrQkFDQSxpQkFDQSxHQUFHLFFBQ0Y7RUFDRCxPQUFPLGtCQUFrQixlQUFlO0VBQ3hDLFFBQUEsR0FBT0MsYUFBQUEsY0FBQUEsQ0FBYyxrQkFBa0IsRUFDckMsR0FBRyxLQUNMLENBQUM7Q0FDSDtDQUNBLGVBQWUsa0JBQWtCLG9CQUFvQixnQkFBZ0I7Q0FDckUsZUFBZSxjQUFjLGtCQUFrQixlQUFlLGdCQUFnQixFQUFFO0NBQ2hGLGVBQWUsbUJBQW1CO0NBQ2xDLE9BQU87QUFDVDs7O0FDSkEsSUFBYSxhQUFhO0FBQzFCLElBQWEsYUFBYTtBQUMxQixJQUFhLGVBQWU7QUFDNUIsSUFBYSxlQUFlO0FBQzVCLElBQWEsZUFBZTtBQUM1QixJQUFhLHNCQUFzQiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzXX0=