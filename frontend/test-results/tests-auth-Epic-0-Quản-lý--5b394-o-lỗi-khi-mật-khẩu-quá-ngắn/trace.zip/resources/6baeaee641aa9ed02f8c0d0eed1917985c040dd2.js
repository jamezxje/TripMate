import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Navbar.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Compass, LogOut, Globe, UserCheck } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import { useUserStore } from "/src/store/useUserStore.js";
import { Badge } from "/src/components/Badge.jsx";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/layout/Navbar.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const Navbar = () => {
	_s();
	const { t, i18n } = useTranslation();
	const { currentUser, logout, updateUserRole } = useUserStore();
	const toggleLanguage = () => {
		const nextLang = i18n.language === "vi" ? "en" : "vi";
		i18n.changeLanguage(nextLang);
	};
	const toggleRole = () => {
		if (!currentUser) return;
		const newRole = currentUser.role === "LEADER" ? "MEMBER" : "LEADER";
		updateUserRole(newRole);
	};
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200/80 shadow-xs",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between h-16",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-md shadow-indigo-200",
						children: /* @__PURE__ */ _jsxDEV(Compass, { className: "w-6 h-6 animate-pulse-slow" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xl font-black bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent tracking-tight",
						children: "TripMate"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "hidden sm:inline-block ml-2 text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700",
						children: "v1.0"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 sm:gap-3",
					children: [
						currentUser && /* @__PURE__ */ _jsxDEV("button", {
							onClick: toggleRole,
							title: "Bấm để đổi vai trò thử nghiệm (Leader/Member)",
							className: "hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors text-xs font-medium text-slate-700",
							children: [
								/* @__PURE__ */ _jsxDEV(UserCheck, { className: "w-4 h-4 text-indigo-600" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 50,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Role:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV(Badge, {
									variant: currentUser.role === "LEADER" ? "leader" : "member",
									children: currentUser.role
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 52,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: toggleLanguage,
							className: "flex items-center gap-1 px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 rounded-xl transition-colors min-h-[44px]",
							title: "Change Language",
							children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-4 h-4 text-slate-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "uppercase",
								children: i18n.language || "VI"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 13
						}, this),
						currentUser ? /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pl-2 border-l border-slate-200",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs border border-indigo-200",
									children: currentUser.fullName ? currentUser.fullName.charAt(0) : "U"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 71,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "hidden md:inline-block text-sm font-semibold text-slate-700 max-w-[120px] truncate",
									children: currentUser.fullName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: logout,
									className: "p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center",
									title: "Logout",
									children: /* @__PURE__ */ _jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 82,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 15
						}, this) : null
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 5
	}, this);
};
_s(Navbar, "dc/WybezzTT4x8nUMesivuxMaHY=", false, function() {
	return [useTranslation, useUserStore];
});
_c = Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Navbar.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/layout/Navbar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/layout/Navbar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/layout/Navbar.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsU0FBUyxRQUFRLE9BQU8saUJBQWlCO0FBQ2xELFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsYUFBYTs7OztBQUV0QixPQUFPLE1BQU0sZUFBZTs7Q0FDMUIsTUFBTSxFQUFFLEdBQUcsU0FBUyxlQUFlO0NBQ25DLE1BQU0sRUFBRSxhQUFhLFFBQVEsbUJBQW1CLGFBQWE7Q0FFN0QsTUFBTSx1QkFBdUI7RUFDM0IsTUFBTSxXQUFXLEtBQUssYUFBYSxPQUFPLE9BQU87RUFDakQsS0FBSyxlQUFlLFFBQVE7Q0FDOUI7Q0FFQSxNQUFNLG1CQUFtQjtFQUN2QixJQUFJLENBQUMsYUFBYTtFQUNsQixNQUFNLFVBQVUsWUFBWSxTQUFTLFdBQVcsV0FBVztFQUMzRCxlQUFlLE9BQU87Q0FDeEI7Q0FFQSxPQUNFLHdCQUFDLFVBQUQ7RUFBUSxXQUFVO1lBQ2hCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxTQUFELEVBQVMsV0FBVSw2QkFBOEI7Ozs7O0tBQzlDOzs7O2VBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFpSDtLQUUzSDs7OztlQUNOLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUEwRztLQUVwSDs7OzthQUNIOzs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVHLGVBQ0Msd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxPQUFNO09BQ04sV0FBVTtpQkFIWjtRQUtFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDBCQUEyQjs7Ozs7UUFDaEQsd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7O1FBQ2pCLHdCQUFDLE9BQUQ7U0FBTyxTQUFTLFlBQVksU0FBUyxXQUFXLFdBQVc7bUJBQ3hELFlBQVk7UUFDUjs7Ozs7T0FDRDs7Ozs7O01BSVYsd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxXQUFVO09BQ1YsT0FBTTtpQkFIUixDQUtFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7OztpQkFDM0Msd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWEsS0FBSyxZQUFZO09BQVc7Ozs7ZUFDbkQ7Ozs7OztNQUdQLGNBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixZQUFZLFdBQVcsWUFBWSxTQUFTLE9BQU8sQ0FBQyxJQUFJO1FBQ3REOzs7OztRQUNMLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLFlBQVk7UUFDVDs7Ozs7UUFDTix3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7U0FDVixPQUFNO21CQUVOLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7O1FBQ3ZCOzs7OztPQUNMOzs7OztpQkFDSDtLQUNEOzs7OztZQUNGOzs7Ozs7RUFDRjs7Ozs7Q0FDQzs7Ozs7QUFFWiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJOYXZiYXIuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gJ3JlYWN0LWkxOG5leHQnO1xuaW1wb3J0IHsgQ29tcGFzcywgTG9nT3V0LCBHbG9iZSwgVXNlckNoZWNrIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IHVzZVVzZXJTdG9yZSB9IGZyb20gJy4uLy4uL3N0b3JlL3VzZVVzZXJTdG9yZSc7XG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gJy4uL0JhZGdlJztcblxuZXhwb3J0IGNvbnN0IE5hdmJhciA9ICgpID0+IHtcbiAgY29uc3QgeyB0LCBpMThuIH0gPSB1c2VUcmFuc2xhdGlvbigpO1xuICBjb25zdCB7IGN1cnJlbnRVc2VyLCBsb2dvdXQsIHVwZGF0ZVVzZXJSb2xlIH0gPSB1c2VVc2VyU3RvcmUoKTtcblxuICBjb25zdCB0b2dnbGVMYW5ndWFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuZXh0TGFuZyA9IGkxOG4ubGFuZ3VhZ2UgPT09ICd2aScgPyAnZW4nIDogJ3ZpJztcbiAgICBpMThuLmNoYW5nZUxhbmd1YWdlKG5leHRMYW5nKTtcbiAgfTtcblxuICBjb25zdCB0b2dnbGVSb2xlID0gKCkgPT4ge1xuICAgIGlmICghY3VycmVudFVzZXIpIHJldHVybjtcbiAgICBjb25zdCBuZXdSb2xlID0gY3VycmVudFVzZXIucm9sZSA9PT0gJ0xFQURFUicgPyAnTUVNQkVSJyA6ICdMRUFERVInO1xuICAgIHVwZGF0ZVVzZXJSb2xlKG5ld1JvbGUpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGhlYWRlciBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgei00MCBiZy13aGl0ZS84MCBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAvODAgc2hhZG93LXhzXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGgtMTZcIj5cbiAgICAgICAgICB7LyogTG9nbyAmIEJyYW5kICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS1pbmRpZ28tNjAwIHRvLXZpb2xldC01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LWluZGlnby0yMDBcIj5cbiAgICAgICAgICAgICAgPENvbXBhc3MgY2xhc3NOYW1lPVwidy02IGgtNiBhbmltYXRlLXB1bHNlLXNsb3dcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYmxhY2sgYmctZ3JhZGllbnQtdG8tciBmcm9tLWluZGlnby02MDAgdG8tdmlvbGV0LTYwMCBiZy1jbGlwLXRleHQgdGV4dC10cmFuc3BhcmVudCB0cmFja2luZy10aWdodFwiPlxuICAgICAgICAgICAgICAgIFRyaXBNYXRlXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZS1ibG9jayBtbC0yIHRleHQteHMgZm9udC1zZW1pYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctaW5kaWdvLTUwIHRleHQtaW5kaWdvLTcwMFwiPlxuICAgICAgICAgICAgICAgIHYxLjBcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUmlnaHQgQWN0aW9uczogVXNlciBpbmZvLCBSb2xlIHN3aXRjaCwgaTE4biwgTG9nb3V0ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgc206Z2FwLTNcIj5cbiAgICAgICAgICAgIHsvKiBEZXYgcm9sZSBzd2l0Y2hlciBiYWRnZSB0b2dnbGUgKi99XG4gICAgICAgICAgICB7Y3VycmVudFVzZXIgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlUm9sZX1cbiAgICAgICAgICAgICAgICB0aXRsZT1cIkLhuqVtIMSR4buDIMSR4buVaSB2YWkgdHLDsiB0aOG7rSBuZ2hp4buHbSAoTGVhZGVyL01lbWJlcilcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlbiBzbTpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtNTAgdHJhbnNpdGlvbi1jb2xvcnMgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8VXNlckNoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1pbmRpZ28tNjAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Sb2xlOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD17Y3VycmVudFVzZXIucm9sZSA9PT0gJ0xFQURFUicgPyAnbGVhZGVyJyA6ICdtZW1iZXInfT5cbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5yb2xlfVxuICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIExhbmd1YWdlIFRvZ2dsZSAqL31cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlTGFuZ3VhZ2V9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBtaW4taC1bNDRweF1cIlxuICAgICAgICAgICAgICB0aXRsZT1cIkNoYW5nZSBMYW5ndWFnZVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxHbG9iZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNTAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidXBwZXJjYXNlXCI+e2kxOG4ubGFuZ3VhZ2UgfHwgJ1ZJJ308L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgey8qIEN1cnJlbnQgVXNlciAqL31cbiAgICAgICAgICAgIHtjdXJyZW50VXNlciA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwbC0yIGJvcmRlci1sIGJvcmRlci1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGJnLWluZGlnby0xMDAgdGV4dC1pbmRpZ28tNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCB0ZXh0LXhzIGJvcmRlciBib3JkZXItaW5kaWdvLTIwMFwiPlxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRVc2VyLmZ1bGxOYW1lID8gY3VycmVudFVzZXIuZnVsbE5hbWUuY2hhckF0KDApIDogJ1UnfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBtZDppbmxpbmUtYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1heC13LVsxMjBweF0gdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5mdWxsTmFtZX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17bG9nb3V0fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtcm9zZS02MDAgaG92ZXI6Ymctcm9zZS01MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIG1pbi1oLVs0NHB4XSBtaW4tdy1bNDRweF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMb2dvdXRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxMb2dPdXQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG4gICk7XG59O1xuIl19