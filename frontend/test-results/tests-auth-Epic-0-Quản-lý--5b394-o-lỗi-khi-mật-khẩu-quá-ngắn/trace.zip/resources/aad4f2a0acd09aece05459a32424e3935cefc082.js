import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/trips/JoinTripModal.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { KeyRound } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import { Modal } from "/src/components/Modal.jsx";
import { Input } from "/src/components/Input.jsx";
import { Button } from "/src/components/Button.jsx";
import { Alert } from "/src/components/Alert.jsx";
import { tripApi } from "/src/features/trips/tripApi.js";
import { useTripStore } from "/src/store/useTripStore.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/trips/JoinTripModal.jsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const JoinTripModal = ({ isOpen, onClose }) => {
	_s();
	const { t } = useTranslation();
	const { setCurrentTrip } = useTripStore();
	const [joinCode, setJoinCode] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState("");
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!joinCode.trim()) {
			setError("Vui lòng nhập mã tham gia");
			return;
		}
		setIsLoading(true);
		setError("");
		try {
			const res = await tripApi.joinTrip(joinCode.trim());
			if (res.data) {
				setCurrentTrip(res.data);
				setJoinCode("");
				onClose();
			}
		} catch (err) {
			setError(err.message || "Mã tham gia không hợp lệ hoặc chuyến đi không tồn tại.");
		} finally {
			setIsLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV(Modal, {
		isOpen,
		onClose,
		title: t("trip.join", "Tham gia bằng mã code"),
		children: /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			className: "flex flex-col gap-4",
			children: [
				error && /* @__PURE__ */ _jsxDEV(Alert, {
					type: "error",
					message: error,
					onClose: () => setError("")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 19
				}, this),
				/* @__PURE__ */ _jsxDEV(Input, {
					label: "Mã mời chuyến đi (Join Code)",
					placeholder: "Nhập mã 6 ký tự (ví dụ: ABC123)...",
					value: joinCode,
					onChange: (e) => setJoinCode(e.target.value.toUpperCase()),
					icon: KeyRound,
					required: true,
					autoFocus: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-end gap-3 mt-4",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						onClick: onClose,
						disabled: isLoading,
						children: t("common.cancel", "Hủy")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						type: "submit",
						isLoading,
						children: t("common.confirm", "Gia nhập")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 5
	}, this);
};
_s(JoinTripModal, "Yb+nFjATGg7mB8oVkyh3ge7hXR8=", false, function() {
	return [useTranslation, useTripStore];
});
_c = JoinTripModal;
var _c;
$RefreshReg$(_c, "JoinTripModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/trips/JoinTripModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/trips/JoinTripModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/trips/JoinTripModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/trips/JoinTripModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGFBQWE7QUFDdEIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsY0FBYztBQUN2QixTQUFTLGFBQWE7QUFDdEIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsb0JBQW9COzs7O0FBRTdCLE9BQU8sTUFBTSxpQkFBaUIsRUFBRSxRQUFRLGNBQWM7O0NBQ3BELE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FDN0IsTUFBTSxFQUFFLG1CQUFtQixhQUFhO0NBQ3hDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FFckMsTUFBTSxlQUFlLE9BQU8sTUFBTTtFQUNoQyxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLFNBQVMsS0FBSyxHQUFHO0dBQ3BCLFNBQVMsMkJBQTJCO0dBQ3BDO0VBQ0Y7RUFFQSxhQUFhLElBQUk7RUFDakIsU0FBUyxFQUFFO0VBRVgsSUFBSTtHQUNGLE1BQU0sTUFBTSxNQUFNLFFBQVEsU0FBUyxTQUFTLEtBQUssQ0FBQztHQUNsRCxJQUFJLElBQUksTUFBTTtJQUNaLGVBQWUsSUFBSSxJQUFJO0lBQ3ZCLFlBQVksRUFBRTtJQUNkLFFBQVE7R0FDVjtFQUNGLFNBQVMsS0FBSztHQUNaLFNBQVMsSUFBSSxXQUFXLHdEQUF3RDtFQUNsRixVQUFVO0dBQ1IsYUFBYSxLQUFLO0VBQ3BCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBZTtFQUFpQjtFQUFTLE9BQU8sRUFBRSxhQUFhLHVCQUF1QjtZQUNwRix3QkFBQyxRQUFEO0dBQU0sVUFBVTtHQUFjLFdBQVU7YUFBeEM7SUFDRyxTQUFTLHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVEsU0FBUztLQUFPLGVBQWUsU0FBUyxFQUFFO0lBQUk7Ozs7O0lBRTVFLHdCQUFDLE9BQUQ7S0FDRSxPQUFNO0tBQ04sYUFBWTtLQUNaLE9BQU87S0FDUCxXQUFXLE1BQU0sWUFBWSxFQUFFLE9BQU8sTUFBTSxZQUFZLENBQUM7S0FDekQsTUFBTTtLQUNOO0tBQ0E7SUFDRDs7Ozs7SUFFRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFRLFNBQVE7TUFBVSxTQUFTO01BQVMsVUFBVTtnQkFDbkQsRUFBRSxpQkFBaUIsS0FBSztLQUNuQjs7OztlQUNSLHdCQUFDLFFBQUQ7TUFBUSxNQUFLO01BQW9CO2dCQUM5QixFQUFFLGtCQUFrQixVQUFVO0tBQ3pCOzs7O2FBQ0w7Ozs7OztHQUNEOzs7Ozs7Q0FDRDs7Ozs7QUFFWCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJKb2luVHJpcE1vZGFsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gJ3JlYWN0LWkxOG5leHQnO1xuaW1wb3J0IHsgS2V5Um91bmQgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgTW9kYWwgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL01vZGFsJztcbmltcG9ydCB7IElucHV0IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9JbnB1dCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0J1dHRvbic7XG5pbXBvcnQgeyBBbGVydCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvQWxlcnQnO1xuaW1wb3J0IHsgdHJpcEFwaSB9IGZyb20gJy4vdHJpcEFwaSc7XG5pbXBvcnQgeyB1c2VUcmlwU3RvcmUgfSBmcm9tICcuLi8uLi9zdG9yZS91c2VUcmlwU3RvcmUnO1xuXG5leHBvcnQgY29uc3QgSm9pblRyaXBNb2RhbCA9ICh7IGlzT3Blbiwgb25DbG9zZSB9KSA9PiB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcbiAgY29uc3QgeyBzZXRDdXJyZW50VHJpcCB9ID0gdXNlVHJpcFN0b3JlKCk7XG4gIGNvbnN0IFtqb2luQ29kZSwgc2V0Sm9pbkNvZGVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIWpvaW5Db2RlLnRyaW0oKSkge1xuICAgICAgc2V0RXJyb3IoJ1Z1aSBsw7JuZyBuaOG6rXAgbcOjIHRoYW0gZ2lhJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xuICAgIHNldEVycm9yKCcnKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0cmlwQXBpLmpvaW5UcmlwKGpvaW5Db2RlLnRyaW0oKSk7XG4gICAgICBpZiAocmVzLmRhdGEpIHtcbiAgICAgICAgc2V0Q3VycmVudFRyaXAocmVzLmRhdGEpO1xuICAgICAgICBzZXRKb2luQ29kZSgnJyk7XG4gICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlIHx8ICdNw6MgdGhhbSBnaWEga2jDtG5nIGjhu6NwIGzhu4cgaG/hurdjIGNodXnhur9uIMSRaSBraMO0bmcgdOG7k24gdOG6oWkuJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPE1vZGFsIGlzT3Blbj17aXNPcGVufSBvbkNsb3NlPXtvbkNsb3NlfSB0aXRsZT17dCgndHJpcC5qb2luJywgJ1RoYW0gZ2lhIGLhurFuZyBtw6MgY29kZScpfT5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTRcIj5cbiAgICAgICAge2Vycm9yICYmIDxBbGVydCB0eXBlPVwiZXJyb3JcIiBtZXNzYWdlPXtlcnJvcn0gb25DbG9zZT17KCkgPT4gc2V0RXJyb3IoJycpfSAvPn1cblxuICAgICAgICA8SW5wdXRcbiAgICAgICAgICBsYWJlbD1cIk3DoyBt4budaSBjaHV54bq/biDEkWkgKEpvaW4gQ29kZSlcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTmjhuq1wIG3DoyA2IGvDvSB04buxICh2w60gZOG7pTogQUJDMTIzKS4uLlwiXG4gICAgICAgICAgdmFsdWU9e2pvaW5Db2RlfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Sm9pbkNvZGUoZS50YXJnZXQudmFsdWUudG9VcHBlckNhc2UoKSl9XG4gICAgICAgICAgaWNvbj17S2V5Um91bmR9XG4gICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICBhdXRvRm9jdXNcbiAgICAgICAgLz5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgbXQtNFwiPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXtvbkNsb3NlfSBkaXNhYmxlZD17aXNMb2FkaW5nfT5cbiAgICAgICAgICAgIHt0KCdjb21tb24uY2FuY2VsJywgJ0jhu6d5Jyl9XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgaXNMb2FkaW5nPXtpc0xvYWRpbmd9PlxuICAgICAgICAgICAge3QoJ2NvbW1vbi5jb25maXJtJywgJ0dpYSBuaOG6rXAnKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9Nb2RhbD5cbiAgKTtcbn07XG4iXX0=