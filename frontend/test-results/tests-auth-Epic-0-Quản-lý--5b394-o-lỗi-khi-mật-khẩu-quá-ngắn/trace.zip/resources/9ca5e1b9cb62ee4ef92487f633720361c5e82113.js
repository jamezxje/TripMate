import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/funds/FundContributionModal.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { DollarSign, UserCheck } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import { Modal } from "/src/components/Modal.jsx";
import { Input } from "/src/components/Input.jsx";
import { Button } from "/src/components/Button.jsx";
import { Alert } from "/src/components/Alert.jsx";
import { fundApi } from "/src/features/funds/fundApi.js";
import { useTripStore } from "/src/store/useTripStore.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/funds/FundContributionModal.jsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const FundContributionModal = ({ isOpen, onClose, onSuccess }) => {
	_s();
	const { t } = useTranslation();
	const { currentTrip } = useTripStore();
	const [selectedUserId, setSelectedUserId] = useState(currentTrip?.members?.[0]?.userId || "");
	const [amount, setAmount] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState("");
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!currentTrip?.id) {
			setError("Chưa chọn chuyến đi");
			return;
		}
		if (!selectedUserId) {
			setError("Vui lòng chọn người đóng quỹ");
			return;
		}
		if (!amount || parseFloat(amount) <= 0) {
			setError("Số tiền đóng quỹ phải lớn hơn 0");
			return;
		}
		setIsLoading(true);
		setError("");
		try {
			await fundApi.contributeToFund(currentTrip.id, Number(selectedUserId), parseFloat(amount));
			setAmount("");
			onClose();
			if (onSuccess) onSuccess();
		} catch (err) {
			setError(err.message || "Ghi nhận đóng quỹ thất bại");
		} finally {
			setIsLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV(Modal, {
		isOpen,
		onClose,
		title: "Đóng tiền Quỹ chung",
		children: /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			className: "flex flex-col gap-4",
			children: [
				error && /* @__PURE__ */ _jsxDEV(Alert, {
					type: "error",
					message: error,
					onClose: () => setError("")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 19
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "w-full flex flex-col gap-1.5",
					children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "text-xs font-semibold text-slate-700 uppercase tracking-wider",
						children: "Thành viên đóng quỹ"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative flex items-center",
						children: [/* @__PURE__ */ _jsxDEV(UserCheck, { className: "absolute left-3.5 w-5 h-5 text-slate-400 pointer-events-none" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							value: selectedUserId,
							onChange: (e) => setSelectedUserId(e.target.value),
							className: "w-full min-h-[44px] rounded-xl border border-slate-200 bg-white pl-11 pr-4 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500",
							required: true,
							children: currentTrip?.members?.map((m) => /* @__PURE__ */ _jsxDEV("option", {
								value: m.userId,
								children: [
									m.fullName,
									" (",
									m.role,
									")"
								]
							}, m.userId, true, {
								fileName: _jsxFileName,
								lineNumber: 75,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Input, {
					label: "Số tiền đóng quỹ (VND)",
					type: "number",
					placeholder: "Ví dụ: 500000...",
					value: amount,
					onChange: (e) => setAmount(e.target.value),
					icon: DollarSign,
					step: "1000",
					min: "1000",
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-end gap-3 mt-4",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						onClick: onClose,
						disabled: isLoading,
						children: t("common.cancel", "Hủy")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						type: "submit",
						isLoading,
						children: "Ghi nhận"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 57,
		columnNumber: 5
	}, this);
};
_s(FundContributionModal, "Hg401vOtXKEJHPZ669WQHNLsIi4=", false, function() {
	return [useTranslation, useTripStore];
});
_c = FundContributionModal;
var _c;
$RefreshReg$(_c, "FundContributionModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/funds/FundContributionModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/funds/FundContributionModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/funds/FundContributionModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/funds/FundContributionModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLFlBQVksaUJBQWlCO0FBQ3RDLFNBQVMsYUFBYTtBQUN0QixTQUFTLGFBQWE7QUFDdEIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsYUFBYTtBQUN0QixTQUFTLGVBQWU7QUFDeEIsU0FBUyxvQkFBb0I7Ozs7QUFFN0IsT0FBTyxNQUFNLHlCQUF5QixFQUFFLFFBQVEsU0FBUyxnQkFBZ0I7O0NBQ3ZFLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FDN0IsTUFBTSxFQUFFLGdCQUFnQixhQUFhO0NBRXJDLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQzFDLGFBQWEsVUFBVSxFQUFFLEVBQUUsVUFBVSxFQUN2QztDQUNBLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxFQUFFO0NBQ3ZDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FFckMsTUFBTSxlQUFlLE9BQU8sTUFBTTtFQUNoQyxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLGFBQWEsSUFBSTtHQUNwQixTQUFTLHFCQUFxQjtHQUM5QjtFQUNGO0VBQ0EsSUFBSSxDQUFDLGdCQUFnQjtHQUNuQixTQUFTLDhCQUE4QjtHQUN2QztFQUNGO0VBQ0EsSUFBSSxDQUFDLFVBQVUsV0FBVyxNQUFNLEtBQUssR0FBRztHQUN0QyxTQUFTLGlDQUFpQztHQUMxQztFQUNGO0VBRUEsYUFBYSxJQUFJO0VBQ2pCLFNBQVMsRUFBRTtFQUVYLElBQUk7R0FDRixNQUFNLFFBQVEsaUJBQ1osWUFBWSxJQUNaLE9BQU8sY0FBYyxHQUNyQixXQUFXLE1BQU0sQ0FDbkI7R0FDQSxVQUFVLEVBQUU7R0FDWixRQUFRO0dBQ1IsSUFBSSxXQUFXLFVBQVU7RUFDM0IsU0FBUyxLQUFLO0dBQ1osU0FBUyxJQUFJLFdBQVcsNEJBQTRCO0VBQ3RELFVBQVU7R0FDUixhQUFhLEtBQUs7RUFDcEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFlO0VBQWlCO0VBQVMsT0FBTTtZQUM3Qyx3QkFBQyxRQUFEO0dBQU0sVUFBVTtHQUFjLFdBQVU7YUFBeEM7SUFDRyxTQUFTLHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVEsU0FBUztLQUFPLGVBQWUsU0FBUyxFQUFFO0lBQUk7Ozs7O0lBRzVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBZ0U7S0FFMUU7Ozs7ZUFDUCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLCtEQUFnRTs7OztnQkFDckYsd0JBQUMsVUFBRDtPQUNFLE9BQU87T0FDUCxXQUFXLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxLQUFLO09BQ2pELFdBQVU7T0FDVjtpQkFFQyxhQUFhLFNBQVMsS0FBSyxNQUMxQix3QkFBQyxVQUFEO1FBQXVCLE9BQU8sRUFBRTtrQkFBaEM7U0FDRyxFQUFFO1NBQVM7U0FBRyxFQUFFO1NBQUs7UUFDaEI7VUFGSyxFQUFFOzs7O2NBRVAsQ0FDVDtNQUNLOzs7O2NBQ0w7Ozs7O2FBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FDRSxPQUFNO0tBQ04sTUFBSztLQUNMLGFBQVk7S0FDWixPQUFPO0tBQ1AsV0FBVyxNQUFNLFVBQVUsRUFBRSxPQUFPLEtBQUs7S0FDekMsTUFBTTtLQUNOLE1BQUs7S0FDTCxLQUFJO0tBQ0o7SUFDRDs7Ozs7SUFFRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFRLFNBQVE7TUFBVSxTQUFTO01BQVMsVUFBVTtnQkFDbkQsRUFBRSxpQkFBaUIsS0FBSztLQUNuQjs7OztlQUNSLHdCQUFDLFFBQUQ7TUFBUSxNQUFLO01BQW9CO2dCQUFXO0tBRXBDOzs7O2FBQ0w7Ozs7OztHQUNEOzs7Ozs7Q0FDRDs7Ozs7QUFFWCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJGdW5kQ29udHJpYnV0aW9uTW9kYWwuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSAncmVhY3QtaTE4bmV4dCc7XG5pbXBvcnQgeyBEb2xsYXJTaWduLCBVc2VyQ2hlY2sgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgTW9kYWwgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL01vZGFsJztcbmltcG9ydCB7IElucHV0IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9JbnB1dCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0J1dHRvbic7XG5pbXBvcnQgeyBBbGVydCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvQWxlcnQnO1xuaW1wb3J0IHsgZnVuZEFwaSB9IGZyb20gJy4vZnVuZEFwaSc7XG5pbXBvcnQgeyB1c2VUcmlwU3RvcmUgfSBmcm9tICcuLi8uLi9zdG9yZS91c2VUcmlwU3RvcmUnO1xuXG5leHBvcnQgY29uc3QgRnVuZENvbnRyaWJ1dGlvbk1vZGFsID0gKHsgaXNPcGVuLCBvbkNsb3NlLCBvblN1Y2Nlc3MgfSkgPT4ge1xuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XG4gIGNvbnN0IHsgY3VycmVudFRyaXAgfSA9IHVzZVRyaXBTdG9yZSgpO1xuXG4gIGNvbnN0IFtzZWxlY3RlZFVzZXJJZCwgc2V0U2VsZWN0ZWRVc2VySWRdID0gdXNlU3RhdGUoXG4gICAgY3VycmVudFRyaXA/Lm1lbWJlcnM/LlswXT8udXNlcklkIHx8ICcnXG4gICk7XG4gIGNvbnN0IFthbW91bnQsIHNldEFtb3VudF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICghY3VycmVudFRyaXA/LmlkKSB7XG4gICAgICBzZXRFcnJvcignQ2jGsGEgY2jhu41uIGNodXnhur9uIMSRaScpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIXNlbGVjdGVkVXNlcklkKSB7XG4gICAgICBzZXRFcnJvcignVnVpIGzDsm5nIGNo4buNbiBuZ8aw4budaSDEkcOzbmcgcXXhu7knKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFhbW91bnQgfHwgcGFyc2VGbG9hdChhbW91bnQpIDw9IDApIHtcbiAgICAgIHNldEVycm9yKCdT4buRIHRp4buBbiDEkcOzbmcgcXXhu7kgcGjhuqNpIGzhu5tuIGjGoW4gMCcpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcbiAgICBzZXRFcnJvcignJyk7XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgZnVuZEFwaS5jb250cmlidXRlVG9GdW5kKFxuICAgICAgICBjdXJyZW50VHJpcC5pZCxcbiAgICAgICAgTnVtYmVyKHNlbGVjdGVkVXNlcklkKSxcbiAgICAgICAgcGFyc2VGbG9hdChhbW91bnQpXG4gICAgICApO1xuICAgICAgc2V0QW1vdW50KCcnKTtcbiAgICAgIG9uQ2xvc2UoKTtcbiAgICAgIGlmIChvblN1Y2Nlc3MpIG9uU3VjY2VzcygpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgJ0doaSBuaOG6rW4gxJHDs25nIHF14bu5IHRo4bqldCBi4bqhaScpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxNb2RhbCBpc09wZW49e2lzT3Blbn0gb25DbG9zZT17b25DbG9zZX0gdGl0bGU9XCLEkMOzbmcgdGnhu4FuIFF14bu5IGNodW5nXCI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00XCI+XG4gICAgICAgIHtlcnJvciAmJiA8QWxlcnQgdHlwZT1cImVycm9yXCIgbWVzc2FnZT17ZXJyb3J9IG9uQ2xvc2U9eygpID0+IHNldEVycm9yKCcnKX0gLz59XG5cbiAgICAgICAgey8qIFVzZXIgc2VsZWN0ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgVGjDoG5oIHZpw6puIMSRw7NuZyBxdeG7uVxuICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgPFVzZXJDaGVjayBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMuNSB3LTUgaC01IHRleHQtc2xhdGUtNDAwIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRVc2VySWR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRVc2VySWQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWluLWgtWzQ0cHhdIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcGwtMTEgcHItNCB0ZXh0LXNtIHRleHQtc2xhdGUtOTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tMTAwIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2N1cnJlbnRUcmlwPy5tZW1iZXJzPy5tYXAoKG0pID0+IChcbiAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17bS51c2VySWR9IHZhbHVlPXttLnVzZXJJZH0+XG4gICAgICAgICAgICAgICAgICB7bS5mdWxsTmFtZX0gKHttLnJvbGV9KVxuICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQW1vdW50ICovfVxuICAgICAgICA8SW5wdXRcbiAgICAgICAgICBsYWJlbD1cIlPhu5EgdGnhu4FuIMSRw7NuZyBxdeG7uSAoVk5EKVwiXG4gICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJWw60gZOG7pTogNTAwMDAwLi4uXCJcbiAgICAgICAgICB2YWx1ZT17YW1vdW50fVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QW1vdW50KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICBpY29uPXtEb2xsYXJTaWdufVxuICAgICAgICAgIHN0ZXA9XCIxMDAwXCJcbiAgICAgICAgICBtaW49XCIxMDAwXCJcbiAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAvPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBtdC00XCI+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e29uQ2xvc2V9IGRpc2FibGVkPXtpc0xvYWRpbmd9PlxuICAgICAgICAgICAge3QoJ2NvbW1vbi5jYW5jZWwnLCAnSOG7p3knKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBpc0xvYWRpbmc9e2lzTG9hZGluZ30+XG4gICAgICAgICAgICBHaGkgbmjhuq1uXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9mb3JtPlxuICAgIDwvTW9kYWw+XG4gICk7XG59O1xuIl19