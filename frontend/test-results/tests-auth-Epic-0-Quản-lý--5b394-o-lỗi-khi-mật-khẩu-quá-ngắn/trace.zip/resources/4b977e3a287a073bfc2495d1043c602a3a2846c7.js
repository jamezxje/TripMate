import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProtectedRoute.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { Navigate, Outlet, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=aa845dd0";
import { useUserStore } from "/src/store/useUserStore.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/ProtectedRoute.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const ProtectedRoute = ({ children }) => {
	_s();
	const { isAuthenticated, token } = useUserStore();
	const location = useLocation();
	const isUserLoggedIn = isAuthenticated || !!token || !!localStorage.getItem("token");
	if (!isUserLoggedIn) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/login",
			state: { from: location },
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 12
		}, this);
	}
	return children ? children : /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 32
	}, this);
};
_s(ProtectedRoute, "gexAGL2rEaTwxbcH6Cn/7Q0yQnk=", false, function() {
	return [useUserStore, useLocation];
});
_c = ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ProtectedRoute.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/ProtectedRoute.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/ProtectedRoute.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/ProtectedRoute.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsVUFBVSxRQUFRLG1CQUFtQjtBQUM5QyxTQUFTLG9CQUFvQjs7OztBQUU3QixPQUFPLE1BQU0sa0JBQWtCLEVBQUUsZUFBZTs7Q0FDOUMsTUFBTSxFQUFFLGlCQUFpQixVQUFVLGFBQWE7Q0FDaEQsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsTUFBTSxpQkFBaUIsbUJBQW1CLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxhQUFhLFFBQVEsT0FBTztDQUVuRixJQUFJLENBQUMsZ0JBQWdCO0VBQ25CLE9BQU8sd0JBQUMsVUFBRDtHQUFVLElBQUc7R0FBUyxPQUFPLEVBQUUsTUFBTSxTQUFTO0dBQUc7RUFBUzs7Ozs7Q0FDbkU7Q0FFQSxPQUFPLFdBQVcsV0FBVyx3QkFBQyxRQUFELENBQVM7Ozs7O0FBQ3hDIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb3RlY3RlZFJvdXRlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTmF2aWdhdGUsIE91dGxldCwgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZVVzZXJTdG9yZSB9IGZyb20gJy4uL3N0b3JlL3VzZVVzZXJTdG9yZSc7XG5cbmV4cG9ydCBjb25zdCBQcm90ZWN0ZWRSb3V0ZSA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgY29uc3QgeyBpc0F1dGhlbnRpY2F0ZWQsIHRva2VuIH0gPSB1c2VVc2VyU3RvcmUoKTtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuXG4gIGNvbnN0IGlzVXNlckxvZ2dlZEluID0gaXNBdXRoZW50aWNhdGVkIHx8ICEhdG9rZW4gfHwgISFsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKTtcblxuICBpZiAoIWlzVXNlckxvZ2dlZEluKSB7XG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9sb2dpblwiIHN0YXRlPXt7IGZyb206IGxvY2F0aW9uIH19IHJlcGxhY2UgLz47XG4gIH1cblxuICByZXR1cm4gY2hpbGRyZW4gPyBjaGlsZHJlbiA6IDxPdXRsZXQgLz47XG59O1xuIl19