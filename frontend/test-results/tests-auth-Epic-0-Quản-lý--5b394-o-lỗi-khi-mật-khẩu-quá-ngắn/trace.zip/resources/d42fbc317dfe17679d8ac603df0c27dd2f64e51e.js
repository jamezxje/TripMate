import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/settlement/SettlementDashboard.jsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Calculator, CheckCircle2, ArrowRight, RefreshCw, UserCheck, PartyPopper } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import { Card, CardHeader, CardBody } from "/src/components/Card.jsx";
import { Button } from "/src/components/Button.jsx";
import { Badge } from "/src/components/Badge.jsx";
import { Alert } from "/src/components/Alert.jsx";
import { Table } from "/src/components/Table.jsx";
import { settlementApi } from "/src/features/settlement/settlementApi.js";
import { useTripStore } from "/src/store/useTripStore.js";
import { useUserStore } from "/src/store/useUserStore.js";
import { formatCurrency } from "/src/utils/formatters.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/settlement/SettlementDashboard.jsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const SettlementDashboard = () => {
	_s();
	const { t } = useTranslation();
	const { currentTrip, setCurrentTrip } = useTripStore();
	const { currentUser } = useUserStore();
	const [summary, setSummary] = useState(null);
	const [isLoading, setIsLoading] = useState(false);
	const [actionLoadingId, setActionLoadingId] = useState(null);
	const [error, setError] = useState("");
	const [successMessage, setSuccessMessage] = useState("");
	const fetchSettlementSummary = useCallback(async () => {
		if (!currentTrip?.id) return;
		setIsLoading(true);
		setError("");
		try {
			const res = await settlementApi.getSettlementSummary(currentTrip.id);
			if (res.data) {
				setSummary(res.data);
			}
		} catch (err) {
			setError(err.message || "Không thể tải thông tin quyết toán");
		} finally {
			setIsLoading(false);
		}
	}, [currentTrip?.id]);
	useEffect(() => {
		fetchSettlementSummary();
	}, [fetchSettlementSummary]);
	const handleCompleteTransfer = async (settlementId) => {
		setActionLoadingId(settlementId);
		setError("");
		setSuccessMessage("");
		try {
			const res = await settlementApi.completeSettlement(settlementId);
			if (res.data) {
				setSuccessMessage("Đã đánh dấu hoàn tất chuyển khoản!");
				// Refresh summary to update status and check if trip status changed to CLOSED
				await fetchSettlementSummary();
			}
		} catch (err) {
			setError(err.message || "Thao tác thất bại. Chỉ Trưởng nhóm mới có quyền này.");
		} finally {
			setActionLoadingId(null);
		}
	};
	if (!currentTrip) {
		return /* @__PURE__ */ _jsxDEV(Card, {
			className: "text-center py-12",
			children: [
				/* @__PURE__ */ _jsxDEV(Calculator, { className: "w-12 h-12 text-slate-300 mx-auto mb-3" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-lg font-bold text-slate-800",
					children: "Chưa chọn Chuyến đi"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-slate-500 text-sm mt-1",
					children: "Vui lòng chọn hoặc tạo mới chuyến đi ở trang danh sách để xem quyết toán."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 7
		}, this);
	}
	const allTransfersSettled = summary?.suggestedTransfers && summary.suggestedTransfers.length > 0 && summary.suggestedTransfers.every((t) => t.isSettled);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Calculator, { className: "w-7 h-7 text-indigo-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
						t("settlement.title", "Quyết toán Chuyến đi"),
						" - ",
						currentTrip.name
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-slate-500 text-sm mt-0.5",
					children: "Bảng tổng sắp số dư cá nhân và đề xuất chuyển khoản bù trừ tối ưu nhất."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						icon: RefreshCw,
						onClick: fetchSettlementSummary,
						isLoading,
						children: "Tải lại"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV(Alert, {
				type: "error",
				message: error,
				onClose: () => setError("")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 17
			}, this),
			successMessage && /* @__PURE__ */ _jsxDEV(Alert, {
				type: "success",
				message: successMessage,
				onClose: () => setSuccessMessage("")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 26
			}, this),
			(allTransfersSettled || summary?.tripStatus === "CLOSED") && /* @__PURE__ */ _jsxDEV(Card, {
				className: "bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-xl border-none",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 bg-white/20 rounded-2xl shrink-0",
						children: /* @__PURE__ */ _jsxDEV(PartyPopper, { className: "w-8 h-8 text-white" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-lg font-black text-white",
						children: "Chuyến đi đã Quyết toán xong!"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-emerald-100 text-sm mt-0.5",
						children: [
							"Tất cả các khoản chuyển tiền giữa các thành viên đã hoàn tất. Trạng thái chuyến đi: ",
							/* @__PURE__ */ _jsxDEV("strong", { children: "CLOSED (Đã đóng)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 101
							}, this),
							"."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Card, { children: [/* @__PURE__ */ _jsxDEV(CardHeader, {
				title: "Bảng Tổng sắp Số dư Cá nhân",
				subtitle: "Số dư = (Đóng quỹ + Ứng tiền trả hộ) - Chi phí cá nhân phải chịu"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 125,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(CardBody, { children: summary?.balances && summary.balances.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",
				children: summary.balances.map((b) => {
					const isPositive = b.netBalance > 0;
					const isNegative = b.netBalance < 0;
					return /* @__PURE__ */ _jsxDEV("div", {
						className: `p-4 rounded-2xl border transition-all ${isPositive ? "bg-emerald-50/40 border-emerald-200" : isNegative ? "bg-rose-50/40 border-rose-200" : "bg-slate-50 border-slate-200"}`,
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between gap-2 mb-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2.5 min-w-0",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "w-9 h-9 rounded-full bg-white font-bold text-xs flex items-center justify-center border shadow-xs shrink-0",
										children: b.fullName ? b.fullName.charAt(0) : "U"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 149,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "font-bold text-slate-800 text-sm truncate",
											children: b.fullName
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 153,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-slate-500 truncate",
											children: b.email
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 154,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 152,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 23
								}, this), isPositive ? /* @__PURE__ */ _jsxDEV(Badge, {
									variant: "positive",
									children: "Nhận lại"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 25
								}, this) : isNegative ? /* @__PURE__ */ _jsxDEV(Badge, {
									variant: "negative",
									children: "Đóng thêm"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 162,
									columnNumber: 25
								}, this) : /* @__PURE__ */ _jsxDEV(Badge, {
									variant: "closed",
									children: "Hòa tiền"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 25
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1 text-xs border-t border-slate-200/60 pt-2.5 text-slate-600",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Đã đóng quỹ:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 171,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold",
											children: formatCurrency(b.totalFundContributed)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 172,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Tự ứng trả hộ:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 175,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold",
											children: formatCurrency(b.totalPaidOutOfPocket)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 176,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 174,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Chi phí phải chịu:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 179,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold text-slate-800",
											children: formatCurrency(b.totalAmountOwed)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 180,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 178,
										columnNumber: 23
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-3 pt-2.5 border-t border-slate-200/80 flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-slate-600",
									children: "Số dư ròng:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 188,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: `text-base font-black ${isPositive ? "text-emerald-600" : isNegative ? "text-rose-600" : "text-slate-700"}`,
									children: [isPositive ? "+" : "", formatCurrency(b.netBalance)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 189,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 21
							}, this)
						]
					}, b.userId, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 19
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 131,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV("p", {
				className: "text-center py-6 text-slate-500 text-sm",
				children: "Chưa có dữ liệu số dư."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 207,
				columnNumber: 13
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 129,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Card, { children: [/* @__PURE__ */ _jsxDEV(CardHeader, {
				title: "Danh sách Chuyển khoản Bù trừ Đề xuất",
				subtitle: "Thuật toán tự động tính toán số lượt chuyển tiền tối ưu nhất giữa các cá nhân."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 214,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(CardBody, { children: summary?.suggestedTransfers && summary.suggestedTransfers.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-3",
				children: summary.suggestedTransfers.map((t) => /* @__PURE__ */ _jsxDEV("div", {
					className: `p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all ${t.isSettled ? "bg-slate-50 border-slate-200/80 opacity-75" : "bg-white border-indigo-200/80 shadow-xs hover:border-indigo-300"}`,
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 bg-slate-100 p-2.5 rounded-xl border border-slate-200 text-sm",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-extrabold text-slate-800",
									children: t.fromUserName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 23
								}, this),
								/* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4 text-indigo-600 shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 23
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-extrabold text-slate-800",
									children: t.toUserName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 234,
									columnNumber: 23
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 231,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 font-semibold",
							children: "Số tiền cần chuyển:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 237,
							columnNumber: 23
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-lg font-black text-indigo-600",
							children: formatCurrency(t.amount)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 23
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 236,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 230,
						columnNumber: 19
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between sm:justify-end gap-3 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100",
						children: t.isSettled ? /* @__PURE__ */ _jsxDEV(Badge, {
							variant: "ongoing",
							className: "gap-1 px-3 py-1.5 text-xs",
							children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 247,
								columnNumber: 25
							}, this), "Đã hoàn tất"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 246,
							columnNumber: 23
						}, this) : /* @__PURE__ */ _jsxDEV(Button, {
							variant: "success",
							size: "sm",
							icon: CheckCircle2,
							isLoading: actionLoadingId === t.id,
							onClick: () => handleCompleteTransfer(t.id),
							children: "Đánh dấu đã chuyển"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 251,
							columnNumber: 23
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 244,
						columnNumber: 19
					}, this)]
				}, t.id, true, {
					fileName: _jsxFileName,
					lineNumber: 222,
					columnNumber: 17
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 220,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "text-center py-10 text-slate-500 text-sm",
				children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-10 h-10 text-emerald-400 mx-auto mb-2" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 267,
					columnNumber: 15
				}, this), "Tất cả thành viên đã hòa tiền hoặc chưa có giao dịch cần chuyển khoản."]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 266,
				columnNumber: 13
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 218,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 83,
		columnNumber: 5
	}, this);
};
_s(SettlementDashboard, "NpLuR9Fhzv2EgTkkAokYOZgUWX0=", false, function() {
	return [
		useTranslation,
		useTripStore,
		useUserStore
	];
});
_c = SettlementDashboard;
var _c;
$RefreshReg$(_c, "SettlementDashboard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/settlement/SettlementDashboard.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/settlement/SettlementDashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/settlement/SettlementDashboard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/settlement/SettlementDashboard.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsVUFBVSxtQkFBbUI7QUFDeEQsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxZQUFZLGNBQWMsWUFBWSxXQUFXLFdBQVcsbUJBQW1CO0FBQ3hGLFNBQVMsTUFBTSxZQUFZLGdCQUFnQjtBQUMzQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsYUFBYTtBQUN0QixTQUFTLGFBQWE7QUFDdEIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxzQkFBc0I7Ozs7QUFFL0IsT0FBTyxNQUFNLDRCQUE0Qjs7Q0FDdkMsTUFBTSxFQUFFLE1BQU0sZUFBZTtDQUM3QixNQUFNLEVBQUUsYUFBYSxtQkFBbUIsYUFBYTtDQUNyRCxNQUFNLEVBQUUsZ0JBQWdCLGFBQWE7Q0FFckMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLElBQUk7Q0FDM0QsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxFQUFFO0NBRXZELE1BQU0seUJBQXlCLFlBQVksWUFBWTtFQUNyRCxJQUFJLENBQUMsYUFBYSxJQUFJO0VBQ3RCLGFBQWEsSUFBSTtFQUNqQixTQUFTLEVBQUU7RUFFWCxJQUFJO0dBQ0YsTUFBTSxNQUFNLE1BQU0sY0FBYyxxQkFBcUIsWUFBWSxFQUFFO0dBQ25FLElBQUksSUFBSSxNQUFNO0lBQ1osV0FBVyxJQUFJLElBQUk7R0FDckI7RUFDRixTQUFTLEtBQUs7R0FDWixTQUFTLElBQUksV0FBVyxvQ0FBb0M7RUFDOUQsVUFBVTtHQUNSLGFBQWEsS0FBSztFQUNwQjtDQUNGLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztDQUVwQixnQkFBZ0I7RUFDZCx1QkFBdUI7Q0FDekIsR0FBRyxDQUFDLHNCQUFzQixDQUFDO0NBRTNCLE1BQU0seUJBQXlCLE9BQU8saUJBQWlCO0VBQ3JELG1CQUFtQixZQUFZO0VBQy9CLFNBQVMsRUFBRTtFQUNYLGtCQUFrQixFQUFFO0VBRXBCLElBQUk7R0FDRixNQUFNLE1BQU0sTUFBTSxjQUFjLG1CQUFtQixZQUFZO0dBQy9ELElBQUksSUFBSSxNQUFNO0lBQ1osa0JBQWtCLG9DQUFvQzs7SUFFdEQsTUFBTSx1QkFBdUI7R0FDL0I7RUFDRixTQUFTLEtBQUs7R0FDWixTQUFTLElBQUksV0FBVyxzREFBc0Q7RUFDaEYsVUFBVTtHQUNSLG1CQUFtQixJQUFJO0VBQ3pCO0NBQ0Y7Q0FFQSxJQUFJLENBQUMsYUFBYTtFQUNoQixPQUNFLHdCQUFDLE1BQUQ7R0FBTSxXQUFVO2FBQWhCO0lBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsd0NBQXlDOzs7OztJQUMvRCx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFtQztJQUF1Qjs7Ozs7SUFDeEUsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBOEI7SUFFeEM7Ozs7O0dBQ0M7Ozs7OztDQUVWO0NBRUEsTUFBTSxzQkFDSixTQUFTLHNCQUNULFFBQVEsbUJBQW1CLFNBQVMsS0FDcEMsUUFBUSxtQkFBbUIsT0FBTyxNQUFNLEVBQUUsU0FBUztDQUVyRCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQsQ0FDRSx3QkFBQyxZQUFELEVBQVksV0FBVSwwQkFBMkI7Ozs7ZUFDakQsd0JBQUMsUUFBRDtNQUFPLEVBQUUsb0JBQW9CLHNCQUFzQjtNQUFFO01BQUksWUFBWTtLQUFXOzs7O2FBQzlFOzs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWdDO0lBRTFDOzs7O1lBQ0E7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFFBQUQ7TUFBUSxTQUFRO01BQVUsTUFBTTtNQUFXLFNBQVM7TUFBbUM7Z0JBQVc7S0FFMUY7Ozs7O0lBQ0w7Ozs7WUFDRjs7Ozs7O0dBRUosU0FBUyx3QkFBQyxPQUFEO0lBQU8sTUFBSztJQUFRLFNBQVM7SUFBTyxlQUFlLFNBQVMsRUFBRTtHQUFJOzs7OztHQUMzRSxrQkFBa0Isd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBVSxTQUFTO0lBQWdCLGVBQWUsa0JBQWtCLEVBQUU7R0FBSTs7Ozs7SUFHdkcsdUJBQXVCLFNBQVMsZUFBZSxhQUMvQyx3QkFBQyxNQUFEO0lBQU0sV0FBVTtjQUNkLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxhQUFELEVBQWEsV0FBVSxxQkFBc0I7Ozs7O0tBQzFDOzs7O2VBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFnQztLQUFpQzs7OztlQUMvRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUErQztPQUN1Qyx3QkFBQyxVQUFELFlBQVEsbUJBQXdCOzs7OztPQUFDO01BQ3BIOzs7OzthQUNBOzs7O2FBQ0Y7Ozs7OztHQUNEOzs7OztHQUlSLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxZQUFEO0lBQ0UsT0FBTTtJQUNOLFVBQVM7R0FDVjs7OzthQUNELHdCQUFDLFVBQUQsWUFDRyxTQUFTLFlBQVksUUFBUSxTQUFTLFNBQVMsSUFDOUMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWixRQUFRLFNBQVMsS0FBSyxNQUFNO0tBQzNCLE1BQU0sYUFBYSxFQUFFLGFBQWE7S0FDbEMsTUFBTSxhQUFhLEVBQUUsYUFBYTtLQUVsQyxPQUNFLHdCQUFDLE9BQUQ7TUFFRSxXQUFXLHlDQUNULGFBQ0ksd0NBQ0EsYUFDQSxrQ0FDQTtnQkFQUjtPQVVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixFQUFFLFdBQVcsRUFBRSxTQUFTLE9BQU8sQ0FBQyxJQUFJO1NBQ2xDOzs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQTZDLEVBQUU7VUFBWTs7OztvQkFDeEUsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXVDLEVBQUU7VUFBUzs7OztrQkFDNUQ7Ozs7O2lCQUNGOzs7OztrQkFHSixhQUNDLHdCQUFDLE9BQUQ7U0FBTyxTQUFRO21CQUFXO1FBQWU7Ozs7bUJBQ3ZDLGFBQ0Ysd0JBQUMsT0FBRDtTQUFPLFNBQVE7bUJBQVc7UUFBZ0I7Ozs7bUJBRTFDLHdCQUFDLE9BQUQ7U0FBTyxTQUFRO21CQUFTO1FBQWU7Ozs7Z0JBRXRDOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7O29CQUN4Qix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaUIsZUFBZSxFQUFFLG9CQUFvQjtVQUFROzs7O2tCQUMzRTs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7O29CQUMxQix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaUIsZUFBZSxFQUFFLG9CQUFvQjtVQUFROzs7O2tCQUMzRTs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0scUJBQXdCOzs7O29CQUM5Qix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixlQUFlLEVBQUUsZUFBZTtVQUM3Qjs7OztrQkFDSDs7Ozs7O1FBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW1DO1FBQWlCOzs7O2tCQUNwRSx3QkFBQyxRQUFEO1NBQ0UsV0FBVyx3QkFDVCxhQUNJLHFCQUNBLGFBQ0Esa0JBQ0E7bUJBTlIsQ0FTRyxhQUFhLE1BQU0sSUFDbkIsZUFBZSxFQUFFLFVBQVUsQ0FDeEI7Ozs7O2dCQUNIOzs7Ozs7TUFDRjtRQWhFRSxFQUFFOzs7O1lBZ0VKO0lBRVQsQ0FBQztHQUNFOzs7O2NBRUwsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBMEM7R0FBeUI7Ozs7WUFFMUU7Ozs7V0FDTjs7Ozs7R0FHTix3QkFBQyxNQUFELGFBQ0Usd0JBQUMsWUFBRDtJQUNFLE9BQU07SUFDTixVQUFTO0dBQ1Y7Ozs7YUFDRCx3QkFBQyxVQUFELFlBQ0csU0FBUyxzQkFBc0IsUUFBUSxtQkFBbUIsU0FBUyxJQUNsRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFFBQVEsbUJBQW1CLEtBQUssTUFDL0Isd0JBQUMsT0FBRDtLQUVFLFdBQVcseUdBQ1QsRUFBRSxZQUNFLCtDQUNBO2VBTFIsQ0FRRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlDLEVBQUU7UUFBbUI7Ozs7O1FBQ3RFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLG1DQUFvQzs7Ozs7UUFDMUQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlDLEVBQUU7UUFBaUI7Ozs7O09BQ2pFOzs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXVDO01BQXNCOzs7O2dCQUMxRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDVixlQUFlLEVBQUUsTUFBTTtNQUN2Qjs7OztjQUNBOzs7O2NBQ0Y7Ozs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osRUFBRSxZQUNELHdCQUFDLE9BQUQ7T0FBTyxTQUFRO09BQVUsV0FBVTtpQkFBbkMsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSwyQkFBNEI7Ozs7aUJBQUMsYUFFaEQ7Ozs7O2lCQUVQLHdCQUFDLFFBQUQ7T0FDRSxTQUFRO09BQ1IsTUFBSztPQUNMLE1BQU07T0FDTixXQUFXLG9CQUFvQixFQUFFO09BQ2pDLGVBQWUsdUJBQXVCLEVBQUUsRUFBRTtpQkFDM0M7TUFFTzs7Ozs7S0FFUDs7OzthQUNGO09BdkNFLEVBQUU7Ozs7V0F1Q0osQ0FDTjtHQUNFOzs7O2NBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDBDQUEyQzs7OztjQUFDLHdFQUVqRTs7Ozs7WUFFQzs7OztXQUNOOzs7OztFQUNIOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZXR0bGVtZW50RGFzaGJvYXJkLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gJ3JlYWN0LWkxOG5leHQnO1xuaW1wb3J0IHsgQ2FsY3VsYXRvciwgQ2hlY2tDaXJjbGUyLCBBcnJvd1JpZ2h0LCBSZWZyZXNoQ3csIFVzZXJDaGVjaywgUGFydHlQb3BwZXIgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgQ2FyZCwgQ2FyZEhlYWRlciwgQ2FyZEJvZHkgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0NhcmQnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9CdXR0b24nO1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0JhZGdlJztcbmltcG9ydCB7IEFsZXJ0IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9BbGVydCc7XG5pbXBvcnQgeyBUYWJsZSB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvVGFibGUnO1xuaW1wb3J0IHsgc2V0dGxlbWVudEFwaSB9IGZyb20gJy4vc2V0dGxlbWVudEFwaSc7XG5pbXBvcnQgeyB1c2VUcmlwU3RvcmUgfSBmcm9tICcuLi8uLi9zdG9yZS91c2VUcmlwU3RvcmUnO1xuaW1wb3J0IHsgdXNlVXNlclN0b3JlIH0gZnJvbSAnLi4vLi4vc3RvcmUvdXNlVXNlclN0b3JlJztcbmltcG9ydCB7IGZvcm1hdEN1cnJlbmN5IH0gZnJvbSAnLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5cbmV4cG9ydCBjb25zdCBTZXR0bGVtZW50RGFzaGJvYXJkID0gKCkgPT4ge1xuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XG4gIGNvbnN0IHsgY3VycmVudFRyaXAsIHNldEN1cnJlbnRUcmlwIH0gPSB1c2VUcmlwU3RvcmUoKTtcbiAgY29uc3QgeyBjdXJyZW50VXNlciB9ID0gdXNlVXNlclN0b3JlKCk7XG5cbiAgY29uc3QgW3N1bW1hcnksIHNldFN1bW1hcnldID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFthY3Rpb25Mb2FkaW5nSWQsIHNldEFjdGlvbkxvYWRpbmdJZF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzdWNjZXNzTWVzc2FnZSwgc2V0U3VjY2Vzc01lc3NhZ2VdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IGZldGNoU2V0dGxlbWVudFN1bW1hcnkgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFjdXJyZW50VHJpcD8uaWQpIHJldHVybjtcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IoJycpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHNldHRsZW1lbnRBcGkuZ2V0U2V0dGxlbWVudFN1bW1hcnkoY3VycmVudFRyaXAuaWQpO1xuICAgICAgaWYgKHJlcy5kYXRhKSB7XG4gICAgICAgIHNldFN1bW1hcnkocmVzLmRhdGEpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgJ0tow7RuZyB0aOG7gyB04bqjaSB0aMO0bmcgdGluIHF1eeG6v3QgdG/DoW4nKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH0sIFtjdXJyZW50VHJpcD8uaWRdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGZldGNoU2V0dGxlbWVudFN1bW1hcnkoKTtcbiAgfSwgW2ZldGNoU2V0dGxlbWVudFN1bW1hcnldKTtcblxuICBjb25zdCBoYW5kbGVDb21wbGV0ZVRyYW5zZmVyID0gYXN5bmMgKHNldHRsZW1lbnRJZCkgPT4ge1xuICAgIHNldEFjdGlvbkxvYWRpbmdJZChzZXR0bGVtZW50SWQpO1xuICAgIHNldEVycm9yKCcnKTtcbiAgICBzZXRTdWNjZXNzTWVzc2FnZSgnJyk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgc2V0dGxlbWVudEFwaS5jb21wbGV0ZVNldHRsZW1lbnQoc2V0dGxlbWVudElkKTtcbiAgICAgIGlmIChyZXMuZGF0YSkge1xuICAgICAgICBzZXRTdWNjZXNzTWVzc2FnZSgnxJDDoyDEkcOhbmggZOG6pXUgaG/DoG4gdOG6pXQgY2h1eeG7g24ga2hv4bqjbiEnKTtcbiAgICAgICAgLy8gUmVmcmVzaCBzdW1tYXJ5IHRvIHVwZGF0ZSBzdGF0dXMgYW5kIGNoZWNrIGlmIHRyaXAgc3RhdHVzIGNoYW5nZWQgdG8gQ0xPU0VEXG4gICAgICAgIGF3YWl0IGZldGNoU2V0dGxlbWVudFN1bW1hcnkoKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlIHx8ICdUaGFvIHTDoWMgdGjhuqV0IGLhuqFpLiBDaOG7iSBUcsaw4bufbmcgbmjDs20gbeG7m2kgY8OzIHF1eeG7gW4gbsOgeS4nKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0QWN0aW9uTG9hZGluZ0lkKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICBpZiAoIWN1cnJlbnRUcmlwKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEyXCI+XG4gICAgICAgIDxDYWxjdWxhdG9yIGNsYXNzTmFtZT1cInctMTIgaC0xMiB0ZXh0LXNsYXRlLTMwMCBteC1hdXRvIG1iLTNcIiAvPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5DaMawYSBjaOG7jW4gQ2h1eeG6v24gxJFpPC9oMz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBtdC0xXCI+XG4gICAgICAgICAgVnVpIGzDsm5nIGNo4buNbiBob+G6t2MgdOG6oW8gbeG7m2kgY2h1eeG6v24gxJFpIOG7nyB0cmFuZyBkYW5oIHPDoWNoIMSR4buDIHhlbSBxdXnhur90IHRvw6FuLlxuICAgICAgICA8L3A+XG4gICAgICA8L0NhcmQ+XG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0IGFsbFRyYW5zZmVyc1NldHRsZWQgPVxuICAgIHN1bW1hcnk/LnN1Z2dlc3RlZFRyYW5zZmVycyAmJlxuICAgIHN1bW1hcnkuc3VnZ2VzdGVkVHJhbnNmZXJzLmxlbmd0aCA+IDAgJiZcbiAgICBzdW1tYXJ5LnN1Z2dlc3RlZFRyYW5zZmVycy5ldmVyeSgodCkgPT4gdC5pc1NldHRsZWQpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC02XCI+XG4gICAgICB7LyogVG9wIEhlYWRlciAmIFJlZnJlc2ggKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwIHRyYWNraW5nLXRpZ2h0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8Q2FsY3VsYXRvciBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtaW5kaWdvLTYwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj57dCgnc2V0dGxlbWVudC50aXRsZScsICdRdXnhur90IHRvw6FuIENodXnhur9uIMSRaScpfSAtIHtjdXJyZW50VHJpcC5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIHRleHQtc20gbXQtMC41XCI+XG4gICAgICAgICAgICBC4bqjbmcgdOG7lW5nIHPhuq9wIHPhu5EgZMawIGPDoSBuaMOibiB2w6AgxJHhu4EgeHXhuqV0IGNodXnhu4NuIGtob+G6o24gYsO5IHRy4burIHThu5FpIMawdSBuaOG6pXQuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIGljb249e1JlZnJlc2hDd30gb25DbGljaz17ZmV0Y2hTZXR0bGVtZW50U3VtbWFyeX0gaXNMb2FkaW5nPXtpc0xvYWRpbmd9PlxuICAgICAgICAgICAgVOG6o2kgbOG6oWlcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2Vycm9yICYmIDxBbGVydCB0eXBlPVwiZXJyb3JcIiBtZXNzYWdlPXtlcnJvcn0gb25DbG9zZT17KCkgPT4gc2V0RXJyb3IoJycpfSAvPn1cbiAgICAgIHtzdWNjZXNzTWVzc2FnZSAmJiA8QWxlcnQgdHlwZT1cInN1Y2Nlc3NcIiBtZXNzYWdlPXtzdWNjZXNzTWVzc2FnZX0gb25DbG9zZT17KCkgPT4gc2V0U3VjY2Vzc01lc3NhZ2UoJycpfSAvPn1cblxuICAgICAgey8qIENvbmdyYXR1bGF0aW9ucyBCYW5uZXIgd2hlbiB0cmlwIGlzIGZ1bGx5IHNldHRsZWQgJiBDTE9TRUQgKi99XG4gICAgICB7KGFsbFRyYW5zZmVyc1NldHRsZWQgfHwgc3VtbWFyeT8udHJpcFN0YXR1cyA9PT0gJ0NMT1NFRCcpICYmIChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNTAwIHRvLXRlYWwtNjAwIHRleHQtd2hpdGUgc2hhZG93LXhsIGJvcmRlci1ub25lXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctd2hpdGUvMjAgcm91bmRlZC0yeGwgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgPFBhcnR5UG9wcGVyIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYmxhY2sgdGV4dC13aGl0ZVwiPkNodXnhur9uIMSRaSDEkcOjIFF1eeG6v3QgdG/DoW4geG9uZyE8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtMTAwIHRleHQtc20gbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgVOG6pXQgY+G6oyBjw6FjIGtob+G6o24gY2h1eeG7g24gdGnhu4FuIGdp4buvYSBjw6FjIHRow6BuaCB2acOqbiDEkcOjIGhvw6BuIHThuqV0LiBUcuG6oW5nIHRow6FpIGNodXnhur9uIMSRaTogPHN0cm9uZz5DTE9TRUQgKMSQw6MgxJHDs25nKTwvc3Ryb25nPi5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBTZWN0aW9uIDE6IFVzZXIgQmFsYW5jZXMgU3VtbWFyeSBHcmlkL1RhYmxlICovfVxuICAgICAgPENhcmQ+XG4gICAgICAgIDxDYXJkSGVhZGVyXG4gICAgICAgICAgdGl0bGU9XCJC4bqjbmcgVOG7lW5nIHPhuq9wIFPhu5EgZMawIEPDoSBuaMOiblwiXG4gICAgICAgICAgc3VidGl0bGU9XCJT4buRIGTGsCA9ICjEkMOzbmcgcXXhu7kgKyDhu6huZyB0aeG7gW4gdHLhuqMgaOG7mSkgLSBDaGkgcGjDrSBjw6EgbmjDom4gcGjhuqNpIGNo4buLdVwiXG4gICAgICAgIC8+XG4gICAgICAgIDxDYXJkQm9keT5cbiAgICAgICAgICB7c3VtbWFyeT8uYmFsYW5jZXMgJiYgc3VtbWFyeS5iYWxhbmNlcy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC00XCI+XG4gICAgICAgICAgICAgIHtzdW1tYXJ5LmJhbGFuY2VzLm1hcCgoYikgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzUG9zaXRpdmUgPSBiLm5ldEJhbGFuY2UgPiAwO1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzTmVnYXRpdmUgPSBiLm5ldEJhbGFuY2UgPCAwO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAga2V5PXtiLnVzZXJJZH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC00IHJvdW5kZWQtMnhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgIGlzUG9zaXRpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAvNDAgYm9yZGVyLWVtZXJhbGQtMjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiBpc05lZ2F0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1yb3NlLTUwLzQwIGJvcmRlci1yb3NlLTIwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGJvcmRlci1zbGF0ZS0yMDAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBtYi0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWZ1bGwgYmctd2hpdGUgZm9udC1ib2xkIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIHNoYWRvdy14cyBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Yi5mdWxsTmFtZSA/IGIuZnVsbE5hbWUuY2hhckF0KDApIDogJ1UnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIHRleHQtc20gdHJ1bmNhdGVcIj57Yi5mdWxsTmFtZX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIHRydW5jYXRlXCI+e2IuZW1haWx9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogTmV0IEJhbGFuY2UgU3RhdHVzIEJhZGdlICovfVxuICAgICAgICAgICAgICAgICAgICAgIHtpc1Bvc2l0aXZlID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJwb3NpdGl2ZVwiPk5o4bqtbiBs4bqhaTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IGlzTmVnYXRpdmUgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm5lZ2F0aXZlXCI+xJDDs25nIHRow6ptPC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJjbG9zZWRcIj5Iw7JhIHRp4buBbjwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIEJyZWFrZG93biAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEgdGV4dC14cyBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwLzYwIHB0LTIuNSB0ZXh0LXNsYXRlLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPsSQw6MgxJHDs25nIHF14bu5Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57Zm9ybWF0Q3VycmVuY3koYi50b3RhbEZ1bmRDb250cmlidXRlZCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlThu7Eg4bupbmcgdHLhuqMgaOG7mTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2Zvcm1hdEN1cnJlbmN5KGIudG90YWxQYWlkT3V0T2ZQb2NrZXQpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5DaGkgcGjDrSBwaOG6o2kgY2jhu4t1Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KGIudG90YWxBbW91bnRPd2VkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIE5ldCBBbW91bnQgSGlnaGxpZ2h0ICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgcHQtMi41IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAvODAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDBcIj5T4buRIGTGsCByw7JuZzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtYmFzZSBmb250LWJsYWNrICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzUG9zaXRpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LWVtZXJhbGQtNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogaXNOZWdhdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ3RleHQtcm9zZS02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNQb3NpdGl2ZSA/ICcrJyA6ICcnfVxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KGIubmV0QmFsYW5jZSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTYgdGV4dC1zbGF0ZS01MDAgdGV4dC1zbVwiPkNoxrBhIGPDsyBk4buvIGxp4buHdSBz4buRIGTGsC48L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9DYXJkQm9keT5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIFNlY3Rpb24gMjogU3VnZ2VzdGVkIFRyYW5zZmVycyBMaXN0ICovfVxuICAgICAgPENhcmQ+XG4gICAgICAgIDxDYXJkSGVhZGVyXG4gICAgICAgICAgdGl0bGU9XCJEYW5oIHPDoWNoIENodXnhu4NuIGtob+G6o24gQsO5IHRy4burIMSQ4buBIHh14bqldFwiXG4gICAgICAgICAgc3VidGl0bGU9XCJUaHXhuq10IHRvw6FuIHThu7EgxJHhu5luZyB0w61uaCB0b8OhbiBz4buRIGzGsOG7o3QgY2h1eeG7g24gdGnhu4FuIHThu5FpIMawdSBuaOG6pXQgZ2nhu69hIGPDoWMgY8OhIG5ow6JuLlwiXG4gICAgICAgIC8+XG4gICAgICAgIDxDYXJkQm9keT5cbiAgICAgICAgICB7c3VtbWFyeT8uc3VnZ2VzdGVkVHJhbnNmZXJzICYmIHN1bW1hcnkuc3VnZ2VzdGVkVHJhbnNmZXJzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICB7c3VtbWFyeS5zdWdnZXN0ZWRUcmFuc2ZlcnMubWFwKCh0KSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAga2V5PXt0LmlkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgdC5pc1NldHRsZWRcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1zbGF0ZS01MCBib3JkZXItc2xhdGUtMjAwLzgwIG9wYWNpdHktNzUnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgYm9yZGVyLWluZGlnby0yMDAvODAgc2hhZG93LXhzIGhvdmVyOmJvcmRlci1pbmRpZ28tMzAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXNsYXRlLTEwMCBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPnt0LmZyb21Vc2VyTmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWluZGlnby02MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtODAwXCI+e3QudG9Vc2VyTmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1zZW1pYm9sZFwiPlPhu5EgdGnhu4FuIGPhuqduIGNodXnhu4NuOjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYmxhY2sgdGV4dC1pbmRpZ28tNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3kodC5hbW91bnQpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc206anVzdGlmeS1lbmQgZ2FwLTMgYm9yZGVyLXQgc206Ym9yZGVyLXQtMCBwdC0yIHNtOnB0LTAgYm9yZGVyLXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7dC5pc1NldHRsZWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvbmdvaW5nXCIgY2xhc3NOYW1lPVwiZ2FwLTEgcHgtMyBweS0xLjUgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgxJDDoyBob8OgbiB04bqldFxuICAgICAgICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInN1Y2Nlc3NcIlxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb249e0NoZWNrQ2lyY2xlMn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9hZGluZz17YWN0aW9uTG9hZGluZ0lkID09PSB0LmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ29tcGxldGVUcmFuc2Zlcih0LmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICDEkMOhbmggZOG6pXUgxJHDoyBjaHV54buDblxuICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTAgdGV4dC1zbGF0ZS01MDAgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LWVtZXJhbGQtNDAwIG14LWF1dG8gbWItMlwiIC8+XG4gICAgICAgICAgICAgIFThuqV0IGPhuqMgdGjDoG5oIHZpw6puIMSRw6MgaMOyYSB0aeG7gW4gaG/hurdjIGNoxrBhIGPDsyBnaWFvIGThu4tjaCBj4bqnbiBjaHV54buDbiBraG/huqNuLlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9DYXJkQm9keT5cbiAgICAgIDwvQ2FyZD5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=