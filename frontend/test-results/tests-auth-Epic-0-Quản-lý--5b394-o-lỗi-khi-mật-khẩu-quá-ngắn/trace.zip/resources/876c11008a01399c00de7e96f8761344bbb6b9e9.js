import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Button.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/Button.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
export const Button = ({ children, variant = "primary", size = "md", isLoading = false, disabled = false, icon: Icon, className = "", type = "button", onClick, ...props }) => {
	const baseStyles = "font-medium rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center justify-center gap-2 select-none min-h-[44px]";
	const variants = {
		primary: "bg-indigo-600 hover:bg-indigo-700 text-white focus:ring-indigo-500 shadow-sm shadow-indigo-200 active:scale-[0.98]",
		secondary: "bg-slate-800 hover:bg-slate-900 text-white focus:ring-slate-700 shadow-sm active:scale-[0.98]",
		outline: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 focus:ring-indigo-500 active:scale-[0.98]",
		ghost: "text-slate-600 hover:bg-slate-100 hover:text-slate-900 focus:ring-slate-400 active:scale-[0.98]",
		danger: "bg-rose-600 hover:bg-rose-700 text-white focus:ring-rose-500 shadow-sm shadow-rose-200 active:scale-[0.98]",
		success: "bg-emerald-600 hover:bg-emerald-700 text-white focus:ring-emerald-500 shadow-sm active:scale-[0.98]"
	};
	const sizes = {
		sm: "px-3 py-2 text-xs",
		md: "px-4 py-2.5 text-sm",
		lg: "px-6 py-3 text-base"
	};
	return /* @__PURE__ */ _jsxDEV("button", {
		type,
		disabled: disabled || isLoading,
		onClick,
		className: `${baseStyles} ${variants[variant] || variants.primary} ${sizes[size] || sizes.md} ${className}`,
		...props,
		children: [isLoading ? /* @__PURE__ */ _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin text-current" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 9
		}, this) : Icon ? /* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 9
		}, this) : null, /* @__PURE__ */ _jsxDEV("span", { children }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
};
_c = Button;
var _c;
$RefreshReg$(_c, "Button");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Button.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/Button.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/Button.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/Button.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZUFBZTs7O0FBRXhCLE9BQU8sTUFBTSxVQUFVLEVBQ3JCLFVBQ0EsVUFBVSxXQUNWLE9BQU8sTUFDUCxZQUFZLE9BQ1osV0FBVyxPQUNYLE1BQU0sTUFDTixZQUFZLElBQ1osT0FBTyxVQUNQLFNBQ0EsR0FBRyxZQUNDO0NBQ0osTUFBTSxhQUNKO0NBRUYsTUFBTSxXQUFXO0VBQ2YsU0FDRTtFQUNGLFdBQ0U7RUFDRixTQUNFO0VBQ0YsT0FDRTtFQUNGLFFBQ0U7RUFDRixTQUNFO0NBQ0o7Q0FFQSxNQUFNLFFBQVE7RUFDWixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7Q0FDTjtDQUVBLE9BQ0Usd0JBQUMsVUFBRDtFQUNRO0VBQ04sVUFBVSxZQUFZO0VBQ2I7RUFDVCxXQUFXLEdBQUcsV0FBVyxHQUFHLFNBQVMsWUFBWSxTQUFTLFFBQVEsR0FBRyxNQUFNLFNBQVMsTUFBTSxHQUFHLEdBQUc7RUFDaEcsR0FBSTtZQUxOLENBT0csWUFDQyx3QkFBQyxTQUFELEVBQVMsV0FBVSxvQ0FBcUM7Ozs7YUFDdEQsT0FDRix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7O2FBQ3pCLE1BQ0osd0JBQUMsUUFBRCxFQUFPLFNBQWU7Ozs7VUFDaEI7Ozs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkJ1dHRvbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExvYWRlcjIgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgY29uc3QgQnV0dG9uID0gKHtcbiAgY2hpbGRyZW4sXG4gIHZhcmlhbnQgPSAncHJpbWFyeScsXG4gIHNpemUgPSAnbWQnLFxuICBpc0xvYWRpbmcgPSBmYWxzZSxcbiAgZGlzYWJsZWQgPSBmYWxzZSxcbiAgaWNvbjogSWNvbixcbiAgY2xhc3NOYW1lID0gJycsXG4gIHR5cGUgPSAnYnV0dG9uJyxcbiAgb25DbGljayxcbiAgLi4ucHJvcHNcbn0pID0+IHtcbiAgY29uc3QgYmFzZVN0eWxlcyA9XG4gICAgJ2ZvbnQtbWVkaXVtIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1vZmZzZXQtMiBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgc2VsZWN0LW5vbmUgbWluLWgtWzQ0cHhdJztcblxuICBjb25zdCB2YXJpYW50cyA9IHtcbiAgICBwcmltYXJ5OlxuICAgICAgJ2JnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCB0ZXh0LXdoaXRlIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBzaGFkb3ctc20gc2hhZG93LWluZGlnby0yMDAgYWN0aXZlOnNjYWxlLVswLjk4XScsXG4gICAgc2Vjb25kYXJ5OlxuICAgICAgJ2JnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSBmb2N1czpyaW5nLXNsYXRlLTcwMCBzaGFkb3ctc20gYWN0aXZlOnNjYWxlLVswLjk4XScsXG4gICAgb3V0bGluZTpcbiAgICAgICdib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBiZy13aGl0ZSB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS01MCBmb2N1czpyaW5nLWluZGlnby01MDAgYWN0aXZlOnNjYWxlLVswLjk4XScsXG4gICAgZ2hvc3Q6XG4gICAgICAndGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMTAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGZvY3VzOnJpbmctc2xhdGUtNDAwIGFjdGl2ZTpzY2FsZS1bMC45OF0nLFxuICAgIGRhbmdlcjpcbiAgICAgICdiZy1yb3NlLTYwMCBob3ZlcjpiZy1yb3NlLTcwMCB0ZXh0LXdoaXRlIGZvY3VzOnJpbmctcm9zZS01MDAgc2hhZG93LXNtIHNoYWRvdy1yb3NlLTIwMCBhY3RpdmU6c2NhbGUtWzAuOThdJyxcbiAgICBzdWNjZXNzOlxuICAgICAgJ2JnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNzAwIHRleHQtd2hpdGUgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBzaGFkb3ctc20gYWN0aXZlOnNjYWxlLVswLjk4XScsXG4gIH07XG5cbiAgY29uc3Qgc2l6ZXMgPSB7XG4gICAgc206ICdweC0zIHB5LTIgdGV4dC14cycsXG4gICAgbWQ6ICdweC00IHB5LTIuNSB0ZXh0LXNtJyxcbiAgICBsZzogJ3B4LTYgcHktMyB0ZXh0LWJhc2UnLFxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgdHlwZT17dHlwZX1cbiAgICAgIGRpc2FibGVkPXtkaXNhYmxlZCB8fCBpc0xvYWRpbmd9XG4gICAgICBvbkNsaWNrPXtvbkNsaWNrfVxuICAgICAgY2xhc3NOYW1lPXtgJHtiYXNlU3R5bGVzfSAke3ZhcmlhbnRzW3ZhcmlhbnRdIHx8IHZhcmlhbnRzLnByaW1hcnl9ICR7c2l6ZXNbc2l6ZV0gfHwgc2l6ZXMubWR9ICR7Y2xhc3NOYW1lfWB9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAge2lzTG9hZGluZyA/IChcbiAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW4gdGV4dC1jdXJyZW50XCIgLz5cbiAgICAgICkgOiBJY29uID8gKFxuICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICkgOiBudWxsfVxuICAgICAgPHNwYW4+e2NoaWxkcmVufTwvc3Bhbj5cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn07XG4iXX0=