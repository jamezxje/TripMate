import { create } from "/node_modules/.vite/deps/zustand.js?v=8d54bd4c";
export const useTripStore = create((set) => ({
	currentTrip: null,
	trips: [],
	isLoading: false,
	error: null,
	setCurrentTrip: (trip) => {
		if (trip?.id) {
			localStorage.setItem("activeTripId", trip.id);
		}
		set({
			currentTrip: trip,
			error: null
		});
	},
	setTrips: (trips) => set({
		trips,
		error: null
	}),
	setIsLoading: (isLoading) => set({ isLoading }),
	setError: (error) => set({
		error,
		isLoading: false
	}),
	clearCurrentTrip: () => {
		localStorage.removeItem("activeTripId");
		set({ currentTrip: null });
	}
}));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBRXZCLE9BQU8sTUFBTSxlQUFlLFFBQVEsU0FBUztDQUMzQyxhQUFhO0NBQ2IsT0FBTyxDQUFDO0NBQ1IsV0FBVztDQUNYLE9BQU87Q0FFUCxpQkFBaUIsU0FBUztFQUN4QixJQUFJLE1BQU0sSUFBSTtHQUNaLGFBQWEsUUFBUSxnQkFBZ0IsS0FBSyxFQUFFO0VBQzlDO0VBQ0EsSUFBSTtHQUFFLGFBQWE7R0FBTSxPQUFPO0VBQUssQ0FBQztDQUN4QztDQUVBLFdBQVcsVUFBVSxJQUFJO0VBQUU7RUFBTyxPQUFPO0NBQUssQ0FBQztDQUUvQyxlQUFlLGNBQWMsSUFBSSxFQUFFLFVBQVUsQ0FBQztDQUU5QyxXQUFXLFVBQVUsSUFBSTtFQUFFO0VBQU8sV0FBVztDQUFNLENBQUM7Q0FFcEQsd0JBQXdCO0VBQ3RCLGFBQWEsV0FBVyxjQUFjO0VBQ3RDLElBQUksRUFBRSxhQUFhLEtBQUssQ0FBQztDQUMzQjtBQUNGLEVBQUUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidXNlVHJpcFN0b3JlLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZSB9IGZyb20gJ3p1c3RhbmQnO1xuXG5leHBvcnQgY29uc3QgdXNlVHJpcFN0b3JlID0gY3JlYXRlKChzZXQpID0+ICh7XG4gIGN1cnJlbnRUcmlwOiBudWxsLFxuICB0cmlwczogW10sXG4gIGlzTG9hZGluZzogZmFsc2UsXG4gIGVycm9yOiBudWxsLFxuXG4gIHNldEN1cnJlbnRUcmlwOiAodHJpcCkgPT4ge1xuICAgIGlmICh0cmlwPy5pZCkge1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2FjdGl2ZVRyaXBJZCcsIHRyaXAuaWQpO1xuICAgIH1cbiAgICBzZXQoeyBjdXJyZW50VHJpcDogdHJpcCwgZXJyb3I6IG51bGwgfSk7XG4gIH0sXG5cbiAgc2V0VHJpcHM6ICh0cmlwcykgPT4gc2V0KHsgdHJpcHMsIGVycm9yOiBudWxsIH0pLFxuXG4gIHNldElzTG9hZGluZzogKGlzTG9hZGluZykgPT4gc2V0KHsgaXNMb2FkaW5nIH0pLFxuXG4gIHNldEVycm9yOiAoZXJyb3IpID0+IHNldCh7IGVycm9yLCBpc0xvYWRpbmc6IGZhbHNlIH0pLFxuXG4gIGNsZWFyQ3VycmVudFRyaXA6ICgpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnYWN0aXZlVHJpcElkJyk7XG4gICAgc2V0KHsgY3VycmVudFRyaXA6IG51bGwgfSk7XG4gIH0sXG59KSk7XG4iXX0=