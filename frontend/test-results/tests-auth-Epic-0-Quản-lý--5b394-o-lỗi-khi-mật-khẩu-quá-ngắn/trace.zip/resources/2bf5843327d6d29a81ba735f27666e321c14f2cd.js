import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Input.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/Input.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
export const Input = ({ label, error, icon: Icon, className = "", id, type = "text", placeholder, value, onChange, disabled = false, ...props }) => {
	const inputId = id || (label ? label.toLowerCase().replace(/\s+/g, "-") : undefined);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "w-full flex flex-col gap-1.5",
		children: [
			label && /* @__PURE__ */ _jsxDEV("label", {
				htmlFor: inputId,
				className: "text-xs font-semibold text-slate-700 uppercase tracking-wider",
				children: label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative flex items-center",
				children: [Icon && /* @__PURE__ */ _jsxDEV("div", {
					className: "absolute left-3.5 text-slate-400 pointer-events-none",
					children: /* @__PURE__ */ _jsxDEV(Icon, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					id: inputId,
					type,
					value,
					onChange,
					disabled,
					placeholder,
					className: `w-full min-h-[44px] rounded-xl border bg-white px-3.5 text-sm text-slate-900 transition-all duration-200 placeholder:text-slate-400 focus:outline-none focus:ring-2 disabled:bg-slate-100 disabled:text-slate-400 ${Icon ? "pl-11" : ""} ${error ? "border-rose-400 focus:border-rose-500 focus:ring-rose-200" : "border-slate-200 focus:border-indigo-500 focus:ring-indigo-100 hover:border-slate-300"} ${className}`,
					...props
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-rose-500 font-medium pl-0.5",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
};
_c = Input;
var _c;
$RefreshReg$(_c, "Input");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Input.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/Input.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/Input.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/Input.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFFbEIsT0FBTyxNQUFNLFNBQVMsRUFDcEIsT0FDQSxPQUNBLE1BQU0sTUFDTixZQUFZLElBQ1osSUFDQSxPQUFPLFFBQ1AsYUFDQSxPQUNBLFVBQ0EsV0FBVyxPQUNYLEdBQUcsWUFDQztDQUNKLE1BQU0sVUFBVSxPQUFPLFFBQVEsTUFBTSxZQUFZLENBQUMsQ0FBQyxRQUFRLFFBQVEsR0FBRyxJQUFJO0NBRTFFLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNHLFNBQ0Msd0JBQUMsU0FBRDtJQUFPLFNBQVM7SUFBUyxXQUFVO2NBQ2hDO0dBQ0k7Ozs7O0dBRVQsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNHLFFBQ0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztJQUN4Qjs7OztjQUVQLHdCQUFDLFNBQUQ7S0FDRSxJQUFJO0tBQ0U7S0FDQztLQUNHO0tBQ0E7S0FDRztLQUNiLFdBQVcscU5BQ1QsT0FBTyxVQUFVLEdBQ2xCLEdBQ0MsUUFDSSw4REFDQSx3RkFDTCxHQUFHO0tBQ0osR0FBSTtJQUNMOzs7O1lBQ0U7Ozs7OztHQUNKLFNBQVMsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBNEM7R0FBUzs7Ozs7RUFDekU7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIklucHV0LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5leHBvcnQgY29uc3QgSW5wdXQgPSAoe1xuICBsYWJlbCxcbiAgZXJyb3IsXG4gIGljb246IEljb24sXG4gIGNsYXNzTmFtZSA9ICcnLFxuICBpZCxcbiAgdHlwZSA9ICd0ZXh0JyxcbiAgcGxhY2Vob2xkZXIsXG4gIHZhbHVlLFxuICBvbkNoYW5nZSxcbiAgZGlzYWJsZWQgPSBmYWxzZSxcbiAgLi4ucHJvcHNcbn0pID0+IHtcbiAgY29uc3QgaW5wdXRJZCA9IGlkIHx8IChsYWJlbCA/IGxhYmVsLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXFxzKy9nLCAnLScpIDogdW5kZWZpbmVkKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggZmxleC1jb2wgZ2FwLTEuNVwiPlxuICAgICAge2xhYmVsICYmIChcbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2lucHV0SWR9IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICB7bGFiZWx9XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICApfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICB7SWNvbiAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMuNSB0ZXh0LXNsYXRlLTQwMCBwb2ludGVyLWV2ZW50cy1ub25lXCI+XG4gICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgaWQ9e2lucHV0SWR9XG4gICAgICAgICAgdHlwZT17dHlwZX1cbiAgICAgICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICAgICAgb25DaGFuZ2U9e29uQ2hhbmdlfVxuICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICBwbGFjZWhvbGRlcj17cGxhY2Vob2xkZXJ9XG4gICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIG1pbi1oLVs0NHB4XSByb3VuZGVkLXhsIGJvcmRlciBiZy13aGl0ZSBweC0zLjUgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgcGxhY2Vob2xkZXI6dGV4dC1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBkaXNhYmxlZDpiZy1zbGF0ZS0xMDAgZGlzYWJsZWQ6dGV4dC1zbGF0ZS00MDAgJHtcbiAgICAgICAgICAgIEljb24gPyAncGwtMTEnIDogJydcbiAgICAgICAgICB9ICR7XG4gICAgICAgICAgICBlcnJvclxuICAgICAgICAgICAgICA/ICdib3JkZXItcm9zZS00MDAgZm9jdXM6Ym9yZGVyLXJvc2UtNTAwIGZvY3VzOnJpbmctcm9zZS0yMDAnXG4gICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0yMDAgZm9jdXM6Ym9yZGVyLWluZGlnby01MDAgZm9jdXM6cmluZy1pbmRpZ28tMTAwIGhvdmVyOmJvcmRlci1zbGF0ZS0zMDAnXG4gICAgICAgICAgfSAke2NsYXNzTmFtZX1gfVxuICAgICAgICAgIHsuLi5wcm9wc31cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1yb3NlLTUwMCBmb250LW1lZGl1bSBwbC0wLjVcIj57ZXJyb3J9PC9wPn1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=