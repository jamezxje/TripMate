import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/MainLayout.jsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=aa845dd0";
import { Navbar } from "/src/components/layout/Navbar.jsx";
import { NavigationTabs } from "/src/components/layout/NavigationTabs.jsx";
import { MobileNavigation } from "/src/components/layout/MobileNavigation.jsx";
import { useTripStore } from "/src/store/useTripStore.js";
import { tripApi } from "/src/features/trips/tripApi.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/layout/MainLayout.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const MainLayout = () => {
	_s();
	const { currentTrip, setCurrentTrip } = useTripStore();
	useEffect(() => {
		const initActiveTrip = async () => {
			const activeTripId = localStorage.getItem("activeTripId");
			if (activeTripId && !currentTrip) {
				try {
					const res = await tripApi.getTripDetail(activeTripId);
					if (res.data) {
						setCurrentTrip(res.data);
					}
				} catch (err) {
					console.error("Failed to restore active trip", err);
					localStorage.removeItem("activeTripId");
				}
			}
		};
		initActiveTrip();
	}, [currentTrip, setCurrentTrip]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 pb-16 md:pb-0",
		children: [
			/* @__PURE__ */ _jsxDEV(Navbar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(NavigationTabs, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8",
				children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(MobileNavigation, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
};
_s(MainLayout, "FtjfTrtkJbE6/GfnI5WuYrKhECs=", false, function() {
	return [useTripStore];
});
_c = MainLayout;
var _c;
$RefreshReg$(_c, "MainLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/MainLayout.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/layout/MainLayout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/layout/MainLayout.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/layout/MainLayout.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGlCQUFpQjtBQUNqQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsZUFBZTs7OztBQUV4QixPQUFPLE1BQU0sbUJBQW1COztDQUM5QixNQUFNLEVBQUUsYUFBYSxtQkFBbUIsYUFBYTtDQUVyRCxnQkFBZ0I7RUFDZCxNQUFNLGlCQUFpQixZQUFZO0dBQ2pDLE1BQU0sZUFBZSxhQUFhLFFBQVEsY0FBYztHQUN4RCxJQUFJLGdCQUFnQixDQUFDLGFBQWE7SUFDaEMsSUFBSTtLQUNGLE1BQU0sTUFBTSxNQUFNLFFBQVEsY0FBYyxZQUFZO0tBQ3BELElBQUksSUFBSSxNQUFNO01BQ1osZUFBZSxJQUFJLElBQUk7S0FDekI7SUFDRixTQUFTLEtBQUs7S0FDWixRQUFRLE1BQU0saUNBQWlDLEdBQUc7S0FDbEQsYUFBYSxXQUFXLGNBQWM7SUFDeEM7R0FDRjtFQUNGO0VBQ0EsZUFBZTtDQUNqQixHQUFHLENBQUMsYUFBYSxjQUFjLENBQUM7Q0FFaEMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsUUFBRCxDQUFTOzs7OztHQUNULHdCQUFDLGdCQUFELENBQWlCOzs7OztHQUVqQix3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUNkLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7R0FDTDs7Ozs7R0FFTix3QkFBQyxrQkFBRCxDQUFtQjs7Ozs7RUFDaEI7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1haW5MYXlvdXQuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBPdXRsZXQgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IE5hdmJhciB9IGZyb20gJy4vTmF2YmFyJztcbmltcG9ydCB7IE5hdmlnYXRpb25UYWJzIH0gZnJvbSAnLi9OYXZpZ2F0aW9uVGFicyc7XG5pbXBvcnQgeyBNb2JpbGVOYXZpZ2F0aW9uIH0gZnJvbSAnLi9Nb2JpbGVOYXZpZ2F0aW9uJztcbmltcG9ydCB7IHVzZVRyaXBTdG9yZSB9IGZyb20gJy4uLy4uL3N0b3JlL3VzZVRyaXBTdG9yZSc7XG5pbXBvcnQgeyB0cmlwQXBpIH0gZnJvbSAnLi4vLi4vZmVhdHVyZXMvdHJpcHMvdHJpcEFwaSc7XG5cbmV4cG9ydCBjb25zdCBNYWluTGF5b3V0ID0gKCkgPT4ge1xuICBjb25zdCB7IGN1cnJlbnRUcmlwLCBzZXRDdXJyZW50VHJpcCB9ID0gdXNlVHJpcFN0b3JlKCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBpbml0QWN0aXZlVHJpcCA9IGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGFjdGl2ZVRyaXBJZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdhY3RpdmVUcmlwSWQnKTtcbiAgICAgIGlmIChhY3RpdmVUcmlwSWQgJiYgIWN1cnJlbnRUcmlwKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdHJpcEFwaS5nZXRUcmlwRGV0YWlsKGFjdGl2ZVRyaXBJZCk7XG4gICAgICAgICAgaWYgKHJlcy5kYXRhKSB7XG4gICAgICAgICAgICBzZXRDdXJyZW50VHJpcChyZXMuZGF0YSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHJlc3RvcmUgYWN0aXZlIHRyaXBcIiwgZXJyKTtcbiAgICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnYWN0aXZlVHJpcElkJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIGluaXRBY3RpdmVUcmlwKCk7XG4gIH0sIFtjdXJyZW50VHJpcCwgc2V0Q3VycmVudFRyaXBdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTUwIGZsZXggZmxleC1jb2wgZm9udC1zYW5zIHRleHQtc2xhdGUtOTAwIHBiLTE2IG1kOnBiLTBcIj5cbiAgICAgIDxOYXZiYXIgLz5cbiAgICAgIDxOYXZpZ2F0aW9uVGFicyAvPlxuXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LTEgbWF4LXctN3hsIHctZnVsbCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04IHB5LTYgc206cHktOFwiPlxuICAgICAgICA8T3V0bGV0IC8+XG4gICAgICA8L21haW4+XG5cbiAgICAgIDxNb2JpbGVOYXZpZ2F0aW9uIC8+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19