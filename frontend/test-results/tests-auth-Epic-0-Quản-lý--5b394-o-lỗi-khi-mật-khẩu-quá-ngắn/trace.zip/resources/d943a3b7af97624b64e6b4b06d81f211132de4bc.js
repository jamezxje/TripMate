import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/funds/FundSummaryView.jsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Wallet, Plus, ArrowDownCircle, ArrowUpCircle, RefreshCw } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import { Card, CardHeader, CardBody } from "/src/components/Card.jsx";
import { Button } from "/src/components/Button.jsx";
import { Table } from "/src/components/Table.jsx";
import { Alert } from "/src/components/Alert.jsx";
import { FundContributionModal } from "/src/features/funds/FundContributionModal.jsx";
import { fundApi } from "/src/features/funds/fundApi.js";
import { useTripStore } from "/src/store/useTripStore.js";
import { formatCurrency, formatDate } from "/src/utils/formatters.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/funds/FundSummaryView.jsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const FundSummaryView = () => {
	_s();
	const { t } = useTranslation();
	const { currentTrip } = useTripStore();
	const [summary, setSummary] = useState(null);
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState("");
	const [isModalOpen, setIsModalOpen] = useState(false);
	const fetchFundSummary = useCallback(async () => {
		if (!currentTrip?.id) return;
		setIsLoading(true);
		setError("");
		try {
			const res = await fundApi.getFundSummary(currentTrip.id);
			if (res.data) {
				setSummary(res.data);
			}
		} catch (err) {
			setError(err.message || "Không thể tải thông tin quỹ chung");
		} finally {
			setIsLoading(false);
		}
	}, [currentTrip?.id]);
	useEffect(() => {
		fetchFundSummary();
	}, [fetchFundSummary]);
	if (!currentTrip) {
		return /* @__PURE__ */ _jsxDEV(Card, {
			className: "text-center py-12",
			children: [
				/* @__PURE__ */ _jsxDEV(Wallet, { className: "w-12 h-12 text-slate-300 mx-auto mb-3" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-lg font-bold text-slate-800",
					children: "Chưa chọn Chuyến đi"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-slate-500 text-sm mt-1",
					children: "Vui lòng chọn hoặc tạo mới chuyến đi ở trang danh sách để quản lý quỹ chung."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Wallet, { className: "w-7 h-7 text-indigo-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
						t("nav.fund", "Quỹ nhóm"),
						" - ",
						currentTrip.name
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-slate-500 text-sm mt-0.5",
					children: "Theo dõi tiến độ đóng quỹ và quản lý số dư thu chi quỹ chung."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						icon: RefreshCw,
						onClick: fetchFundSummary,
						isLoading,
						children: "Tải lại"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						icon: Plus,
						onClick: () => setIsModalOpen(true),
						children: "Đóng tiền quỹ"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV(Alert, {
				type: "error",
				message: error,
				onClose: () => setError("")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV(Card, {
						className: "bg-gradient-to-br from-emerald-50 to-teal-50/40 border-emerald-200/60",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-bold uppercase tracking-wider text-emerald-600",
								children: "Tổng quỹ đã thu"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("h3", {
								className: "text-2xl font-black text-emerald-900 mt-1",
								children: formatCurrency(summary?.totalCollected || 0)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-emerald-100/80 rounded-2xl text-emerald-700",
								children: /* @__PURE__ */ _jsxDEV(ArrowDownCircle, { className: "w-6 h-6" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 91,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Card, {
						className: "bg-gradient-to-br from-rose-50 to-orange-50/40 border-rose-200/60",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-bold uppercase tracking-wider text-rose-600",
								children: "Đã chi từ quỹ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("h3", {
								className: "text-2xl font-black text-rose-900 mt-1",
								children: formatCurrency(summary?.totalSpentFromFund || 0)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-rose-100/80 rounded-2xl text-rose-700",
								children: /* @__PURE__ */ _jsxDEV(ArrowUpCircle, { className: "w-6 h-6" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Card, {
						className: "bg-gradient-to-br from-indigo-50 to-violet-50/40 border-indigo-200/60",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-bold uppercase tracking-wider text-indigo-600",
								children: "Số dư quỹ hiện tại"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("h3", {
								className: "text-2xl font-black text-indigo-950 mt-1",
								children: formatCurrency(summary?.currentBalance || 0)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-indigo-100/80 rounded-2xl text-indigo-700",
								children: /* @__PURE__ */ _jsxDEV(Wallet, { className: "w-6 h-6" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 121,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Card, { children: [/* @__PURE__ */ _jsxDEV(CardHeader, {
				title: "Lịch sử Đóng quỹ",
				subtitle: "Danh sách chi tiết tiền đóng quỹ của các thành viên trong chuyến đi."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 129,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(CardBody, { children: summary?.contributions && summary.contributions.length > 0 ? /* @__PURE__ */ _jsxDEV(Table, {
				headers: [
					"Thành viên",
					"Số tiền đóng",
					"Thời gian đóng"
				],
				children: summary.contributions.map((c) => /* @__PURE__ */ _jsxDEV("tr", {
					className: "hover:bg-slate-50/80 transition-colors",
					children: [
						/* @__PURE__ */ _jsxDEV("td", {
							className: "px-4 py-3.5 font-bold text-slate-800",
							children: c.userName
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "px-4 py-3.5 font-extrabold text-emerald-600",
							children: ["+", formatCurrency(c.amount)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "px-4 py-3.5 text-xs text-slate-500",
							children: formatDate(c.createdAt)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 19
						}, this)
					]
				}, c.id, true, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 17
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 135,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV("p", {
				className: "text-center py-8 text-slate-500 text-sm",
				children: "Chưa có khoản đóng quỹ nào được ghi nhận. Bấm \"Đóng tiền quỹ\" để thêm mới!"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 147,
				columnNumber: 13
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 133,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 128,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(FundContributionModal, {
				isOpen: isModalOpen,
				onClose: () => setIsModalOpen(false),
				onSuccess: fetchFundSummary
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 5
	}, this);
};
_s(FundSummaryView, "VYlDMVsIEyfXNpN+55Ynl8U/MM0=", false, function() {
	return [useTranslation, useTripStore];
});
_c = FundSummaryView;
var _c;
$RefreshReg$(_c, "FundSummaryView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/funds/FundSummaryView.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/funds/FundSummaryView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/funds/FundSummaryView.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/funds/FundSummaryView.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsVUFBVSxtQkFBbUI7QUFDeEQsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxRQUFRLE1BQU0saUJBQWlCLGVBQWUsaUJBQWlCO0FBQ3hFLFNBQVMsTUFBTSxZQUFZLGdCQUFnQjtBQUMzQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsYUFBYTtBQUN0QixTQUFTLDZCQUE2QjtBQUN0QyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxnQkFBZ0Isa0JBQWtCOzs7O0FBRTNDLE9BQU8sTUFBTSx3QkFBd0I7O0NBQ25DLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FDN0IsTUFBTSxFQUFFLGdCQUFnQixhQUFhO0NBQ3JDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUVwRCxNQUFNLG1CQUFtQixZQUFZLFlBQVk7RUFDL0MsSUFBSSxDQUFDLGFBQWEsSUFBSTtFQUN0QixhQUFhLElBQUk7RUFDakIsU0FBUyxFQUFFO0VBRVgsSUFBSTtHQUNGLE1BQU0sTUFBTSxNQUFNLFFBQVEsZUFBZSxZQUFZLEVBQUU7R0FDdkQsSUFBSSxJQUFJLE1BQU07SUFDWixXQUFXLElBQUksSUFBSTtHQUNyQjtFQUNGLFNBQVMsS0FBSztHQUNaLFNBQVMsSUFBSSxXQUFXLG1DQUFtQztFQUM3RCxVQUFVO0dBQ1IsYUFBYSxLQUFLO0VBQ3BCO0NBQ0YsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO0NBRXBCLGdCQUFnQjtFQUNkLGlCQUFpQjtDQUNuQixHQUFHLENBQUMsZ0JBQWdCLENBQUM7Q0FFckIsSUFBSSxDQUFDLGFBQWE7RUFDaEIsT0FDRSx3QkFBQyxNQUFEO0dBQU0sV0FBVTthQUFoQjtJQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHdDQUF5Qzs7Ozs7SUFDM0Qsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBbUM7SUFBdUI7Ozs7O0lBQ3hFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCO0lBRXhDOzs7OztHQUNDOzs7Ozs7Q0FFVjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDBCQUEyQjs7OztlQUM3Qyx3QkFBQyxRQUFEO01BQU8sRUFBRSxZQUFZLFVBQVU7TUFBRTtNQUFJLFlBQVk7S0FBVzs7OzthQUMxRDs7Ozs7Y0FDSix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFnQztJQUUxQzs7OztZQUNBOzs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBUSxTQUFRO01BQVUsTUFBTTtNQUFXLFNBQVM7TUFBNkI7Z0JBQVc7S0FFcEY7Ozs7ZUFDUix3QkFBQyxRQUFEO01BQVEsTUFBTTtNQUFNLGVBQWUsZUFBZSxJQUFJO2dCQUFHO0tBRWpEOzs7O2FBQ0w7Ozs7O1lBQ0Y7Ozs7OztHQUVKLFNBQVMsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBUSxTQUFTO0lBQU8sZUFBZSxTQUFTLEVBQUU7R0FBSTs7Ozs7R0FHNUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUVFLHdCQUFDLE1BQUQ7TUFBTSxXQUFVO2dCQUNkLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE4RDtPQUFrQjs7OztpQkFDN0Ysd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsZUFBZSxTQUFTLGtCQUFrQixDQUFDO09BQzFDOzs7O2VBQ0Q7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsaUJBQUQsRUFBaUIsV0FBVSxVQUFXOzs7OztPQUNuQzs7OztlQUNGOzs7Ozs7S0FDRDs7Ozs7S0FHTix3QkFBQyxNQUFEO01BQU0sV0FBVTtnQkFDZCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBMkQ7T0FBZ0I7Ozs7aUJBQ3hGLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLGVBQWUsU0FBUyxzQkFBc0IsQ0FBQztPQUM5Qzs7OztlQUNEOzs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLGVBQUQsRUFBZSxXQUFVLFVBQVc7Ozs7O09BQ2pDOzs7O2VBQ0Y7Ozs7OztLQUNEOzs7OztLQUdOLHdCQUFDLE1BQUQ7TUFBTSxXQUFVO2dCQUNkLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE2RDtPQUFxQjs7OztpQkFDL0Ysd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsZUFBZSxTQUFTLGtCQUFrQixDQUFDO09BQzFDOzs7O2VBQ0Q7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7T0FDMUI7Ozs7ZUFDRjs7Ozs7O0tBQ0Q7Ozs7O0lBQ0g7Ozs7OztHQUdMLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxZQUFEO0lBQ0UsT0FBTTtJQUNOLFVBQVM7R0FDVjs7OzthQUNELHdCQUFDLFVBQUQsWUFDRyxTQUFTLGlCQUFpQixRQUFRLGNBQWMsU0FBUyxJQUN4RCx3QkFBQyxPQUFEO0lBQU8sU0FBUztLQUFDO0tBQWM7S0FBZ0I7SUFBZ0I7Y0FDNUQsUUFBUSxjQUFjLEtBQUssTUFDMUIsd0JBQUMsTUFBRDtLQUFlLFdBQVU7ZUFBekI7TUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBd0MsRUFBRTtNQUFhOzs7OztNQUNyRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUE0RCxLQUN4RCxlQUFlLEVBQUUsTUFBTSxDQUN2Qjs7Ozs7O01BQ0osd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXNDLFdBQVcsRUFBRSxTQUFTO01BQU07Ozs7O0tBQzlFO09BTkssRUFBRTs7OztXQU1QLENBQ0w7R0FDSTs7OztjQUVQLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQTBDO0dBRXBEOzs7O1lBRUc7Ozs7V0FDTjs7Ozs7R0FHTix3QkFBQyx1QkFBRDtJQUNFLFFBQVE7SUFDUixlQUFlLGVBQWUsS0FBSztJQUNuQyxXQUFXO0dBQ1o7Ozs7O0VBQ0U7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkZ1bmRTdW1tYXJ5Vmlldy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tICdyZWFjdC1pMThuZXh0JztcbmltcG9ydCB7IFdhbGxldCwgUGx1cywgQXJyb3dEb3duQ2lyY2xlLCBBcnJvd1VwQ2lyY2xlLCBSZWZyZXNoQ3cgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgQ2FyZCwgQ2FyZEhlYWRlciwgQ2FyZEJvZHkgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0NhcmQnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9CdXR0b24nO1xuaW1wb3J0IHsgVGFibGUgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL1RhYmxlJztcbmltcG9ydCB7IEFsZXJ0IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9BbGVydCc7XG5pbXBvcnQgeyBGdW5kQ29udHJpYnV0aW9uTW9kYWwgfSBmcm9tICcuL0Z1bmRDb250cmlidXRpb25Nb2RhbCc7XG5pbXBvcnQgeyBmdW5kQXBpIH0gZnJvbSAnLi9mdW5kQXBpJztcbmltcG9ydCB7IHVzZVRyaXBTdG9yZSB9IGZyb20gJy4uLy4uL3N0b3JlL3VzZVRyaXBTdG9yZSc7XG5pbXBvcnQgeyBmb3JtYXRDdXJyZW5jeSwgZm9ybWF0RGF0ZSB9IGZyb20gJy4uLy4uL3V0aWxzL2Zvcm1hdHRlcnMnO1xuXG5leHBvcnQgY29uc3QgRnVuZFN1bW1hcnlWaWV3ID0gKCkgPT4ge1xuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XG4gIGNvbnN0IHsgY3VycmVudFRyaXAgfSA9IHVzZVRyaXBTdG9yZSgpO1xuICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtpc01vZGFsT3Blbiwgc2V0SXNNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGZldGNoRnVuZFN1bW1hcnkgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFjdXJyZW50VHJpcD8uaWQpIHJldHVybjtcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IoJycpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZ1bmRBcGkuZ2V0RnVuZFN1bW1hcnkoY3VycmVudFRyaXAuaWQpO1xuICAgICAgaWYgKHJlcy5kYXRhKSB7XG4gICAgICAgIHNldFN1bW1hcnkocmVzLmRhdGEpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgJ0tow7RuZyB0aOG7gyB04bqjaSB0aMO0bmcgdGluIHF14bu5IGNodW5nJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9LCBbY3VycmVudFRyaXA/LmlkXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBmZXRjaEZ1bmRTdW1tYXJ5KCk7XG4gIH0sIFtmZXRjaEZ1bmRTdW1tYXJ5XSk7XG5cbiAgaWYgKCFjdXJyZW50VHJpcCkge1xuICAgIHJldHVybiAoXG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxuICAgICAgICA8V2FsbGV0IGNsYXNzTmFtZT1cInctMTIgaC0xMiB0ZXh0LXNsYXRlLTMwMCBteC1hdXRvIG1iLTNcIiAvPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5DaMawYSBjaOG7jW4gQ2h1eeG6v24gxJFpPC9oMz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBtdC0xXCI+XG4gICAgICAgICAgVnVpIGzDsm5nIGNo4buNbiBob+G6t2MgdOG6oW8gbeG7m2kgY2h1eeG6v24gxJFpIOG7nyB0cmFuZyBkYW5oIHPDoWNoIMSR4buDIHF14bqjbiBsw70gcXXhu7kgY2h1bmcuXG4gICAgICAgIDwvcD5cbiAgICAgIDwvQ2FyZD5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTZcIj5cbiAgICAgIHsvKiBIZWFkZXIgJiBRdWljayBBY3Rpb24gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwIHRyYWNraW5nLXRpZ2h0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8V2FsbGV0IGNsYXNzTmFtZT1cInctNyBoLTcgdGV4dC1pbmRpZ28tNjAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPnt0KCduYXYuZnVuZCcsICdRdeG7uSBuaMOzbScpfSAtIHtjdXJyZW50VHJpcC5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIHRleHQtc20gbXQtMC41XCI+XG4gICAgICAgICAgICBUaGVvIGTDtWkgdGnhur9uIMSR4buZIMSRw7NuZyBxdeG7uSB2w6AgcXXhuqNuIGzDvSBz4buRIGTGsCB0aHUgY2hpIHF14bu5IGNodW5nLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgaWNvbj17UmVmcmVzaEN3fSBvbkNsaWNrPXtmZXRjaEZ1bmRTdW1tYXJ5fSBpc0xvYWRpbmc9e2lzTG9hZGluZ30+XG4gICAgICAgICAgICBU4bqjaSBs4bqhaVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDxCdXR0b24gaWNvbj17UGx1c30gb25DbGljaz17KCkgPT4gc2V0SXNNb2RhbE9wZW4odHJ1ZSl9PlxuICAgICAgICAgICAgxJDDs25nIHRp4buBbiBxdeG7uVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3IgJiYgPEFsZXJ0IHR5cGU9XCJlcnJvclwiIG1lc3NhZ2U9e2Vycm9yfSBvbkNsb3NlPXsoKSA9PiBzZXRFcnJvcignJyl9IC8+fVxuXG4gICAgICB7LyogRnVuZCBNZXRyaWNzIERhc2hib2FyZCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtNFwiPlxuICAgICAgICB7LyogVG90YWwgQ29sbGVjdGVkICovfVxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWVtZXJhbGQtNTAgdG8tdGVhbC01MC80MCBib3JkZXItZW1lcmFsZC0yMDAvNjBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZW1lcmFsZC02MDBcIj5U4buVbmcgcXXhu7kgxJHDoyB0aHU8L3A+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtZW1lcmFsZC05MDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShzdW1tYXJ5Py50b3RhbENvbGxlY3RlZCB8fCAwKX1cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctZW1lcmFsZC0xMDAvODAgcm91bmRlZC0yeGwgdGV4dC1lbWVyYWxkLTcwMFwiPlxuICAgICAgICAgICAgICA8QXJyb3dEb3duQ2lyY2xlIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7LyogVG90YWwgU3BlbnQgRnJvbSBGdW5kICovfVxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXJvc2UtNTAgdG8tb3JhbmdlLTUwLzQwIGJvcmRlci1yb3NlLTIwMC82MFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1yb3NlLTYwMFwiPsSQw6MgY2hpIHThu6sgcXXhu7k8L3A+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtcm9zZS05MDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShzdW1tYXJ5Py50b3RhbFNwZW50RnJvbUZ1bmQgfHwgMCl9XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXJvc2UtMTAwLzgwIHJvdW5kZWQtMnhsIHRleHQtcm9zZS03MDBcIj5cbiAgICAgICAgICAgICAgPEFycm93VXBDaXJjbGUgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIHsvKiBDdXJyZW50IEZ1bmQgQmFsYW5jZSAqL31cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1pbmRpZ28tNTAgdG8tdmlvbGV0LTUwLzQwIGJvcmRlci1pbmRpZ28tMjAwLzYwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWluZGlnby02MDBcIj5T4buRIGTGsCBxdeG7uSBoaeG7h24gdOG6oWk8L3A+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtaW5kaWdvLTk1MCBtdC0xXCI+XG4gICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KHN1bW1hcnk/LmN1cnJlbnRCYWxhbmNlIHx8IDApfVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1pbmRpZ28tMTAwLzgwIHJvdW5kZWQtMnhsIHRleHQtaW5kaWdvLTcwMFwiPlxuICAgICAgICAgICAgICA8V2FsbGV0IGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQ29udHJpYnV0aW9ucyBIaXN0b3J5IFRhYmxlICovfVxuICAgICAgPENhcmQ+XG4gICAgICAgIDxDYXJkSGVhZGVyXG4gICAgICAgICAgdGl0bGU9XCJM4buLY2ggc+G7rSDEkMOzbmcgcXXhu7lcIlxuICAgICAgICAgIHN1YnRpdGxlPVwiRGFuaCBzw6FjaCBjaGkgdGnhur90IHRp4buBbiDEkcOzbmcgcXXhu7kgY+G7p2EgY8OhYyB0aMOgbmggdmnDqm4gdHJvbmcgY2h1eeG6v24gxJFpLlwiXG4gICAgICAgIC8+XG4gICAgICAgIDxDYXJkQm9keT5cbiAgICAgICAgICB7c3VtbWFyeT8uY29udHJpYnV0aW9ucyAmJiBzdW1tYXJ5LmNvbnRyaWJ1dGlvbnMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgIDxUYWJsZSBoZWFkZXJzPXtbJ1Row6BuaCB2acOqbicsICdT4buRIHRp4buBbiDEkcOzbmcnLCAnVGjhu51pIGdpYW4gxJHDs25nJ119PlxuICAgICAgICAgICAgICB7c3VtbWFyeS5jb250cmlidXRpb25zLm1hcCgoYykgPT4gKFxuICAgICAgICAgICAgICAgIDx0ciBrZXk9e2MuaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTUwLzgwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zLjUgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+e2MudXNlck5hbWV9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMuNSBmb250LWV4dHJhYm9sZCB0ZXh0LWVtZXJhbGQtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICt7Zm9ybWF0Q3VycmVuY3koYy5hbW91bnQpfVxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMuNSB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+e2Zvcm1hdERhdGUoYy5jcmVhdGVkQXQpfTwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L1RhYmxlPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04IHRleHQtc2xhdGUtNTAwIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgQ2jGsGEgY8OzIGtob+G6o24gxJHDs25nIHF14bu5IG7DoG8gxJHGsOG7o2MgZ2hpIG5o4bqtbi4gQuG6pW0gXCLEkMOzbmcgdGnhu4FuIHF14bu5XCIgxJHhu4MgdGjDqm0gbeG7m2khXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9DYXJkQm9keT5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIE1vZGFsICovfVxuICAgICAgPEZ1bmRDb250cmlidXRpb25Nb2RhbFxuICAgICAgICBpc09wZW49e2lzTW9kYWxPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJc01vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgIG9uU3VjY2Vzcz17ZmV0Y2hGdW5kU3VtbWFyeX1cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19