import { create } from "/node_modules/.vite/deps/zustand.js?v=8d54bd4c";
import api from "/src/services/api.js";
const getInitialUser = () => {
	try {
		const storedUser = localStorage.getItem("currentUser");
		return storedUser ? JSON.parse(storedUser) : null;
	} catch (e) {
		return null;
	}
};
const initialToken = localStorage.getItem("token") || null;
const initialUser = getInitialUser();
export const useUserStore = create((set, get) => ({
	currentUser: initialUser,
	token: initialToken,
	isAuthenticated: !!initialToken,
	setAuth: (token, user) => {
		if (token) {
			localStorage.setItem("token", token);
		}
		if (user) {
			localStorage.setItem("currentUser", JSON.stringify(user));
			if (user.id) {
				localStorage.setItem("userId", String(user.id));
			}
		}
		set({
			token,
			currentUser: user,
			isAuthenticated: !!token
		});
	},
	clearAuth: () => {
		localStorage.removeItem("token");
		localStorage.removeItem("currentUser");
		localStorage.removeItem("userId");
		set({
			currentUser: null,
			token: null,
			isAuthenticated: false
		});
	},
	logout: () => {
		get().clearAuth();
	},
	setCurrentUser: (user) => {
		if (user) {
			localStorage.setItem("currentUser", JSON.stringify(user));
			if (user.id) {
				localStorage.setItem("userId", String(user.id));
			}
		}
		set({ currentUser: user });
	},
	fetchCurrentUser: async () => {
		try {
			const response = await api.get("/auth/me");
			if (response && response.data) {
				const user = response.data;
				localStorage.setItem("currentUser", JSON.stringify(user));
				if (user.id) {
					localStorage.setItem("userId", String(user.id));
				}
				set({
					currentUser: user,
					isAuthenticated: true
				});
			}
		} catch (error) {
			console.error("Lỗi nạp thông tin người dùng:", error);
			get().clearAuth();
		}
	},
	updateUserRole: (role) => set((state) => {
		const updatedUser = state.currentUser ? {
			...state.currentUser,
			role
		} : null;
		if (updatedUser) {
			localStorage.setItem("currentUser", JSON.stringify(updatedUser));
		}
		return { currentUser: updatedUser };
	})
}));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLE9BQU8sU0FBUztBQUVoQixNQUFNLHVCQUF1QjtDQUMzQixJQUFJO0VBQ0YsTUFBTSxhQUFhLGFBQWEsUUFBUSxhQUFhO0VBQ3JELE9BQU8sYUFBYSxLQUFLLE1BQU0sVUFBVSxJQUFJO0NBQy9DLFNBQVMsR0FBRztFQUNWLE9BQU87Q0FDVDtBQUNGO0FBRUEsTUFBTSxlQUFlLGFBQWEsUUFBUSxPQUFPLEtBQUs7QUFDdEQsTUFBTSxjQUFjLGVBQWU7QUFFbkMsT0FBTyxNQUFNLGVBQWUsUUFBUSxLQUFLLFNBQVM7Q0FDaEQsYUFBYTtDQUNiLE9BQU87Q0FDUCxpQkFBaUIsQ0FBQyxDQUFDO0NBRW5CLFVBQVUsT0FBTyxTQUFTO0VBQ3hCLElBQUksT0FBTztHQUNULGFBQWEsUUFBUSxTQUFTLEtBQUs7RUFDckM7RUFDQSxJQUFJLE1BQU07R0FDUixhQUFhLFFBQVEsZUFBZSxLQUFLLFVBQVUsSUFBSSxDQUFDO0dBQ3hELElBQUksS0FBSyxJQUFJO0lBQ1gsYUFBYSxRQUFRLFVBQVUsT0FBTyxLQUFLLEVBQUUsQ0FBQztHQUNoRDtFQUNGO0VBQ0EsSUFBSTtHQUFFO0dBQU8sYUFBYTtHQUFNLGlCQUFpQixDQUFDLENBQUM7RUFBTSxDQUFDO0NBQzVEO0NBRUEsaUJBQWlCO0VBQ2YsYUFBYSxXQUFXLE9BQU87RUFDL0IsYUFBYSxXQUFXLGFBQWE7RUFDckMsYUFBYSxXQUFXLFFBQVE7RUFDaEMsSUFBSTtHQUFFLGFBQWE7R0FBTSxPQUFPO0dBQU0saUJBQWlCO0VBQU0sQ0FBQztDQUNoRTtDQUVBLGNBQWM7RUFDWixJQUFJLENBQUMsQ0FBQyxVQUFVO0NBQ2xCO0NBRUEsaUJBQWlCLFNBQVM7RUFDeEIsSUFBSSxNQUFNO0dBQ1IsYUFBYSxRQUFRLGVBQWUsS0FBSyxVQUFVLElBQUksQ0FBQztHQUN4RCxJQUFJLEtBQUssSUFBSTtJQUNYLGFBQWEsUUFBUSxVQUFVLE9BQU8sS0FBSyxFQUFFLENBQUM7R0FDaEQ7RUFDRjtFQUNBLElBQUksRUFBRSxhQUFhLEtBQUssQ0FBQztDQUMzQjtDQUVBLGtCQUFrQixZQUFZO0VBQzVCLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxJQUFJLElBQUksVUFBVTtHQUN6QyxJQUFJLFlBQVksU0FBUyxNQUFNO0lBQzdCLE1BQU0sT0FBTyxTQUFTO0lBQ3RCLGFBQWEsUUFBUSxlQUFlLEtBQUssVUFBVSxJQUFJLENBQUM7SUFDeEQsSUFBSSxLQUFLLElBQUk7S0FDWCxhQUFhLFFBQVEsVUFBVSxPQUFPLEtBQUssRUFBRSxDQUFDO0lBQ2hEO0lBQ0EsSUFBSTtLQUFFLGFBQWE7S0FBTSxpQkFBaUI7SUFBSyxDQUFDO0dBQ2xEO0VBQ0YsU0FBUyxPQUFPO0dBQ2QsUUFBUSxNQUFNLGlDQUFpQyxLQUFLO0dBQ3BELElBQUksQ0FBQyxDQUFDLFVBQVU7RUFDbEI7Q0FDRjtDQUVBLGlCQUFpQixTQUNmLEtBQUssVUFBVTtFQUNiLE1BQU0sY0FBYyxNQUFNLGNBQWM7R0FBRSxHQUFHLE1BQU07R0FBYTtFQUFLLElBQUk7RUFDekUsSUFBSSxhQUFhO0dBQ2YsYUFBYSxRQUFRLGVBQWUsS0FBSyxVQUFVLFdBQVcsQ0FBQztFQUNqRTtFQUNBLE9BQU8sRUFBRSxhQUFhLFlBQVk7Q0FDcEMsQ0FBQztBQUNMLEVBQUUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidXNlVXNlclN0b3JlLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZSB9IGZyb20gJ3p1c3RhbmQnO1xuaW1wb3J0IGFwaSBmcm9tICcuLi9zZXJ2aWNlcy9hcGknO1xuXG5jb25zdCBnZXRJbml0aWFsVXNlciA9ICgpID0+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBzdG9yZWRVc2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2N1cnJlbnRVc2VyJyk7XG4gICAgcmV0dXJuIHN0b3JlZFVzZXIgPyBKU09OLnBhcnNlKHN0b3JlZFVzZXIpIDogbnVsbDtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59O1xuXG5jb25zdCBpbml0aWFsVG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKSB8fCBudWxsO1xuY29uc3QgaW5pdGlhbFVzZXIgPSBnZXRJbml0aWFsVXNlcigpO1xuXG5leHBvcnQgY29uc3QgdXNlVXNlclN0b3JlID0gY3JlYXRlKChzZXQsIGdldCkgPT4gKHtcbiAgY3VycmVudFVzZXI6IGluaXRpYWxVc2VyLFxuICB0b2tlbjogaW5pdGlhbFRva2VuLFxuICBpc0F1dGhlbnRpY2F0ZWQ6ICEhaW5pdGlhbFRva2VuLFxuXG4gIHNldEF1dGg6ICh0b2tlbiwgdXNlcikgPT4ge1xuICAgIGlmICh0b2tlbikge1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Rva2VuJywgdG9rZW4pO1xuICAgIH1cbiAgICBpZiAodXNlcikge1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2N1cnJlbnRVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcikpO1xuICAgICAgaWYgKHVzZXIuaWQpIHtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3VzZXJJZCcsIFN0cmluZyh1c2VyLmlkKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHNldCh7IHRva2VuLCBjdXJyZW50VXNlcjogdXNlciwgaXNBdXRoZW50aWNhdGVkOiAhIXRva2VuIH0pO1xuICB9LFxuXG4gIGNsZWFyQXV0aDogKCkgPT4ge1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd0b2tlbicpO1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdjdXJyZW50VXNlcicpO1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd1c2VySWQnKTtcbiAgICBzZXQoeyBjdXJyZW50VXNlcjogbnVsbCwgdG9rZW46IG51bGwsIGlzQXV0aGVudGljYXRlZDogZmFsc2UgfSk7XG4gIH0sXG5cbiAgbG9nb3V0OiAoKSA9PiB7XG4gICAgZ2V0KCkuY2xlYXJBdXRoKCk7XG4gIH0sXG5cbiAgc2V0Q3VycmVudFVzZXI6ICh1c2VyKSA9PiB7XG4gICAgaWYgKHVzZXIpIHtcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdjdXJyZW50VXNlcicsIEpTT04uc3RyaW5naWZ5KHVzZXIpKTtcbiAgICAgIGlmICh1c2VyLmlkKSB7XG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd1c2VySWQnLCBTdHJpbmcodXNlci5pZCkpO1xuICAgICAgfVxuICAgIH1cbiAgICBzZXQoeyBjdXJyZW50VXNlcjogdXNlciB9KTtcbiAgfSxcblxuICBmZXRjaEN1cnJlbnRVc2VyOiBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldCgnL2F1dGgvbWUnKTtcbiAgICAgIGlmIChyZXNwb25zZSAmJiByZXNwb25zZS5kYXRhKSB7XG4gICAgICAgIGNvbnN0IHVzZXIgPSByZXNwb25zZS5kYXRhO1xuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnY3VycmVudFVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKSk7XG4gICAgICAgIGlmICh1c2VyLmlkKSB7XG4gICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3VzZXJJZCcsIFN0cmluZyh1c2VyLmlkKSk7XG4gICAgICAgIH1cbiAgICAgICAgc2V0KHsgY3VycmVudFVzZXI6IHVzZXIsIGlzQXV0aGVudGljYXRlZDogdHJ1ZSB9KTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignTOG7l2kgbuG6oXAgdGjDtG5nIHRpbiBuZ8aw4budaSBkw7luZzonLCBlcnJvcik7XG4gICAgICBnZXQoKS5jbGVhckF1dGgoKTtcbiAgICB9XG4gIH0sXG5cbiAgdXBkYXRlVXNlclJvbGU6IChyb2xlKSA9PlxuICAgIHNldCgoc3RhdGUpID0+IHtcbiAgICAgIGNvbnN0IHVwZGF0ZWRVc2VyID0gc3RhdGUuY3VycmVudFVzZXIgPyB7IC4uLnN0YXRlLmN1cnJlbnRVc2VyLCByb2xlIH0gOiBudWxsO1xuICAgICAgaWYgKHVwZGF0ZWRVc2VyKSB7XG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdjdXJyZW50VXNlcicsIEpTT04uc3RyaW5naWZ5KHVwZGF0ZWRVc2VyKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4geyBjdXJyZW50VXNlcjogdXBkYXRlZFVzZXIgfTtcbiAgICB9KSxcbn0pKTtcbiJdfQ==