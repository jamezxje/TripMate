import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Alert.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { AlertCircle, CheckCircle2, Info, AlertTriangle, X } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/Alert.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
export const Alert = ({ type = "info", title, message, onClose, className = "" }) => {
	const configs = {
		info: {
			bg: "bg-sky-50 border-sky-200 text-sky-800",
			icon: Info,
			iconColor: "text-sky-500"
		},
		success: {
			bg: "bg-emerald-50 border-emerald-200 text-emerald-800",
			icon: CheckCircle2,
			iconColor: "text-emerald-500"
		},
		warning: {
			bg: "bg-amber-50 border-amber-200 text-amber-800",
			icon: AlertTriangle,
			iconColor: "text-amber-500"
		},
		error: {
			bg: "bg-rose-50 border-rose-200 text-rose-800",
			icon: AlertCircle,
			iconColor: "text-rose-500"
		}
	};
	const config = configs[type] || configs.info;
	const IconComponent = config.icon;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `p-4 rounded-xl border flex items-start gap-3 transition-all ${config.bg} ${className}`,
		children: [
			/* @__PURE__ */ _jsxDEV(IconComponent, { className: `w-5 h-5 shrink-0 mt-0.5 ${config.iconColor}` }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 text-sm",
				children: [title && /* @__PURE__ */ _jsxDEV("h4", {
					className: "font-bold mb-0.5",
					children: title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 19
				}, this), message && /* @__PURE__ */ _jsxDEV("p", {
					className: "opacity-90",
					children: message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 7
			}, this),
			onClose && /* @__PURE__ */ _jsxDEV("button", {
				onClick: onClose,
				className: "p-1 hover:opacity-75 rounded-lg transition-opacity min-h-[32px] min-w-[32px] flex items-center justify-center",
				children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 5
	}, this);
};
_c = Alert;
var _c;
$RefreshReg$(_c, "Alert");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Alert.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/Alert.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/Alert.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/Alert.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsYUFBYSxjQUFjLE1BQU0sZUFBZSxTQUFTOzs7QUFFbEUsT0FBTyxNQUFNLFNBQVMsRUFBRSxPQUFPLFFBQVEsT0FBTyxTQUFTLFNBQVMsWUFBWSxTQUFTO0NBQ25GLE1BQU0sVUFBVTtFQUNkLE1BQU07R0FDSixJQUFJO0dBQ0osTUFBTTtHQUNOLFdBQVc7RUFDYjtFQUNBLFNBQVM7R0FDUCxJQUFJO0dBQ0osTUFBTTtHQUNOLFdBQVc7RUFDYjtFQUNBLFNBQVM7R0FDUCxJQUFJO0dBQ0osTUFBTTtHQUNOLFdBQVc7RUFDYjtFQUNBLE9BQU87R0FDTCxJQUFJO0dBQ0osTUFBTTtHQUNOLFdBQVc7RUFDYjtDQUNGO0NBRUEsTUFBTSxTQUFTLFFBQVEsU0FBUyxRQUFRO0NBQ3hDLE1BQU0sZ0JBQWdCLE9BQU87Q0FFN0IsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVywrREFBK0QsT0FBTyxHQUFHLEdBQUc7WUFBNUY7R0FDRSx3QkFBQyxlQUFELEVBQWUsV0FBVywyQkFBMkIsT0FBTyxZQUFjOzs7OztHQUMxRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0csU0FBUyx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFvQjtJQUFVOzs7O2NBQ3JELFdBQVcsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYztJQUFXOzs7O1lBQy9DOzs7Ozs7R0FDSixXQUNDLHdCQUFDLFVBQUQ7SUFDRSxTQUFTO0lBQ1QsV0FBVTtjQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0dBQ2xCOzs7OztFQUVQOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBbGVydC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEFsZXJ0Q2lyY2xlLCBDaGVja0NpcmNsZTIsIEluZm8sIEFsZXJ0VHJpYW5nbGUsIFggfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgY29uc3QgQWxlcnQgPSAoeyB0eXBlID0gJ2luZm8nLCB0aXRsZSwgbWVzc2FnZSwgb25DbG9zZSwgY2xhc3NOYW1lID0gJycgfSkgPT4ge1xuICBjb25zdCBjb25maWdzID0ge1xuICAgIGluZm86IHtcbiAgICAgIGJnOiAnYmctc2t5LTUwIGJvcmRlci1za3ktMjAwIHRleHQtc2t5LTgwMCcsXG4gICAgICBpY29uOiBJbmZvLFxuICAgICAgaWNvbkNvbG9yOiAndGV4dC1za3ktNTAwJyxcbiAgICB9LFxuICAgIHN1Y2Nlc3M6IHtcbiAgICAgIGJnOiAnYmctZW1lcmFsZC01MCBib3JkZXItZW1lcmFsZC0yMDAgdGV4dC1lbWVyYWxkLTgwMCcsXG4gICAgICBpY29uOiBDaGVja0NpcmNsZTIsXG4gICAgICBpY29uQ29sb3I6ICd0ZXh0LWVtZXJhbGQtNTAwJyxcbiAgICB9LFxuICAgIHdhcm5pbmc6IHtcbiAgICAgIGJnOiAnYmctYW1iZXItNTAgYm9yZGVyLWFtYmVyLTIwMCB0ZXh0LWFtYmVyLTgwMCcsXG4gICAgICBpY29uOiBBbGVydFRyaWFuZ2xlLFxuICAgICAgaWNvbkNvbG9yOiAndGV4dC1hbWJlci01MDAnLFxuICAgIH0sXG4gICAgZXJyb3I6IHtcbiAgICAgIGJnOiAnYmctcm9zZS01MCBib3JkZXItcm9zZS0yMDAgdGV4dC1yb3NlLTgwMCcsXG4gICAgICBpY29uOiBBbGVydENpcmNsZSxcbiAgICAgIGljb25Db2xvcjogJ3RleHQtcm9zZS01MDAnLFxuICAgIH0sXG4gIH07XG5cbiAgY29uc3QgY29uZmlnID0gY29uZmlnc1t0eXBlXSB8fCBjb25maWdzLmluZm87XG4gIGNvbnN0IEljb25Db21wb25lbnQgPSBjb25maWcuaWNvbjtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtgcC00IHJvdW5kZWQteGwgYm9yZGVyIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgdHJhbnNpdGlvbi1hbGwgJHtjb25maWcuYmd9ICR7Y2xhc3NOYW1lfWB9PlxuICAgICAgPEljb25Db21wb25lbnQgY2xhc3NOYW1lPXtgdy01IGgtNSBzaHJpbmstMCBtdC0wLjUgJHtjb25maWcuaWNvbkNvbG9yfWB9IC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSB0ZXh0LXNtXCI+XG4gICAgICAgIHt0aXRsZSAmJiA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIG1iLTAuNVwiPnt0aXRsZX08L2g0Pn1cbiAgICAgICAge21lc3NhZ2UgJiYgPHAgY2xhc3NOYW1lPVwib3BhY2l0eS05MFwiPnttZXNzYWdlfTwvcD59XG4gICAgICA8L2Rpdj5cbiAgICAgIHtvbkNsb3NlICYmIChcbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgY2xhc3NOYW1lPVwicC0xIGhvdmVyOm9wYWNpdHktNzUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLW9wYWNpdHkgbWluLWgtWzMycHhdIG1pbi13LVszMnB4XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiXG4gICAgICAgID5cbiAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==