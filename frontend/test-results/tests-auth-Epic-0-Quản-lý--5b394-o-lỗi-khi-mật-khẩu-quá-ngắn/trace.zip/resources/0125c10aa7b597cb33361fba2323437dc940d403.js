import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/expenses/SplitExpenseForm.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { DollarSign, FileText, UserCheck, Wallet, CheckSquare, Square, AlertTriangle } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import { Input } from "/src/components/Input.jsx";
import { Button } from "/src/components/Button.jsx";
import { Alert } from "/src/components/Alert.jsx";
import { expenseApi } from "/src/features/expenses/expenseApi.js";
import { useUserStore } from "/src/store/useUserStore.js";
import { useTripStore } from "/src/store/useTripStore.js";
import { formatCurrency } from "/src/utils/formatters.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/expenses/SplitExpenseForm.jsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const SplitExpenseForm = ({ onSuccess, onCancel }) => {
	_s();
	const { t } = useTranslation();
	const { currentUser } = useUserStore();
	const { currentTrip } = useTripStore();
	// Find user role in current trip
	const currentMember = currentTrip?.members?.find((m) => String(m.userId) === String(currentUser?.id));
	const isLeader = currentMember?.role === "LEADER";
	// Form State
	const [description, setDescription] = useState("");
	const [amount, setAmount] = useState("");
	const [isPaidByFund, setIsPaidByFund] = useState(false);
	const [payerId, setPayerId] = useState(currentUser?.id || "");
	const [splitType, setSplitType] = useState("EQUAL");
	// Participants selection & amounts
	const [selectedUserIds, setSelectedUserIds] = useState(currentTrip?.members?.map((m) => m.userId) || []);
	const [exactAmounts, setExactAmounts] = useState({});
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState("");
	// Handle participant checkbox toggle
	const toggleParticipant = (userId) => {
		if (selectedUserIds.includes(userId)) {
			if (selectedUserIds.length === 1) return;
			setSelectedUserIds(selectedUserIds.filter((id) => id !== userId));
		} else {
			setSelectedUserIds([...selectedUserIds, userId]);
		}
	};
	// Handle exact amount input for a user
	const handleExactAmountChange = (userId, val) => {
		setExactAmounts((prev) => ({
			...prev,
			[userId]: val
		}));
	};
	// Live calculation for validation
	const numAmount = parseFloat(amount) || 0;
	const numParticipants = selectedUserIds.length;
	const totalExactSum = selectedUserIds.reduce((sum, id) => {
		const val = parseFloat(exactAmounts[id]) || 0;
		return sum + val;
	}, 0);
	const isExactSumMatching = splitType === "EXACT_AMOUNT" ? Math.abs(totalExactSum - numAmount) < .01 : true;
	const exactDiff = totalExactSum - numAmount;
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!description.trim()) {
			setError("Vui lòng nhập mô tả khoản chi");
			return;
		}
		if (numAmount <= 0) {
			setError("Số tiền chi phải lớn hơn 0");
			return;
		}
		if (selectedUserIds.length === 0) {
			setError("Phải có ít nhất 1 thành viên tham gia chia tiền");
			return;
		}
		if (splitType === "EXACT_AMOUNT" && !isExactSumMatching) {
			setError("Tổng tiền chia cho từng người không khớp với tổng hóa đơn");
			return;
		}
		setIsLoading(true);
		setError("");
		try {
			const splits = selectedUserIds.map((userId) => ({
				userId,
				amountOwed: splitType === "EXACT_AMOUNT" ? parseFloat(exactAmounts[userId]) || 0 : null
			}));
			const payload = {
				tripId: currentTrip.id,
				description: description.trim(),
				amount: numAmount,
				isPaidByFund: isLeader ? isPaidByFund : false,
				payerId: isLeader && isPaidByFund ? null : Number(payerId),
				splitType,
				splits
			};
			await expenseApi.createExpense(payload);
			if (onSuccess) onSuccess();
		} catch (err) {
			setError(err.message || "Tạo khoản chi thất bại");
		} finally {
			setIsLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: handleSubmit,
		className: "flex flex-col gap-5",
		children: [
			error && /* @__PURE__ */ _jsxDEV(Alert, {
				type: "error",
				message: error,
				onClose: () => setError("")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 123,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ _jsxDEV(Input, {
					label: "Mô tả khoản chi",
					placeholder: "Ví dụ: Tiền phòng KS, Ăn tối...",
					value: description,
					onChange: (e) => setDescription(e.target.value),
					icon: FileText,
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Input, {
					label: "Tổng số tiền (VND)",
					type: "number",
					placeholder: "Ví dụ: 300000...",
					value: amount,
					onChange: (e) => setAmount(e.target.value),
					icon: DollarSign,
					step: "1000",
					min: "1000",
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 135,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 126,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex flex-col gap-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs font-bold text-slate-700 uppercase tracking-wider",
						children: "Người thanh toán (Payer)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 11
					}, this), isLeader && /* @__PURE__ */ _jsxDEV("label", {
						className: "inline-flex items-center gap-2 cursor-pointer select-none",
						children: [/* @__PURE__ */ _jsxDEV("input", {
							type: "checkbox",
							checked: isPaidByFund,
							onChange: (e) => {
								setIsPaidByFund(e.target.checked);
								if (e.target.checked) setPayerId("");
								else setPayerId(currentUser?.id || "");
							},
							className: "w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-indigo-700 flex items-center gap-1",
							children: [/* @__PURE__ */ _jsxDEV(Wallet, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 17
							}, this), " Dùng tiền Quỹ chung"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 150,
					columnNumber: 9
				}, this), !isPaidByFund ? /* @__PURE__ */ _jsxDEV("div", {
					className: "relative flex items-center",
					children: [/* @__PURE__ */ _jsxDEV(UserCheck, { className: "absolute left-3.5 w-5 h-5 text-slate-400 pointer-events-none" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 178,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						value: payerId,
						onChange: (e) => setPayerId(e.target.value),
						disabled: !isLeader,
						className: "w-full min-h-[44px] rounded-xl border border-slate-200 bg-white pl-11 pr-4 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-100 disabled:bg-slate-100 disabled:text-slate-500",
						children: currentTrip?.members?.map((m) => /* @__PURE__ */ _jsxDEV("option", {
							value: m.userId,
							children: [
								m.fullName,
								" ",
								m.userId === currentUser?.id ? "(Chính bạn)" : ""
							]
						}, m.userId, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 177,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "p-3 bg-indigo-50 border border-indigo-200/80 rounded-xl text-xs font-semibold text-indigo-800 flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Wallet, { className: "w-4 h-4 text-indigo-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 194,
						columnNumber: 13
					}, this), "Khoản chi này sẽ được trừ trực tiếp từ số dư Quỹ chung của nhóm."]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 193,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 149,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
				className: "text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2 block",
				children: "Hình thức chia tiền"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 202,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setSplitType("EQUAL"),
					className: `py-2 text-xs font-bold rounded-lg transition-all min-h-[40px] ${splitType === "EQUAL" ? "bg-white text-indigo-700 shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
					children: "Chia đều (EQUAL)"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 206,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setSplitType("EXACT_AMOUNT"),
					className: `py-2 text-xs font-bold rounded-lg transition-all min-h-[40px] ${splitType === "EXACT_AMOUNT" ? "bg-white text-indigo-700 shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
					children: "Chia số tiền cụ thể (EXACT)"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 217,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 205,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 201,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs font-semibold text-slate-700 uppercase tracking-wider",
					children: [
						"Người tham gia chịu tiền (",
						selectedUserIds.length,
						"/",
						currentTrip?.members?.length || 0,
						")"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 233,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col gap-2 max-h-60 overflow-y-auto p-1",
					children: currentTrip?.members?.map((m) => {
						const isSelected = selectedUserIds.includes(m.userId);
						const equalShare = splitType === "EQUAL" && isSelected && numParticipants > 0 ? numAmount / numParticipants : 0;
						return /* @__PURE__ */ _jsxDEV("div", {
							onClick: () => toggleParticipant(m.userId),
							className: `p-3 rounded-xl border flex items-center justify-between gap-3 cursor-pointer transition-all ${isSelected ? "bg-indigo-50/50 border-indigo-200 text-slate-900" : "bg-white border-slate-200/80 text-slate-400 opacity-60"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [isSelected ? /* @__PURE__ */ _jsxDEV(CheckSquare, { className: "w-5 h-5 text-indigo-600 shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 21
								}, this) : /* @__PURE__ */ _jsxDEV(Square, { className: "w-5 h-5 text-slate-300 shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-bold",
									children: m.fullName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 261,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 255,
								columnNumber: 17
							}, this), isSelected && /* @__PURE__ */ _jsxDEV("div", { children: splitType === "EQUAL" ? /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-extrabold text-indigo-600",
								children: formatCurrency(equalShare)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 268,
								columnNumber: 23
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1",
								onClick: (e) => e.stopPropagation(),
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "number",
									placeholder: "0",
									value: exactAmounts[m.userId] || "",
									onChange: (e) => handleExactAmountChange(m.userId, e.target.value),
									className: "w-28 min-h-[36px] px-2 py-1 text-right text-xs font-bold rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-100"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 273,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-slate-500",
									children: "đ"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 280,
									columnNumber: 25
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 272,
								columnNumber: 23
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 266,
								columnNumber: 19
							}, this)]
						}, m.userId, true, {
							fileName: _jsxFileName,
							lineNumber: 246,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 237,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 232,
				columnNumber: 7
			}, this),
			splitType === "EXACT_AMOUNT" && numAmount > 0 && /* @__PURE__ */ _jsxDEV("div", { children: !isExactSumMatching ? /* @__PURE__ */ _jsxDEV(Alert, {
				type: "warning",
				title: "Tổng tiền chia không khớp với hóa đơn!",
				message: `Tổng tiền đã chia: ${formatCurrency(totalExactSum)} / Hóa đơn: ${formatCurrency(numAmount)} (Lệch ${formatCurrency(Math.abs(exactDiff))})`
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 295,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV(Alert, {
				type: "success",
				message: `Tổng tiền chia (${formatCurrency(totalExactSum)}) đã khớp hoàn toàn với hóa đơn!`
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 303,
				columnNumber: 13
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 293,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex justify-end gap-3 mt-2",
				children: [/* @__PURE__ */ _jsxDEV(Button, {
					variant: "outline",
					onClick: onCancel,
					disabled: isLoading,
					children: t("common.cancel", "Hủy")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 313,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					type: "submit",
					isLoading,
					disabled: splitType === "EXACT_AMOUNT" && !isExactSumMatching,
					children: t("common.save", "Lưu khoản chi")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 312,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 122,
		columnNumber: 5
	}, this);
};
_s(SplitExpenseForm, "ghiZwbYDEWS9rNHjT6OxYEf4FGU=", false, function() {
	return [
		useTranslation,
		useUserStore,
		useTripStore
	];
});
_c = SplitExpenseForm;
var _c;
$RefreshReg$(_c, "SplitExpenseForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/expenses/SplitExpenseForm.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/expenses/SplitExpenseForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/expenses/SplitExpenseForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/expenses/SplitExpenseForm.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsWUFBWSxVQUFVLFdBQVcsUUFBUSxhQUFhLFFBQVEscUJBQXFCO0FBQzVGLFNBQVMsYUFBYTtBQUN0QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsc0JBQXNCOzs7O0FBRS9CLE9BQU8sTUFBTSxvQkFBb0IsRUFBRSxXQUFXLGVBQWU7O0NBQzNELE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FDN0IsTUFBTSxFQUFFLGdCQUFnQixhQUFhO0NBQ3JDLE1BQU0sRUFBRSxnQkFBZ0IsYUFBYTs7Q0FHckMsTUFBTSxnQkFBZ0IsYUFBYSxTQUFTLE1BQ3pDLE1BQU0sT0FBTyxFQUFFLE1BQU0sTUFBTSxPQUFPLGFBQWEsRUFBRSxDQUNwRDtDQUNBLE1BQU0sV0FBVyxlQUFlLFNBQVM7O0NBR3pDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEVBQUU7Q0FDdkMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsYUFBYSxNQUFNLEVBQUU7Q0FDNUQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsT0FBTzs7Q0FHbEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FDNUMsYUFBYSxTQUFTLEtBQUssTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDLENBQ2pEO0NBQ0EsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsQ0FBQyxDQUFDO0NBRW5ELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7O0NBR3JDLE1BQU0scUJBQXFCLFdBQVc7RUFDcEMsSUFBSSxnQkFBZ0IsU0FBUyxNQUFNLEdBQUc7R0FDcEMsSUFBSSxnQkFBZ0IsV0FBVyxHQUFHO0dBQ2xDLG1CQUFtQixnQkFBZ0IsUUFBUSxPQUFPLE9BQU8sTUFBTSxDQUFDO0VBQ2xFLE9BQU87R0FDTCxtQkFBbUIsQ0FBQyxHQUFHLGlCQUFpQixNQUFNLENBQUM7RUFDakQ7Q0FDRjs7Q0FHQSxNQUFNLDJCQUEyQixRQUFRLFFBQVE7RUFDL0MsaUJBQWlCLFVBQVU7R0FDekIsR0FBRztJQUNGLFNBQVM7RUFDWixFQUFFO0NBQ0o7O0NBR0EsTUFBTSxZQUFZLFdBQVcsTUFBTSxLQUFLO0NBQ3hDLE1BQU0sa0JBQWtCLGdCQUFnQjtDQUV4QyxNQUFNLGdCQUFnQixnQkFBZ0IsUUFBUSxLQUFLLE9BQU87RUFDeEQsTUFBTSxNQUFNLFdBQVcsYUFBYSxHQUFHLEtBQUs7RUFDNUMsT0FBTyxNQUFNO0NBQ2YsR0FBRyxDQUFDO0NBRUosTUFBTSxxQkFDSixjQUFjLGlCQUFpQixLQUFLLElBQUksZ0JBQWdCLFNBQVMsSUFBSSxNQUFPO0NBRTlFLE1BQU0sWUFBWSxnQkFBZ0I7Q0FFbEMsTUFBTSxlQUFlLE9BQU8sTUFBTTtFQUNoQyxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLFlBQVksS0FBSyxHQUFHO0dBQ3ZCLFNBQVMsK0JBQStCO0dBQ3hDO0VBQ0Y7RUFDQSxJQUFJLGFBQWEsR0FBRztHQUNsQixTQUFTLDRCQUE0QjtHQUNyQztFQUNGO0VBQ0EsSUFBSSxnQkFBZ0IsV0FBVyxHQUFHO0dBQ2hDLFNBQVMsaURBQWlEO0dBQzFEO0VBQ0Y7RUFDQSxJQUFJLGNBQWMsa0JBQWtCLENBQUMsb0JBQW9CO0dBQ3ZELFNBQVMsMkRBQTJEO0dBQ3BFO0VBQ0Y7RUFFQSxhQUFhLElBQUk7RUFDakIsU0FBUyxFQUFFO0VBRVgsSUFBSTtHQUNGLE1BQU0sU0FBUyxnQkFBZ0IsS0FBSyxZQUFZO0lBQzlDO0lBQ0EsWUFDRSxjQUFjLGlCQUNWLFdBQVcsYUFBYSxPQUFPLEtBQUssSUFDcEM7R0FDUixFQUFFO0dBRUYsTUFBTSxVQUFVO0lBQ2QsUUFBUSxZQUFZO0lBQ3BCLGFBQWEsWUFBWSxLQUFLO0lBQzlCLFFBQVE7SUFDUixjQUFjLFdBQVcsZUFBZTtJQUN4QyxTQUFTLFlBQVksZUFBZSxPQUFPLE9BQU8sT0FBTztJQUN6RDtJQUNBO0dBQ0Y7R0FFQSxNQUFNLFdBQVcsY0FBYyxPQUFPO0dBQ3RDLElBQUksV0FBVyxVQUFVO0VBQzNCLFNBQVMsS0FBSztHQUNaLFNBQVMsSUFBSSxXQUFXLHdCQUF3QjtFQUNsRCxVQUFVO0dBQ1IsYUFBYSxLQUFLO0VBQ3BCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxVQUFVO0VBQWMsV0FBVTtZQUF4QztHQUNHLFNBQVMsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBUSxTQUFTO0lBQU8sZUFBZSxTQUFTLEVBQUU7R0FBSTs7Ozs7R0FHNUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FDRSxPQUFNO0tBQ04sYUFBWTtLQUNaLE9BQU87S0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztLQUM5QyxNQUFNO0tBQ047SUFDRDs7OztjQUNELHdCQUFDLE9BQUQ7S0FDRSxPQUFNO0tBQ04sTUFBSztLQUNMLGFBQVk7S0FDWixPQUFPO0tBQ1AsV0FBVyxNQUFNLFVBQVUsRUFBRSxPQUFPLEtBQUs7S0FDekMsTUFBTTtLQUNOLE1BQUs7S0FDTCxLQUFJO0tBQ0o7SUFDRDs7OztZQUNFOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUE0RDtLQUV0RTs7OztlQUdMLFlBQ0Msd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQ0Usd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxTQUFTO09BQ1QsV0FBVyxNQUFNO1FBQ2YsZ0JBQWdCLEVBQUUsT0FBTyxPQUFPO1FBQ2hDLElBQUksRUFBRSxPQUFPLFNBQVMsV0FBVyxFQUFFO2FBQzlCLFdBQVcsYUFBYSxNQUFNLEVBQUU7T0FDdkM7T0FDQSxXQUFVO01BQ1g7Ozs7Z0JBQ0Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7OztpQkFBQyxzQkFDOUI7Ozs7O2NBQ0Q7Ozs7O2FBRU47Ozs7O2NBR0osQ0FBQyxlQUNBLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSwrREFBZ0U7Ozs7ZUFDckYsd0JBQUMsVUFBRDtNQUNFLE9BQU87TUFDUCxXQUFXLE1BQU0sV0FBVyxFQUFFLE9BQU8sS0FBSztNQUMxQyxVQUFVLENBQUM7TUFDWCxXQUFVO2dCQUVULGFBQWEsU0FBUyxLQUFLLE1BQzFCLHdCQUFDLFVBQUQ7T0FBdUIsT0FBTyxFQUFFO2lCQUFoQztRQUNHLEVBQUU7UUFBUztRQUFFLEVBQUUsV0FBVyxhQUFhLEtBQUssZ0JBQWdCO09BQ3ZEO1NBRkssRUFBRTs7OzthQUVQLENBQ1Q7S0FDSzs7OzthQUNMOzs7OztlQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSwwQkFBMkI7Ozs7ZUFBQyxrRUFFM0M7Ozs7O1lBRUo7Ozs7OztHQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUEyRTtHQUVyRjs7OzthQUNQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLGVBQWUsYUFBYSxPQUFPO0tBQ25DLFdBQVcsaUVBQ1QsY0FBYyxVQUNWLHVDQUNBO2VBRVA7SUFFTzs7OztjQUNSLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsZUFBZSxhQUFhLGNBQWM7S0FDMUMsV0FBVyxpRUFDVCxjQUFjLGlCQUNWLHVDQUNBO2VBRVA7SUFFTzs7OztZQUNMOzs7OztXQUNGOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQjtNQUFnRjtNQUNuRCxnQkFBZ0I7TUFBTztNQUFFLGFBQWEsU0FBUyxVQUFVO01BQUU7S0FDbEY7Ozs7O2NBRU4sd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixhQUFhLFNBQVMsS0FBSyxNQUFNO01BQ2hDLE1BQU0sYUFBYSxnQkFBZ0IsU0FBUyxFQUFFLE1BQU07TUFDcEQsTUFBTSxhQUNKLGNBQWMsV0FBVyxjQUFjLGtCQUFrQixJQUNyRCxZQUFZLGtCQUNaO01BRU4sT0FDRSx3QkFBQyxPQUFEO09BRUUsZUFBZSxrQkFBa0IsRUFBRSxNQUFNO09BQ3pDLFdBQVcsK0ZBQ1QsYUFDSSxxREFDQTtpQkFOUixDQVNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0csYUFDQyx3QkFBQyxhQUFELEVBQWEsV0FBVSxtQ0FBb0M7Ozs7bUJBRTNELHdCQUFDLFFBQUQsRUFBUSxXQUFVLGtDQUFtQzs7OztrQkFFdkQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXFCLEVBQUU7UUFBZTs7OztnQkFDbkQ7Ozs7O2lCQUdKLGNBQ0Msd0JBQUMsT0FBRCxZQUNHLGNBQWMsVUFDYix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixlQUFlLFVBQVU7T0FDdEI7Ozs7a0JBRU4sd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBMEIsVUFBVSxNQUFNLEVBQUUsZ0JBQWdCO2tCQUEzRSxDQUNFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsYUFBWTtTQUNaLE9BQU8sYUFBYSxFQUFFLFdBQVc7U0FDakMsV0FBVyxNQUFNLHdCQUF3QixFQUFFLFFBQVEsRUFBRSxPQUFPLEtBQUs7U0FDakUsV0FBVTtRQUNYOzs7O2tCQUNELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFtQztRQUFPOzs7O2dCQUN2RDs7Ozs7Z0JBRUo7Ozs7ZUFFSjtTQXRDRSxFQUFFOzs7O2FBc0NKO0tBRVQsQ0FBQztJQUNFOzs7O1lBQ0Y7Ozs7OztHQUdKLGNBQWMsa0JBQWtCLFlBQVksS0FDM0Msd0JBQUMsT0FBRCxZQUNHLENBQUMscUJBQ0Esd0JBQUMsT0FBRDtJQUNFLE1BQUs7SUFDTCxPQUFNO0lBQ04sU0FBUyxzQkFBc0IsZUFBZSxhQUFhLEVBQUUsY0FBYyxlQUN6RSxTQUNGLEVBQUUsU0FBUyxlQUFlLEtBQUssSUFBSSxTQUFTLENBQUMsRUFBRTtHQUNoRDs7OztjQUVELHdCQUFDLE9BQUQ7SUFDRSxNQUFLO0lBQ0wsU0FBUyxtQkFBbUIsZUFBZSxhQUFhLEVBQUU7R0FDM0Q7Ozs7WUFFQTs7Ozs7R0FJUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsUUFBRDtLQUFRLFNBQVE7S0FBVSxTQUFTO0tBQVUsVUFBVTtlQUNwRCxFQUFFLGlCQUFpQixLQUFLO0lBQ25COzs7O2NBQ1Isd0JBQUMsUUFBRDtLQUNFLE1BQUs7S0FDTTtLQUNYLFVBQVUsY0FBYyxrQkFBa0IsQ0FBQztlQUUxQyxFQUFFLGVBQWUsZUFBZTtJQUMzQjs7OztZQUNMOzs7Ozs7RUFDRDs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU3BsaXRFeHBlbnNlRm9ybS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gJ3JlYWN0LWkxOG5leHQnO1xuaW1wb3J0IHsgRG9sbGFyU2lnbiwgRmlsZVRleHQsIFVzZXJDaGVjaywgV2FsbGV0LCBDaGVja1NxdWFyZSwgU3F1YXJlLCBBbGVydFRyaWFuZ2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IElucHV0IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9JbnB1dCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0J1dHRvbic7XG5pbXBvcnQgeyBBbGVydCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvQWxlcnQnO1xuaW1wb3J0IHsgZXhwZW5zZUFwaSB9IGZyb20gJy4vZXhwZW5zZUFwaSc7XG5pbXBvcnQgeyB1c2VVc2VyU3RvcmUgfSBmcm9tICcuLi8uLi9zdG9yZS91c2VVc2VyU3RvcmUnO1xuaW1wb3J0IHsgdXNlVHJpcFN0b3JlIH0gZnJvbSAnLi4vLi4vc3RvcmUvdXNlVHJpcFN0b3JlJztcbmltcG9ydCB7IGZvcm1hdEN1cnJlbmN5IH0gZnJvbSAnLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5cbmV4cG9ydCBjb25zdCBTcGxpdEV4cGVuc2VGb3JtID0gKHsgb25TdWNjZXNzLCBvbkNhbmNlbCB9KSA9PiB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcbiAgY29uc3QgeyBjdXJyZW50VXNlciB9ID0gdXNlVXNlclN0b3JlKCk7XG4gIGNvbnN0IHsgY3VycmVudFRyaXAgfSA9IHVzZVRyaXBTdG9yZSgpO1xuXG4gIC8vIEZpbmQgdXNlciByb2xlIGluIGN1cnJlbnQgdHJpcFxuICBjb25zdCBjdXJyZW50TWVtYmVyID0gY3VycmVudFRyaXA/Lm1lbWJlcnM/LmZpbmQoXG4gICAgKG0pID0+IFN0cmluZyhtLnVzZXJJZCkgPT09IFN0cmluZyhjdXJyZW50VXNlcj8uaWQpXG4gICk7XG4gIGNvbnN0IGlzTGVhZGVyID0gY3VycmVudE1lbWJlcj8ucm9sZSA9PT0gJ0xFQURFUic7XG5cbiAgLy8gRm9ybSBTdGF0ZVxuICBjb25zdCBbZGVzY3JpcHRpb24sIHNldERlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2Ftb3VudCwgc2V0QW1vdW50XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2lzUGFpZEJ5RnVuZCwgc2V0SXNQYWlkQnlGdW5kXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3BheWVySWQsIHNldFBheWVySWRdID0gdXNlU3RhdGUoY3VycmVudFVzZXI/LmlkIHx8ICcnKTtcbiAgY29uc3QgW3NwbGl0VHlwZSwgc2V0U3BsaXRUeXBlXSA9IHVzZVN0YXRlKCdFUVVBTCcpOyAvLyBFUVVBTCBvciBFWEFDVF9BTU9VTlRcblxuICAvLyBQYXJ0aWNpcGFudHMgc2VsZWN0aW9uICYgYW1vdW50c1xuICBjb25zdCBbc2VsZWN0ZWRVc2VySWRzLCBzZXRTZWxlY3RlZFVzZXJJZHNdID0gdXNlU3RhdGUoXG4gICAgY3VycmVudFRyaXA/Lm1lbWJlcnM/Lm1hcCgobSkgPT4gbS51c2VySWQpIHx8IFtdXG4gICk7XG4gIGNvbnN0IFtleGFjdEFtb3VudHMsIHNldEV4YWN0QW1vdW50c10gPSB1c2VTdGF0ZSh7fSk7XG5cbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gSGFuZGxlIHBhcnRpY2lwYW50IGNoZWNrYm94IHRvZ2dsZVxuICBjb25zdCB0b2dnbGVQYXJ0aWNpcGFudCA9ICh1c2VySWQpID0+IHtcbiAgICBpZiAoc2VsZWN0ZWRVc2VySWRzLmluY2x1ZGVzKHVzZXJJZCkpIHtcbiAgICAgIGlmIChzZWxlY3RlZFVzZXJJZHMubGVuZ3RoID09PSAxKSByZXR1cm47IC8vIE11c3QgaGF2ZSBhdCBsZWFzdCAxIHBhcnRpY2lwYW50XG4gICAgICBzZXRTZWxlY3RlZFVzZXJJZHMoc2VsZWN0ZWRVc2VySWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB1c2VySWQpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0U2VsZWN0ZWRVc2VySWRzKFsuLi5zZWxlY3RlZFVzZXJJZHMsIHVzZXJJZF0pO1xuICAgIH1cbiAgfTtcblxuICAvLyBIYW5kbGUgZXhhY3QgYW1vdW50IGlucHV0IGZvciBhIHVzZXJcbiAgY29uc3QgaGFuZGxlRXhhY3RBbW91bnRDaGFuZ2UgPSAodXNlcklkLCB2YWwpID0+IHtcbiAgICBzZXRFeGFjdEFtb3VudHMoKHByZXYpID0+ICh7XG4gICAgICAuLi5wcmV2LFxuICAgICAgW3VzZXJJZF06IHZhbCxcbiAgICB9KSk7XG4gIH07XG5cbiAgLy8gTGl2ZSBjYWxjdWxhdGlvbiBmb3IgdmFsaWRhdGlvblxuICBjb25zdCBudW1BbW91bnQgPSBwYXJzZUZsb2F0KGFtb3VudCkgfHwgMDtcbiAgY29uc3QgbnVtUGFydGljaXBhbnRzID0gc2VsZWN0ZWRVc2VySWRzLmxlbmd0aDtcblxuICBjb25zdCB0b3RhbEV4YWN0U3VtID0gc2VsZWN0ZWRVc2VySWRzLnJlZHVjZSgoc3VtLCBpZCkgPT4ge1xuICAgIGNvbnN0IHZhbCA9IHBhcnNlRmxvYXQoZXhhY3RBbW91bnRzW2lkXSkgfHwgMDtcbiAgICByZXR1cm4gc3VtICsgdmFsO1xuICB9LCAwKTtcblxuICBjb25zdCBpc0V4YWN0U3VtTWF0Y2hpbmcgPVxuICAgIHNwbGl0VHlwZSA9PT0gJ0VYQUNUX0FNT1VOVCcgPyBNYXRoLmFicyh0b3RhbEV4YWN0U3VtIC0gbnVtQW1vdW50KSA8IDAuMDEgOiB0cnVlO1xuXG4gIGNvbnN0IGV4YWN0RGlmZiA9IHRvdGFsRXhhY3RTdW0gLSBudW1BbW91bnQ7XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFkZXNjcmlwdGlvbi50cmltKCkpIHtcbiAgICAgIHNldEVycm9yKCdWdWkgbMOybmcgbmjhuq1wIG3DtCB04bqjIGtob+G6o24gY2hpJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChudW1BbW91bnQgPD0gMCkge1xuICAgICAgc2V0RXJyb3IoJ1Phu5EgdGnhu4FuIGNoaSBwaOG6o2kgbOG7m24gaMahbiAwJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChzZWxlY3RlZFVzZXJJZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBzZXRFcnJvcignUGjhuqNpIGPDsyDDrXQgbmjhuqV0IDEgdGjDoG5oIHZpw6puIHRoYW0gZ2lhIGNoaWEgdGnhu4FuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChzcGxpdFR5cGUgPT09ICdFWEFDVF9BTU9VTlQnICYmICFpc0V4YWN0U3VtTWF0Y2hpbmcpIHtcbiAgICAgIHNldEVycm9yKCdU4buVbmcgdGnhu4FuIGNoaWEgY2hvIHThu6tuZyBuZ8aw4budaSBraMO0bmcga2jhu5twIHbhu5tpIHThu5VuZyBow7NhIMSRxqFuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xuICAgIHNldEVycm9yKCcnKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBzcGxpdHMgPSBzZWxlY3RlZFVzZXJJZHMubWFwKCh1c2VySWQpID0+ICh7XG4gICAgICAgIHVzZXJJZCxcbiAgICAgICAgYW1vdW50T3dlZDpcbiAgICAgICAgICBzcGxpdFR5cGUgPT09ICdFWEFDVF9BTU9VTlQnXG4gICAgICAgICAgICA/IHBhcnNlRmxvYXQoZXhhY3RBbW91bnRzW3VzZXJJZF0pIHx8IDBcbiAgICAgICAgICAgIDogbnVsbCxcbiAgICAgIH0pKTtcblxuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgICAgdHJpcElkOiBjdXJyZW50VHJpcC5pZCxcbiAgICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLnRyaW0oKSxcbiAgICAgICAgYW1vdW50OiBudW1BbW91bnQsXG4gICAgICAgIGlzUGFpZEJ5RnVuZDogaXNMZWFkZXIgPyBpc1BhaWRCeUZ1bmQgOiBmYWxzZSxcbiAgICAgICAgcGF5ZXJJZDogaXNMZWFkZXIgJiYgaXNQYWlkQnlGdW5kID8gbnVsbCA6IE51bWJlcihwYXllcklkKSxcbiAgICAgICAgc3BsaXRUeXBlLFxuICAgICAgICBzcGxpdHMsXG4gICAgICB9O1xuXG4gICAgICBhd2FpdCBleHBlbnNlQXBpLmNyZWF0ZUV4cGVuc2UocGF5bG9hZCk7XG4gICAgICBpZiAob25TdWNjZXNzKSBvblN1Y2Nlc3MoKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlIHx8ICdU4bqhbyBraG/huqNuIGNoaSB0aOG6pXQgYuG6oWknKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC01XCI+XG4gICAgICB7ZXJyb3IgJiYgPEFsZXJ0IHR5cGU9XCJlcnJvclwiIG1lc3NhZ2U9e2Vycm9yfSBvbkNsb3NlPXsoKSA9PiBzZXRFcnJvcignJyl9IC8+fVxuXG4gICAgICB7LyogRGVzY3JpcHRpb24gJiBBbW91bnQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgPElucHV0XG4gICAgICAgICAgbGFiZWw9XCJNw7QgdOG6oyBraG/huqNuIGNoaVwiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJWw60gZOG7pTogVGnhu4FuIHBow7JuZyBLUywgxIJuIHThu5FpLi4uXCJcbiAgICAgICAgICB2YWx1ZT17ZGVzY3JpcHRpb259XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREZXNjcmlwdGlvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgaWNvbj17RmlsZVRleHR9XG4gICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgLz5cbiAgICAgICAgPElucHV0XG4gICAgICAgICAgbGFiZWw9XCJU4buVbmcgc+G7kSB0aeG7gW4gKFZORClcIlxuICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVsOtIGThu6U6IDMwMDAwMC4uLlwiXG4gICAgICAgICAgdmFsdWU9e2Ftb3VudH1cbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFtb3VudChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgaWNvbj17RG9sbGFyU2lnbn1cbiAgICAgICAgICBzdGVwPVwiMTAwMFwiXG4gICAgICAgICAgbWluPVwiMTAwMFwiXG4gICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUGF5ZXIgQXV0aG9yaXphdGlvbiBTZWN0aW9uICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICBOZ8aw4budaSB0aGFuaCB0b8OhbiAoUGF5ZXIpXG4gICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgey8qIEZ1bmQgVG9nZ2xlIChPbmx5IExlYWRlciBjYW4gZW5hYmxlKSAqL31cbiAgICAgICAgICB7aXNMZWFkZXIgJiYgKFxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlciBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2lzUGFpZEJ5RnVuZH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldElzUGFpZEJ5RnVuZChlLnRhcmdldC5jaGVja2VkKTtcbiAgICAgICAgICAgICAgICAgIGlmIChlLnRhcmdldC5jaGVja2VkKSBzZXRQYXllcklkKCcnKTtcbiAgICAgICAgICAgICAgICAgIGVsc2Ugc2V0UGF5ZXJJZChjdXJyZW50VXNlcj8uaWQgfHwgJycpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWluZGlnby02MDAgcm91bmRlZCBmb2N1czpyaW5nLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWluZGlnby03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICA8V2FsbGV0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gRMO5bmcgdGnhu4FuIFF14bu5IGNodW5nXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFBheWVyIFNlbGVjdCBEcm9wZG93biAqL31cbiAgICAgICAgeyFpc1BhaWRCeUZ1bmQgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgPFVzZXJDaGVjayBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMuNSB3LTUgaC01IHRleHQtc2xhdGUtNDAwIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICB2YWx1ZT17cGF5ZXJJZH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXllcklkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFpc0xlYWRlcn1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1pbi1oLVs0NHB4XSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHBsLTExIHByLTQgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTEwMCBkaXNhYmxlZDpiZy1zbGF0ZS0xMDAgZGlzYWJsZWQ6dGV4dC1zbGF0ZS01MDBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7Y3VycmVudFRyaXA/Lm1lbWJlcnM/Lm1hcCgobSkgPT4gKFxuICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXttLnVzZXJJZH0gdmFsdWU9e20udXNlcklkfT5cbiAgICAgICAgICAgICAgICAgIHttLmZ1bGxOYW1lfSB7bS51c2VySWQgPT09IGN1cnJlbnRVc2VyPy5pZCA/ICcoQ2jDrW5oIGLhuqFuKScgOiAnJ31cbiAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1pbmRpZ28tNTAgYm9yZGVyIGJvcmRlci1pbmRpZ28tMjAwLzgwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtaW5kaWdvLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPFdhbGxldCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtaW5kaWdvLTYwMFwiIC8+XG4gICAgICAgICAgICBLaG/huqNuIGNoaSBuw6B5IHPhur0gxJHGsOG7o2MgdHLhu6sgdHLhu7FjIHRp4bq/cCB04burIHPhu5EgZMawIFF14bu5IGNodW5nIGPhu6dhIG5ow7NtLlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTcGxpdCBUeXBlIFRhYnMgKi99XG4gICAgICA8ZGl2PlxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0yIGJsb2NrXCI+XG4gICAgICAgICAgSMOsbmggdGjhu6ljIGNoaWEgdGnhu4FuXG4gICAgICAgIDwvbGFiZWw+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiBwLTEgYmctc2xhdGUtMTAwIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNwbGl0VHlwZSgnRVFVQUwnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTIgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBtaW4taC1bNDBweF0gJHtcbiAgICAgICAgICAgICAgc3BsaXRUeXBlID09PSAnRVFVQUwnXG4gICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgdGV4dC1pbmRpZ28tNzAwIHNoYWRvdy14cydcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTYwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIENoaWEgxJHhu4F1IChFUVVBTClcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNwbGl0VHlwZSgnRVhBQ1RfQU1PVU5UJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgbWluLWgtWzQwcHhdICR7XG4gICAgICAgICAgICAgIHNwbGl0VHlwZSA9PT0gJ0VYQUNUX0FNT1VOVCdcbiAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSB0ZXh0LWluZGlnby03MDAgc2hhZG93LXhzJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNjAwIGhvdmVyOnRleHQtc2xhdGUtOTAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgQ2hpYSBz4buRIHRp4buBbiBj4bulIHRo4buDIChFWEFDVClcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFBhcnRpY2lwYW50cyAmIExpdmUgQ2FsY3VsYXRpb24gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgIE5nxrDhu51pIHRoYW0gZ2lhIGNo4buLdSB0aeG7gW4gKHtzZWxlY3RlZFVzZXJJZHMubGVuZ3RofS97Y3VycmVudFRyaXA/Lm1lbWJlcnM/Lmxlbmd0aCB8fCAwfSlcbiAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMiBtYXgtaC02MCBvdmVyZmxvdy15LWF1dG8gcC0xXCI+XG4gICAgICAgICAge2N1cnJlbnRUcmlwPy5tZW1iZXJzPy5tYXAoKG0pID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBzZWxlY3RlZFVzZXJJZHMuaW5jbHVkZXMobS51c2VySWQpO1xuICAgICAgICAgICAgY29uc3QgZXF1YWxTaGFyZSA9XG4gICAgICAgICAgICAgIHNwbGl0VHlwZSA9PT0gJ0VRVUFMJyAmJiBpc1NlbGVjdGVkICYmIG51bVBhcnRpY2lwYW50cyA+IDBcbiAgICAgICAgICAgICAgICA/IG51bUFtb3VudCAvIG51bVBhcnRpY2lwYW50c1xuICAgICAgICAgICAgICAgIDogMDtcblxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17bS51c2VySWR9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlUGFydGljaXBhbnQobS51c2VySWQpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLXhsIGJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctaW5kaWdvLTUwLzUwIGJvcmRlci1pbmRpZ28tMjAwIHRleHQtc2xhdGUtOTAwJ1xuICAgICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSBib3JkZXItc2xhdGUtMjAwLzgwIHRleHQtc2xhdGUtNDAwIG9wYWNpdHktNjAnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICB7aXNTZWxlY3RlZCA/IChcbiAgICAgICAgICAgICAgICAgICAgPENoZWNrU3F1YXJlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1pbmRpZ28tNjAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxTcXVhcmUgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTMwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGRcIj57bS5mdWxsTmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogRGlzcGxheSBjYWxjdWxhdGVkIHNoYXJlIG9yIGlucHV0ICovfVxuICAgICAgICAgICAgICAgIHtpc1NlbGVjdGVkICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIHtzcGxpdFR5cGUgPT09ICdFUVVBTCcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWV4dHJhYm9sZCB0ZXh0LWluZGlnby02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShlcXVhbFNoYXJlKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2V4YWN0QW1vdW50c1ttLnVzZXJJZF0gfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRXhhY3RBbW91bnRDaGFuZ2UobS51c2VySWQsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0yOCBtaW4taC1bMzZweF0gcHgtMiBweS0xIHRleHQtcmlnaHQgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDBcIj7EkTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIExpdmUgV2FybmluZyBmb3IgRVhBQ1RfQU1PVU5UIG1pc21hdGNoICovfVxuICAgICAge3NwbGl0VHlwZSA9PT0gJ0VYQUNUX0FNT1VOVCcgJiYgbnVtQW1vdW50ID4gMCAmJiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgeyFpc0V4YWN0U3VtTWF0Y2hpbmcgPyAoXG4gICAgICAgICAgICA8QWxlcnRcbiAgICAgICAgICAgICAgdHlwZT1cIndhcm5pbmdcIlxuICAgICAgICAgICAgICB0aXRsZT1cIlThu5VuZyB0aeG7gW4gY2hpYSBraMO0bmcga2jhu5twIHbhu5tpIGjDs2EgxJHGoW4hXCJcbiAgICAgICAgICAgICAgbWVzc2FnZT17YFThu5VuZyB0aeG7gW4gxJHDoyBjaGlhOiAke2Zvcm1hdEN1cnJlbmN5KHRvdGFsRXhhY3RTdW0pfSAvIEjDs2EgxJHGoW46ICR7Zm9ybWF0Q3VycmVuY3koXG4gICAgICAgICAgICAgICAgbnVtQW1vdW50XG4gICAgICAgICAgICAgICl9IChM4buHY2ggJHtmb3JtYXRDdXJyZW5jeShNYXRoLmFicyhleGFjdERpZmYpKX0pYH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxBbGVydFxuICAgICAgICAgICAgICB0eXBlPVwic3VjY2Vzc1wiXG4gICAgICAgICAgICAgIG1lc3NhZ2U9e2BU4buVbmcgdGnhu4FuIGNoaWEgKCR7Zm9ybWF0Q3VycmVuY3kodG90YWxFeGFjdFN1bSl9KSDEkcOjIGto4bubcCBob8OgbiB0b8OgbiB24bubaSBow7NhIMSRxqFuIWB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFN1Ym1pdCAvIENhbmNlbCBCdXR0b25zICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIG10LTJcIj5cbiAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e29uQ2FuY2VsfSBkaXNhYmxlZD17aXNMb2FkaW5nfT5cbiAgICAgICAgICB7dCgnY29tbW9uLmNhbmNlbCcsICdI4buneScpfVxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPEJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxuICAgICAgICAgIGRpc2FibGVkPXtzcGxpdFR5cGUgPT09ICdFWEFDVF9BTU9VTlQnICYmICFpc0V4YWN0U3VtTWF0Y2hpbmd9XG4gICAgICAgID5cbiAgICAgICAgICB7dCgnY29tbW9uLnNhdmUnLCAnTMawdSBraG/huqNuIGNoaScpfVxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZm9ybT5cbiAgKTtcbn07XG4iXX0=