import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Table.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/Table.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
export const Table = ({ headers, children, emptyMessage = "Không có dữ liệu" }) => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "w-full overflow-x-auto rounded-xl border border-slate-200/80 bg-white shadow-sm",
		children: /* @__PURE__ */ _jsxDEV("table", {
			className: "w-full text-left border-collapse min-w-[600px]",
			children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
				className: "bg-slate-50/80 border-b border-slate-200/80 text-xs font-bold text-slate-500 uppercase tracking-wider",
				children: headers.map((header, index) => /* @__PURE__ */ _jsxDEV("th", {
					className: "px-4 py-3.5",
					children: header
				}, index, false, {
					fileName: _jsxFileName,
					lineNumber: 10,
					columnNumber: 15
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("tbody", {
				className: "divide-y divide-slate-100 text-sm text-slate-700",
				children
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
};
_c = Table;
var _c;
$RefreshReg$(_c, "Table");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Table.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/Table.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/Table.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/Table.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFFbEIsT0FBTyxNQUFNLFNBQVMsRUFBRSxTQUFTLFVBQVUsZUFBZSx5QkFBeUI7Q0FDakYsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLFNBQUQ7R0FBTyxXQUFVO2FBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1gsUUFBUSxLQUFLLFFBQVEsVUFDcEIsd0JBQUMsTUFBRDtLQUFnQixXQUFVO2VBQ3ZCO0lBQ0MsR0FGSzs7OztXQUVMLENBQ0w7R0FDQzs7OztZQUNDOzs7O2FBQ1Asd0JBQUMsU0FBRDtJQUFPLFdBQVU7SUFDZDtHQUNJOzs7O1dBQ0Y7Ozs7OztDQUNKOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRhYmxlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5leHBvcnQgY29uc3QgVGFibGUgPSAoeyBoZWFkZXJzLCBjaGlsZHJlbiwgZW1wdHlNZXNzYWdlID0gJ0tow7RuZyBjw7MgZOG7ryBsaeG7h3UnIH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBvdmVyZmxvdy14LWF1dG8gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBiZy13aGl0ZSBzaGFkb3ctc21cIj5cbiAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IGJvcmRlci1jb2xsYXBzZSBtaW4tdy1bNjAwcHhdXCI+XG4gICAgICAgIDx0aGVhZD5cbiAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAvODAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMC84MCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgIHtoZWFkZXJzLm1hcCgoaGVhZGVyLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICA8dGgga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwicHgtNCBweS0zLjVcIj5cbiAgICAgICAgICAgICAgICB7aGVhZGVyfVxuICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC90cj5cbiAgICAgICAgPC90aGVhZD5cbiAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgdGV4dC1zbSB0ZXh0LXNsYXRlLTcwMFwiPlxuICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgPC90Ym9keT5cbiAgICAgIDwvdGFibGU+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19