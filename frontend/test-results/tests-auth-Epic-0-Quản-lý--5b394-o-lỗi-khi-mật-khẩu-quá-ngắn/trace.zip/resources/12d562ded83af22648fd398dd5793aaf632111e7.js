import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/AppRoutes.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { BrowserRouter, Routes, Route } from "/node_modules/.vite/deps/react-router-dom.js?v=aa845dd0";
import { MainLayout } from "/src/components/layout/MainLayout.jsx";
import { ProtectedRoute } from "/src/components/ProtectedRoute.jsx";
import { TripList } from "/src/features/trips/TripList.jsx";
import { FundSummaryView } from "/src/features/funds/FundSummaryView.jsx";
import { ExpenseList } from "/src/features/expenses/ExpenseList.jsx";
import { SettlementDashboard } from "/src/features/settlement/SettlementDashboard.jsx";
import { LoginPage } from "/src/features/auth/LoginPage.jsx";
import { RegisterPage } from "/src/features/auth/RegisterPage.jsx";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/routes/AppRoutes.jsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
export const AppRoutes = () => {
	return /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: [
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: /* @__PURE__ */ _jsxDEV(LoginPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 39
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/register",
			element: /* @__PURE__ */ _jsxDEV(RegisterPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 42
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 25
			}, this),
			children: /* @__PURE__ */ _jsxDEV(Route, {
				path: "/",
				element: /* @__PURE__ */ _jsxDEV(MainLayout, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 36
				}, this),
				children: [
					/* @__PURE__ */ _jsxDEV(Route, {
						index: true,
						element: /* @__PURE__ */ _jsxDEV(TripList, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 35
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "funds",
						element: /* @__PURE__ */ _jsxDEV(FundSummaryView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 24,
							columnNumber: 42
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "expenses",
						element: /* @__PURE__ */ _jsxDEV(ExpenseList, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 45
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "settlement",
						element: /* @__PURE__ */ _jsxDEV(SettlementDashboard, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 47
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
};
_c = AppRoutes;
var _c;
$RefreshReg$(_c, "AppRoutes");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/AppRoutes.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/routes/AppRoutes.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/routes/AppRoutes.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/routes/AppRoutes.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZUFBZSxRQUFRLGFBQWE7QUFDN0MsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUywyQkFBMkI7QUFDcEMsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxvQkFBb0I7OztBQUU3QixPQUFPLE1BQU0sa0JBQWtCO0NBQzdCLE9BQ0Usd0JBQUMsZUFBRCxZQUNFLHdCQUFDLFFBQUQ7RUFFRSx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFTLFNBQVMsd0JBQUMsV0FBRCxDQUFZOzs7OztFQUFJOzs7OztFQUM5Qyx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFZLFNBQVMsd0JBQUMsY0FBRCxDQUFlOzs7OztFQUFJOzs7OztFQUdwRCx3QkFBQyxPQUFEO0dBQU8sU0FBUyx3QkFBQyxnQkFBRCxDQUFpQjs7Ozs7YUFDL0Isd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBSSxTQUFTLHdCQUFDLFlBQUQsQ0FBYTs7Ozs7Y0FBdEM7S0FDRSx3QkFBQyxPQUFEO01BQU87TUFBTSxTQUFTLHdCQUFDLFVBQUQsQ0FBVzs7Ozs7S0FBSTs7Ozs7S0FDckMsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBUSxTQUFTLHdCQUFDLGlCQUFELENBQWtCOzs7OztLQUFJOzs7OztLQUNuRCx3QkFBQyxPQUFEO01BQU8sTUFBSztNQUFXLFNBQVMsd0JBQUMsYUFBRCxDQUFjOzs7OztLQUFJOzs7OztLQUNsRCx3QkFBQyxPQUFEO01BQU8sTUFBSztNQUFhLFNBQVMsd0JBQUMscUJBQUQsQ0FBc0I7Ozs7O0tBQUk7Ozs7O0lBQ3ZEOzs7Ozs7RUFDRjs7Ozs7Q0FDRDs7OztVQUNLOzs7OztBQUVuQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHBSb3V0ZXMuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBCcm93c2VyUm91dGVyLCBSb3V0ZXMsIFJvdXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBNYWluTGF5b3V0IH0gZnJvbSAnLi4vY29tcG9uZW50cy9sYXlvdXQvTWFpbkxheW91dCc7XG5pbXBvcnQgeyBQcm90ZWN0ZWRSb3V0ZSB9IGZyb20gJy4uL2NvbXBvbmVudHMvUHJvdGVjdGVkUm91dGUnO1xuaW1wb3J0IHsgVHJpcExpc3QgfSBmcm9tICcuLi9mZWF0dXJlcy90cmlwcy9UcmlwTGlzdCc7XG5pbXBvcnQgeyBGdW5kU3VtbWFyeVZpZXcgfSBmcm9tICcuLi9mZWF0dXJlcy9mdW5kcy9GdW5kU3VtbWFyeVZpZXcnO1xuaW1wb3J0IHsgRXhwZW5zZUxpc3QgfSBmcm9tICcuLi9mZWF0dXJlcy9leHBlbnNlcy9FeHBlbnNlTGlzdCc7XG5pbXBvcnQgeyBTZXR0bGVtZW50RGFzaGJvYXJkIH0gZnJvbSAnLi4vZmVhdHVyZXMvc2V0dGxlbWVudC9TZXR0bGVtZW50RGFzaGJvYXJkJztcbmltcG9ydCB7IExvZ2luUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2F1dGgvTG9naW5QYWdlJztcbmltcG9ydCB7IFJlZ2lzdGVyUGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2F1dGgvUmVnaXN0ZXJQYWdlJztcblxuZXhwb3J0IGNvbnN0IEFwcFJvdXRlcyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8QnJvd3NlclJvdXRlcj5cbiAgICAgIDxSb3V0ZXM+XG4gICAgICAgIHsvKiBQdWJsaWMgUm91dGVzICovfVxuICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxMb2dpblBhZ2UgLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL3JlZ2lzdGVyXCIgZWxlbWVudD17PFJlZ2lzdGVyUGFnZSAvPn0gLz5cblxuICAgICAgICB7LyogUHJvdGVjdGVkIFByaXZhdGUgUm91dGVzICovfVxuICAgICAgICA8Um91dGUgZWxlbWVudD17PFByb3RlY3RlZFJvdXRlIC8+fT5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8TWFpbkxheW91dCAvPn0+XG4gICAgICAgICAgICA8Um91dGUgaW5kZXggZWxlbWVudD17PFRyaXBMaXN0IC8+fSAvPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJmdW5kc1wiIGVsZW1lbnQ9ezxGdW5kU3VtbWFyeVZpZXcgLz59IC8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cImV4cGVuc2VzXCIgZWxlbWVudD17PEV4cGVuc2VMaXN0IC8+fSAvPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJzZXR0bGVtZW50XCIgZWxlbWVudD17PFNldHRsZW1lbnREYXNoYm9hcmQgLz59IC8+XG4gICAgICAgICAgPC9Sb3V0ZT5cbiAgICAgICAgPC9Sb3V0ZT5cbiAgICAgIDwvUm91dGVzPlxuICAgIDwvQnJvd3NlclJvdXRlcj5cbiAgKTtcbn07XG4iXX0=