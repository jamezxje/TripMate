import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/trips/CreateTripModal.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Compass } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import { Modal } from "/src/components/Modal.jsx";
import { Input } from "/src/components/Input.jsx";
import { Button } from "/src/components/Button.jsx";
import { Alert } from "/src/components/Alert.jsx";
import { tripApi } from "/src/features/trips/tripApi.js";
import { useTripStore } from "/src/store/useTripStore.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/trips/CreateTripModal.jsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const CreateTripModal = ({ isOpen, onClose }) => {
	_s();
	const { t } = useTranslation();
	const { setCurrentTrip } = useTripStore();
	const [name, setName] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState("");
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!name.trim()) {
			setError("Tên chuyến đi không được để trống");
			return;
		}
		setIsLoading(true);
		setError("");
		try {
			const res = await tripApi.createTrip(name.trim());
			if (res.data) {
				setCurrentTrip(res.data);
				setName("");
				onClose();
			}
		} catch (err) {
			setError(err.message || "Tạo chuyến đi thất bại. Vui lòng thử lại.");
		} finally {
			setIsLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV(Modal, {
		isOpen,
		onClose,
		title: t("trip.create", "Tạo chuyến đi mới"),
		children: /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			className: "flex flex-col gap-4",
			children: [
				error && /* @__PURE__ */ _jsxDEV(Alert, {
					type: "error",
					message: error,
					onClose: () => setError("")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 19
				}, this),
				/* @__PURE__ */ _jsxDEV(Input, {
					label: "Tên chuyến đi",
					placeholder: "Ví dụ: Du lịch Đà Nẵng 4N3Đ...",
					value: name,
					onChange: (e) => setName(e.target.value),
					icon: Compass,
					required: true,
					autoFocus: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-end gap-3 mt-4",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						onClick: onClose,
						disabled: isLoading,
						children: t("common.cancel", "Hủy")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						type: "submit",
						isLoading,
						children: t("common.save", "Tạo ngay")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 5
	}, this);
};
_s(CreateTripModal, "3FhbsHFnt2oJiCeLHBkPnwkqKY8=", false, function() {
	return [useTranslation, useTripStore];
});
_c = CreateTripModal;
var _c;
$RefreshReg$(_c, "CreateTripModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/trips/CreateTripModal.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/trips/CreateTripModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/trips/CreateTripModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/trips/CreateTripModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGVBQWU7QUFDeEIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsYUFBYTtBQUN0QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsZUFBZTtBQUN4QixTQUFTLG9CQUFvQjs7OztBQUU3QixPQUFPLE1BQU0sbUJBQW1CLEVBQUUsUUFBUSxjQUFjOztDQUN0RCxNQUFNLEVBQUUsTUFBTSxlQUFlO0NBQzdCLE1BQU0sRUFBRSxtQkFBbUIsYUFBYTtDQUN4QyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsRUFBRTtDQUNuQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBRXJDLE1BQU0sZUFBZSxPQUFPLE1BQU07RUFDaEMsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxLQUFLLEtBQUssR0FBRztHQUNoQixTQUFTLG1DQUFtQztHQUM1QztFQUNGO0VBRUEsYUFBYSxJQUFJO0VBQ2pCLFNBQVMsRUFBRTtFQUVYLElBQUk7R0FDRixNQUFNLE1BQU0sTUFBTSxRQUFRLFdBQVcsS0FBSyxLQUFLLENBQUM7R0FDaEQsSUFBSSxJQUFJLE1BQU07SUFDWixlQUFlLElBQUksSUFBSTtJQUN2QixRQUFRLEVBQUU7SUFDVixRQUFRO0dBQ1Y7RUFDRixTQUFTLEtBQUs7R0FDWixTQUFTLElBQUksV0FBVywyQ0FBMkM7RUFDckUsVUFBVTtHQUNSLGFBQWEsS0FBSztFQUNwQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQWU7RUFBaUI7RUFBUyxPQUFPLEVBQUUsZUFBZSxtQkFBbUI7WUFDbEYsd0JBQUMsUUFBRDtHQUFNLFVBQVU7R0FBYyxXQUFVO2FBQXhDO0lBQ0csU0FBUyx3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFRLFNBQVM7S0FBTyxlQUFlLFNBQVMsRUFBRTtJQUFJOzs7OztJQUU1RSx3QkFBQyxPQUFEO0tBQ0UsT0FBTTtLQUNOLGFBQVk7S0FDWixPQUFPO0tBQ1AsV0FBVyxNQUFNLFFBQVEsRUFBRSxPQUFPLEtBQUs7S0FDdkMsTUFBTTtLQUNOO0tBQ0E7SUFDRDs7Ozs7SUFFRCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFRLFNBQVE7TUFBVSxTQUFTO01BQVMsVUFBVTtnQkFDbkQsRUFBRSxpQkFBaUIsS0FBSztLQUNuQjs7OztlQUNSLHdCQUFDLFFBQUQ7TUFBUSxNQUFLO01BQW9CO2dCQUM5QixFQUFFLGVBQWUsVUFBVTtLQUN0Qjs7OzthQUNMOzs7Ozs7R0FDRDs7Ozs7O0NBQ0Q7Ozs7O0FBRVgiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ3JlYXRlVHJpcE1vZGFsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gJ3JlYWN0LWkxOG5leHQnO1xuaW1wb3J0IHsgQ29tcGFzcyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvTW9kYWwnO1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0lucHV0JztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvQnV0dG9uJztcbmltcG9ydCB7IEFsZXJ0IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9BbGVydCc7XG5pbXBvcnQgeyB0cmlwQXBpIH0gZnJvbSAnLi90cmlwQXBpJztcbmltcG9ydCB7IHVzZVRyaXBTdG9yZSB9IGZyb20gJy4uLy4uL3N0b3JlL3VzZVRyaXBTdG9yZSc7XG5cbmV4cG9ydCBjb25zdCBDcmVhdGVUcmlwTW9kYWwgPSAoeyBpc09wZW4sIG9uQ2xvc2UgfSkgPT4ge1xuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XG4gIGNvbnN0IHsgc2V0Q3VycmVudFRyaXAgfSA9IHVzZVRyaXBTdG9yZSgpO1xuICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICghbmFtZS50cmltKCkpIHtcbiAgICAgIHNldEVycm9yKCdUw6puIGNodXnhur9uIMSRaSBraMO0bmcgxJHGsOG7o2MgxJHhu4MgdHLhu5FuZycpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcbiAgICBzZXRFcnJvcignJyk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgdHJpcEFwaS5jcmVhdGVUcmlwKG5hbWUudHJpbSgpKTtcbiAgICAgIGlmIChyZXMuZGF0YSkge1xuICAgICAgICBzZXRDdXJyZW50VHJpcChyZXMuZGF0YSk7XG4gICAgICAgIHNldE5hbWUoJycpO1xuICAgICAgICBvbkNsb3NlKCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSB8fCAnVOG6oW8gY2h1eeG6v24gxJFpIHRo4bqldCBi4bqhaS4gVnVpIGzDsm5nIHRo4butIGzhuqFpLicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxNb2RhbCBpc09wZW49e2lzT3Blbn0gb25DbG9zZT17b25DbG9zZX0gdGl0bGU9e3QoJ3RyaXAuY3JlYXRlJywgJ1ThuqFvIGNodXnhur9uIMSRaSBt4bubaScpfT5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTRcIj5cbiAgICAgICAge2Vycm9yICYmIDxBbGVydCB0eXBlPVwiZXJyb3JcIiBtZXNzYWdlPXtlcnJvcn0gb25DbG9zZT17KCkgPT4gc2V0RXJyb3IoJycpfSAvPn1cblxuICAgICAgICA8SW5wdXRcbiAgICAgICAgICBsYWJlbD1cIlTDqm4gY2h1eeG6v24gxJFpXCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlbDrSBk4bulOiBEdSBs4buLY2ggxJDDoCBO4bq1bmcgNE4zxJAuLi5cIlxuICAgICAgICAgIHZhbHVlPXtuYW1lfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgaWNvbj17Q29tcGFzc31cbiAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICAvPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBtdC00XCI+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e29uQ2xvc2V9IGRpc2FibGVkPXtpc0xvYWRpbmd9PlxuICAgICAgICAgICAge3QoJ2NvbW1vbi5jYW5jZWwnLCAnSOG7p3knKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBpc0xvYWRpbmc9e2lzTG9hZGluZ30+XG4gICAgICAgICAgICB7dCgnY29tbW9uLnNhdmUnLCAnVOG6oW8gbmdheScpfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L01vZGFsPlxuICApO1xufTtcbiJdfQ==