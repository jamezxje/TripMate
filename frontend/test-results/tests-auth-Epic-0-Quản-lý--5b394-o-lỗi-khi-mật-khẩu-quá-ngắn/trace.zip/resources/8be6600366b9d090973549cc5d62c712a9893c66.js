import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Card.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/Card.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
export const Card = ({ children, className = "", onClick, hover = false }) => {
	return /* @__PURE__ */ _jsxDEV("div", {
		onClick,
		className: `bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-sm transition-all duration-200 ${hover ? "hover:shadow-md hover:border-slate-300 cursor-pointer active:scale-[0.99]" : ""} ${className}`,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
};
_c = Card;
export const CardHeader = ({ title, subtitle, action, className = "" }) => /* @__PURE__ */ _jsxDEV("div", {
	className: `flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 ${className}`,
	children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
		className: "text-lg font-bold text-slate-800",
		children: title
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 7
	}, this), subtitle && /* @__PURE__ */ _jsxDEV("p", {
		className: "text-xs text-slate-500 mt-0.5",
		children: subtitle
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 20
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this), action && /* @__PURE__ */ _jsxDEV("div", { children: action }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 16
	}, this)]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 17,
	columnNumber: 3
}, this);
_c2 = CardHeader;
export const CardBody = ({ children, className = "" }) => /* @__PURE__ */ _jsxDEV("div", {
	className,
	children
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 27,
	columnNumber: 3
}, this);
_c3 = CardBody;
var _c, _c2, _c3;
$RefreshReg$(_c, "Card");
$RefreshReg$(_c2, "CardHeader");
$RefreshReg$(_c3, "CardBody");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Card.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/Card.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/Card.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/Card.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFFbEIsT0FBTyxNQUFNLFFBQVEsRUFBRSxVQUFVLFlBQVksSUFBSSxTQUFTLFFBQVEsWUFBWTtDQUM1RSxPQUNFLHdCQUFDLE9BQUQ7RUFDVztFQUNULFdBQVcsb0dBQ1QsUUFBUSw4RUFBOEUsR0FDdkYsR0FBRztFQUVIO0NBQ0U7Ozs7O0FBRVQ7O0FBRUEsT0FBTyxNQUFNLGNBQWMsRUFBRSxPQUFPLFVBQVUsUUFBUSxZQUFZLFNBQ2hFLHdCQUFDLE9BQUQ7Q0FBSyxXQUFXLHdFQUF3RTtXQUF4RixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0VBQUksV0FBVTtZQUFvQztDQUFVOzs7O1dBQzNELFlBQVksd0JBQUMsS0FBRDtFQUFHLFdBQVU7WUFBaUM7Q0FBWTs7OztTQUNwRTs7OztXQUNKLFVBQVUsd0JBQUMsT0FBRCxZQUFNLE9BQVk7Ozs7U0FDMUI7Ozs7Ozs7QUFHUCxPQUFPLE1BQU0sWUFBWSxFQUFFLFVBQVUsWUFBWSxTQUMvQyx3QkFBQyxPQUFEO0NBQWdCO0NBQVk7QUFBYyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDYXJkLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5leHBvcnQgY29uc3QgQ2FyZCA9ICh7IGNoaWxkcmVuLCBjbGFzc05hbWUgPSAnJywgb25DbGljaywgaG92ZXIgPSBmYWxzZSB9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgb25DbGljaz17b25DbGlja31cbiAgICAgIGNsYXNzTmFtZT17YGJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIHAtNSBzbTpwLTYgc2hhZG93LXNtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCAke1xuICAgICAgICBob3ZlciA/ICdob3ZlcjpzaGFkb3ctbWQgaG92ZXI6Ym9yZGVyLXNsYXRlLTMwMCBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtWzAuOTldJyA6ICcnXG4gICAgICB9ICR7Y2xhc3NOYW1lfWB9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGNvbnN0IENhcmRIZWFkZXIgPSAoeyB0aXRsZSwgc3VidGl0bGUsIGFjdGlvbiwgY2xhc3NOYW1lID0gJycgfSkgPT4gKFxuICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBtYi01ICR7Y2xhc3NOYW1lfWB9PlxuICAgIDxkaXY+XG4gICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj57dGl0bGV9PC9oMz5cbiAgICAgIHtzdWJ0aXRsZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIG10LTAuNVwiPntzdWJ0aXRsZX08L3A+fVxuICAgIDwvZGl2PlxuICAgIHthY3Rpb24gJiYgPGRpdj57YWN0aW9ufTwvZGl2Pn1cbiAgPC9kaXY+XG4pO1xuXG5leHBvcnQgY29uc3QgQ2FyZEJvZHkgPSAoeyBjaGlsZHJlbiwgY2xhc3NOYW1lID0gJycgfSkgPT4gKFxuICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3NOYW1lfT57Y2hpbGRyZW59PC9kaXY+XG4pO1xuIl19