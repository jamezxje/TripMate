import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/RegisterPage.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=aa845dd0";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Compass, User, Mail, Lock, UserPlus, Loader2, Globe } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import api from "/src/services/api.js";
import { useUserStore } from "/src/store/useUserStore.js";
import { Alert } from "/src/components/Alert.jsx";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/auth/RegisterPage.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const RegisterPage = () => {
	_s();
	const { t, i18n } = useTranslation();
	const navigate = useNavigate();
	const { setAuth } = useUserStore();
	const [formData, setFormData] = useState({
		fullName: "",
		email: "",
		password: "",
		confirmPassword: ""
	});
	const [loading, setLoading] = useState(false);
	const [errorMessage, setErrorMessage] = useState("");
	const [successMessage, setSuccessMessage] = useState("");
	const handleChange = (e) => {
		setFormData({
			...formData,
			[e.target.name]: e.target.value
		});
		if (errorMessage) setErrorMessage("");
	};
	const toggleLanguage = () => {
		const nextLang = i18n.language === "vi" ? "en" : "vi";
		i18n.changeLanguage(nextLang);
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		setErrorMessage("");
		setSuccessMessage("");
		// Client-side validations
		if (formData.password.length < 6) {
			setErrorMessage(t("auth.password_min_length"));
			return;
		}
		if (formData.password !== formData.confirmPassword) {
			setErrorMessage(t("auth.password_mismatch"));
			return;
		}
		setLoading(true);
		try {
			const response = await api.post("/auth/register", {
				fullName: formData.fullName,
				email: formData.email,
				password: formData.password
			});
			if (response && response.success && response.data) {
				const { accessToken, user } = response.data;
				setAuth(accessToken, user);
				setSuccessMessage(t("auth.register_success"));
				setTimeout(() => {
					navigate("/", { replace: true });
				}, 1e3);
			} else {
				setErrorMessage(response?.message || t("auth.register_failed"));
			}
		} catch (err) {
			setErrorMessage(err.message || t("auth.register_failed"));
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute -top-40 -right-40 w-96 h-96 bg-indigo-600/30 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute -bottom-40 -left-40 w-96 h-96 bg-violet-600/30 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "absolute top-4 right-4 z-10",
				children: /* @__PURE__ */ _jsxDEV("button", {
					onClick: toggleLanguage,
					className: "flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-300 hover:text-white bg-slate-800/80 border border-slate-700 rounded-xl transition-colors min-h-[44px]",
					children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-4 h-4 text-indigo-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "uppercase",
						children: i18n.language || "VI"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "sm:mx-auto sm:w-full sm:max-w-md z-10",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-center items-center gap-3 mb-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-500 to-violet-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30",
							children: /* @__PURE__ */ _jsxDEV(Compass, { className: "w-7 h-7" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-3xl font-black bg-gradient-to-r from-indigo-400 via-violet-300 to-white bg-clip-text text-transparent tracking-tight",
							children: "TripMate"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-center text-2xl font-bold tracking-tight text-white mt-2",
						children: t("auth.register_title")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-center text-sm text-slate-400",
						children: t("auth.register_subtitle")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-8 sm:mx-auto sm:w-full sm:max-w-md z-10 px-4 sm:px-0",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-800/90 backdrop-blur-xl py-8 px-4 shadow-2xl border border-slate-700/80 sm:rounded-2xl sm:px-10",
					children: [
						errorMessage && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-6",
							children: /* @__PURE__ */ _jsxDEV(Alert, {
								variant: "danger",
								title: t("common.error"),
								children: errorMessage
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 13
						}, this),
						successMessage && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-6",
							children: /* @__PURE__ */ _jsxDEV(Alert, {
								variant: "success",
								title: t("common.success"),
								children: successMessage
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							className: "space-y-5",
							onSubmit: handleSubmit,
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-sm font-semibold text-slate-300 mb-1.5",
									children: t("auth.fullname_label")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative rounded-xl shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none",
										children: /* @__PURE__ */ _jsxDEV(User, { className: "h-5 w-5 text-slate-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 138,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 137,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										name: "fullName",
										required: true,
										value: formData.fullName,
										onChange: handleChange,
										placeholder: "Nguyễn Văn A",
										className: "block w-full pl-10 pr-4 py-3 bg-slate-900/90 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all min-h-[44px]"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 140,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-sm font-semibold text-slate-300 mb-1.5",
									children: t("auth.email_label")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 153,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative rounded-xl shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none",
										children: /* @__PURE__ */ _jsxDEV(Mail, { className: "h-5 w-5 text-slate-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 158,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 157,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "email",
										name: "email",
										required: true,
										value: formData.email,
										onChange: handleChange,
										placeholder: "name@example.com",
										className: "block w-full pl-10 pr-4 py-3 bg-slate-900/90 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all min-h-[44px]"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 160,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 156,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 152,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-sm font-semibold text-slate-300 mb-1.5",
									children: t("auth.password_label")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative rounded-xl shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none",
										children: /* @__PURE__ */ _jsxDEV(Lock, { className: "h-5 w-5 text-slate-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 178,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 177,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "password",
										name: "password",
										required: true,
										value: formData.password,
										onChange: handleChange,
										placeholder: "••••••••",
										className: "block w-full pl-10 pr-4 py-3 bg-slate-900/90 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all min-h-[44px]"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 180,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 172,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-sm font-semibold text-slate-300 mb-1.5",
									children: t("auth.confirm_password_label")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 193,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative rounded-xl shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none",
										children: /* @__PURE__ */ _jsxDEV(Lock, { className: "h-5 w-5 text-slate-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 198,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 197,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "password",
										name: "confirmPassword",
										required: true,
										value: formData.confirmPassword,
										onChange: handleChange,
										placeholder: "••••••••",
										className: "block w-full pl-10 pr-4 py-3 bg-slate-900/90 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all min-h-[44px]"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 192,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: loading,
									className: "w-full flex justify-center items-center gap-2 py-3.5 px-4 border border-transparent rounded-xl shadow-lg shadow-indigo-500/25 text-sm font-bold text-white bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all disabled:opacity-50 min-h-[44px]",
									children: loading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-5 h-5 animate-spin" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 220,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: t("auth.registering") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 221,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 219,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(UserPlus, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 225,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: t("auth.register_button") }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 226,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 224,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 213,
									columnNumber: 15
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 212,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-6 pt-6 border-t border-slate-700/80 text-center",
							children: /* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm text-slate-400",
								children: [
									t("auth.already_have_account"),
									" ",
									/* @__PURE__ */ _jsxDEV(Link, {
										to: "/login",
										className: "font-bold text-indigo-400 hover:text-indigo-300 transition-colors ml-1",
										children: t("auth.login_now")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 236,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 233,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 114,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 80,
		columnNumber: 5
	}, this);
};
_s(RegisterPage, "z5GhcEsZlQuWhe2qrnHk6GERR7g=", false, function() {
	return [
		useTranslation,
		useNavigate,
		useUserStore
	];
});
_c = RegisterPage;
var _c;
$RefreshReg$(_c, "RegisterPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/RegisterPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/auth/RegisterPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/auth/RegisterPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/auth/RegisterPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGFBQWEsWUFBWTtBQUNsQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLFNBQVMsTUFBTSxNQUFNLE1BQU0sVUFBVSxTQUFTLGFBQWE7QUFDcEUsT0FBTyxTQUFTO0FBQ2hCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsYUFBYTs7OztBQUV0QixPQUFPLE1BQU0scUJBQXFCOztDQUNoQyxNQUFNLEVBQUUsR0FBRyxTQUFTLGVBQWU7Q0FDbkMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxFQUFFLFlBQVksYUFBYTtDQUVqQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVM7RUFDdkMsVUFBVTtFQUNWLE9BQU87RUFDUCxVQUFVO0VBQ1YsaUJBQWlCO0NBQ25CLENBQUM7Q0FDRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFO0NBQ25ELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTtDQUV2RCxNQUFNLGdCQUFnQixNQUFNO0VBQzFCLFlBQVk7R0FDVixHQUFHO0lBQ0YsRUFBRSxPQUFPLE9BQU8sRUFBRSxPQUFPO0VBQzVCLENBQUM7RUFDRCxJQUFJLGNBQWMsZ0JBQWdCLEVBQUU7Q0FDdEM7Q0FFQSxNQUFNLHVCQUF1QjtFQUMzQixNQUFNLFdBQVcsS0FBSyxhQUFhLE9BQU8sT0FBTztFQUNqRCxLQUFLLGVBQWUsUUFBUTtDQUM5QjtDQUVBLE1BQU0sZUFBZSxPQUFPLE1BQU07RUFDaEMsRUFBRSxlQUFlO0VBQ2pCLGdCQUFnQixFQUFFO0VBQ2xCLGtCQUFrQixFQUFFOztFQUdwQixJQUFJLFNBQVMsU0FBUyxTQUFTLEdBQUc7R0FDaEMsZ0JBQWdCLEVBQUUsMEJBQTBCLENBQUM7R0FDN0M7RUFDRjtFQUVBLElBQUksU0FBUyxhQUFhLFNBQVMsaUJBQWlCO0dBQ2xELGdCQUFnQixFQUFFLHdCQUF3QixDQUFDO0dBQzNDO0VBQ0Y7RUFFQSxXQUFXLElBQUk7RUFFZixJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sSUFBSSxLQUFLLGtCQUFrQjtJQUNoRCxVQUFVLFNBQVM7SUFDbkIsT0FBTyxTQUFTO0lBQ2hCLFVBQVUsU0FBUztHQUNyQixDQUFDO0dBRUQsSUFBSSxZQUFZLFNBQVMsV0FBVyxTQUFTLE1BQU07SUFDakQsTUFBTSxFQUFFLGFBQWEsU0FBUyxTQUFTO0lBQ3ZDLFFBQVEsYUFBYSxJQUFJO0lBQ3pCLGtCQUFrQixFQUFFLHVCQUF1QixDQUFDO0lBQzVDLGlCQUFpQjtLQUNmLFNBQVMsS0FBSyxFQUFFLFNBQVMsS0FBSyxDQUFDO0lBQ2pDLEdBQUcsR0FBSTtHQUNULE9BQU87SUFDTCxnQkFBZ0IsVUFBVSxXQUFXLEVBQUUsc0JBQXNCLENBQUM7R0FDaEU7RUFDRixTQUFTLEtBQUs7R0FDWixnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsc0JBQXNCLENBQUM7RUFDMUQsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRCxFQUFLLFdBQVUsa0dBQXVHOzs7OztHQUN0SCx3QkFBQyxPQUFELEVBQUssV0FBVSxvR0FBeUc7Ozs7O0dBR3hILHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFVO2VBRlosQ0FJRSx3QkFBQyxPQUFELEVBQU8sV0FBVSwwQkFBMkI7Ozs7ZUFDNUMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWEsS0FBSyxZQUFZO0tBQVc7Ozs7YUFDbkQ7Ozs7OztHQUNMOzs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7O01BQzNCOzs7O2dCQUNMLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUE0SDtNQUV0STs7OztjQUNIOzs7Ozs7S0FDTCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDWCxFQUFFLHFCQUFxQjtLQUN0Qjs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDVixFQUFFLHdCQUF3QjtLQUMxQjs7Ozs7SUFDQTs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0csZ0JBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsT0FBRDtRQUFPLFNBQVE7UUFBUyxPQUFPLEVBQUUsY0FBYztrQkFDNUM7T0FDSTs7Ozs7TUFDSjs7Ozs7TUFHTixrQkFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFEO1FBQU8sU0FBUTtRQUFVLE9BQU8sRUFBRSxnQkFBZ0I7a0JBQy9DO09BQ0k7Ozs7O01BQ0o7Ozs7O01BR1Asd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBWSxVQUFVO2lCQUF0QztRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFDZCxFQUFFLHFCQUFxQjtRQUNuQjs7OztrQkFDUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHlCQUEwQjs7Ozs7U0FDdkM7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxNQUFLO1VBQ0w7VUFDQSxPQUFPLFNBQVM7VUFDaEIsVUFBVTtVQUNWLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O2dCQUNGOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFDZCxFQUFFLGtCQUFrQjtRQUNoQjs7OztrQkFDUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHlCQUEwQjs7Ozs7U0FDdkM7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxNQUFLO1VBQ0w7VUFDQSxPQUFPLFNBQVM7VUFDaEIsVUFBVTtVQUNWLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O2dCQUNGOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFDZCxFQUFFLHFCQUFxQjtRQUNuQjs7OztrQkFDUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHlCQUEwQjs7Ozs7U0FDdkM7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxNQUFLO1VBQ0w7VUFDQSxPQUFPLFNBQVM7VUFDaEIsVUFBVTtVQUNWLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O2dCQUNGOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFDZCxFQUFFLDZCQUE2QjtRQUMzQjs7OztrQkFDUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHlCQUEwQjs7Ozs7U0FDdkM7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxNQUFLO1VBQ0w7VUFDQSxPQUFPLFNBQVM7VUFDaEIsVUFBVTtVQUNWLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O2dCQUNGOzs7OztRQUVMLHdCQUFDLE9BQUQsWUFDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFVBQVU7U0FDVixXQUFVO21CQUVULFVBQ0MsZ0RBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsdUJBQXdCOzs7O21CQUMzQyx3QkFBQyxRQUFELFlBQU8sRUFBRSxrQkFBa0IsRUFBUTs7OztpQkFDbkM7Ozs7b0JBRUYsZ0RBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OzttQkFDL0Isd0JBQUMsUUFBRCxZQUFPLEVBQUUsc0JBQXNCLEVBQVE7Ozs7aUJBQ3ZDOzs7OztRQUVFOzs7O2lCQUNMOzs7OztPQUNEOzs7Ozs7TUFFTix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUNHLEVBQUUsMkJBQTJCO1NBQUc7U0FDakMsd0JBQUMsTUFBRDtVQUNFLElBQUc7VUFDSCxXQUFVO29CQUVULEVBQUUsZ0JBQWdCO1NBQ2Y7Ozs7O1FBQ0w7Ozs7OztNQUNBOzs7OztLQUNGOzs7Ozs7R0FDRjs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmVnaXN0ZXJQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tICdyZWFjdC1pMThuZXh0JztcbmltcG9ydCB7IENvbXBhc3MsIFVzZXIsIE1haWwsIExvY2ssIFVzZXJQbHVzLCBMb2FkZXIyLCBHbG9iZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgYXBpIGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaSc7XG5pbXBvcnQgeyB1c2VVc2VyU3RvcmUgfSBmcm9tICcuLi8uLi9zdG9yZS91c2VVc2VyU3RvcmUnO1xuaW1wb3J0IHsgQWxlcnQgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0FsZXJ0JztcblxuZXhwb3J0IGNvbnN0IFJlZ2lzdGVyUGFnZSA9ICgpID0+IHtcbiAgY29uc3QgeyB0LCBpMThuIH0gPSB1c2VUcmFuc2xhdGlvbigpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHsgc2V0QXV0aCB9ID0gdXNlVXNlclN0b3JlKCk7XG5cbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XG4gICAgZnVsbE5hbWU6ICcnLFxuICAgIGVtYWlsOiAnJyxcbiAgICBwYXNzd29yZDogJycsXG4gICAgY29uZmlybVBhc3N3b3JkOiAnJyxcbiAgfSk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yTWVzc2FnZSwgc2V0RXJyb3JNZXNzYWdlXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3N1Y2Nlc3NNZXNzYWdlLCBzZXRTdWNjZXNzTWVzc2FnZV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcbiAgICBzZXRGb3JtRGF0YSh7XG4gICAgICAuLi5mb3JtRGF0YSxcbiAgICAgIFtlLnRhcmdldC5uYW1lXTogZS50YXJnZXQudmFsdWUsXG4gICAgfSk7XG4gICAgaWYgKGVycm9yTWVzc2FnZSkgc2V0RXJyb3JNZXNzYWdlKCcnKTtcbiAgfTtcblxuICBjb25zdCB0b2dnbGVMYW5ndWFnZSA9ICgpID0+IHtcbiAgICBjb25zdCBuZXh0TGFuZyA9IGkxOG4ubGFuZ3VhZ2UgPT09ICd2aScgPyAnZW4nIDogJ3ZpJztcbiAgICBpMThuLmNoYW5nZUxhbmd1YWdlKG5leHRMYW5nKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRFcnJvck1lc3NhZ2UoJycpO1xuICAgIHNldFN1Y2Nlc3NNZXNzYWdlKCcnKTtcblxuICAgIC8vIENsaWVudC1zaWRlIHZhbGlkYXRpb25zXG4gICAgaWYgKGZvcm1EYXRhLnBhc3N3b3JkLmxlbmd0aCA8IDYpIHtcbiAgICAgIHNldEVycm9yTWVzc2FnZSh0KCdhdXRoLnBhc3N3b3JkX21pbl9sZW5ndGgnKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGZvcm1EYXRhLnBhc3N3b3JkICE9PSBmb3JtRGF0YS5jb25maXJtUGFzc3dvcmQpIHtcbiAgICAgIHNldEVycm9yTWVzc2FnZSh0KCdhdXRoLnBhc3N3b3JkX21pc21hdGNoJykpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldExvYWRpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdCgnL2F1dGgvcmVnaXN0ZXInLCB7XG4gICAgICAgIGZ1bGxOYW1lOiBmb3JtRGF0YS5mdWxsTmFtZSxcbiAgICAgICAgZW1haWw6IGZvcm1EYXRhLmVtYWlsLFxuICAgICAgICBwYXNzd29yZDogZm9ybURhdGEucGFzc3dvcmQsXG4gICAgICB9KTtcblxuICAgICAgaWYgKHJlc3BvbnNlICYmIHJlc3BvbnNlLnN1Y2Nlc3MgJiYgcmVzcG9uc2UuZGF0YSkge1xuICAgICAgICBjb25zdCB7IGFjY2Vzc1Rva2VuLCB1c2VyIH0gPSByZXNwb25zZS5kYXRhO1xuICAgICAgICBzZXRBdXRoKGFjY2Vzc1Rva2VuLCB1c2VyKTtcbiAgICAgICAgc2V0U3VjY2Vzc01lc3NhZ2UodCgnYXV0aC5yZWdpc3Rlcl9zdWNjZXNzJykpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBuYXZpZ2F0ZSgnLycsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICAgICAgfSwgMTAwMCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRFcnJvck1lc3NhZ2UocmVzcG9uc2U/Lm1lc3NhZ2UgfHwgdCgnYXV0aC5yZWdpc3Rlcl9mYWlsZWQnKSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvck1lc3NhZ2UoZXJyLm1lc3NhZ2UgfHwgdCgnYXV0aC5yZWdpc3Rlcl9mYWlsZWQnKSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTkwMCBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIHB5LTEyIHNtOnB4LTYgbGc6cHgtOCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgIHsvKiBCYWNrZ3JvdW5kIEdsb3cgT3ZlcmxheSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC00MCAtcmlnaHQtNDAgdy05NiBoLTk2IGJnLWluZGlnby02MDAvMzAgcm91bmRlZC1mdWxsIGJsdXItM3hsIHBvaW50ZXItZXZlbnRzLW5vbmVcIj48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWJvdHRvbS00MCAtbGVmdC00MCB3LTk2IGgtOTYgYmctdmlvbGV0LTYwMC8zMCByb3VuZGVkLWZ1bGwgYmx1ci0zeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiPjwvZGl2PlxuXG4gICAgICB7LyogVG9wIHJpZ2h0IGxhbmd1YWdlIHRvZ2dsZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCB6LTEwXCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVMYW5ndWFnZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlIGJnLXNsYXRlLTgwMC84MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIG1pbi1oLVs0NHB4XVwiXG4gICAgICAgID5cbiAgICAgICAgICA8R2xvYmUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWluZGlnby00MDBcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVwcGVyY2FzZVwiPntpMThuLmxhbmd1YWdlIHx8ICdWSSd9PC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOm14LWF1dG8gc206dy1mdWxsIHNtOm1heC13LW1kIHotMTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBnYXAtMyBtYi0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS1pbmRpZ28tNTAwIHRvLXZpb2xldC01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctbGcgc2hhZG93LWluZGlnby01MDAvMzBcIj5cbiAgICAgICAgICAgIDxDb21wYXNzIGNsYXNzTmFtZT1cInctNyBoLTdcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYmxhY2sgYmctZ3JhZGllbnQtdG8tciBmcm9tLWluZGlnby00MDAgdmlhLXZpb2xldC0zMDAgdG8td2hpdGUgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnQgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgIFRyaXBNYXRlXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LXdoaXRlIG10LTJcIj5cbiAgICAgICAgICB7dCgnYXV0aC5yZWdpc3Rlcl90aXRsZScpfVxuICAgICAgICA8L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICB7dCgnYXV0aC5yZWdpc3Rlcl9zdWJ0aXRsZScpfVxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHNtOm14LWF1dG8gc206dy1mdWxsIHNtOm1heC13LW1kIHotMTAgcHgtNCBzbTpweC0wXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtODAwLzkwIGJhY2tkcm9wLWJsdXIteGwgcHktOCBweC00IHNoYWRvdy0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAvODAgc206cm91bmRlZC0yeGwgc206cHgtMTBcIj5cbiAgICAgICAgICB7ZXJyb3JNZXNzYWdlICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxuICAgICAgICAgICAgICA8QWxlcnQgdmFyaWFudD1cImRhbmdlclwiIHRpdGxlPXt0KCdjb21tb24uZXJyb3InKX0+XG4gICAgICAgICAgICAgICAge2Vycm9yTWVzc2FnZX1cbiAgICAgICAgICAgICAgPC9BbGVydD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7c3VjY2Vzc01lc3NhZ2UgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XG4gICAgICAgICAgICAgIDxBbGVydCB2YXJpYW50PVwic3VjY2Vzc1wiIHRpdGxlPXt0KCdjb21tb24uc3VjY2VzcycpfT5cbiAgICAgICAgICAgICAgICB7c3VjY2Vzc01lc3NhZ2V9XG4gICAgICAgICAgICAgIDwvQWxlcnQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS01XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgIHt0KCdhdXRoLmZ1bGxuYW1lX2xhYmVsJyl9XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC14bCBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcGwtMy41IGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cbiAgICAgICAgICAgICAgICAgIDxVc2VyIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1zbGF0ZS01MDBcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgbmFtZT1cImZ1bGxOYW1lXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZnVsbE5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOZ3V54buFbiBWxINuIEFcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgdy1mdWxsIHBsLTEwIHByLTQgcHktMyBiZy1zbGF0ZS05MDAvOTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWFsbCBtaW4taC1bNDRweF1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDAgbWItMS41XCI+XG4gICAgICAgICAgICAgICAge3QoJ2F1dGguZW1haWxfbGFiZWwnKX1cbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSByb3VuZGVkLXhsIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC0zLjUgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgPE1haWwgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LXNsYXRlLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgbmFtZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1haWx9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJuYW1lQGV4YW1wbGUuY29tXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBwbC0xMCBwci00IHB5LTMgYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS01MDAgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1hbGwgbWluLWgtWzQ0cHhdXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgIHt0KCdhdXRoLnBhc3N3b3JkX2xhYmVsJyl9XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC14bCBzaGFkb3cteHNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcGwtMy41IGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cbiAgICAgICAgICAgICAgICAgIDxMb2NrIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1zbGF0ZS01MDBcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBwbC0xMCBwci00IHB5LTMgYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS01MDAgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1hbGwgbWluLWgtWzQ0cHhdXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgIHt0KCdhdXRoLmNvbmZpcm1fcGFzc3dvcmRfbGFiZWwnKX1cbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSByb3VuZGVkLXhsIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC0zLjUgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LXNsYXRlLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgbmFtZT1cImNvbmZpcm1QYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvbmZpcm1QYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAouKAouKAolwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgcGwtMTAgcHItNCBweS0zIGJnLXNsYXRlLTkwMC85MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNTAwIHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tYWxsIG1pbi1oLVs0NHB4XVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBnYXAtMiBweS0zLjUgcHgtNCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1pbmRpZ28tNTAwLzI1IHRleHQtc20gZm9udC1ib2xkIHRleHQtd2hpdGUgYmctZ3JhZGllbnQtdG8tciBmcm9tLWluZGlnby02MDAgdG8tdmlvbGV0LTYwMCBob3Zlcjpmcm9tLWluZGlnby01MDAgaG92ZXI6dG8tdmlvbGV0LTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctb2Zmc2V0LTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwIHRyYW5zaXRpb24tYWxsIGRpc2FibGVkOm9wYWNpdHktNTAgbWluLWgtWzQ0cHhdXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwidy01IGgtNSBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57dCgnYXV0aC5yZWdpc3RlcmluZycpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8VXNlclBsdXMgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt0KCdhdXRoLnJlZ2lzdGVyX2J1dHRvbicpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTcwMC84MCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICB7dCgnYXV0aC5hbHJlYWR5X2hhdmVfYWNjb3VudCcpfXsnICd9XG4gICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgdG89XCIvbG9naW5cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWluZGlnby00MDAgaG92ZXI6dGV4dC1pbmRpZ28tMzAwIHRyYW5zaXRpb24tY29sb3JzIG1sLTFcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3QoJ2F1dGgubG9naW5fbm93Jyl9XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=