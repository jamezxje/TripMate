/**
* Formats a number or string to Vietnamese Currency (VND)
*/
export const formatCurrency = (amount) => {
	if (amount === undefined || amount === null) return "0 ₫";
	return new Intl.NumberFormat("vi-VN", {
		style: "currency",
		currency: "VND"
	}).format(amount);
};
/**
* Formats an ISO date string to readable locale date
*/
export const formatDate = (dateString) => {
	if (!dateString) return "";
	const date = new Date(dateString);
	return date.toLocaleDateString("vi-VN", {
		day: "2-digit",
		month: "2-digit",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	});
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7O0FBR0EsT0FBTyxNQUFNLGtCQUFrQixXQUFXO0NBQ3hDLElBQUksV0FBVyxhQUFhLFdBQVcsTUFBTSxPQUFPO0NBQ3BELE9BQU8sSUFBSSxLQUFLLGFBQWEsU0FBUztFQUNwQyxPQUFPO0VBQ1AsVUFBVTtDQUNaLENBQUMsQ0FBQyxDQUFDLE9BQU8sTUFBTTtBQUNsQjs7OztBQUtBLE9BQU8sTUFBTSxjQUFjLGVBQWU7Q0FDeEMsSUFBSSxDQUFDLFlBQVksT0FBTztDQUN4QixNQUFNLE9BQU8sSUFBSSxLQUFLLFVBQVU7Q0FDaEMsT0FBTyxLQUFLLG1CQUFtQixTQUFTO0VBQ3RDLEtBQUs7RUFDTCxPQUFPO0VBQ1AsTUFBTTtFQUNOLE1BQU07RUFDTixRQUFRO0NBQ1YsQ0FBQztBQUNIIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImZvcm1hdHRlcnMuanMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBGb3JtYXRzIGEgbnVtYmVyIG9yIHN0cmluZyB0byBWaWV0bmFtZXNlIEN1cnJlbmN5IChWTkQpXG4gKi9cbmV4cG9ydCBjb25zdCBmb3JtYXRDdXJyZW5jeSA9IChhbW91bnQpID0+IHtcbiAgaWYgKGFtb3VudCA9PT0gdW5kZWZpbmVkIHx8IGFtb3VudCA9PT0gbnVsbCkgcmV0dXJuICcwIOKCqyc7XG4gIHJldHVybiBuZXcgSW50bC5OdW1iZXJGb3JtYXQoJ3ZpLVZOJywge1xuICAgIHN0eWxlOiAnY3VycmVuY3knLFxuICAgIGN1cnJlbmN5OiAnVk5EJyxcbiAgfSkuZm9ybWF0KGFtb3VudCk7XG59O1xuXG4vKipcbiAqIEZvcm1hdHMgYW4gSVNPIGRhdGUgc3RyaW5nIHRvIHJlYWRhYmxlIGxvY2FsZSBkYXRlXG4gKi9cbmV4cG9ydCBjb25zdCBmb3JtYXREYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcbiAgaWYgKCFkYXRlU3RyaW5nKSByZXR1cm4gJyc7XG4gIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlU3RyaW5nKTtcbiAgcmV0dXJuIGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCd2aS1WTicsIHtcbiAgICBkYXk6ICcyLWRpZ2l0JyxcbiAgICBtb250aDogJzItZGlnaXQnLFxuICAgIHllYXI6ICdudW1lcmljJyxcbiAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgbWludXRlOiAnMi1kaWdpdCcsXG4gIH0pO1xufTtcbiJdfQ==