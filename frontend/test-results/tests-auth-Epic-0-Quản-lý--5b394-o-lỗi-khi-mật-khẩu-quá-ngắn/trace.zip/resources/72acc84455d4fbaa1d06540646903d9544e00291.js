import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/expenses/ExpenseList.jsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Receipt, Plus, RefreshCw, Wallet, UserCheck, Calendar } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import { Card, CardHeader, CardBody } from "/src/components/Card.jsx";
import { Button } from "/src/components/Button.jsx";
import { Modal } from "/src/components/Modal.jsx";
import { Badge } from "/src/components/Badge.jsx";
import { Alert } from "/src/components/Alert.jsx";
import { SplitExpenseForm } from "/src/features/expenses/SplitExpenseForm.jsx";
import { expenseApi } from "/src/features/expenses/expenseApi.js";
import { useTripStore } from "/src/store/useTripStore.js";
import { formatCurrency, formatDate } from "/src/utils/formatters.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/expenses/ExpenseList.jsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const ExpenseList = () => {
	_s();
	const { t } = useTranslation();
	const { currentTrip } = useTripStore();
	const [expenses, setExpenses] = useState([]);
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState("");
	const [isModalOpen, setIsModalOpen] = useState(false);
	const fetchExpenses = useCallback(async () => {
		if (!currentTrip?.id) return;
		setIsLoading(true);
		setError("");
		try {
			const res = await expenseApi.getExpensesByTripId(currentTrip.id);
			if (res.data) {
				setExpenses(res.data);
			}
		} catch (err) {
			setError(err.message || "Không thể tải danh sách chi tiêu");
		} finally {
			setIsLoading(false);
		}
	}, [currentTrip?.id]);
	useEffect(() => {
		fetchExpenses();
	}, [fetchExpenses]);
	if (!currentTrip) {
		return /* @__PURE__ */ _jsxDEV(Card, {
			className: "text-center py-12",
			children: [
				/* @__PURE__ */ _jsxDEV(Receipt, { className: "w-12 h-12 text-slate-300 mx-auto mb-3" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-lg font-bold text-slate-800",
					children: "Chưa chọn Chuyến đi"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-slate-500 text-sm mt-1",
					children: "Vui lòng chọn hoặc tạo mới chuyến đi ở trang danh sách để quản lý chi tiêu."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Receipt, { className: "w-7 h-7 text-indigo-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
						t("expense.list_title", "Danh sách Chi tiêu"),
						" - ",
						currentTrip.name
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-slate-500 text-sm mt-0.5",
					children: "Ghi chép và phân bổ các khoản chi trong chuyến đi."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						icon: RefreshCw,
						onClick: fetchExpenses,
						isLoading,
						children: "Tải lại"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						icon: Plus,
						onClick: () => setIsModalOpen(true),
						children: "Thêm khoản chi mới"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV(Alert, {
				type: "error",
				message: error,
				onClose: () => setError("")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 17
			}, this),
			expenses && expenses.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 gap-4",
				children: expenses.map((item) => /* @__PURE__ */ _jsxDEV(Card, {
					className: "hover:border-indigo-200 transition-colors",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-indigo-50 text-indigo-600 rounded-2xl shrink-0 mt-0.5",
								children: /* @__PURE__ */ _jsxDEV(Receipt, { className: "w-6 h-6" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 89,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-black text-slate-800",
								children: item.description
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap items-center gap-2 mt-1 text-xs text-slate-500",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5 text-slate-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 95,
											columnNumber: 25
										}, this), formatDate(item.createdAt)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 94,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 98,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: ["Người ghi: ", /* @__PURE__ */ _jsxDEV("strong", {
										className: "text-slate-700",
										children: item.createdByName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 99,
										columnNumber: 40
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 99,
										columnNumber: 23
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 93,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 91,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col md:items-end",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-black text-indigo-600",
								children: formatCurrency(item.amount)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-1 flex items-center gap-1.5",
								children: [item.isPaidByFund ? /* @__PURE__ */ _jsxDEV(Badge, {
									variant: "settled",
									className: "gap-1",
									children: [/* @__PURE__ */ _jsxDEV(Wallet, { className: "w-3 h-3" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 111,
										columnNumber: 25
									}, this), " Trả từ Quỹ chung"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 110,
									columnNumber: 23
								}, this) : /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-500 font-medium",
									children: ["Trả bởi: ", /* @__PURE__ */ _jsxDEV("strong", {
										className: "text-slate-800",
										children: item.payerName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 115,
										columnNumber: 34
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV(Badge, {
									variant: "info",
									children: item.splitType
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs font-bold text-slate-500 uppercase tracking-wider mb-2",
						children: [
							"Phân bổ chi phí (",
							item.splits?.length || 0,
							" người chịu)"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2",
						children: item.splits?.map((split) => /* @__PURE__ */ _jsxDEV("div", {
							className: "p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-700 truncate max-w-[100px]",
								children: split.userName
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 23
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-slate-900",
								children: formatCurrency(split.amountOwed)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 23
							}, this)]
						}, split.id, true, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 21
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 15
					}, this)]
				}, item.id, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV(Card, {
				className: "text-center py-12",
				children: [
					/* @__PURE__ */ _jsxDEV(Receipt, { className: "w-12 h-12 text-slate-300 mx-auto mb-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-lg font-bold text-slate-800",
						children: "Chưa có khoản chi nào"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-slate-500 text-sm mt-1",
						children: "Bấm \"Thêm khoản chi mới\" để bắt đầu ghi chép chi tiêu cho chuyến đi!"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 148,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(Modal, {
				isOpen: isModalOpen,
				onClose: () => setIsModalOpen(false),
				title: "Thêm khoản chi tiêu mới",
				maxWidth: "max-w-2xl",
				children: /* @__PURE__ */ _jsxDEV(SplitExpenseForm, {
					onSuccess: () => {
						setIsModalOpen(false);
						fetchExpenses();
					},
					onCancel: () => setIsModalOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 164,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 158,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 5
	}, this);
};
_s(ExpenseList, "ZIBt5r1gudqB9yEl0qcabCdlBrk=", false, function() {
	return [useTranslation, useTripStore];
});
_c = ExpenseList;
var _c;
$RefreshReg$(_c, "ExpenseList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/expenses/ExpenseList.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/expenses/ExpenseList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/expenses/ExpenseList.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/expenses/ExpenseList.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsVUFBVSxtQkFBbUI7QUFDeEQsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxTQUFTLE1BQU0sV0FBVyxRQUFRLFdBQVcsZ0JBQWdCO0FBQ3RFLFNBQVMsTUFBTSxZQUFZLGdCQUFnQjtBQUMzQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsYUFBYTtBQUN0QixTQUFTLGFBQWE7QUFDdEIsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxnQkFBZ0Isa0JBQWtCOzs7O0FBRTNDLE9BQU8sTUFBTSxvQkFBb0I7O0NBQy9CLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FDN0IsTUFBTSxFQUFFLGdCQUFnQixhQUFhO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxDQUFDLENBQUM7Q0FDM0MsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBRXBELE1BQU0sZ0JBQWdCLFlBQVksWUFBWTtFQUM1QyxJQUFJLENBQUMsYUFBYSxJQUFJO0VBQ3RCLGFBQWEsSUFBSTtFQUNqQixTQUFTLEVBQUU7RUFFWCxJQUFJO0dBQ0YsTUFBTSxNQUFNLE1BQU0sV0FBVyxvQkFBb0IsWUFBWSxFQUFFO0dBQy9ELElBQUksSUFBSSxNQUFNO0lBQ1osWUFBWSxJQUFJLElBQUk7R0FDdEI7RUFDRixTQUFTLEtBQUs7R0FDWixTQUFTLElBQUksV0FBVyxrQ0FBa0M7RUFDNUQsVUFBVTtHQUNSLGFBQWEsS0FBSztFQUNwQjtDQUNGLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztDQUVwQixnQkFBZ0I7RUFDZCxjQUFjO0NBQ2hCLEdBQUcsQ0FBQyxhQUFhLENBQUM7Q0FFbEIsSUFBSSxDQUFDLGFBQWE7RUFDaEIsT0FDRSx3QkFBQyxNQUFEO0dBQU0sV0FBVTthQUFoQjtJQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLHdDQUF5Qzs7Ozs7SUFDNUQsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBbUM7SUFBdUI7Ozs7O0lBQ3hFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCO0lBRXhDOzs7OztHQUNDOzs7Ozs7Q0FFVjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLDBCQUEyQjs7OztlQUM5Qyx3QkFBQyxRQUFEO01BQU8sRUFBRSxzQkFBc0Isb0JBQW9CO01BQUU7TUFBSSxZQUFZO0tBQVc7Ozs7YUFDOUU7Ozs7O2NBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBZ0M7SUFFMUM7Ozs7WUFDQTs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQVEsU0FBUTtNQUFVLE1BQU07TUFBVyxTQUFTO01BQTBCO2dCQUFXO0tBRWpGOzs7O2VBQ1Isd0JBQUMsUUFBRDtNQUFRLE1BQU07TUFBTSxlQUFlLGVBQWUsSUFBSTtnQkFBRztLQUVqRDs7OzthQUNMOzs7OztZQUNGOzs7Ozs7R0FFSixTQUFTLHdCQUFDLE9BQUQ7SUFBTyxNQUFLO0lBQVEsU0FBUztJQUFPLGVBQWUsU0FBUyxFQUFFO0dBQUk7Ozs7O0dBRzNFLFlBQVksU0FBUyxTQUFTLElBQzdCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osU0FBUyxLQUFLLFNBQ2Isd0JBQUMsTUFBRDtLQUFvQixXQUFVO2VBQTlCLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7O09BQzNCOzs7O2lCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBcUMsS0FBSztPQUFnQjs7OztpQkFDeEUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSw2QkFBOEI7Ozs7b0JBQ2pELFdBQVcsS0FBSyxTQUFTLENBQ3RCOzs7Ozs7U0FDTix3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7U0FDYix3QkFBQyxRQUFELGFBQU0sZUFBVyx3QkFBQyxVQUFEO1VBQVEsV0FBVTtvQkFBa0IsS0FBSztTQUFzQjs7OztpQkFBTzs7Ozs7UUFDcEY7Ozs7O2VBQ0Y7Ozs7ZUFDRjs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixlQUFlLEtBQUssTUFBTTtPQUN2Qjs7OztpQkFDTix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNHLEtBQUssZUFDSix3QkFBQyxPQUFEO1NBQU8sU0FBUTtTQUFVLFdBQVU7bUJBQW5DLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7OzttQkFBQyxtQkFDekI7Ozs7O21CQUVQLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUFxRCxhQUMxQyx3QkFBQyxVQUFEO1VBQVEsV0FBVTtvQkFBa0IsS0FBSztTQUFrQjs7OztpQkFDaEU7Ozs7O2tCQUVSLHdCQUFDLE9BQUQ7U0FBTyxTQUFRO21CQUFRLEtBQUs7UUFBaUI7Ozs7Z0JBQzFDOzs7OztlQUNGOzs7OztjQUNGOzs7OztlQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUE4RTtPQUMxRCxLQUFLLFFBQVEsVUFBVTtPQUFFO01BQzFDOzs7OztlQUNILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLEtBQUssUUFBUSxLQUFLLFVBQ2pCLHdCQUFDLE9BQUQ7T0FFRSxXQUFVO2lCQUZaLENBSUUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsTUFBTTtPQUNIOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLGVBQWUsTUFBTSxVQUFVO09BQzVCOzs7O2VBQ0g7U0FURSxNQUFNOzs7O2FBU1IsQ0FDTjtLQUNFOzs7O2FBQ0Y7Ozs7YUFDRDtPQTNESyxLQUFLOzs7O1dBMkRWLENBQ1A7R0FDRTs7OztjQUVMLHdCQUFDLE1BQUQ7SUFBTSxXQUFVO2NBQWhCO0tBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsd0NBQXlDOzs7OztLQUM1RCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBbUM7S0FBeUI7Ozs7O0tBQzFFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE4QjtLQUV4Qzs7Ozs7SUFDQzs7Ozs7O0dBSVIsd0JBQUMsT0FBRDtJQUNFLFFBQVE7SUFDUixlQUFlLGVBQWUsS0FBSztJQUNuQyxPQUFNO0lBQ04sVUFBUztjQUVULHdCQUFDLGtCQUFEO0tBQ0UsaUJBQWlCO01BQ2YsZUFBZSxLQUFLO01BQ3BCLGNBQWM7S0FDaEI7S0FDQSxnQkFBZ0IsZUFBZSxLQUFLO0lBQ3JDOzs7OztHQUNJOzs7OztFQUNKOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJFeHBlbnNlTGlzdC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tICdyZWFjdC1pMThuZXh0JztcbmltcG9ydCB7IFJlY2VpcHQsIFBsdXMsIFJlZnJlc2hDdywgV2FsbGV0LCBVc2VyQ2hlY2ssIENhbGVuZGFyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IENhcmQsIENhcmRIZWFkZXIsIENhcmRCb2R5IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9DYXJkJztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvQnV0dG9uJztcbmltcG9ydCB7IE1vZGFsIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9Nb2RhbCc7XG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvQmFkZ2UnO1xuaW1wb3J0IHsgQWxlcnQgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0FsZXJ0JztcbmltcG9ydCB7IFNwbGl0RXhwZW5zZUZvcm0gfSBmcm9tICcuL1NwbGl0RXhwZW5zZUZvcm0nO1xuaW1wb3J0IHsgZXhwZW5zZUFwaSB9IGZyb20gJy4vZXhwZW5zZUFwaSc7XG5pbXBvcnQgeyB1c2VUcmlwU3RvcmUgfSBmcm9tICcuLi8uLi9zdG9yZS91c2VUcmlwU3RvcmUnO1xuaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3ksIGZvcm1hdERhdGUgfSBmcm9tICcuLi8uLi91dGlscy9mb3JtYXR0ZXJzJztcblxuZXhwb3J0IGNvbnN0IEV4cGVuc2VMaXN0ID0gKCkgPT4ge1xuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XG4gIGNvbnN0IHsgY3VycmVudFRyaXAgfSA9IHVzZVRyaXBTdG9yZSgpO1xuICBjb25zdCBbZXhwZW5zZXMsIHNldEV4cGVuc2VzXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtpc01vZGFsT3Blbiwgc2V0SXNNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGZldGNoRXhwZW5zZXMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFjdXJyZW50VHJpcD8uaWQpIHJldHVybjtcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IoJycpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGV4cGVuc2VBcGkuZ2V0RXhwZW5zZXNCeVRyaXBJZChjdXJyZW50VHJpcC5pZCk7XG4gICAgICBpZiAocmVzLmRhdGEpIHtcbiAgICAgICAgc2V0RXhwZW5zZXMocmVzLmRhdGEpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgJ0tow7RuZyB0aOG7gyB04bqjaSBkYW5oIHPDoWNoIGNoaSB0acOqdScpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfSwgW2N1cnJlbnRUcmlwPy5pZF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2hFeHBlbnNlcygpO1xuICB9LCBbZmV0Y2hFeHBlbnNlc10pO1xuXG4gIGlmICghY3VycmVudFRyaXApIHtcbiAgICByZXR1cm4gKFxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cbiAgICAgICAgPFJlY2VpcHQgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtc2xhdGUtMzAwIG14LWF1dG8gbWItM1wiIC8+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPkNoxrBhIGNo4buNbiBDaHV54bq/biDEkWk8L2gzPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCB0ZXh0LXNtIG10LTFcIj5cbiAgICAgICAgICBWdWkgbMOybmcgY2jhu41uIGhv4bq3YyB04bqhbyBt4bubaSBjaHV54bq/biDEkWkg4bufIHRyYW5nIGRhbmggc8OhY2ggxJHhu4MgcXXhuqNuIGzDvSBjaGkgdGnDqnUuXG4gICAgICAgIDwvcD5cbiAgICAgIDwvQ2FyZD5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTZcIj5cbiAgICAgIHsvKiBUb3AgSGVhZGVyICYgQWN0aW9ucyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS04MDAgdHJhY2tpbmctdGlnaHQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxSZWNlaXB0IGNsYXNzTmFtZT1cInctNyBoLTcgdGV4dC1pbmRpZ28tNjAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPnt0KCdleHBlbnNlLmxpc3RfdGl0bGUnLCAnRGFuaCBzw6FjaCBDaGkgdGnDqnUnKX0gLSB7Y3VycmVudFRyaXAubmFtZX08L3NwYW4+XG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCB0ZXh0LXNtIG10LTAuNVwiPlxuICAgICAgICAgICAgR2hpIGNow6lwIHbDoCBwaMOibiBi4buVIGPDoWMga2hv4bqjbiBjaGkgdHJvbmcgY2h1eeG6v24gxJFpLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBpY29uPXtSZWZyZXNoQ3d9IG9uQ2xpY2s9e2ZldGNoRXhwZW5zZXN9IGlzTG9hZGluZz17aXNMb2FkaW5nfT5cbiAgICAgICAgICAgIFThuqNpIGzhuqFpXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiBpY29uPXtQbHVzfSBvbkNsaWNrPXsoKSA9PiBzZXRJc01vZGFsT3Blbih0cnVlKX0+XG4gICAgICAgICAgICBUaMOqbSBraG/huqNuIGNoaSBt4bubaVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3IgJiYgPEFsZXJ0IHR5cGU9XCJlcnJvclwiIG1lc3NhZ2U9e2Vycm9yfSBvbkNsb3NlPXsoKSA9PiBzZXRFcnJvcignJyl9IC8+fVxuXG4gICAgICB7LyogRXhwZW5zZXMgSGlzdG9yeSBMaXN0ICovfVxuICAgICAge2V4cGVuc2VzICYmIGV4cGVuc2VzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNFwiPlxuICAgICAgICAgIHtleHBlbnNlcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgIDxDYXJkIGtleT17aXRlbS5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ym9yZGVyLWluZGlnby0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBwYi00IG1iLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLWluZGlnby01MCB0ZXh0LWluZGlnby02MDAgcm91bmRlZC0yeGwgc2hyaW5rLTAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxSZWNlaXB0IGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwXCI+e2l0ZW0uZGVzY3JpcHRpb259PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtMSB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZShpdGVtLmNyZWF0ZWRBdCl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKAojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5OZ8aw4budaSBnaGk6IDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDBcIj57aXRlbS5jcmVhdGVkQnlOYW1lfTwvc3Ryb25nPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDppdGVtcy1lbmRcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1pbmRpZ28tNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtmb3JtYXRDdXJyZW5jeShpdGVtLmFtb3VudCl9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5pc1BhaWRCeUZ1bmQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJzZXR0bGVkXCIgY2xhc3NOYW1lPVwiZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxXYWxsZXQgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+IFRy4bqjIHThu6sgUXXhu7kgY2h1bmdcbiAgICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFRy4bqjIGLhu59pOiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtODAwXCI+e2l0ZW0ucGF5ZXJOYW1lfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJpbmZvXCI+e2l0ZW0uc3BsaXRUeXBlfTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFNwbGl0cyBMaXN0ICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICBQaMOibiBi4buVIGNoaSBwaMOtICh7aXRlbS5zcGxpdHM/Lmxlbmd0aCB8fCAwfSBuZ8aw4budaSBjaOG7i3UpXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBtZDpncmlkLWNvbHMtNCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAge2l0ZW0uc3BsaXRzPy5tYXAoKHNwbGl0KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e3NwbGl0LmlkfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQteGwgYmctc2xhdGUtNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCB0cnVuY2F0ZSBtYXgtdy1bMTAwcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c3BsaXQudXNlck5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KHNwbGl0LmFtb3VudE93ZWQpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cbiAgICAgICAgICA8UmVjZWlwdCBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1zbGF0ZS0zMDAgbXgtYXV0byBtYi0zXCIgLz5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5DaMawYSBjw7Mga2hv4bqjbiBjaGkgbsOgbzwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBtdC0xXCI+XG4gICAgICAgICAgICBC4bqlbSBcIlRow6ptIGtob+G6o24gY2hpIG3hu5tpXCIgxJHhu4MgYuG6r3QgxJHhuqd1IGdoaSBjaMOpcCBjaGkgdGnDqnUgY2hvIGNodXnhur9uIMSRaSFcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBDcmVhdGUgRXhwZW5zZSBNb2RhbCAqL31cbiAgICAgIDxNb2RhbFxuICAgICAgICBpc09wZW49e2lzTW9kYWxPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJc01vZGFsT3BlbihmYWxzZSl9XG4gICAgICAgIHRpdGxlPVwiVGjDqm0ga2hv4bqjbiBjaGkgdGnDqnUgbeG7m2lcIlxuICAgICAgICBtYXhXaWR0aD1cIm1heC13LTJ4bFwiXG4gICAgICA+XG4gICAgICAgIDxTcGxpdEV4cGVuc2VGb3JtXG4gICAgICAgICAgb25TdWNjZXNzPXsoKSA9PiB7XG4gICAgICAgICAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XG4gICAgICAgICAgICBmZXRjaEV4cGVuc2VzKCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0SXNNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAvPlxuICAgICAgPC9Nb2RhbD5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=