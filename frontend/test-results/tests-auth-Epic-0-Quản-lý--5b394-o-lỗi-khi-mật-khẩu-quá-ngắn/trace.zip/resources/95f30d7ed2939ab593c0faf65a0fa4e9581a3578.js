//#region node_modules/i18next/dist/esm/i18next.js
var isString = (obj) => typeof obj === "string";
var defer = () => {
	let res;
	let rej;
	const promise = new Promise((resolve, reject) => {
		res = resolve;
		rej = reject;
	});
	promise.resolve = res;
	promise.reject = rej;
	return promise;
};
var makeString = (object) => {
	if (object == null) return "";
	return String(object);
};
var copy = (a, s, t) => {
	a.forEach((m) => {
		if (s[m]) t[m] = s[m];
	});
};
var lastOfPathSeparatorRegExp = /###/g;
var cleanKey = (key) => key && key.includes("###") ? key.replace(lastOfPathSeparatorRegExp, ".") : key;
var canNotTraverseDeeper = (object) => !object || isString(object);
var getLastOfPath = (object, path, Empty) => {
	const stack = !isString(path) ? path : path.split(".");
	let stackIndex = 0;
	while (stackIndex < stack.length - 1) {
		if (canNotTraverseDeeper(object)) return {};
		const key = cleanKey(stack[stackIndex]);
		if (!object[key] && Empty) object[key] = new Empty();
		if (Object.prototype.hasOwnProperty.call(object, key)) object = object[key];
		else object = {};
		++stackIndex;
	}
	if (canNotTraverseDeeper(object)) return {};
	return {
		obj: object,
		k: cleanKey(stack[stackIndex])
	};
};
var setPath = (object, path, newValue) => {
	const { obj, k } = getLastOfPath(object, path, Object);
	if (obj !== void 0 || path.length === 1) {
		obj[k] = newValue;
		return;
	}
	let e = path[path.length - 1];
	let p = path.slice(0, path.length - 1);
	let last = getLastOfPath(object, p, Object);
	while (last.obj === void 0 && p.length) {
		e = `${p[p.length - 1]}.${e}`;
		p = p.slice(0, p.length - 1);
		last = getLastOfPath(object, p, Object);
		if (last?.obj && typeof last.obj[`${last.k}.${e}`] !== "undefined") last.obj = void 0;
	}
	last.obj[`${last.k}.${e}`] = newValue;
};
var pushPath = (object, path, newValue, concat) => {
	const { obj, k } = getLastOfPath(object, path, Object);
	obj[k] = obj[k] || [];
	obj[k].push(newValue);
};
var getPath = (object, path) => {
	const { obj, k } = getLastOfPath(object, path);
	if (!obj) return void 0;
	if (!Object.prototype.hasOwnProperty.call(obj, k)) return void 0;
	return obj[k];
};
var getPathWithDefaults = (data, defaultData, key) => {
	const value = getPath(data, key);
	if (value !== void 0) return value;
	return getPath(defaultData, key);
};
var deepExtend = (target, source, overwrite) => {
	for (const prop in source) if (prop !== "__proto__" && prop !== "constructor") if (Object.prototype.hasOwnProperty.call(target, prop)) if (isString(target[prop]) || target[prop] instanceof String || isString(source[prop]) || source[prop] instanceof String) {
		if (overwrite) target[prop] = source[prop];
	} else deepExtend(target[prop], source[prop], overwrite);
	else target[prop] = source[prop];
	return target;
};
var regexEscape = (str) => str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
var _entityMap = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;",
	"/": "&#x2F;"
};
var escape = (data) => {
	if (isString(data)) return data.replace(/[&<>"'\/]/g, (s) => _entityMap[s]);
	return data;
};
var RegExpCache = class {
	constructor(capacity) {
		this.capacity = capacity;
		this.regExpMap = /* @__PURE__ */ new Map();
		this.regExpQueue = [];
	}
	getRegExp(pattern) {
		const regExpFromCache = this.regExpMap.get(pattern);
		if (regExpFromCache !== void 0) return regExpFromCache;
		const regExpNew = new RegExp(pattern);
		if (this.regExpQueue.length === this.capacity) this.regExpMap.delete(this.regExpQueue.shift());
		this.regExpMap.set(pattern, regExpNew);
		this.regExpQueue.push(pattern);
		return regExpNew;
	}
};
var chars = [
	" ",
	",",
	"?",
	"!",
	";"
];
var looksLikeObjectPathRegExpCache = new RegExpCache(20);
var looksLikeObjectPath = (key, nsSeparator, keySeparator) => {
	nsSeparator = nsSeparator || "";
	keySeparator = keySeparator || "";
	const possibleChars = chars.filter((c) => !nsSeparator.includes(c) && !keySeparator.includes(c));
	if (possibleChars.length === 0) return true;
	const r = looksLikeObjectPathRegExpCache.getRegExp(`(${possibleChars.map((c) => c === "?" ? "\\?" : c).join("|")})`);
	let matched = !r.test(key);
	if (!matched) {
		const ki = key.indexOf(keySeparator);
		if (ki > 0 && !r.test(key.substring(0, ki))) matched = true;
	}
	return matched;
};
var deepFind = (obj, path, keySeparator = ".") => {
	if (!obj) return void 0;
	if (obj[path]) {
		if (!Object.prototype.hasOwnProperty.call(obj, path)) return void 0;
		return obj[path];
	}
	const tokens = path.split(keySeparator);
	let current = obj;
	for (let i = 0; i < tokens.length;) {
		if (!current || typeof current !== "object") return;
		let next;
		let nextPath = "";
		for (let j = i; j < tokens.length; ++j) {
			if (j !== i) nextPath += keySeparator;
			nextPath += tokens[j];
			next = current[nextPath];
			if (next !== void 0) {
				if ([
					"string",
					"number",
					"boolean"
				].includes(typeof next) && j < tokens.length - 1) continue;
				i += j - i + 1;
				break;
			}
		}
		current = next;
	}
	return current;
};
var getCleanedCode = (code) => code?.replace(/_/g, "-");
var consoleLogger = {
	type: "logger",
	log(args) {
		this.output("log", args);
	},
	warn(args) {
		this.output("warn", args);
	},
	error(args) {
		this.output("error", args);
	},
	output(type, args) {
		console?.[type]?.apply?.(console, args);
	}
};
var baseLogger = new class Logger {
	constructor(concreteLogger, options = {}) {
		this.init(concreteLogger, options);
	}
	init(concreteLogger, options = {}) {
		this.prefix = options.prefix || "i18next:";
		this.logger = concreteLogger || consoleLogger;
		this.options = options;
		this.debug = options.debug;
	}
	log(...args) {
		return this.forward(args, "log", "", true);
	}
	warn(...args) {
		return this.forward(args, "warn", "", true);
	}
	error(...args) {
		return this.forward(args, "error", "");
	}
	deprecate(...args) {
		return this.forward(args, "warn", "WARNING DEPRECATED: ", true);
	}
	forward(args, lvl, prefix, debugOnly) {
		if (debugOnly && !this.debug) return null;
		args = args.map((a) => isString(a) ? a.replace(/[\r\n\x00-\x1F\x7F]/g, " ") : a);
		if (isString(args[0])) args[0] = `${prefix}${this.prefix} ${args[0]}`;
		return this.logger[lvl](args);
	}
	create(moduleName) {
		return new Logger(this.logger, {
			prefix: `${this.prefix}:${moduleName}:`,
			...this.options
		});
	}
	clone(options) {
		options = options || this.options;
		options.prefix = options.prefix || this.prefix;
		return new Logger(this.logger, options);
	}
}();
var EventEmitter = class {
	constructor() {
		this.observers = {};
	}
	on(events, listener) {
		events.split(" ").forEach((event) => {
			if (!this.observers[event]) this.observers[event] = /* @__PURE__ */ new Map();
			const numListeners = this.observers[event].get(listener) || 0;
			this.observers[event].set(listener, numListeners + 1);
		});
		return this;
	}
	off(event, listener) {
		if (!this.observers[event]) return;
		if (!listener) {
			delete this.observers[event];
			return;
		}
		this.observers[event].delete(listener);
	}
	once(event, listener) {
		const wrapper = (...args) => {
			listener(...args);
			this.off(event, wrapper);
		};
		this.on(event, wrapper);
		return this;
	}
	emit(event, ...args) {
		if (this.observers[event]) Array.from(this.observers[event].entries()).forEach(([observer, numTimesAdded]) => {
			for (let i = 0; i < numTimesAdded; i++) observer(...args);
		});
		if (this.observers["*"]) Array.from(this.observers["*"].entries()).forEach(([observer, numTimesAdded]) => {
			for (let i = 0; i < numTimesAdded; i++) observer(event, ...args);
		});
	}
};
var ResourceStore = class extends EventEmitter {
	constructor(data, options = {
		ns: ["translation"],
		defaultNS: "translation"
	}) {
		super();
		this.data = data || {};
		this.options = options;
		if (this.options.keySeparator === void 0) this.options.keySeparator = ".";
		if (this.options.ignoreJSONStructure === void 0) this.options.ignoreJSONStructure = true;
	}
	addNamespaces(ns) {
		if (!this.options.ns.includes(ns)) this.options.ns.push(ns);
	}
	removeNamespaces(ns) {
		const index = this.options.ns.indexOf(ns);
		if (index > -1) this.options.ns.splice(index, 1);
	}
	getResource(lng, ns, key, options = {}) {
		const keySeparator = options.keySeparator !== void 0 ? options.keySeparator : this.options.keySeparator;
		const ignoreJSONStructure = options.ignoreJSONStructure !== void 0 ? options.ignoreJSONStructure : this.options.ignoreJSONStructure;
		let path;
		if (lng.includes(".")) path = lng.split(".");
		else {
			path = [lng, ns];
			if (key) if (Array.isArray(key)) path.push(...key);
			else if (isString(key) && keySeparator) path.push(...key.split(keySeparator));
			else path.push(key);
		}
		const result = getPath(this.data, path);
		if (!result && !ns && !key && lng.includes(".")) {
			lng = path[0];
			ns = path[1];
			key = path.slice(2).join(".");
		}
		if (result || !ignoreJSONStructure || !isString(key)) return result;
		return deepFind(this.data?.[lng]?.[ns], key, keySeparator);
	}
	addResource(lng, ns, key, value, options = { silent: false }) {
		const keySeparator = options.keySeparator !== void 0 ? options.keySeparator : this.options.keySeparator;
		let path = [lng, ns];
		if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);
		if (lng.includes(".")) {
			path = lng.split(".");
			value = ns;
			ns = path[1];
		}
		this.addNamespaces(ns);
		setPath(this.data, path, value);
		if (!options.silent) this.emit("added", lng, ns, key, value);
	}
	addResources(lng, ns, resources, options = { silent: false }) {
		for (const m in resources) if (isString(resources[m]) || Array.isArray(resources[m])) this.addResource(lng, ns, m, resources[m], { silent: true });
		if (!options.silent) this.emit("added", lng, ns, resources);
	}
	addResourceBundle(lng, ns, resources, deep, overwrite, options = {
		silent: false,
		skipCopy: false
	}) {
		let path = [lng, ns];
		if (lng.includes(".")) {
			path = lng.split(".");
			deep = resources;
			resources = ns;
			ns = path[1];
		}
		this.addNamespaces(ns);
		let pack = getPath(this.data, path) || {};
		if (!options.skipCopy) resources = JSON.parse(JSON.stringify(resources));
		if (deep) deepExtend(pack, resources, overwrite);
		else pack = {
			...pack,
			...resources
		};
		setPath(this.data, path, pack);
		if (!options.silent) this.emit("added", lng, ns, resources);
	}
	removeResourceBundle(lng, ns) {
		if (this.hasResourceBundle(lng, ns)) delete this.data[lng][ns];
		this.removeNamespaces(ns);
		this.emit("removed", lng, ns);
	}
	hasResourceBundle(lng, ns) {
		return this.getResource(lng, ns) !== void 0;
	}
	getResourceBundle(lng, ns) {
		if (!ns) ns = this.options.defaultNS;
		return this.getResource(lng, ns);
	}
	getDataByLanguage(lng) {
		return this.data[lng];
	}
	hasLanguageSomeTranslations(lng) {
		const data = this.getDataByLanguage(lng);
		return !!(data && Object.keys(data) || []).find((v) => data[v] && Object.keys(data[v]).length > 0);
	}
	toJSON() {
		return this.data;
	}
};
var postProcessor = {
	processors: {},
	addPostProcessor(module) {
		this.processors[module.name] = module;
	},
	handle(processors, value, key, options, translator) {
		processors.forEach((processor) => {
			value = this.processors[processor]?.process(value, key, options, translator) ?? value;
		});
		return value;
	}
};
var PATH_KEY = Symbol("i18next/PATH_KEY");
function createProxy() {
	const state = [];
	const handler = Object.create(null);
	let proxy;
	handler.get = (target, key) => {
		proxy?.revoke?.();
		if (key === PATH_KEY) return state;
		state.push(key);
		proxy = Proxy.revocable(target, handler);
		return proxy.proxy;
	};
	return Proxy.revocable(Object.create(null), handler).proxy;
}
function keysFromSelector(selector, opts) {
	const { [PATH_KEY]: path } = selector(createProxy());
	const keySeparator = opts?.keySeparator ?? ".";
	const nsSeparator = opts?.nsSeparator ?? ":";
	const strict = opts?.enableSelector === "strict";
	if (path.length > 1 && nsSeparator) {
		const ns = opts?.ns;
		const nsList = strict ? Array.isArray(ns) ? ns : ns ? [ns] : null : Array.isArray(ns) ? ns : null;
		if (nsList) {
			if ((strict ? nsList : nsList.length > 1 ? nsList.slice(1) : []).includes(path[0])) return `${path[0]}${nsSeparator}${path.slice(1).join(keySeparator)}`;
		}
	}
	return path.join(keySeparator);
}
var shouldHandleAsObject = (res) => !isString(res) && typeof res !== "boolean" && typeof res !== "number";
var Translator = class Translator extends EventEmitter {
	constructor(services, options = {}) {
		super();
		copy([
			"resourceStore",
			"languageUtils",
			"pluralResolver",
			"interpolator",
			"backendConnector",
			"i18nFormat",
			"utils"
		], services, this);
		this.options = options;
		if (this.options.keySeparator === void 0) this.options.keySeparator = ".";
		this.logger = baseLogger.create("translator");
		this.checkedLoadedFor = {};
	}
	changeLanguage(lng) {
		if (lng) this.language = lng;
	}
	exists(key, o = { interpolation: {} }) {
		const opt = { ...o };
		if (key == null) return false;
		const resolved = this.resolve(key, opt);
		if (resolved?.res === void 0) return false;
		const isObject = shouldHandleAsObject(resolved.res);
		if (opt.returnObjects === false && isObject) return false;
		return true;
	}
	extractFromKey(key, opt) {
		let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
		if (nsSeparator === void 0) nsSeparator = ":";
		const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
		let namespaces = opt.ns || this.options.defaultNS || [];
		const wouldCheckForNsInKey = nsSeparator && key.includes(nsSeparator);
		const seemsNaturalLanguage = !this.options.userDefinedKeySeparator && !opt.keySeparator && !this.options.userDefinedNsSeparator && !opt.nsSeparator && !looksLikeObjectPath(key, nsSeparator, keySeparator);
		if (wouldCheckForNsInKey && !seemsNaturalLanguage) {
			const m = key.match(this.interpolator.nestingRegexp);
			if (m && m.length > 0) return {
				key,
				namespaces: isString(namespaces) ? [namespaces] : namespaces
			};
			const parts = key.split(nsSeparator);
			if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.includes(parts[0])) namespaces = parts.shift();
			key = parts.join(keySeparator);
		}
		return {
			key,
			namespaces: isString(namespaces) ? [namespaces] : namespaces
		};
	}
	translate(keys, o, lastKey) {
		let opt = typeof o === "object" ? { ...o } : o;
		if (typeof opt !== "object" && this.options.overloadTranslationOptionHandler) opt = this.options.overloadTranslationOptionHandler(arguments);
		if (typeof opt === "object") opt = { ...opt };
		if (!opt) opt = {};
		if (keys == null) return "";
		if (typeof keys === "function") keys = keysFromSelector(keys, {
			...this.options,
			...opt
		});
		if (!Array.isArray(keys)) keys = [String(keys)];
		keys = keys.map((k) => typeof k === "function" ? keysFromSelector(k, {
			...this.options,
			...opt
		}) : String(k));
		const returnDetails = opt.returnDetails !== void 0 ? opt.returnDetails : this.options.returnDetails;
		const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
		const { key, namespaces } = this.extractFromKey(keys[keys.length - 1], opt);
		const namespace = namespaces[namespaces.length - 1];
		let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
		if (nsSeparator === void 0) nsSeparator = ":";
		const lng = opt.lng || this.language;
		const appendNamespaceToCIMode = opt.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
		if (lng?.toLowerCase() === "cimode") {
			if (appendNamespaceToCIMode) {
				if (returnDetails) return {
					res: `${namespace}${nsSeparator}${key}`,
					usedKey: key,
					exactUsedKey: key,
					usedLng: lng,
					usedNS: namespace,
					usedParams: this.getUsedParamsDetails(opt)
				};
				return `${namespace}${nsSeparator}${key}`;
			}
			if (returnDetails) return {
				res: key,
				usedKey: key,
				exactUsedKey: key,
				usedLng: lng,
				usedNS: namespace,
				usedParams: this.getUsedParamsDetails(opt)
			};
			return key;
		}
		const resolved = this.resolve(keys, opt);
		let res = resolved?.res;
		const resUsedKey = resolved?.usedKey || key;
		const resExactUsedKey = resolved?.exactUsedKey || key;
		const noObject = [
			"[object Number]",
			"[object Function]",
			"[object RegExp]"
		];
		const joinArrays = opt.joinArrays !== void 0 ? opt.joinArrays : this.options.joinArrays;
		const handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
		const needsPluralHandling = opt.count !== void 0 && !isString(opt.count);
		const hasDefaultValue = Translator.hasDefaultValue(opt);
		const defaultValueSuffix = needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, opt) : "";
		const defaultValueSuffixOrdinalFallback = opt.ordinal && needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, { ordinal: false }) : "";
		const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
		const defaultValue = needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] || opt[`defaultValue${defaultValueSuffix}`] || opt[`defaultValue${defaultValueSuffixOrdinalFallback}`] || opt.defaultValue;
		let resForObjHndl = res;
		if (handleAsObjectInI18nFormat && !res && hasDefaultValue) resForObjHndl = defaultValue;
		const handleAsObject = shouldHandleAsObject(resForObjHndl);
		const resType = Object.prototype.toString.apply(resForObjHndl);
		if (handleAsObjectInI18nFormat && resForObjHndl && handleAsObject && !noObject.includes(resType) && !(isString(joinArrays) && Array.isArray(resForObjHndl))) {
			if (!opt.returnObjects && !this.options.returnObjects) {
				if (!this.options.returnedObjectHandler) this.logger.warn("accessing an object - but returnObjects options is not enabled!");
				const r = this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, resForObjHndl, {
					...opt,
					ns: namespaces
				}) : `key '${key} (${this.language})' returned an object instead of string.`;
				if (returnDetails) {
					resolved.res = r;
					resolved.usedParams = this.getUsedParamsDetails(opt);
					return resolved;
				}
				return r;
			}
			if (keySeparator) {
				const resTypeIsArray = Array.isArray(resForObjHndl);
				const copy = resTypeIsArray ? [] : {};
				const newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;
				for (const m in resForObjHndl) if (Object.prototype.hasOwnProperty.call(resForObjHndl, m)) {
					const deepKey = `${newKeyToUse}${keySeparator}${m}`;
					if (hasDefaultValue && !res) copy[m] = this.translate(deepKey, {
						...opt,
						defaultValue: shouldHandleAsObject(defaultValue) ? defaultValue[m] : void 0,
						joinArrays: false,
						ns: namespaces
					});
					else copy[m] = this.translate(deepKey, {
						...opt,
						joinArrays: false,
						ns: namespaces
					});
					if (copy[m] === deepKey) copy[m] = resForObjHndl[m];
				}
				res = copy;
			}
		} else if (handleAsObjectInI18nFormat && isString(joinArrays) && Array.isArray(res)) {
			res = res.join(joinArrays);
			if (res) res = this.extendTranslation(res, keys, opt, lastKey);
		} else {
			let usedDefault = false;
			let usedKey = false;
			if (!this.isValidLookup(res) && hasDefaultValue) {
				usedDefault = true;
				res = defaultValue;
			}
			if (!this.isValidLookup(res)) {
				usedKey = true;
				res = key;
			}
			const resForMissing = (opt.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey) && usedKey ? void 0 : res;
			const updateMissing = hasDefaultValue && defaultValue !== res && this.options.updateMissing;
			if (usedKey || usedDefault || updateMissing) {
				this.logger.log(updateMissing ? "updateKey" : "missingKey", lng, namespace, needsPluralHandling && !updateMissing ? `${key}${this.pluralResolver.getSuffix(lng, opt.count, opt)}` : key, updateMissing ? defaultValue : res);
				if (keySeparator) {
					const fk = this.resolve(key, {
						...opt,
						keySeparator: false
					});
					if (fk && fk.res) this.logger.warn("Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.");
				}
				let lngs = [];
				const fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, opt.lng || this.language);
				if (this.options.saveMissingTo === "fallback" && fallbackLngs && fallbackLngs[0]) for (let i = 0; i < fallbackLngs.length; i++) lngs.push(fallbackLngs[i]);
				else if (this.options.saveMissingTo === "all") lngs = this.languageUtils.toResolveHierarchy(opt.lng || this.language);
				else lngs.push(opt.lng || this.language);
				const send = (l, k, specificDefaultValue) => {
					const defaultForMissing = hasDefaultValue && specificDefaultValue !== res ? specificDefaultValue : resForMissing;
					if (this.options.missingKeyHandler) this.options.missingKeyHandler(l, namespace, k, defaultForMissing, updateMissing, opt);
					else if (this.backendConnector?.saveMissing) this.backendConnector.saveMissing(l, namespace, k, defaultForMissing, updateMissing, opt);
					this.emit("missingKey", l, namespace, k, res);
				};
				if (this.options.saveMissing) if (this.options.saveMissingPlurals && needsPluralHandling) lngs.forEach((language) => {
					const suffixes = this.pluralResolver.getSuffixes(language, opt);
					if (needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] && !suffixes.includes(`${this.options.pluralSeparator}zero`)) suffixes.push(`${this.options.pluralSeparator}zero`);
					suffixes.forEach((suffix) => {
						send([language], key + suffix, opt[`defaultValue${suffix}`] || defaultValue);
					});
				});
				else send(lngs, key, defaultValue);
			}
			res = this.extendTranslation(res, keys, opt, resolved, lastKey);
			if (usedKey && res === key && this.options.appendNamespaceToMissingKey) res = `${namespace}${nsSeparator}${key}`;
			if ((usedKey || usedDefault) && this.options.parseMissingKeyHandler) res = this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey ? `${namespace}${nsSeparator}${key}` : key, usedDefault ? res : void 0, opt);
		}
		if (returnDetails) {
			resolved.res = res;
			resolved.usedParams = this.getUsedParamsDetails(opt);
			return resolved;
		}
		return res;
	}
	extendTranslation(res, key, opt, resolved, lastKey) {
		if (this.i18nFormat?.parse) res = this.i18nFormat.parse(res, {
			...this.options.interpolation.defaultVariables,
			...opt
		}, opt.lng || this.language || resolved.usedLng, resolved.usedNS, resolved.usedKey, { resolved });
		else if (!opt.skipInterpolation) {
			if (opt.interpolation) this.interpolator.init({
				...opt,
				interpolation: {
					...this.options.interpolation,
					...opt.interpolation
				}
			});
			const skipOnVariables = isString(res) && (opt?.interpolation?.skipOnVariables !== void 0 ? opt.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables);
			let nestBef;
			if (skipOnVariables) {
				const nb = res.match(this.interpolator.nestingRegexp);
				nestBef = nb && nb.length;
			}
			let data = opt.replace && !isString(opt.replace) ? opt.replace : opt;
			if (this.options.interpolation.defaultVariables) data = {
				...this.options.interpolation.defaultVariables,
				...data
			};
			res = this.interpolator.interpolate(res, data, opt.lng || this.language || resolved.usedLng, opt);
			if (skipOnVariables) {
				const na = res.match(this.interpolator.nestingRegexp);
				const nestAft = na && na.length;
				if (nestBef < nestAft) opt.nest = false;
			}
			if (!opt.lng && resolved && resolved.res) opt.lng = this.language || resolved.usedLng;
			if (opt.nest !== false) res = this.interpolator.nest(res, (...args) => {
				if (lastKey?.[0] === args[0] && !opt.context) {
					this.logger.warn(`It seems you are nesting recursively key: ${args[0]} in key: ${key[0]}`);
					return null;
				}
				return this.translate(...args, key);
			}, opt);
			if (opt.interpolation) this.interpolator.reset();
		}
		const postProcess = opt.postProcess || this.options.postProcess;
		const postProcessorNames = isString(postProcess) ? [postProcess] : postProcess;
		if (res != null && postProcessorNames?.length && opt.applyPostProcessor !== false) res = postProcessor.handle(postProcessorNames, res, key, this.options && this.options.postProcessPassResolved ? {
			i18nResolved: {
				...resolved,
				usedParams: this.getUsedParamsDetails(opt)
			},
			...opt
		} : opt, this);
		return res;
	}
	resolve(keys, opt = {}) {
		let found;
		let usedKey;
		let exactUsedKey;
		let usedLng;
		let usedNS;
		if (isString(keys)) keys = [keys];
		if (Array.isArray(keys)) keys = keys.map((k) => typeof k === "function" ? keysFromSelector(k, {
			...this.options,
			...opt
		}) : k);
		keys.forEach((k) => {
			if (this.isValidLookup(found)) return;
			const extracted = this.extractFromKey(k, opt);
			const key = extracted.key;
			usedKey = key;
			let namespaces = extracted.namespaces;
			if (this.options.fallbackNS) namespaces = namespaces.concat(this.options.fallbackNS);
			const needsPluralHandling = opt.count !== void 0 && !isString(opt.count);
			const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
			const needsContextHandling = opt.context !== void 0 && (isString(opt.context) || typeof opt.context === "number") && opt.context !== "";
			const codes = opt.lngs ? opt.lngs : this.languageUtils.toResolveHierarchy(opt.lng || this.language, opt.fallbackLng);
			namespaces.forEach((ns) => {
				if (this.isValidLookup(found)) return;
				usedNS = ns;
				if (!this.checkedLoadedFor[`${codes[0]}-${ns}`] && this.utils?.hasLoadedNamespace && !this.utils?.hasLoadedNamespace(usedNS)) {
					this.checkedLoadedFor[`${codes[0]}-${ns}`] = true;
					this.logger.warn(`key "${usedKey}" for languages "${codes.join(", ")}" won't get resolved as namespace "${usedNS}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
				}
				codes.forEach((code) => {
					if (this.isValidLookup(found)) return;
					usedLng = code;
					const finalKeys = [key];
					if (this.i18nFormat?.addLookupKeys) this.i18nFormat.addLookupKeys(finalKeys, key, code, ns, opt);
					else {
						let pluralSuffix;
						if (needsPluralHandling) pluralSuffix = this.pluralResolver.getSuffix(code, opt.count, opt);
						const zeroSuffix = `${this.options.pluralSeparator}zero`;
						const ordinalPrefix = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
						if (needsPluralHandling) {
							if (opt.ordinal && pluralSuffix.startsWith(ordinalPrefix)) finalKeys.push(key + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
							finalKeys.push(key + pluralSuffix);
							if (needsZeroSuffixLookup) finalKeys.push(key + zeroSuffix);
						}
						if (needsContextHandling) {
							const contextKey = `${key}${this.options.contextSeparator || "_"}${opt.context}`;
							finalKeys.push(contextKey);
							if (needsPluralHandling) {
								if (opt.ordinal && pluralSuffix.startsWith(ordinalPrefix)) finalKeys.push(contextKey + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
								finalKeys.push(contextKey + pluralSuffix);
								if (needsZeroSuffixLookup) finalKeys.push(contextKey + zeroSuffix);
							}
						}
					}
					let possibleKey;
					while (possibleKey = finalKeys.pop()) if (!this.isValidLookup(found)) {
						exactUsedKey = possibleKey;
						found = this.getResource(code, ns, possibleKey, opt);
					}
				});
			});
		});
		return {
			res: found,
			usedKey,
			exactUsedKey,
			usedLng,
			usedNS
		};
	}
	isValidLookup(res) {
		return res !== void 0 && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === "");
	}
	getResource(code, ns, key, options = {}) {
		if (this.i18nFormat?.getResource) return this.i18nFormat.getResource(code, ns, key, options);
		return this.resourceStore.getResource(code, ns, key, options);
	}
	getUsedParamsDetails(options = {}) {
		const optionsKeys = [
			"defaultValue",
			"ordinal",
			"context",
			"replace",
			"lng",
			"lngs",
			"fallbackLng",
			"ns",
			"keySeparator",
			"nsSeparator",
			"returnObjects",
			"returnDetails",
			"joinArrays",
			"postProcess",
			"interpolation"
		];
		const useOptionsReplaceForData = options.replace && !isString(options.replace);
		let data = useOptionsReplaceForData ? options.replace : options;
		if (useOptionsReplaceForData && typeof options.count !== "undefined") data = {
			...data,
			count: options.count
		};
		if (this.options.interpolation.defaultVariables) data = {
			...this.options.interpolation.defaultVariables,
			...data
		};
		if (!useOptionsReplaceForData) {
			data = { ...data };
			for (const key of optionsKeys) delete data[key];
		}
		return data;
	}
	static hasDefaultValue(options) {
		const prefix = "defaultValue";
		for (const option in options) if (Object.prototype.hasOwnProperty.call(options, option) && option.startsWith(prefix) && void 0 !== options[option]) return true;
		return false;
	}
};
var LanguageUtil = class {
	constructor(options) {
		this.options = options;
		this.supportedLngs = this.options.supportedLngs || false;
		this.logger = baseLogger.create("languageUtils");
	}
	getScriptPartFromCode(code) {
		code = getCleanedCode(code);
		if (!code || !code.includes("-")) return null;
		const p = code.split("-");
		if (p.length === 2) return null;
		p.pop();
		if (p[p.length - 1].toLowerCase() === "x") return null;
		return this.formatLanguageCode(p.join("-"));
	}
	getLanguagePartFromCode(code) {
		code = getCleanedCode(code);
		if (!code || !code.includes("-")) return code;
		const p = code.split("-");
		return this.formatLanguageCode(p[0]);
	}
	formatLanguageCode(code) {
		if (isString(code) && code.includes("-")) {
			let formattedCode;
			try {
				formattedCode = Intl.getCanonicalLocales(code)[0];
			} catch (e) {}
			if (formattedCode && this.options.lowerCaseLng) formattedCode = formattedCode.toLowerCase();
			if (formattedCode) return formattedCode;
			if (this.options.lowerCaseLng) return code.toLowerCase();
			return code;
		}
		return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
	}
	isSupportedCode(code) {
		if (this.options.load === "languageOnly" || this.options.nonExplicitSupportedLngs) code = this.getLanguagePartFromCode(code);
		return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.includes(code);
	}
	getBestMatchFromCodes(codes) {
		if (!codes) return null;
		let found;
		codes.forEach((code) => {
			if (found) return;
			const cleanedLng = this.formatLanguageCode(code);
			if (!this.options.supportedLngs || this.isSupportedCode(cleanedLng)) found = cleanedLng;
		});
		if (!found && this.options.supportedLngs) codes.forEach((code) => {
			if (found) return;
			const lngScOnly = this.getScriptPartFromCode(code);
			if (this.isSupportedCode(lngScOnly)) return found = lngScOnly;
			const lngOnly = this.getLanguagePartFromCode(code);
			if (this.isSupportedCode(lngOnly)) return found = lngOnly;
			found = this.options.supportedLngs.find((supportedLng) => {
				if (supportedLng === lngOnly) return true;
				if (!supportedLng.includes("-") && !lngOnly.includes("-")) return false;
				if (supportedLng.includes("-") && !lngOnly.includes("-") && supportedLng.slice(0, supportedLng.indexOf("-")) === lngOnly) return true;
				if (supportedLng.startsWith(lngOnly) && lngOnly.length > 1) return true;
				return false;
			});
		});
		if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
		return found;
	}
	getFallbackCodes(fallbacks, code) {
		if (!fallbacks) return [];
		if (typeof fallbacks === "function") fallbacks = fallbacks(code);
		if (isString(fallbacks)) fallbacks = [fallbacks];
		if (Array.isArray(fallbacks)) return fallbacks;
		if (!code) return fallbacks.default || [];
		let found = fallbacks[code];
		if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
		if (!found) found = fallbacks[this.formatLanguageCode(code)];
		if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
		if (!found) found = fallbacks.default;
		return found || [];
	}
	toResolveHierarchy(code, fallbackCode) {
		const fallbackCodes = this.getFallbackCodes((fallbackCode === false ? [] : fallbackCode) || this.options.fallbackLng || [], code);
		const codes = [];
		const addCode = (c) => {
			if (!c) return;
			if (this.isSupportedCode(c)) codes.push(c);
			else this.logger.warn(`rejecting language code not found in supportedLngs: ${c}`);
		};
		if (isString(code) && (code.includes("-") || code.includes("_"))) {
			if (this.options.load !== "languageOnly") addCode(this.formatLanguageCode(code));
			if (this.options.load !== "languageOnly" && this.options.load !== "currentOnly") addCode(this.getScriptPartFromCode(code));
			if (this.options.load !== "currentOnly") addCode(this.getLanguagePartFromCode(code));
		} else if (isString(code)) addCode(this.formatLanguageCode(code));
		fallbackCodes.forEach((fc) => {
			if (!codes.includes(fc)) addCode(this.formatLanguageCode(fc));
		});
		return codes;
	}
};
var suffixesOrder = {
	zero: 0,
	one: 1,
	two: 2,
	few: 3,
	many: 4,
	other: 5
};
var dummyRule = {
	select: (count) => count === 1 ? "one" : "other",
	resolvedOptions: () => ({ pluralCategories: ["one", "other"] })
};
var PluralResolver = class {
	constructor(languageUtils, options = {}) {
		this.languageUtils = languageUtils;
		this.options = options;
		this.logger = baseLogger.create("pluralResolver");
		this.pluralRulesCache = {};
	}
	clearCache() {
		this.pluralRulesCache = {};
	}
	getRule(code, options = {}) {
		const cleanedCode = getCleanedCode(code === "dev" ? "en" : code);
		const type = options.ordinal ? "ordinal" : "cardinal";
		const cacheKey = JSON.stringify({
			cleanedCode,
			type
		});
		if (cacheKey in this.pluralRulesCache) return this.pluralRulesCache[cacheKey];
		let rule;
		try {
			rule = new Intl.PluralRules(cleanedCode, { type });
		} catch (err) {
			if (typeof Intl === "undefined") {
				this.logger.error("No Intl support, please use an Intl polyfill!");
				return dummyRule;
			}
			if (!code.match(/-|_/)) return dummyRule;
			const lngPart = this.languageUtils.getLanguagePartFromCode(code);
			rule = this.getRule(lngPart, options);
		}
		this.pluralRulesCache[cacheKey] = rule;
		return rule;
	}
	needsPlural(code, options = {}) {
		let rule = this.getRule(code, options);
		if (!rule) rule = this.getRule("dev", options);
		return rule?.resolvedOptions().pluralCategories.length > 1;
	}
	getPluralFormsOfKey(code, key, options = {}) {
		return this.getSuffixes(code, options).map((suffix) => `${key}${suffix}`);
	}
	getSuffixes(code, options = {}) {
		let rule = this.getRule(code, options);
		if (!rule) rule = this.getRule("dev", options);
		if (!rule) return [];
		return rule.resolvedOptions().pluralCategories.sort((pluralCategory1, pluralCategory2) => suffixesOrder[pluralCategory1] - suffixesOrder[pluralCategory2]).map((pluralCategory) => `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ""}${pluralCategory}`);
	}
	getSuffix(code, count, options = {}) {
		const rule = this.getRule(code, options);
		if (rule) return `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ""}${rule.select(count)}`;
		this.logger.warn(`no plural rule found for: ${code}`);
		return this.getSuffix("dev", count, options);
	}
};
var deepFindWithDefaults = (data, defaultData, key, keySeparator = ".", ignoreJSONStructure = true) => {
	let path = getPathWithDefaults(data, defaultData, key);
	if (!path && ignoreJSONStructure && isString(key)) {
		path = deepFind(data, key, keySeparator);
		if (path === void 0) path = deepFind(defaultData, key, keySeparator);
	}
	return path;
};
var regexSafe = (val) => val.replace(/\$/g, "$$$$");
var Interpolator = class {
	constructor(options = {}) {
		this.logger = baseLogger.create("interpolator");
		this.options = options;
		this.format = options?.interpolation?.format || ((value) => value);
		this.init(options);
	}
	init(options = {}) {
		if (!options.interpolation) options.interpolation = { escapeValue: true };
		const { escape: escape$1, escapeValue, useRawValueToEscape, prefix, prefixEscaped, suffix, suffixEscaped, formatSeparator, unescapeSuffix, unescapePrefix, nestingPrefix, nestingPrefixEscaped, nestingSuffix, nestingSuffixEscaped, nestingOptionsSeparator, maxReplaces, alwaysFormat } = options.interpolation;
		this.escape = escape$1 !== void 0 ? escape$1 : escape;
		this.escapeValue = escapeValue !== void 0 ? escapeValue : true;
		this.useRawValueToEscape = useRawValueToEscape !== void 0 ? useRawValueToEscape : false;
		this.prefix = prefix ? regexEscape(prefix) : prefixEscaped || "{{";
		this.suffix = suffix ? regexEscape(suffix) : suffixEscaped || "}}";
		this.formatSeparator = formatSeparator || ",";
		this.unescapePrefix = unescapeSuffix ? "" : unescapePrefix ? regexEscape(unescapePrefix) : "-";
		this.unescapeSuffix = this.unescapePrefix ? "" : unescapeSuffix ? regexEscape(unescapeSuffix) : "";
		this.nestingPrefix = nestingPrefix ? regexEscape(nestingPrefix) : nestingPrefixEscaped || regexEscape("$t(");
		this.nestingSuffix = nestingSuffix ? regexEscape(nestingSuffix) : nestingSuffixEscaped || regexEscape(")");
		this.nestingOptionsSeparator = nestingOptionsSeparator || ",";
		this.maxReplaces = maxReplaces || 1e3;
		this.alwaysFormat = alwaysFormat !== void 0 ? alwaysFormat : false;
		this.resetRegExp();
	}
	reset() {
		if (this.options) this.init(this.options);
	}
	resetRegExp() {
		const getOrResetRegExp = (existingRegExp, pattern) => {
			if (existingRegExp?.source === pattern) {
				existingRegExp.lastIndex = 0;
				return existingRegExp;
			}
			return new RegExp(pattern, "g");
		};
		this.regexp = getOrResetRegExp(this.regexp, `${this.prefix}(.+?)${this.suffix}`);
		this.regexpUnescape = getOrResetRegExp(this.regexpUnescape, `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`);
		this.nestingRegexp = getOrResetRegExp(this.nestingRegexp, `${this.nestingPrefix}((?:[^()"']+|"[^"]*"|'[^']*'|\\((?:[^()]|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`);
	}
	interpolate(str, data, lng, options) {
		let match;
		let value;
		let replaces;
		const defaultData = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};
		const handleFormat = (key) => {
			if (!key.includes(this.formatSeparator)) {
				const path = deepFindWithDefaults(data, defaultData, key, this.options.keySeparator, this.options.ignoreJSONStructure);
				return this.alwaysFormat ? this.format(path, void 0, lng, {
					...options,
					...data,
					interpolationkey: key
				}) : path;
			}
			const p = key.split(this.formatSeparator);
			const k = p.shift().trim();
			const f = p.join(this.formatSeparator).trim();
			return this.format(deepFindWithDefaults(data, defaultData, k, this.options.keySeparator, this.options.ignoreJSONStructure), f, lng, {
				...options,
				...data,
				interpolationkey: k
			});
		};
		this.resetRegExp();
		if (!this.escapeValue && typeof str === "string" && /\$t\([^)]*\{[^}]*\{\{/.test(str)) this.logger.warn("nesting options string contains interpolated variables with escapeValue: false — if any of those values are attacker-controlled they can inject additional nesting options (e.g. redirect lng/ns). Sanitise untrusted input before passing it to t(), or keep escapeValue: true.");
		const missingInterpolationHandler = options?.missingInterpolationHandler || this.options.missingInterpolationHandler;
		const skipOnVariables = options?.interpolation?.skipOnVariables !== void 0 ? options.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables;
		[{
			regex: this.regexpUnescape,
			safeValue: (val) => val
		}, {
			regex: this.regexp,
			safeValue: (val) => this.escapeValue ? this.escape(val) : val
		}].forEach((todo) => {
			replaces = 0;
			while (match = todo.regex.exec(str)) {
				const matchedVar = match[1].trim();
				value = handleFormat(matchedVar);
				if (value === void 0) if (typeof missingInterpolationHandler === "function") {
					const temp = missingInterpolationHandler(str, match, options);
					value = isString(temp) ? temp : "";
				} else if (options && Object.prototype.hasOwnProperty.call(options, matchedVar)) value = "";
				else if (skipOnVariables) {
					value = match[0];
					continue;
				} else {
					this.logger.warn(`missed to pass in variable ${matchedVar} for interpolating ${str}`);
					value = "";
				}
				else if (!isString(value) && !this.useRawValueToEscape) value = makeString(value);
				const safeValue = todo.safeValue(value);
				str = str.replace(match[0], regexSafe(safeValue));
				if (skipOnVariables) {
					todo.regex.lastIndex += safeValue.length;
					todo.regex.lastIndex -= match[0].length;
				} else todo.regex.lastIndex = 0;
				replaces++;
				if (replaces >= this.maxReplaces) break;
			}
		});
		return str;
	}
	nest(str, fc, options = {}) {
		let match;
		let value;
		let clonedOptions;
		const handleHasOptions = (key, inheritedOptions) => {
			const sep = this.nestingOptionsSeparator;
			if (!key.includes(sep)) return key;
			const c = key.split(new RegExp(`${regexEscape(sep)}[ ]*{`));
			let optionsString = `{${c[1]}`;
			key = c[0];
			optionsString = this.interpolate(optionsString, clonedOptions);
			const matchedSingleQuotes = optionsString.match(/'/g);
			const matchedDoubleQuotes = optionsString.match(/"/g);
			if ((matchedSingleQuotes?.length ?? 0) % 2 === 0 && !matchedDoubleQuotes || (matchedDoubleQuotes?.length ?? 0) % 2 !== 0) optionsString = optionsString.replace(/'/g, "\"");
			try {
				clonedOptions = JSON.parse(optionsString);
				if (inheritedOptions) clonedOptions = {
					...inheritedOptions,
					...clonedOptions
				};
			} catch (e) {
				this.logger.warn(`failed parsing options string in nesting for key ${key}`, e);
				return `${key}${sep}${optionsString}`;
			}
			if (clonedOptions.defaultValue && clonedOptions.defaultValue.includes(this.prefix)) delete clonedOptions.defaultValue;
			return key;
		};
		while (match = this.nestingRegexp.exec(str)) {
			let formatters = [];
			clonedOptions = { ...options };
			clonedOptions = clonedOptions.replace && !isString(clonedOptions.replace) ? clonedOptions.replace : clonedOptions;
			clonedOptions.applyPostProcessor = false;
			delete clonedOptions.defaultValue;
			const keyEndIndex = /{.*}/s.test(match[1]) ? match[1].lastIndexOf("}") + 1 : match[1].indexOf(this.formatSeparator);
			if (keyEndIndex !== -1) {
				formatters = match[1].slice(keyEndIndex).split(this.formatSeparator).map((elem) => elem.trim()).filter(Boolean);
				match[1] = match[1].slice(0, keyEndIndex);
			}
			value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
			if (value && match[0] === str && !isString(value)) return value;
			if (!isString(value)) value = makeString(value);
			if (!value) {
				this.logger.warn(`missed to resolve ${match[1]} for nesting ${str}`);
				value = "";
			}
			if (formatters.length) value = formatters.reduce((v, f) => this.format(v, f, options.lng, {
				...options,
				interpolationkey: match[1].trim()
			}), value.trim());
			str = str.replace(match[0], value);
			this.regexp.lastIndex = 0;
		}
		return str;
	}
};
var parseFormatStr = (formatStr) => {
	let formatName = formatStr.toLowerCase().trim();
	const formatOptions = {};
	if (formatStr.includes("(")) {
		const p = formatStr.split("(");
		formatName = p[0].toLowerCase().trim();
		const optStr = p[1].slice(0, -1);
		if (formatName === "currency" && !optStr.includes(":")) {
			if (!formatOptions.currency) formatOptions.currency = optStr.trim();
		} else if (formatName === "relativetime" && !optStr.includes(":")) {
			if (!formatOptions.range) formatOptions.range = optStr.trim();
		} else optStr.split(";").forEach((opt) => {
			if (opt) {
				const [key, ...rest] = opt.split(":");
				const val = rest.join(":").trim().replace(/^'+|'+$/g, "");
				const trimmedKey = key.trim();
				if (!formatOptions[trimmedKey]) formatOptions[trimmedKey] = val;
				if (val === "false") formatOptions[trimmedKey] = false;
				if (val === "true") formatOptions[trimmedKey] = true;
				if (!isNaN(val)) formatOptions[trimmedKey] = parseInt(val, 10);
			}
		});
	}
	return {
		formatName,
		formatOptions
	};
};
var createCachedFormatter = (fn) => {
	const cache = {};
	return (v, l, o) => {
		let optForCache = o;
		if (o && o.interpolationkey && o.formatParams && o.formatParams[o.interpolationkey] && o[o.interpolationkey]) optForCache = {
			...optForCache,
			[o.interpolationkey]: void 0
		};
		const key = l + JSON.stringify(optForCache);
		let frm = cache[key];
		if (!frm) {
			frm = fn(getCleanedCode(l), o);
			cache[key] = frm;
		}
		return frm(v);
	};
};
var createNonCachedFormatter = (fn) => (v, l, o) => fn(getCleanedCode(l), o)(v);
var Formatter = class {
	constructor(options = {}) {
		this.logger = baseLogger.create("formatter");
		this.options = options;
		this.init(options);
	}
	init(services, options = { interpolation: {} }) {
		this.formatSeparator = options.interpolation.formatSeparator || ",";
		const cf = options.cacheInBuiltFormats ? createCachedFormatter : createNonCachedFormatter;
		this.formats = {
			number: cf((lng, opt) => {
				const formatter = new Intl.NumberFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			}),
			currency: cf((lng, opt) => {
				const formatter = new Intl.NumberFormat(lng, {
					...opt,
					style: "currency"
				});
				return (val) => formatter.format(val);
			}),
			datetime: cf((lng, opt) => {
				const formatter = new Intl.DateTimeFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			}),
			relativetime: cf((lng, opt) => {
				const formatter = new Intl.RelativeTimeFormat(lng, { ...opt });
				return (val) => formatter.format(val, opt.range || "day");
			}),
			list: cf((lng, opt) => {
				const formatter = new Intl.ListFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			})
		};
	}
	add(name, fc) {
		this.formats[name.toLowerCase().trim()] = fc;
	}
	addCached(name, fc) {
		this.formats[name.toLowerCase().trim()] = createCachedFormatter(fc);
	}
	format(value, format, lng, options = {}) {
		if (!format) return value;
		if (value == null) return value;
		const rawFormats = format.split(this.formatSeparator);
		const formats = [];
		for (let i = 0; i < rawFormats.length; i++) {
			let f = rawFormats[i];
			while (f.indexOf("(") > -1 && !f.includes(")") && i + 1 < rawFormats.length) f = `${f}${this.formatSeparator}${rawFormats[++i]}`;
			formats.push(f);
		}
		return formats.reduce((mem, f) => {
			const { formatName, formatOptions } = parseFormatStr(f);
			if (this.formats[formatName]) {
				let formatted = mem;
				try {
					const valOptions = options?.formatParams?.[options.interpolationkey] || {};
					const l = valOptions.locale || valOptions.lng || options.locale || options.lng || lng;
					formatted = this.formats[formatName](mem, l, {
						...formatOptions,
						...options,
						...valOptions
					});
				} catch (error) {
					this.logger.warn(error);
				}
				return formatted;
			} else this.logger.warn(`there was no format function for ${formatName}`);
			return mem;
		}, value);
	}
};
var removePending = (q, name) => {
	if (q.pending[name] !== void 0) {
		delete q.pending[name];
		q.pendingCount--;
	}
};
var Connector = class extends EventEmitter {
	constructor(backend, store, services, options = {}) {
		super();
		this.backend = backend;
		this.store = store;
		this.services = services;
		this.languageUtils = services.languageUtils;
		this.options = options;
		this.logger = baseLogger.create("backendConnector");
		this.waitingReads = [];
		this.maxParallelReads = options.maxParallelReads || 10;
		this.readingCalls = 0;
		this.maxRetries = options.maxRetries >= 0 ? options.maxRetries : 5;
		this.retryTimeout = options.retryTimeout >= 1 ? options.retryTimeout : 350;
		this.state = {};
		this.queue = [];
		this.backend?.init?.(services, options.backend, options);
	}
	queueLoad(languages, namespaces, options, callback) {
		const toLoad = {};
		const pending = {};
		const toLoadLanguages = {};
		const toLoadNamespaces = {};
		languages.forEach((lng) => {
			let hasAllNamespaces = true;
			namespaces.forEach((ns) => {
				const name = `${lng}|${ns}`;
				if (!options.reload && this.store.hasResourceBundle(lng, ns)) this.state[name] = 2;
				else if (this.state[name] < 0);
				else if (this.state[name] === 1) {
					if (pending[name] === void 0) pending[name] = true;
				} else {
					this.state[name] = 1;
					hasAllNamespaces = false;
					if (pending[name] === void 0) pending[name] = true;
					if (toLoad[name] === void 0) toLoad[name] = true;
					if (toLoadNamespaces[ns] === void 0) toLoadNamespaces[ns] = true;
				}
			});
			if (!hasAllNamespaces) toLoadLanguages[lng] = true;
		});
		if (Object.keys(toLoad).length || Object.keys(pending).length) this.queue.push({
			pending,
			pendingCount: Object.keys(pending).length,
			loaded: {},
			errors: [],
			callback
		});
		return {
			toLoad: Object.keys(toLoad),
			pending: Object.keys(pending),
			toLoadLanguages: Object.keys(toLoadLanguages),
			toLoadNamespaces: Object.keys(toLoadNamespaces)
		};
	}
	loaded(name, err, data) {
		const s = name.split("|");
		const lng = s[0];
		const ns = s[1];
		if (err) this.emit("failedLoading", lng, ns, err);
		if (!err && data) this.store.addResourceBundle(lng, ns, data, void 0, void 0, { skipCopy: true });
		this.state[name] = err ? -1 : 2;
		if (err && data) this.state[name] = 0;
		const loaded = {};
		this.queue.forEach((q) => {
			pushPath(q.loaded, [lng], ns);
			removePending(q, name);
			if (err) q.errors.push(err);
			if (q.pendingCount === 0 && !q.done) {
				Object.keys(q.loaded).forEach((l) => {
					if (!loaded[l]) loaded[l] = {};
					const loadedKeys = q.loaded[l];
					if (loadedKeys.length) loadedKeys.forEach((n) => {
						if (loaded[l][n] === void 0) loaded[l][n] = true;
					});
				});
				q.done = true;
				if (q.errors.length) q.callback(q.errors);
				else q.callback();
			}
		});
		this.emit("loaded", loaded);
		this.queue = this.queue.filter((q) => !q.done);
	}
	read(lng, ns, fcName, tried = 0, wait = this.retryTimeout, callback) {
		if (!lng.length) return callback(null, {});
		if (this.readingCalls >= this.maxParallelReads) {
			this.waitingReads.push({
				lng,
				ns,
				fcName,
				tried,
				wait,
				callback
			});
			return;
		}
		this.readingCalls++;
		const resolver = (err, data) => {
			this.readingCalls--;
			if (this.waitingReads.length > 0) {
				const next = this.waitingReads.shift();
				this.read(next.lng, next.ns, next.fcName, next.tried, next.wait, next.callback);
			}
			if (err && data && tried < this.maxRetries) {
				setTimeout(() => {
					this.read(lng, ns, fcName, tried + 1, wait * 2, callback);
				}, wait);
				return;
			}
			callback(err, data);
		};
		const fc = this.backend[fcName].bind(this.backend);
		if (fc.length === 2) {
			try {
				const r = fc(lng, ns);
				if (r && typeof r.then === "function") r.then((data) => resolver(null, data)).catch(resolver);
				else resolver(null, r);
			} catch (err) {
				resolver(err);
			}
			return;
		}
		return fc(lng, ns, resolver);
	}
	prepareLoading(languages, namespaces, options = {}, callback) {
		if (!this.backend) {
			this.logger.warn("No backend was added via i18next.use. Will not load resources.");
			return callback && callback();
		}
		if (isString(languages)) languages = this.languageUtils.toResolveHierarchy(languages);
		if (isString(namespaces)) namespaces = [namespaces];
		const toLoad = this.queueLoad(languages, namespaces, options, callback);
		if (!toLoad.toLoad.length) {
			if (!toLoad.pending.length) callback();
			return null;
		}
		toLoad.toLoad.forEach((name) => {
			this.loadOne(name);
		});
	}
	load(languages, namespaces, callback) {
		this.prepareLoading(languages, namespaces, {}, callback);
	}
	reload(languages, namespaces, callback) {
		this.prepareLoading(languages, namespaces, { reload: true }, callback);
	}
	loadOne(name, prefix = "") {
		const s = name.split("|");
		const lng = s[0];
		const ns = s[1];
		this.read(lng, ns, "read", void 0, void 0, (err, data) => {
			if (err) this.logger.warn(`${prefix}loading namespace ${ns} for language ${lng} failed`, err);
			if (!err && data) this.logger.log(`${prefix}loaded namespace ${ns} for language ${lng}`, data);
			this.loaded(name, err, data);
		});
	}
	saveMissing(languages, namespace, key, fallbackValue, isUpdate, options = {}, clb = () => {}) {
		if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(namespace)) {
			this.logger.warn(`did not save key "${key}" as the namespace "${namespace}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
			return;
		}
		if (key === void 0 || key === null || key === "") return;
		if (this.backend?.create) {
			const opts = {
				...options,
				isUpdate
			};
			const fc = this.backend.create.bind(this.backend);
			if (fc.length < 6) try {
				let r;
				if (fc.length === 5) r = fc(languages, namespace, key, fallbackValue, opts);
				else r = fc(languages, namespace, key, fallbackValue);
				if (r && typeof r.then === "function") r.then((data) => clb(null, data)).catch(clb);
				else clb(null, r);
			} catch (err) {
				clb(err);
			}
			else fc(languages, namespace, key, fallbackValue, clb, opts);
		}
		if (!languages || !languages[0]) return;
		this.store.addResource(languages[0], namespace, key, fallbackValue);
	}
};
var get = () => ({
	debug: false,
	initAsync: true,
	ns: ["translation"],
	defaultNS: ["translation"],
	fallbackLng: ["dev"],
	fallbackNS: false,
	supportedLngs: false,
	nonExplicitSupportedLngs: false,
	load: "all",
	preload: false,
	keySeparator: ".",
	nsSeparator: ":",
	pluralSeparator: "_",
	contextSeparator: "_",
	enableSelector: false,
	partialBundledLanguages: false,
	saveMissing: false,
	updateMissing: false,
	saveMissingTo: "fallback",
	saveMissingPlurals: true,
	missingKeyHandler: false,
	missingInterpolationHandler: false,
	postProcess: false,
	postProcessPassResolved: false,
	returnNull: false,
	returnEmptyString: true,
	returnObjects: false,
	joinArrays: false,
	returnedObjectHandler: false,
	parseMissingKeyHandler: false,
	appendNamespaceToMissingKey: false,
	appendNamespaceToCIMode: false,
	overloadTranslationOptionHandler: (args) => {
		let ret = {};
		if (typeof args[1] === "object") ret = args[1];
		if (isString(args[1])) ret.defaultValue = args[1];
		if (isString(args[2])) ret.tDescription = args[2];
		if (typeof args[2] === "object" || typeof args[3] === "object") {
			const options = args[3] || args[2];
			Object.keys(options).forEach((key) => {
				ret[key] = options[key];
			});
		}
		return ret;
	},
	interpolation: {
		escapeValue: true,
		prefix: "{{",
		suffix: "}}",
		formatSeparator: ",",
		unescapePrefix: "-",
		nestingPrefix: "$t(",
		nestingSuffix: ")",
		nestingOptionsSeparator: ",",
		maxReplaces: 1e3,
		skipOnVariables: true
	},
	cacheInBuiltFormats: true
});
var transformOptions = (options) => {
	if (isString(options.ns)) options.ns = [options.ns];
	if (isString(options.fallbackLng)) options.fallbackLng = [options.fallbackLng];
	if (isString(options.fallbackNS)) options.fallbackNS = [options.fallbackNS];
	if (options.supportedLngs && !options.supportedLngs.includes("cimode")) options.supportedLngs = options.supportedLngs.concat(["cimode"]);
	return options;
};
var noop = () => {};
var bindMemberFunctions = (inst) => {
	Object.getOwnPropertyNames(Object.getPrototypeOf(inst)).forEach((mem) => {
		if (typeof inst[mem] === "function") inst[mem] = inst[mem].bind(inst);
	});
};
var instance = class I18n extends EventEmitter {
	constructor(options = {}, callback) {
		super();
		this.options = transformOptions(options);
		this.services = {};
		this.logger = baseLogger;
		this.modules = { external: [] };
		bindMemberFunctions(this);
		if (callback && !this.isInitialized && !options.isClone) {
			if (!this.options.initAsync) {
				this.init(options, callback);
				return this;
			}
			setTimeout(() => {
				this.init(options, callback);
			}, 0);
		}
	}
	init(options = {}, callback) {
		this.isInitializing = true;
		if (typeof options === "function") {
			callback = options;
			options = {};
		}
		if (options.defaultNS == null && options.ns) {
			if (isString(options.ns)) options.defaultNS = options.ns;
			else if (!options.ns.includes("translation")) options.defaultNS = options.ns[0];
		}
		const defOpts = get();
		this.options = {
			...defOpts,
			...this.options,
			...transformOptions(options)
		};
		this.options.interpolation = {
			...defOpts.interpolation,
			...this.options.interpolation
		};
		if (options.keySeparator !== void 0) this.options.userDefinedKeySeparator = options.keySeparator;
		if (options.nsSeparator !== void 0) this.options.userDefinedNsSeparator = options.nsSeparator;
		if (typeof this.options.overloadTranslationOptionHandler !== "function") this.options.overloadTranslationOptionHandler = defOpts.overloadTranslationOptionHandler;
		const createClassOnDemand = (ClassOrObject) => {
			if (!ClassOrObject) return null;
			if (typeof ClassOrObject === "function") return new ClassOrObject();
			return ClassOrObject;
		};
		if (!this.options.isClone) {
			if (this.modules.logger) baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
			else baseLogger.init(null, this.options);
			let formatter;
			if (this.modules.formatter) formatter = this.modules.formatter;
			else formatter = Formatter;
			const lu = new LanguageUtil(this.options);
			this.store = new ResourceStore(this.options.resources, this.options);
			const s = this.services;
			s.logger = baseLogger;
			s.resourceStore = this.store;
			s.languageUtils = lu;
			s.pluralResolver = new PluralResolver(lu, { prepend: this.options.pluralSeparator });
			if (formatter) {
				s.formatter = createClassOnDemand(formatter);
				if (s.formatter.init) s.formatter.init(s, this.options);
				this.options.interpolation.format = s.formatter.format.bind(s.formatter);
			}
			s.interpolator = new Interpolator(this.options);
			s.utils = { hasLoadedNamespace: this.hasLoadedNamespace.bind(this) };
			s.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
			s.backendConnector.on("*", (event, ...args) => {
				this.emit(event, ...args);
			});
			if (this.modules.languageDetector) {
				s.languageDetector = createClassOnDemand(this.modules.languageDetector);
				if (s.languageDetector.init) s.languageDetector.init(s, this.options.detection, this.options);
			}
			if (this.modules.i18nFormat) {
				s.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
				if (s.i18nFormat.init) s.i18nFormat.init(this);
			}
			this.translator = new Translator(this.services, this.options);
			this.translator.on("*", (event, ...args) => {
				this.emit(event, ...args);
			});
			this.modules.external.forEach((m) => {
				if (m.init) m.init(this);
			});
		}
		this.format = this.options.interpolation.format;
		if (!callback) callback = noop;
		if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
			const codes = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
			if (codes.length > 0 && codes[0] !== "dev") this.options.lng = codes[0];
		}
		if (!this.services.languageDetector && !this.options.lng) this.logger.warn("init: no languageDetector is used and no lng is defined");
		[
			"getResource",
			"hasResourceBundle",
			"getResourceBundle",
			"getDataByLanguage"
		].forEach((fcName) => {
			this[fcName] = (...args) => this.store[fcName](...args);
		});
		[
			"addResource",
			"addResources",
			"addResourceBundle",
			"removeResourceBundle"
		].forEach((fcName) => {
			this[fcName] = (...args) => {
				this.store[fcName](...args);
				return this;
			};
		});
		const deferred = defer();
		const load = () => {
			const finish = (err, t) => {
				this.isInitializing = false;
				if (this.isInitialized && !this.initializedStoreOnce) this.logger.warn("init: i18next is already initialized. You should call init just once!");
				this.isInitialized = true;
				if (!this.options.isClone) this.logger.log("initialized", this.options);
				this.emit("initialized", this.options);
				deferred.resolve(t);
				callback(err, t);
			};
			if ((this.languages || this.isLanguageChangingTo) && !this.isInitialized) return finish(null, this.t.bind(this));
			this.changeLanguage(this.options.lng, finish);
		};
		if (this.options.resources || !this.options.initAsync) load();
		else setTimeout(load, 0);
		return deferred;
	}
	loadResources(language, callback = noop) {
		let usedCallback = callback;
		const usedLng = isString(language) ? language : this.language;
		if (typeof language === "function") usedCallback = language;
		if (!this.options.resources || this.options.partialBundledLanguages) {
			if (usedLng?.toLowerCase() === "cimode" && (!this.options.preload || this.options.preload.length === 0)) return usedCallback();
			const toLoad = [];
			const append = (lng) => {
				if (!lng) return;
				if (lng === "cimode") return;
				this.services.languageUtils.toResolveHierarchy(lng).forEach((l) => {
					if (l === "cimode") return;
					if (!toLoad.includes(l)) toLoad.push(l);
				});
			};
			if (!usedLng) this.services.languageUtils.getFallbackCodes(this.options.fallbackLng).forEach((l) => append(l));
			else append(usedLng);
			this.options.preload?.forEach?.((l) => append(l));
			this.services.backendConnector.load(toLoad, this.options.ns, (e) => {
				if (!e && !this.resolvedLanguage && this.language) this.setResolvedLanguage(this.language);
				usedCallback(e);
			});
		} else usedCallback(null);
	}
	reloadResources(lngs, ns, callback) {
		const deferred = defer();
		if (typeof lngs === "function") {
			callback = lngs;
			lngs = void 0;
		}
		if (typeof ns === "function") {
			callback = ns;
			ns = void 0;
		}
		if (!lngs) lngs = this.languages;
		if (!ns) ns = this.options.ns;
		if (!callback) callback = noop;
		this.services.backendConnector.reload(lngs, ns, (err) => {
			deferred.resolve();
			callback(err);
		});
		return deferred;
	}
	use(module) {
		if (!module) throw new Error("You are passing an undefined module! Please check the object you are passing to i18next.use()");
		if (!module.type) throw new Error("You are passing a wrong module! Please check the object you are passing to i18next.use()");
		if (module.type === "backend") this.modules.backend = module;
		if (module.type === "logger" || module.log && module.warn && module.error) this.modules.logger = module;
		if (module.type === "languageDetector") this.modules.languageDetector = module;
		if (module.type === "i18nFormat") this.modules.i18nFormat = module;
		if (module.type === "postProcessor") postProcessor.addPostProcessor(module);
		if (module.type === "formatter") this.modules.formatter = module;
		if (module.type === "3rdParty") this.modules.external.push(module);
		return this;
	}
	setResolvedLanguage(l) {
		if (!l || !this.languages) return;
		if (["cimode", "dev"].includes(l)) return;
		for (let li = 0; li < this.languages.length; li++) {
			const lngInLngs = this.languages[li];
			if (["cimode", "dev"].includes(lngInLngs)) continue;
			if (this.store.hasLanguageSomeTranslations(lngInLngs)) {
				this.resolvedLanguage = lngInLngs;
				break;
			}
		}
		if (!this.resolvedLanguage && !this.languages.includes(l) && this.store.hasLanguageSomeTranslations(l)) {
			this.resolvedLanguage = l;
			this.languages.unshift(l);
		}
	}
	changeLanguage(lng, callback) {
		this.isLanguageChangingTo = lng;
		const deferred = defer();
		this.emit("languageChanging", lng);
		const setLngProps = (l) => {
			this.language = l;
			this.languages = this.services.languageUtils.toResolveHierarchy(l);
			this.resolvedLanguage = void 0;
			this.setResolvedLanguage(l);
		};
		const done = (err, l) => {
			if (l) {
				if (this.isLanguageChangingTo === lng) {
					setLngProps(l);
					this.translator.changeLanguage(l);
					this.isLanguageChangingTo = void 0;
					this.emit("languageChanged", l);
					this.logger.log("languageChanged", l);
				}
			} else this.isLanguageChangingTo = void 0;
			deferred.resolve((...args) => this.t(...args));
			if (callback) callback(err, (...args) => this.t(...args));
		};
		const setLng = (lngs) => {
			if (!lng && !lngs && this.services.languageDetector) lngs = [];
			const fl = isString(lngs) ? lngs : lngs && lngs[0];
			const l = this.store.hasLanguageSomeTranslations(fl) ? fl : this.services.languageUtils.getBestMatchFromCodes(isString(lngs) ? [lngs] : lngs);
			if (l) {
				if (!this.language) setLngProps(l);
				if (!this.translator.language) this.translator.changeLanguage(l);
				this.services.languageDetector?.cacheUserLanguage?.(l);
			}
			this.loadResources(l, (err) => {
				done(err, l);
			});
		};
		if (!lng && this.services.languageDetector && !this.services.languageDetector.async) setLng(this.services.languageDetector.detect());
		else if (!lng && this.services.languageDetector && this.services.languageDetector.async) if (this.services.languageDetector.detect.length === 0) this.services.languageDetector.detect().then(setLng);
		else this.services.languageDetector.detect(setLng);
		else setLng(lng);
		return deferred;
	}
	getFixedT(lng, ns, keyPrefix, fixedOpts) {
		const scopeNs = fixedOpts?.scopeNs;
		const fixedT = (key, opts, ...rest) => {
			let o;
			if (typeof opts !== "object") o = this.options.overloadTranslationOptionHandler([key, opts].concat(rest));
			else o = { ...opts };
			o.lng = o.lng || fixedT.lng;
			o.lngs = o.lngs || fixedT.lngs;
			const explicitCallNs = o.ns !== void 0 && o.ns !== null;
			o.ns = o.ns || fixedT.ns;
			if (o.keyPrefix !== "") o.keyPrefix = o.keyPrefix || keyPrefix || fixedT.keyPrefix;
			const selectorOpts = {
				...this.options,
				...o
			};
			if (Array.isArray(scopeNs) && !explicitCallNs) selectorOpts.ns = scopeNs;
			if (typeof o.keyPrefix === "function") o.keyPrefix = keysFromSelector(o.keyPrefix, selectorOpts);
			const keySeparator = this.options.keySeparator || ".";
			let resultKey;
			if (o.keyPrefix && Array.isArray(key)) resultKey = key.map((k) => {
				if (typeof k === "function") k = keysFromSelector(k, selectorOpts);
				return `${o.keyPrefix}${keySeparator}${k}`;
			});
			else {
				if (typeof key === "function") key = keysFromSelector(key, selectorOpts);
				resultKey = o.keyPrefix ? `${o.keyPrefix}${keySeparator}${key}` : key;
			}
			return this.t(resultKey, o);
		};
		if (isString(lng)) fixedT.lng = lng;
		else fixedT.lngs = lng;
		fixedT.ns = ns;
		fixedT.keyPrefix = keyPrefix;
		return fixedT;
	}
	t(...args) {
		return this.translator?.translate(...args);
	}
	exists(...args) {
		return this.translator?.exists(...args);
	}
	setDefaultNamespace(ns) {
		this.options.defaultNS = ns;
	}
	hasLoadedNamespace(ns, options = {}) {
		if (!this.isInitialized) {
			this.logger.warn("hasLoadedNamespace: i18next was not initialized", this.languages);
			return false;
		}
		if (!this.languages || !this.languages.length) {
			this.logger.warn("hasLoadedNamespace: i18n.languages were undefined or empty", this.languages);
			return false;
		}
		const lng = options.lng || this.resolvedLanguage || this.languages[0];
		const fallbackLng = this.options ? this.options.fallbackLng : false;
		const lastLng = this.languages[this.languages.length - 1];
		if (lng.toLowerCase() === "cimode") return true;
		const loadNotPending = (l, n) => {
			const loadState = this.services.backendConnector.state[`${l}|${n}`];
			return loadState === -1 || loadState === 0 || loadState === 2;
		};
		if (options.precheck) {
			const preResult = options.precheck(this, loadNotPending);
			if (preResult !== void 0) return preResult;
		}
		if (this.hasResourceBundle(lng, ns)) return true;
		if (!this.services.backendConnector.backend || this.options.resources && !this.options.partialBundledLanguages) return true;
		if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
		return false;
	}
	loadNamespaces(ns, callback) {
		const deferred = defer();
		if (!this.options.ns) {
			if (callback) callback();
			return Promise.resolve();
		}
		if (isString(ns)) ns = [ns];
		ns.forEach((n) => {
			if (!this.options.ns.includes(n)) this.options.ns.push(n);
		});
		this.loadResources((err) => {
			deferred.resolve();
			if (callback) callback(err);
		});
		return deferred;
	}
	loadLanguages(lngs, callback) {
		const deferred = defer();
		if (isString(lngs)) lngs = [lngs];
		const preloaded = this.options.preload || [];
		const newLngs = lngs.filter((lng) => !preloaded.includes(lng) && this.services.languageUtils.isSupportedCode(lng));
		if (!newLngs.length) {
			if (callback) callback();
			return Promise.resolve();
		}
		this.options.preload = preloaded.concat(newLngs);
		this.loadResources((err) => {
			deferred.resolve();
			if (callback) callback(err);
		});
		return deferred;
	}
	dir(lng) {
		if (!lng) lng = this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language);
		if (!lng) return "rtl";
		try {
			const l = new Intl.Locale(lng);
			if (l && l.getTextInfo) {
				const ti = l.getTextInfo();
				if (ti && ti.direction) return ti.direction;
			}
		} catch (e) {}
		const rtlLngs = [
			"ar",
			"shu",
			"sqr",
			"ssh",
			"xaa",
			"yhd",
			"yud",
			"aao",
			"abh",
			"abv",
			"acm",
			"acq",
			"acw",
			"acx",
			"acy",
			"adf",
			"ads",
			"aeb",
			"aec",
			"afb",
			"ajp",
			"apc",
			"apd",
			"arb",
			"arq",
			"ars",
			"ary",
			"arz",
			"auz",
			"avl",
			"ayh",
			"ayl",
			"ayn",
			"ayp",
			"bbz",
			"pga",
			"he",
			"iw",
			"ps",
			"pbt",
			"pbu",
			"pst",
			"prp",
			"prd",
			"ug",
			"ur",
			"ydd",
			"yds",
			"yih",
			"ji",
			"yi",
			"hbo",
			"men",
			"xmn",
			"fa",
			"jpr",
			"peo",
			"pes",
			"prs",
			"dv",
			"sam",
			"ckb"
		];
		const languageUtils = this.services?.languageUtils || new LanguageUtil(get());
		if (lng.toLowerCase().indexOf("-latn") > 1) return "ltr";
		return rtlLngs.includes(languageUtils.getLanguagePartFromCode(lng)) || lng.toLowerCase().indexOf("-arab") > 1 ? "rtl" : "ltr";
	}
	static createInstance(options = {}, callback) {
		const instance = new I18n(options, callback);
		instance.createInstance = I18n.createInstance;
		return instance;
	}
	cloneInstance(options = {}, callback = noop) {
		const forkResourceStore = options.forkResourceStore;
		if (forkResourceStore) delete options.forkResourceStore;
		const mergedOptions = {
			...this.options,
			...options,
			isClone: true
		};
		const clone = new I18n(mergedOptions);
		if (options.debug !== void 0 || options.prefix !== void 0) clone.logger = clone.logger.clone(options);
		[
			"store",
			"services",
			"language"
		].forEach((m) => {
			clone[m] = this[m];
		});
		clone.services = { ...this.services };
		clone.services.utils = { hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone) };
		if (forkResourceStore) {
			clone.store = new ResourceStore(Object.keys(this.store.data).reduce((prev, l) => {
				prev[l] = { ...this.store.data[l] };
				prev[l] = Object.keys(prev[l]).reduce((acc, n) => {
					acc[n] = { ...prev[l][n] };
					return acc;
				}, prev[l]);
				return prev;
			}, {}), mergedOptions);
			clone.services.resourceStore = clone.store;
		}
		if (options.interpolation) {
			const mergedInterpolation = {
				...get().interpolation,
				...this.options.interpolation,
				...options.interpolation
			};
			const mergedForInterpolator = {
				...mergedOptions,
				interpolation: mergedInterpolation
			};
			clone.services.interpolator = new Interpolator(mergedForInterpolator);
		}
		clone.translator = new Translator(clone.services, mergedOptions);
		clone.translator.on("*", (event, ...args) => {
			clone.emit(event, ...args);
		});
		clone.init(mergedOptions, callback);
		clone.translator.options = mergedOptions;
		clone.translator.backendConnector.services.utils = { hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone) };
		return clone;
	}
	toJSON() {
		return {
			options: this.options,
			store: this.store,
			language: this.language,
			languages: this.languages,
			resolvedLanguage: this.resolvedLanguage
		};
	}
}.createInstance();
var createInstance = instance.createInstance;
var dir = instance.dir;
var init = instance.init;
var loadResources = instance.loadResources;
var reloadResources = instance.reloadResources;
var use = instance.use;
var changeLanguage = instance.changeLanguage;
var getFixedT = instance.getFixedT;
var t = instance.t;
var exists = instance.exists;
var setDefaultNamespace = instance.setDefaultNamespace;
var hasLoadedNamespace = instance.hasLoadedNamespace;
var loadNamespaces = instance.loadNamespaces;
var loadLanguages = instance.loadLanguages;
//#endregion
export { changeLanguage, createInstance, instance as default, dir, exists, getFixedT, hasLoadedNamespace, init, keysFromSelector as keyFromSelector, loadLanguages, loadNamespaces, loadResources, reloadResources, setDefaultNamespace, t, use };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaTE4bmV4dC5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi9pMThuZXh0L2Rpc3QvZXNtL2kxOG5leHQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgaXNTdHJpbmcgPSBvYmogPT4gdHlwZW9mIG9iaiA9PT0gJ3N0cmluZyc7XG5jb25zdCBkZWZlciA9ICgpID0+IHtcbiAgbGV0IHJlcztcbiAgbGV0IHJlajtcbiAgY29uc3QgcHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICByZXMgPSByZXNvbHZlO1xuICAgIHJlaiA9IHJlamVjdDtcbiAgfSk7XG4gIHByb21pc2UucmVzb2x2ZSA9IHJlcztcbiAgcHJvbWlzZS5yZWplY3QgPSByZWo7XG4gIHJldHVybiBwcm9taXNlO1xufTtcbmNvbnN0IG1ha2VTdHJpbmcgPSBvYmplY3QgPT4ge1xuICBpZiAob2JqZWN0ID09IG51bGwpIHJldHVybiAnJztcbiAgcmV0dXJuIFN0cmluZyhvYmplY3QpO1xufTtcbmNvbnN0IGNvcHkgPSAoYSwgcywgdCkgPT4ge1xuICBhLmZvckVhY2gobSA9PiB7XG4gICAgaWYgKHNbbV0pIHRbbV0gPSBzW21dO1xuICB9KTtcbn07XG5jb25zdCBsYXN0T2ZQYXRoU2VwYXJhdG9yUmVnRXhwID0gLyMjIy9nO1xuY29uc3QgY2xlYW5LZXkgPSBrZXkgPT4ga2V5ICYmIGtleS5pbmNsdWRlcygnIyMjJykgPyBrZXkucmVwbGFjZShsYXN0T2ZQYXRoU2VwYXJhdG9yUmVnRXhwLCAnLicpIDoga2V5O1xuY29uc3QgY2FuTm90VHJhdmVyc2VEZWVwZXIgPSBvYmplY3QgPT4gIW9iamVjdCB8fCBpc1N0cmluZyhvYmplY3QpO1xuY29uc3QgZ2V0TGFzdE9mUGF0aCA9IChvYmplY3QsIHBhdGgsIEVtcHR5KSA9PiB7XG4gIGNvbnN0IHN0YWNrID0gIWlzU3RyaW5nKHBhdGgpID8gcGF0aCA6IHBhdGguc3BsaXQoJy4nKTtcbiAgbGV0IHN0YWNrSW5kZXggPSAwO1xuICB3aGlsZSAoc3RhY2tJbmRleCA8IHN0YWNrLmxlbmd0aCAtIDEpIHtcbiAgICBpZiAoY2FuTm90VHJhdmVyc2VEZWVwZXIob2JqZWN0KSkgcmV0dXJuIHt9O1xuICAgIGNvbnN0IGtleSA9IGNsZWFuS2V5KHN0YWNrW3N0YWNrSW5kZXhdKTtcbiAgICBpZiAoIW9iamVjdFtrZXldICYmIEVtcHR5KSBvYmplY3Rba2V5XSA9IG5ldyBFbXB0eSgpO1xuICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBrZXkpKSB7XG4gICAgICBvYmplY3QgPSBvYmplY3Rba2V5XTtcbiAgICB9IGVsc2Uge1xuICAgICAgb2JqZWN0ID0ge307XG4gICAgfVxuICAgICsrc3RhY2tJbmRleDtcbiAgfVxuICBpZiAoY2FuTm90VHJhdmVyc2VEZWVwZXIob2JqZWN0KSkgcmV0dXJuIHt9O1xuICByZXR1cm4ge1xuICAgIG9iajogb2JqZWN0LFxuICAgIGs6IGNsZWFuS2V5KHN0YWNrW3N0YWNrSW5kZXhdKVxuICB9O1xufTtcbmNvbnN0IHNldFBhdGggPSAob2JqZWN0LCBwYXRoLCBuZXdWYWx1ZSkgPT4ge1xuICBjb25zdCB7XG4gICAgb2JqLFxuICAgIGtcbiAgfSA9IGdldExhc3RPZlBhdGgob2JqZWN0LCBwYXRoLCBPYmplY3QpO1xuICBpZiAob2JqICE9PSB1bmRlZmluZWQgfHwgcGF0aC5sZW5ndGggPT09IDEpIHtcbiAgICBvYmpba10gPSBuZXdWYWx1ZTtcbiAgICByZXR1cm47XG4gIH1cbiAgbGV0IGUgPSBwYXRoW3BhdGgubGVuZ3RoIC0gMV07XG4gIGxldCBwID0gcGF0aC5zbGljZSgwLCBwYXRoLmxlbmd0aCAtIDEpO1xuICBsZXQgbGFzdCA9IGdldExhc3RPZlBhdGgob2JqZWN0LCBwLCBPYmplY3QpO1xuICB3aGlsZSAobGFzdC5vYmogPT09IHVuZGVmaW5lZCAmJiBwLmxlbmd0aCkge1xuICAgIGUgPSBgJHtwW3AubGVuZ3RoIC0gMV19LiR7ZX1gO1xuICAgIHAgPSBwLnNsaWNlKDAsIHAubGVuZ3RoIC0gMSk7XG4gICAgbGFzdCA9IGdldExhc3RPZlBhdGgob2JqZWN0LCBwLCBPYmplY3QpO1xuICAgIGlmIChsYXN0Py5vYmogJiYgdHlwZW9mIGxhc3Qub2JqW2Ake2xhc3Qua30uJHtlfWBdICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgbGFzdC5vYmogPSB1bmRlZmluZWQ7XG4gICAgfVxuICB9XG4gIGxhc3Qub2JqW2Ake2xhc3Qua30uJHtlfWBdID0gbmV3VmFsdWU7XG59O1xuY29uc3QgcHVzaFBhdGggPSAob2JqZWN0LCBwYXRoLCBuZXdWYWx1ZSwgY29uY2F0KSA9PiB7XG4gIGNvbnN0IHtcbiAgICBvYmosXG4gICAga1xuICB9ID0gZ2V0TGFzdE9mUGF0aChvYmplY3QsIHBhdGgsIE9iamVjdCk7XG4gIG9ialtrXSA9IG9ialtrXSB8fCBbXTtcbiAgb2JqW2tdLnB1c2gobmV3VmFsdWUpO1xufTtcbmNvbnN0IGdldFBhdGggPSAob2JqZWN0LCBwYXRoKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBvYmosXG4gICAga1xuICB9ID0gZ2V0TGFzdE9mUGF0aChvYmplY3QsIHBhdGgpO1xuICBpZiAoIW9iaikgcmV0dXJuIHVuZGVmaW5lZDtcbiAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBrKSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgcmV0dXJuIG9ialtrXTtcbn07XG5jb25zdCBnZXRQYXRoV2l0aERlZmF1bHRzID0gKGRhdGEsIGRlZmF1bHREYXRhLCBrZXkpID0+IHtcbiAgY29uc3QgdmFsdWUgPSBnZXRQYXRoKGRhdGEsIGtleSk7XG4gIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIHJldHVybiBnZXRQYXRoKGRlZmF1bHREYXRhLCBrZXkpO1xufTtcbmNvbnN0IGRlZXBFeHRlbmQgPSAodGFyZ2V0LCBzb3VyY2UsIG92ZXJ3cml0ZSkgPT4ge1xuICBmb3IgKGNvbnN0IHByb3AgaW4gc291cmNlKSB7XG4gICAgaWYgKHByb3AgIT09ICdfX3Byb3RvX18nICYmIHByb3AgIT09ICdjb25zdHJ1Y3RvcicpIHtcbiAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwodGFyZ2V0LCBwcm9wKSkge1xuICAgICAgICBpZiAoaXNTdHJpbmcodGFyZ2V0W3Byb3BdKSB8fCB0YXJnZXRbcHJvcF0gaW5zdGFuY2VvZiBTdHJpbmcgfHwgaXNTdHJpbmcoc291cmNlW3Byb3BdKSB8fCBzb3VyY2VbcHJvcF0gaW5zdGFuY2VvZiBTdHJpbmcpIHtcbiAgICAgICAgICBpZiAob3ZlcndyaXRlKSB0YXJnZXRbcHJvcF0gPSBzb3VyY2VbcHJvcF07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZGVlcEV4dGVuZCh0YXJnZXRbcHJvcF0sIHNvdXJjZVtwcm9wXSwgb3ZlcndyaXRlKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGFyZ2V0W3Byb3BdID0gc291cmNlW3Byb3BdO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gdGFyZ2V0O1xufTtcbmNvbnN0IHJlZ2V4RXNjYXBlID0gc3RyID0+IHN0ci5yZXBsYWNlKC9bXFwtXFxbXFxdXFwvXFx7XFx9XFwoXFwpXFwqXFwrXFw/XFwuXFxcXFxcXlxcJFxcfF0vZywgJ1xcXFwkJicpO1xuY29uc3QgX2VudGl0eU1hcCA9IHtcbiAgJyYnOiAnJmFtcDsnLFxuICAnPCc6ICcmbHQ7JyxcbiAgJz4nOiAnJmd0OycsXG4gICdcIic6ICcmcXVvdDsnLFxuICBcIidcIjogJyYjMzk7JyxcbiAgJy8nOiAnJiN4MkY7J1xufTtcbmNvbnN0IGVzY2FwZSA9IGRhdGEgPT4ge1xuICBpZiAoaXNTdHJpbmcoZGF0YSkpIHtcbiAgICByZXR1cm4gZGF0YS5yZXBsYWNlKC9bJjw+XCInXFwvXS9nLCBzID0+IF9lbnRpdHlNYXBbc10pO1xuICB9XG4gIHJldHVybiBkYXRhO1xufTtcbmNsYXNzIFJlZ0V4cENhY2hlIHtcbiAgY29uc3RydWN0b3IoY2FwYWNpdHkpIHtcbiAgICB0aGlzLmNhcGFjaXR5ID0gY2FwYWNpdHk7XG4gICAgdGhpcy5yZWdFeHBNYXAgPSBuZXcgTWFwKCk7XG4gICAgdGhpcy5yZWdFeHBRdWV1ZSA9IFtdO1xuICB9XG4gIGdldFJlZ0V4cChwYXR0ZXJuKSB7XG4gICAgY29uc3QgcmVnRXhwRnJvbUNhY2hlID0gdGhpcy5yZWdFeHBNYXAuZ2V0KHBhdHRlcm4pO1xuICAgIGlmIChyZWdFeHBGcm9tQ2FjaGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIHJlZ0V4cEZyb21DYWNoZTtcbiAgICB9XG4gICAgY29uc3QgcmVnRXhwTmV3ID0gbmV3IFJlZ0V4cChwYXR0ZXJuKTtcbiAgICBpZiAodGhpcy5yZWdFeHBRdWV1ZS5sZW5ndGggPT09IHRoaXMuY2FwYWNpdHkpIHtcbiAgICAgIHRoaXMucmVnRXhwTWFwLmRlbGV0ZSh0aGlzLnJlZ0V4cFF1ZXVlLnNoaWZ0KCkpO1xuICAgIH1cbiAgICB0aGlzLnJlZ0V4cE1hcC5zZXQocGF0dGVybiwgcmVnRXhwTmV3KTtcbiAgICB0aGlzLnJlZ0V4cFF1ZXVlLnB1c2gocGF0dGVybik7XG4gICAgcmV0dXJuIHJlZ0V4cE5ldztcbiAgfVxufVxuY29uc3QgY2hhcnMgPSBbJyAnLCAnLCcsICc/JywgJyEnLCAnOyddO1xuY29uc3QgbG9va3NMaWtlT2JqZWN0UGF0aFJlZ0V4cENhY2hlID0gbmV3IFJlZ0V4cENhY2hlKDIwKTtcbmNvbnN0IGxvb2tzTGlrZU9iamVjdFBhdGggPSAoa2V5LCBuc1NlcGFyYXRvciwga2V5U2VwYXJhdG9yKSA9PiB7XG4gIG5zU2VwYXJhdG9yID0gbnNTZXBhcmF0b3IgfHwgJyc7XG4gIGtleVNlcGFyYXRvciA9IGtleVNlcGFyYXRvciB8fCAnJztcbiAgY29uc3QgcG9zc2libGVDaGFycyA9IGNoYXJzLmZpbHRlcihjID0+ICFuc1NlcGFyYXRvci5pbmNsdWRlcyhjKSAmJiAha2V5U2VwYXJhdG9yLmluY2x1ZGVzKGMpKTtcbiAgaWYgKHBvc3NpYmxlQ2hhcnMubGVuZ3RoID09PSAwKSByZXR1cm4gdHJ1ZTtcbiAgY29uc3QgciA9IGxvb2tzTGlrZU9iamVjdFBhdGhSZWdFeHBDYWNoZS5nZXRSZWdFeHAoYCgke3Bvc3NpYmxlQ2hhcnMubWFwKGMgPT4gYyA9PT0gJz8nID8gJ1xcXFw/JyA6IGMpLmpvaW4oJ3wnKX0pYCk7XG4gIGxldCBtYXRjaGVkID0gIXIudGVzdChrZXkpO1xuICBpZiAoIW1hdGNoZWQpIHtcbiAgICBjb25zdCBraSA9IGtleS5pbmRleE9mKGtleVNlcGFyYXRvcik7XG4gICAgaWYgKGtpID4gMCAmJiAhci50ZXN0KGtleS5zdWJzdHJpbmcoMCwga2kpKSkge1xuICAgICAgbWF0Y2hlZCA9IHRydWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBtYXRjaGVkO1xufTtcbmNvbnN0IGRlZXBGaW5kID0gKG9iaiwgcGF0aCwga2V5U2VwYXJhdG9yID0gJy4nKSA9PiB7XG4gIGlmICghb2JqKSByZXR1cm4gdW5kZWZpbmVkO1xuICBpZiAob2JqW3BhdGhdKSB7XG4gICAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwYXRoKSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICByZXR1cm4gb2JqW3BhdGhdO1xuICB9XG4gIGNvbnN0IHRva2VucyA9IHBhdGguc3BsaXQoa2V5U2VwYXJhdG9yKTtcbiAgbGV0IGN1cnJlbnQgPSBvYmo7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdG9rZW5zLmxlbmd0aDspIHtcbiAgICBpZiAoIWN1cnJlbnQgfHwgdHlwZW9mIGN1cnJlbnQgIT09ICdvYmplY3QnKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBsZXQgbmV4dDtcbiAgICBsZXQgbmV4dFBhdGggPSAnJztcbiAgICBmb3IgKGxldCBqID0gaTsgaiA8IHRva2Vucy5sZW5ndGg7ICsraikge1xuICAgICAgaWYgKGogIT09IGkpIHtcbiAgICAgICAgbmV4dFBhdGggKz0ga2V5U2VwYXJhdG9yO1xuICAgICAgfVxuICAgICAgbmV4dFBhdGggKz0gdG9rZW5zW2pdO1xuICAgICAgbmV4dCA9IGN1cnJlbnRbbmV4dFBhdGhdO1xuICAgICAgaWYgKG5leHQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBpZiAoWydzdHJpbmcnLCAnbnVtYmVyJywgJ2Jvb2xlYW4nXS5pbmNsdWRlcyh0eXBlb2YgbmV4dCkgJiYgaiA8IHRva2Vucy5sZW5ndGggLSAxKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaSArPSBqIC0gaSArIDE7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBjdXJyZW50ID0gbmV4dDtcbiAgfVxuICByZXR1cm4gY3VycmVudDtcbn07XG5jb25zdCBnZXRDbGVhbmVkQ29kZSA9IGNvZGUgPT4gY29kZT8ucmVwbGFjZSgvXy9nLCAnLScpO1xuXG5jb25zdCBjb25zb2xlTG9nZ2VyID0ge1xuICB0eXBlOiAnbG9nZ2VyJyxcbiAgbG9nKGFyZ3MpIHtcbiAgICB0aGlzLm91dHB1dCgnbG9nJywgYXJncyk7XG4gIH0sXG4gIHdhcm4oYXJncykge1xuICAgIHRoaXMub3V0cHV0KCd3YXJuJywgYXJncyk7XG4gIH0sXG4gIGVycm9yKGFyZ3MpIHtcbiAgICB0aGlzLm91dHB1dCgnZXJyb3InLCBhcmdzKTtcbiAgfSxcbiAgb3V0cHV0KHR5cGUsIGFyZ3MpIHtcbiAgICBjb25zb2xlPy5bdHlwZV0/LmFwcGx5Py4oY29uc29sZSwgYXJncyk7XG4gIH1cbn07XG5jbGFzcyBMb2dnZXIge1xuICBjb25zdHJ1Y3Rvcihjb25jcmV0ZUxvZ2dlciwgb3B0aW9ucyA9IHt9KSB7XG4gICAgdGhpcy5pbml0KGNvbmNyZXRlTG9nZ2VyLCBvcHRpb25zKTtcbiAgfVxuICBpbml0KGNvbmNyZXRlTG9nZ2VyLCBvcHRpb25zID0ge30pIHtcbiAgICB0aGlzLnByZWZpeCA9IG9wdGlvbnMucHJlZml4IHx8ICdpMThuZXh0Oic7XG4gICAgdGhpcy5sb2dnZXIgPSBjb25jcmV0ZUxvZ2dlciB8fCBjb25zb2xlTG9nZ2VyO1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy5kZWJ1ZyA9IG9wdGlvbnMuZGVidWc7XG4gIH1cbiAgbG9nKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy5mb3J3YXJkKGFyZ3MsICdsb2cnLCAnJywgdHJ1ZSk7XG4gIH1cbiAgd2FybiguLi5hcmdzKSB7XG4gICAgcmV0dXJuIHRoaXMuZm9yd2FyZChhcmdzLCAnd2FybicsICcnLCB0cnVlKTtcbiAgfVxuICBlcnJvciguLi5hcmdzKSB7XG4gICAgcmV0dXJuIHRoaXMuZm9yd2FyZChhcmdzLCAnZXJyb3InLCAnJyk7XG4gIH1cbiAgZGVwcmVjYXRlKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy5mb3J3YXJkKGFyZ3MsICd3YXJuJywgJ1dBUk5JTkcgREVQUkVDQVRFRDogJywgdHJ1ZSk7XG4gIH1cbiAgZm9yd2FyZChhcmdzLCBsdmwsIHByZWZpeCwgZGVidWdPbmx5KSB7XG4gICAgaWYgKGRlYnVnT25seSAmJiAhdGhpcy5kZWJ1ZykgcmV0dXJuIG51bGw7XG4gICAgYXJncyA9IGFyZ3MubWFwKGEgPT4gaXNTdHJpbmcoYSkgPyBhLnJlcGxhY2UoL1tcXHJcXG5cXHgwMC1cXHgxRlxceDdGXS9nLCAnICcpIDogYSk7XG4gICAgaWYgKGlzU3RyaW5nKGFyZ3NbMF0pKSBhcmdzWzBdID0gYCR7cHJlZml4fSR7dGhpcy5wcmVmaXh9ICR7YXJnc1swXX1gO1xuICAgIHJldHVybiB0aGlzLmxvZ2dlcltsdmxdKGFyZ3MpO1xuICB9XG4gIGNyZWF0ZShtb2R1bGVOYW1lKSB7XG4gICAgcmV0dXJuIG5ldyBMb2dnZXIodGhpcy5sb2dnZXIsIHtcbiAgICAgIC4uLntcbiAgICAgICAgcHJlZml4OiBgJHt0aGlzLnByZWZpeH06JHttb2R1bGVOYW1lfTpgXG4gICAgICB9LFxuICAgICAgLi4udGhpcy5vcHRpb25zXG4gICAgfSk7XG4gIH1cbiAgY2xvbmUob3B0aW9ucykge1xuICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IHRoaXMub3B0aW9ucztcbiAgICBvcHRpb25zLnByZWZpeCA9IG9wdGlvbnMucHJlZml4IHx8IHRoaXMucHJlZml4O1xuICAgIHJldHVybiBuZXcgTG9nZ2VyKHRoaXMubG9nZ2VyLCBvcHRpb25zKTtcbiAgfVxufVxudmFyIGJhc2VMb2dnZXIgPSBuZXcgTG9nZ2VyKCk7XG5cbmNsYXNzIEV2ZW50RW1pdHRlciB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMub2JzZXJ2ZXJzID0ge307XG4gIH1cbiAgb24oZXZlbnRzLCBsaXN0ZW5lcikge1xuICAgIGV2ZW50cy5zcGxpdCgnICcpLmZvckVhY2goZXZlbnQgPT4ge1xuICAgICAgaWYgKCF0aGlzLm9ic2VydmVyc1tldmVudF0pIHRoaXMub2JzZXJ2ZXJzW2V2ZW50XSA9IG5ldyBNYXAoKTtcbiAgICAgIGNvbnN0IG51bUxpc3RlbmVycyA9IHRoaXMub2JzZXJ2ZXJzW2V2ZW50XS5nZXQobGlzdGVuZXIpIHx8IDA7XG4gICAgICB0aGlzLm9ic2VydmVyc1tldmVudF0uc2V0KGxpc3RlbmVyLCBudW1MaXN0ZW5lcnMgKyAxKTtcbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBvZmYoZXZlbnQsIGxpc3RlbmVyKSB7XG4gICAgaWYgKCF0aGlzLm9ic2VydmVyc1tldmVudF0pIHJldHVybjtcbiAgICBpZiAoIWxpc3RlbmVyKSB7XG4gICAgICBkZWxldGUgdGhpcy5vYnNlcnZlcnNbZXZlbnRdO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLm9ic2VydmVyc1tldmVudF0uZGVsZXRlKGxpc3RlbmVyKTtcbiAgfVxuICBvbmNlKGV2ZW50LCBsaXN0ZW5lcikge1xuICAgIGNvbnN0IHdyYXBwZXIgPSAoLi4uYXJncykgPT4ge1xuICAgICAgbGlzdGVuZXIoLi4uYXJncyk7XG4gICAgICB0aGlzLm9mZihldmVudCwgd3JhcHBlcik7XG4gICAgfTtcbiAgICB0aGlzLm9uKGV2ZW50LCB3cmFwcGVyKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBlbWl0KGV2ZW50LCAuLi5hcmdzKSB7XG4gICAgaWYgKHRoaXMub2JzZXJ2ZXJzW2V2ZW50XSkge1xuICAgICAgY29uc3QgY2xvbmVkID0gQXJyYXkuZnJvbSh0aGlzLm9ic2VydmVyc1tldmVudF0uZW50cmllcygpKTtcbiAgICAgIGNsb25lZC5mb3JFYWNoKChbb2JzZXJ2ZXIsIG51bVRpbWVzQWRkZWRdKSA9PiB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbnVtVGltZXNBZGRlZDsgaSsrKSB7XG4gICAgICAgICAgb2JzZXJ2ZXIoLi4uYXJncyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAodGhpcy5vYnNlcnZlcnNbJyonXSkge1xuICAgICAgY29uc3QgY2xvbmVkID0gQXJyYXkuZnJvbSh0aGlzLm9ic2VydmVyc1snKiddLmVudHJpZXMoKSk7XG4gICAgICBjbG9uZWQuZm9yRWFjaCgoW29ic2VydmVyLCBudW1UaW1lc0FkZGVkXSkgPT4ge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG51bVRpbWVzQWRkZWQ7IGkrKykge1xuICAgICAgICAgIG9ic2VydmVyKGV2ZW50LCAuLi5hcmdzKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG59XG5cbmNsYXNzIFJlc291cmNlU3RvcmUgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3RvcihkYXRhLCBvcHRpb25zID0ge1xuICAgIG5zOiBbJ3RyYW5zbGF0aW9uJ10sXG4gICAgZGVmYXVsdE5TOiAndHJhbnNsYXRpb24nXG4gIH0pIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuZGF0YSA9IGRhdGEgfHwge307XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICBpZiAodGhpcy5vcHRpb25zLmtleVNlcGFyYXRvciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLm9wdGlvbnMua2V5U2VwYXJhdG9yID0gJy4nO1xuICAgIH1cbiAgICBpZiAodGhpcy5vcHRpb25zLmlnbm9yZUpTT05TdHJ1Y3R1cmUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5vcHRpb25zLmlnbm9yZUpTT05TdHJ1Y3R1cmUgPSB0cnVlO1xuICAgIH1cbiAgfVxuICBhZGROYW1lc3BhY2VzKG5zKSB7XG4gICAgaWYgKCF0aGlzLm9wdGlvbnMubnMuaW5jbHVkZXMobnMpKSB7XG4gICAgICB0aGlzLm9wdGlvbnMubnMucHVzaChucyk7XG4gICAgfVxuICB9XG4gIHJlbW92ZU5hbWVzcGFjZXMobnMpIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMub3B0aW9ucy5ucy5pbmRleE9mKG5zKTtcbiAgICBpZiAoaW5kZXggPiAtMSkge1xuICAgICAgdGhpcy5vcHRpb25zLm5zLnNwbGljZShpbmRleCwgMSk7XG4gICAgfVxuICB9XG4gIGdldFJlc291cmNlKGxuZywgbnMsIGtleSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3Qga2V5U2VwYXJhdG9yID0gb3B0aW9ucy5rZXlTZXBhcmF0b3IgIT09IHVuZGVmaW5lZCA/IG9wdGlvbnMua2V5U2VwYXJhdG9yIDogdGhpcy5vcHRpb25zLmtleVNlcGFyYXRvcjtcbiAgICBjb25zdCBpZ25vcmVKU09OU3RydWN0dXJlID0gb3B0aW9ucy5pZ25vcmVKU09OU3RydWN0dXJlICE9PSB1bmRlZmluZWQgPyBvcHRpb25zLmlnbm9yZUpTT05TdHJ1Y3R1cmUgOiB0aGlzLm9wdGlvbnMuaWdub3JlSlNPTlN0cnVjdHVyZTtcbiAgICBsZXQgcGF0aDtcbiAgICBpZiAobG5nLmluY2x1ZGVzKCcuJykpIHtcbiAgICAgIHBhdGggPSBsbmcuc3BsaXQoJy4nKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcGF0aCA9IFtsbmcsIG5zXTtcbiAgICAgIGlmIChrZXkpIHtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoa2V5KSkge1xuICAgICAgICAgIHBhdGgucHVzaCguLi5rZXkpO1xuICAgICAgICB9IGVsc2UgaWYgKGlzU3RyaW5nKGtleSkgJiYga2V5U2VwYXJhdG9yKSB7XG4gICAgICAgICAgcGF0aC5wdXNoKC4uLmtleS5zcGxpdChrZXlTZXBhcmF0b3IpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwYXRoLnB1c2goa2V5KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCByZXN1bHQgPSBnZXRQYXRoKHRoaXMuZGF0YSwgcGF0aCk7XG4gICAgaWYgKCFyZXN1bHQgJiYgIW5zICYmICFrZXkgJiYgbG5nLmluY2x1ZGVzKCcuJykpIHtcbiAgICAgIGxuZyA9IHBhdGhbMF07XG4gICAgICBucyA9IHBhdGhbMV07XG4gICAgICBrZXkgPSBwYXRoLnNsaWNlKDIpLmpvaW4oJy4nKTtcbiAgICB9XG4gICAgaWYgKHJlc3VsdCB8fCAhaWdub3JlSlNPTlN0cnVjdHVyZSB8fCAhaXNTdHJpbmcoa2V5KSkgcmV0dXJuIHJlc3VsdDtcbiAgICByZXR1cm4gZGVlcEZpbmQodGhpcy5kYXRhPy5bbG5nXT8uW25zXSwga2V5LCBrZXlTZXBhcmF0b3IpO1xuICB9XG4gIGFkZFJlc291cmNlKGxuZywgbnMsIGtleSwgdmFsdWUsIG9wdGlvbnMgPSB7XG4gICAgc2lsZW50OiBmYWxzZVxuICB9KSB7XG4gICAgY29uc3Qga2V5U2VwYXJhdG9yID0gb3B0aW9ucy5rZXlTZXBhcmF0b3IgIT09IHVuZGVmaW5lZCA/IG9wdGlvbnMua2V5U2VwYXJhdG9yIDogdGhpcy5vcHRpb25zLmtleVNlcGFyYXRvcjtcbiAgICBsZXQgcGF0aCA9IFtsbmcsIG5zXTtcbiAgICBpZiAoa2V5KSBwYXRoID0gcGF0aC5jb25jYXQoa2V5U2VwYXJhdG9yID8ga2V5LnNwbGl0KGtleVNlcGFyYXRvcikgOiBrZXkpO1xuICAgIGlmIChsbmcuaW5jbHVkZXMoJy4nKSkge1xuICAgICAgcGF0aCA9IGxuZy5zcGxpdCgnLicpO1xuICAgICAgdmFsdWUgPSBucztcbiAgICAgIG5zID0gcGF0aFsxXTtcbiAgICB9XG4gICAgdGhpcy5hZGROYW1lc3BhY2VzKG5zKTtcbiAgICBzZXRQYXRoKHRoaXMuZGF0YSwgcGF0aCwgdmFsdWUpO1xuICAgIGlmICghb3B0aW9ucy5zaWxlbnQpIHRoaXMuZW1pdCgnYWRkZWQnLCBsbmcsIG5zLCBrZXksIHZhbHVlKTtcbiAgfVxuICBhZGRSZXNvdXJjZXMobG5nLCBucywgcmVzb3VyY2VzLCBvcHRpb25zID0ge1xuICAgIHNpbGVudDogZmFsc2VcbiAgfSkge1xuICAgIGZvciAoY29uc3QgbSBpbiByZXNvdXJjZXMpIHtcbiAgICAgIGlmIChpc1N0cmluZyhyZXNvdXJjZXNbbV0pIHx8IEFycmF5LmlzQXJyYXkocmVzb3VyY2VzW21dKSkgdGhpcy5hZGRSZXNvdXJjZShsbmcsIG5zLCBtLCByZXNvdXJjZXNbbV0sIHtcbiAgICAgICAgc2lsZW50OiB0cnVlXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKCFvcHRpb25zLnNpbGVudCkgdGhpcy5lbWl0KCdhZGRlZCcsIGxuZywgbnMsIHJlc291cmNlcyk7XG4gIH1cbiAgYWRkUmVzb3VyY2VCdW5kbGUobG5nLCBucywgcmVzb3VyY2VzLCBkZWVwLCBvdmVyd3JpdGUsIG9wdGlvbnMgPSB7XG4gICAgc2lsZW50OiBmYWxzZSxcbiAgICBza2lwQ29weTogZmFsc2VcbiAgfSkge1xuICAgIGxldCBwYXRoID0gW2xuZywgbnNdO1xuICAgIGlmIChsbmcuaW5jbHVkZXMoJy4nKSkge1xuICAgICAgcGF0aCA9IGxuZy5zcGxpdCgnLicpO1xuICAgICAgZGVlcCA9IHJlc291cmNlcztcbiAgICAgIHJlc291cmNlcyA9IG5zO1xuICAgICAgbnMgPSBwYXRoWzFdO1xuICAgIH1cbiAgICB0aGlzLmFkZE5hbWVzcGFjZXMobnMpO1xuICAgIGxldCBwYWNrID0gZ2V0UGF0aCh0aGlzLmRhdGEsIHBhdGgpIHx8IHt9O1xuICAgIGlmICghb3B0aW9ucy5za2lwQ29weSkgcmVzb3VyY2VzID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShyZXNvdXJjZXMpKTtcbiAgICBpZiAoZGVlcCkge1xuICAgICAgZGVlcEV4dGVuZChwYWNrLCByZXNvdXJjZXMsIG92ZXJ3cml0ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhY2sgPSB7XG4gICAgICAgIC4uLnBhY2ssXG4gICAgICAgIC4uLnJlc291cmNlc1xuICAgICAgfTtcbiAgICB9XG4gICAgc2V0UGF0aCh0aGlzLmRhdGEsIHBhdGgsIHBhY2spO1xuICAgIGlmICghb3B0aW9ucy5zaWxlbnQpIHRoaXMuZW1pdCgnYWRkZWQnLCBsbmcsIG5zLCByZXNvdXJjZXMpO1xuICB9XG4gIHJlbW92ZVJlc291cmNlQnVuZGxlKGxuZywgbnMpIHtcbiAgICBpZiAodGhpcy5oYXNSZXNvdXJjZUJ1bmRsZShsbmcsIG5zKSkge1xuICAgICAgZGVsZXRlIHRoaXMuZGF0YVtsbmddW25zXTtcbiAgICB9XG4gICAgdGhpcy5yZW1vdmVOYW1lc3BhY2VzKG5zKTtcbiAgICB0aGlzLmVtaXQoJ3JlbW92ZWQnLCBsbmcsIG5zKTtcbiAgfVxuICBoYXNSZXNvdXJjZUJ1bmRsZShsbmcsIG5zKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0UmVzb3VyY2UobG5nLCBucykgIT09IHVuZGVmaW5lZDtcbiAgfVxuICBnZXRSZXNvdXJjZUJ1bmRsZShsbmcsIG5zKSB7XG4gICAgaWYgKCFucykgbnMgPSB0aGlzLm9wdGlvbnMuZGVmYXVsdE5TO1xuICAgIHJldHVybiB0aGlzLmdldFJlc291cmNlKGxuZywgbnMpO1xuICB9XG4gIGdldERhdGFCeUxhbmd1YWdlKGxuZykge1xuICAgIHJldHVybiB0aGlzLmRhdGFbbG5nXTtcbiAgfVxuICBoYXNMYW5ndWFnZVNvbWVUcmFuc2xhdGlvbnMobG5nKSB7XG4gICAgY29uc3QgZGF0YSA9IHRoaXMuZ2V0RGF0YUJ5TGFuZ3VhZ2UobG5nKTtcbiAgICBjb25zdCBuID0gZGF0YSAmJiBPYmplY3Qua2V5cyhkYXRhKSB8fCBbXTtcbiAgICByZXR1cm4gISFuLmZpbmQodiA9PiBkYXRhW3ZdICYmIE9iamVjdC5rZXlzKGRhdGFbdl0pLmxlbmd0aCA+IDApO1xuICB9XG4gIHRvSlNPTigpIHtcbiAgICByZXR1cm4gdGhpcy5kYXRhO1xuICB9XG59XG5cbnZhciBwb3N0UHJvY2Vzc29yID0ge1xuICBwcm9jZXNzb3JzOiB7fSxcbiAgYWRkUG9zdFByb2Nlc3Nvcihtb2R1bGUpIHtcbiAgICB0aGlzLnByb2Nlc3NvcnNbbW9kdWxlLm5hbWVdID0gbW9kdWxlO1xuICB9LFxuICBoYW5kbGUocHJvY2Vzc29ycywgdmFsdWUsIGtleSwgb3B0aW9ucywgdHJhbnNsYXRvcikge1xuICAgIHByb2Nlc3NvcnMuZm9yRWFjaChwcm9jZXNzb3IgPT4ge1xuICAgICAgdmFsdWUgPSB0aGlzLnByb2Nlc3NvcnNbcHJvY2Vzc29yXT8ucHJvY2Vzcyh2YWx1ZSwga2V5LCBvcHRpb25zLCB0cmFuc2xhdG9yKSA/PyB2YWx1ZTtcbiAgICB9KTtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbn07XG5cbmNvbnN0IFBBVEhfS0VZID0gU3ltYm9sKCdpMThuZXh0L1BBVEhfS0VZJyk7XG5mdW5jdGlvbiBjcmVhdGVQcm94eSgpIHtcbiAgY29uc3Qgc3RhdGUgPSBbXTtcbiAgY29uc3QgaGFuZGxlciA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGxldCBwcm94eTtcbiAgaGFuZGxlci5nZXQgPSAodGFyZ2V0LCBrZXkpID0+IHtcbiAgICBwcm94eT8ucmV2b2tlPy4oKTtcbiAgICBpZiAoa2V5ID09PSBQQVRIX0tFWSkgcmV0dXJuIHN0YXRlO1xuICAgIHN0YXRlLnB1c2goa2V5KTtcbiAgICBwcm94eSA9IFByb3h5LnJldm9jYWJsZSh0YXJnZXQsIGhhbmRsZXIpO1xuICAgIHJldHVybiBwcm94eS5wcm94eTtcbiAgfTtcbiAgcmV0dXJuIFByb3h5LnJldm9jYWJsZShPYmplY3QuY3JlYXRlKG51bGwpLCBoYW5kbGVyKS5wcm94eTtcbn1cbmZ1bmN0aW9uIGtleXNGcm9tU2VsZWN0b3Ioc2VsZWN0b3IsIG9wdHMpIHtcbiAgY29uc3Qge1xuICAgIFtQQVRIX0tFWV06IHBhdGhcbiAgfSA9IHNlbGVjdG9yKGNyZWF0ZVByb3h5KCkpO1xuICBjb25zdCBrZXlTZXBhcmF0b3IgPSBvcHRzPy5rZXlTZXBhcmF0b3IgPz8gJy4nO1xuICBjb25zdCBuc1NlcGFyYXRvciA9IG9wdHM/Lm5zU2VwYXJhdG9yID8/ICc6JztcbiAgY29uc3Qgc3RyaWN0ID0gb3B0cz8uZW5hYmxlU2VsZWN0b3IgPT09ICdzdHJpY3QnO1xuICBpZiAocGF0aC5sZW5ndGggPiAxICYmIG5zU2VwYXJhdG9yKSB7XG4gICAgY29uc3QgbnMgPSBvcHRzPy5ucztcbiAgICBjb25zdCBuc0xpc3QgPSBzdHJpY3QgPyBBcnJheS5pc0FycmF5KG5zKSA/IG5zIDogbnMgPyBbbnNdIDogbnVsbCA6IEFycmF5LmlzQXJyYXkobnMpID8gbnMgOiBudWxsO1xuICAgIGlmIChuc0xpc3QpIHtcbiAgICAgIGNvbnN0IGNhbmRpZGF0ZXMgPSBzdHJpY3QgPyBuc0xpc3QgOiBuc0xpc3QubGVuZ3RoID4gMSA/IG5zTGlzdC5zbGljZSgxKSA6IFtdO1xuICAgICAgaWYgKGNhbmRpZGF0ZXMuaW5jbHVkZXMocGF0aFswXSkpIHtcbiAgICAgICAgcmV0dXJuIGAke3BhdGhbMF19JHtuc1NlcGFyYXRvcn0ke3BhdGguc2xpY2UoMSkuam9pbihrZXlTZXBhcmF0b3IpfWA7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBwYXRoLmpvaW4oa2V5U2VwYXJhdG9yKTtcbn1cblxuY29uc3Qgc2hvdWxkSGFuZGxlQXNPYmplY3QgPSByZXMgPT4gIWlzU3RyaW5nKHJlcykgJiYgdHlwZW9mIHJlcyAhPT0gJ2Jvb2xlYW4nICYmIHR5cGVvZiByZXMgIT09ICdudW1iZXInO1xuY2xhc3MgVHJhbnNsYXRvciBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIGNvbnN0cnVjdG9yKHNlcnZpY2VzLCBvcHRpb25zID0ge30pIHtcbiAgICBzdXBlcigpO1xuICAgIGNvcHkoWydyZXNvdXJjZVN0b3JlJywgJ2xhbmd1YWdlVXRpbHMnLCAncGx1cmFsUmVzb2x2ZXInLCAnaW50ZXJwb2xhdG9yJywgJ2JhY2tlbmRDb25uZWN0b3InLCAnaTE4bkZvcm1hdCcsICd1dGlscyddLCBzZXJ2aWNlcywgdGhpcyk7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICBpZiAodGhpcy5vcHRpb25zLmtleVNlcGFyYXRvciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLm9wdGlvbnMua2V5U2VwYXJhdG9yID0gJy4nO1xuICAgIH1cbiAgICB0aGlzLmxvZ2dlciA9IGJhc2VMb2dnZXIuY3JlYXRlKCd0cmFuc2xhdG9yJyk7XG4gICAgdGhpcy5jaGVja2VkTG9hZGVkRm9yID0ge307XG4gIH1cbiAgY2hhbmdlTGFuZ3VhZ2UobG5nKSB7XG4gICAgaWYgKGxuZykgdGhpcy5sYW5ndWFnZSA9IGxuZztcbiAgfVxuICBleGlzdHMoa2V5LCBvID0ge1xuICAgIGludGVycG9sYXRpb246IHt9XG4gIH0pIHtcbiAgICBjb25zdCBvcHQgPSB7XG4gICAgICAuLi5vXG4gICAgfTtcbiAgICBpZiAoa2V5ID09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCByZXNvbHZlZCA9IHRoaXMucmVzb2x2ZShrZXksIG9wdCk7XG4gICAgaWYgKHJlc29sdmVkPy5yZXMgPT09IHVuZGVmaW5lZCkgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGlzT2JqZWN0ID0gc2hvdWxkSGFuZGxlQXNPYmplY3QocmVzb2x2ZWQucmVzKTtcbiAgICBpZiAob3B0LnJldHVybk9iamVjdHMgPT09IGZhbHNlICYmIGlzT2JqZWN0KSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGV4dHJhY3RGcm9tS2V5KGtleSwgb3B0KSB7XG4gICAgbGV0IG5zU2VwYXJhdG9yID0gb3B0Lm5zU2VwYXJhdG9yICE9PSB1bmRlZmluZWQgPyBvcHQubnNTZXBhcmF0b3IgOiB0aGlzLm9wdGlvbnMubnNTZXBhcmF0b3I7XG4gICAgaWYgKG5zU2VwYXJhdG9yID09PSB1bmRlZmluZWQpIG5zU2VwYXJhdG9yID0gJzonO1xuICAgIGNvbnN0IGtleVNlcGFyYXRvciA9IG9wdC5rZXlTZXBhcmF0b3IgIT09IHVuZGVmaW5lZCA/IG9wdC5rZXlTZXBhcmF0b3IgOiB0aGlzLm9wdGlvbnMua2V5U2VwYXJhdG9yO1xuICAgIGxldCBuYW1lc3BhY2VzID0gb3B0Lm5zIHx8IHRoaXMub3B0aW9ucy5kZWZhdWx0TlMgfHwgW107XG4gICAgY29uc3Qgd291bGRDaGVja0Zvck5zSW5LZXkgPSBuc1NlcGFyYXRvciAmJiBrZXkuaW5jbHVkZXMobnNTZXBhcmF0b3IpO1xuICAgIGNvbnN0IHNlZW1zTmF0dXJhbExhbmd1YWdlID0gIXRoaXMub3B0aW9ucy51c2VyRGVmaW5lZEtleVNlcGFyYXRvciAmJiAhb3B0LmtleVNlcGFyYXRvciAmJiAhdGhpcy5vcHRpb25zLnVzZXJEZWZpbmVkTnNTZXBhcmF0b3IgJiYgIW9wdC5uc1NlcGFyYXRvciAmJiAhbG9va3NMaWtlT2JqZWN0UGF0aChrZXksIG5zU2VwYXJhdG9yLCBrZXlTZXBhcmF0b3IpO1xuICAgIGlmICh3b3VsZENoZWNrRm9yTnNJbktleSAmJiAhc2VlbXNOYXR1cmFsTGFuZ3VhZ2UpIHtcbiAgICAgIGNvbnN0IG0gPSBrZXkubWF0Y2godGhpcy5pbnRlcnBvbGF0b3IubmVzdGluZ1JlZ2V4cCk7XG4gICAgICBpZiAobSAmJiBtLmxlbmd0aCA+IDApIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBrZXksXG4gICAgICAgICAgbmFtZXNwYWNlczogaXNTdHJpbmcobmFtZXNwYWNlcykgPyBbbmFtZXNwYWNlc10gOiBuYW1lc3BhY2VzXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBjb25zdCBwYXJ0cyA9IGtleS5zcGxpdChuc1NlcGFyYXRvcik7XG4gICAgICBpZiAobnNTZXBhcmF0b3IgIT09IGtleVNlcGFyYXRvciB8fCBuc1NlcGFyYXRvciA9PT0ga2V5U2VwYXJhdG9yICYmIHRoaXMub3B0aW9ucy5ucy5pbmNsdWRlcyhwYXJ0c1swXSkpIG5hbWVzcGFjZXMgPSBwYXJ0cy5zaGlmdCgpO1xuICAgICAga2V5ID0gcGFydHMuam9pbihrZXlTZXBhcmF0b3IpO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAga2V5LFxuICAgICAgbmFtZXNwYWNlczogaXNTdHJpbmcobmFtZXNwYWNlcykgPyBbbmFtZXNwYWNlc10gOiBuYW1lc3BhY2VzXG4gICAgfTtcbiAgfVxuICB0cmFuc2xhdGUoa2V5cywgbywgbGFzdEtleSkge1xuICAgIGxldCBvcHQgPSB0eXBlb2YgbyA9PT0gJ29iamVjdCcgPyB7XG4gICAgICAuLi5vXG4gICAgfSA6IG87XG4gICAgaWYgKHR5cGVvZiBvcHQgIT09ICdvYmplY3QnICYmIHRoaXMub3B0aW9ucy5vdmVybG9hZFRyYW5zbGF0aW9uT3B0aW9uSGFuZGxlcikge1xuICAgICAgb3B0ID0gdGhpcy5vcHRpb25zLm92ZXJsb2FkVHJhbnNsYXRpb25PcHRpb25IYW5kbGVyKGFyZ3VtZW50cyk7XG4gICAgfVxuICAgIGlmICh0eXBlb2Ygb3B0ID09PSAnb2JqZWN0Jykgb3B0ID0ge1xuICAgICAgLi4ub3B0XG4gICAgfTtcbiAgICBpZiAoIW9wdCkgb3B0ID0ge307XG4gICAgaWYgKGtleXMgPT0gbnVsbCkgcmV0dXJuICcnO1xuICAgIGlmICh0eXBlb2Yga2V5cyA9PT0gJ2Z1bmN0aW9uJykga2V5cyA9IGtleXNGcm9tU2VsZWN0b3Ioa2V5cywge1xuICAgICAgLi4udGhpcy5vcHRpb25zLFxuICAgICAgLi4ub3B0XG4gICAgfSk7XG4gICAgaWYgKCFBcnJheS5pc0FycmF5KGtleXMpKSBrZXlzID0gW1N0cmluZyhrZXlzKV07XG4gICAga2V5cyA9IGtleXMubWFwKGsgPT4gdHlwZW9mIGsgPT09ICdmdW5jdGlvbicgPyBrZXlzRnJvbVNlbGVjdG9yKGssIHtcbiAgICAgIC4uLnRoaXMub3B0aW9ucyxcbiAgICAgIC4uLm9wdFxuICAgIH0pIDogU3RyaW5nKGspKTtcbiAgICBjb25zdCByZXR1cm5EZXRhaWxzID0gb3B0LnJldHVybkRldGFpbHMgIT09IHVuZGVmaW5lZCA/IG9wdC5yZXR1cm5EZXRhaWxzIDogdGhpcy5vcHRpb25zLnJldHVybkRldGFpbHM7XG4gICAgY29uc3Qga2V5U2VwYXJhdG9yID0gb3B0LmtleVNlcGFyYXRvciAhPT0gdW5kZWZpbmVkID8gb3B0LmtleVNlcGFyYXRvciA6IHRoaXMub3B0aW9ucy5rZXlTZXBhcmF0b3I7XG4gICAgY29uc3Qge1xuICAgICAga2V5LFxuICAgICAgbmFtZXNwYWNlc1xuICAgIH0gPSB0aGlzLmV4dHJhY3RGcm9tS2V5KGtleXNba2V5cy5sZW5ndGggLSAxXSwgb3B0KTtcbiAgICBjb25zdCBuYW1lc3BhY2UgPSBuYW1lc3BhY2VzW25hbWVzcGFjZXMubGVuZ3RoIC0gMV07XG4gICAgbGV0IG5zU2VwYXJhdG9yID0gb3B0Lm5zU2VwYXJhdG9yICE9PSB1bmRlZmluZWQgPyBvcHQubnNTZXBhcmF0b3IgOiB0aGlzLm9wdGlvbnMubnNTZXBhcmF0b3I7XG4gICAgaWYgKG5zU2VwYXJhdG9yID09PSB1bmRlZmluZWQpIG5zU2VwYXJhdG9yID0gJzonO1xuICAgIGNvbnN0IGxuZyA9IG9wdC5sbmcgfHwgdGhpcy5sYW5ndWFnZTtcbiAgICBjb25zdCBhcHBlbmROYW1lc3BhY2VUb0NJTW9kZSA9IG9wdC5hcHBlbmROYW1lc3BhY2VUb0NJTW9kZSB8fCB0aGlzLm9wdGlvbnMuYXBwZW5kTmFtZXNwYWNlVG9DSU1vZGU7XG4gICAgaWYgKGxuZz8udG9Mb3dlckNhc2UoKSA9PT0gJ2NpbW9kZScpIHtcbiAgICAgIGlmIChhcHBlbmROYW1lc3BhY2VUb0NJTW9kZSkge1xuICAgICAgICBpZiAocmV0dXJuRGV0YWlscykge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXM6IGAke25hbWVzcGFjZX0ke25zU2VwYXJhdG9yfSR7a2V5fWAsXG4gICAgICAgICAgICB1c2VkS2V5OiBrZXksXG4gICAgICAgICAgICBleGFjdFVzZWRLZXk6IGtleSxcbiAgICAgICAgICAgIHVzZWRMbmc6IGxuZyxcbiAgICAgICAgICAgIHVzZWROUzogbmFtZXNwYWNlLFxuICAgICAgICAgICAgdXNlZFBhcmFtczogdGhpcy5nZXRVc2VkUGFyYW1zRGV0YWlscyhvcHQpXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYCR7bmFtZXNwYWNlfSR7bnNTZXBhcmF0b3J9JHtrZXl9YDtcbiAgICAgIH1cbiAgICAgIGlmIChyZXR1cm5EZXRhaWxzKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgcmVzOiBrZXksXG4gICAgICAgICAgdXNlZEtleToga2V5LFxuICAgICAgICAgIGV4YWN0VXNlZEtleToga2V5LFxuICAgICAgICAgIHVzZWRMbmc6IGxuZyxcbiAgICAgICAgICB1c2VkTlM6IG5hbWVzcGFjZSxcbiAgICAgICAgICB1c2VkUGFyYW1zOiB0aGlzLmdldFVzZWRQYXJhbXNEZXRhaWxzKG9wdClcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBrZXk7XG4gICAgfVxuICAgIGNvbnN0IHJlc29sdmVkID0gdGhpcy5yZXNvbHZlKGtleXMsIG9wdCk7XG4gICAgbGV0IHJlcyA9IHJlc29sdmVkPy5yZXM7XG4gICAgY29uc3QgcmVzVXNlZEtleSA9IHJlc29sdmVkPy51c2VkS2V5IHx8IGtleTtcbiAgICBjb25zdCByZXNFeGFjdFVzZWRLZXkgPSByZXNvbHZlZD8uZXhhY3RVc2VkS2V5IHx8IGtleTtcbiAgICBjb25zdCBub09iamVjdCA9IFsnW29iamVjdCBOdW1iZXJdJywgJ1tvYmplY3QgRnVuY3Rpb25dJywgJ1tvYmplY3QgUmVnRXhwXSddO1xuICAgIGNvbnN0IGpvaW5BcnJheXMgPSBvcHQuam9pbkFycmF5cyAhPT0gdW5kZWZpbmVkID8gb3B0LmpvaW5BcnJheXMgOiB0aGlzLm9wdGlvbnMuam9pbkFycmF5cztcbiAgICBjb25zdCBoYW5kbGVBc09iamVjdEluSTE4bkZvcm1hdCA9ICF0aGlzLmkxOG5Gb3JtYXQgfHwgdGhpcy5pMThuRm9ybWF0LmhhbmRsZUFzT2JqZWN0O1xuICAgIGNvbnN0IG5lZWRzUGx1cmFsSGFuZGxpbmcgPSBvcHQuY291bnQgIT09IHVuZGVmaW5lZCAmJiAhaXNTdHJpbmcob3B0LmNvdW50KTtcbiAgICBjb25zdCBoYXNEZWZhdWx0VmFsdWUgPSBUcmFuc2xhdG9yLmhhc0RlZmF1bHRWYWx1ZShvcHQpO1xuICAgIGNvbnN0IGRlZmF1bHRWYWx1ZVN1ZmZpeCA9IG5lZWRzUGx1cmFsSGFuZGxpbmcgPyB0aGlzLnBsdXJhbFJlc29sdmVyLmdldFN1ZmZpeChsbmcsIG9wdC5jb3VudCwgb3B0KSA6ICcnO1xuICAgIGNvbnN0IGRlZmF1bHRWYWx1ZVN1ZmZpeE9yZGluYWxGYWxsYmFjayA9IG9wdC5vcmRpbmFsICYmIG5lZWRzUGx1cmFsSGFuZGxpbmcgPyB0aGlzLnBsdXJhbFJlc29sdmVyLmdldFN1ZmZpeChsbmcsIG9wdC5jb3VudCwge1xuICAgICAgb3JkaW5hbDogZmFsc2VcbiAgICB9KSA6ICcnO1xuICAgIGNvbnN0IG5lZWRzWmVyb1N1ZmZpeExvb2t1cCA9IG5lZWRzUGx1cmFsSGFuZGxpbmcgJiYgIW9wdC5vcmRpbmFsICYmIG9wdC5jb3VudCA9PT0gMDtcbiAgICBjb25zdCBkZWZhdWx0VmFsdWUgPSBuZWVkc1plcm9TdWZmaXhMb29rdXAgJiYgb3B0W2BkZWZhdWx0VmFsdWUke3RoaXMub3B0aW9ucy5wbHVyYWxTZXBhcmF0b3J9emVyb2BdIHx8IG9wdFtgZGVmYXVsdFZhbHVlJHtkZWZhdWx0VmFsdWVTdWZmaXh9YF0gfHwgb3B0W2BkZWZhdWx0VmFsdWUke2RlZmF1bHRWYWx1ZVN1ZmZpeE9yZGluYWxGYWxsYmFja31gXSB8fCBvcHQuZGVmYXVsdFZhbHVlO1xuICAgIGxldCByZXNGb3JPYmpIbmRsID0gcmVzO1xuICAgIGlmIChoYW5kbGVBc09iamVjdEluSTE4bkZvcm1hdCAmJiAhcmVzICYmIGhhc0RlZmF1bHRWYWx1ZSkge1xuICAgICAgcmVzRm9yT2JqSG5kbCA9IGRlZmF1bHRWYWx1ZTtcbiAgICB9XG4gICAgY29uc3QgaGFuZGxlQXNPYmplY3QgPSBzaG91bGRIYW5kbGVBc09iamVjdChyZXNGb3JPYmpIbmRsKTtcbiAgICBjb25zdCByZXNUeXBlID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5hcHBseShyZXNGb3JPYmpIbmRsKTtcbiAgICBpZiAoaGFuZGxlQXNPYmplY3RJbkkxOG5Gb3JtYXQgJiYgcmVzRm9yT2JqSG5kbCAmJiBoYW5kbGVBc09iamVjdCAmJiAhbm9PYmplY3QuaW5jbHVkZXMocmVzVHlwZSkgJiYgIShpc1N0cmluZyhqb2luQXJyYXlzKSAmJiBBcnJheS5pc0FycmF5KHJlc0Zvck9iakhuZGwpKSkge1xuICAgICAgaWYgKCFvcHQucmV0dXJuT2JqZWN0cyAmJiAhdGhpcy5vcHRpb25zLnJldHVybk9iamVjdHMpIHtcbiAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMucmV0dXJuZWRPYmplY3RIYW5kbGVyKSB7XG4gICAgICAgICAgdGhpcy5sb2dnZXIud2FybignYWNjZXNzaW5nIGFuIG9iamVjdCAtIGJ1dCByZXR1cm5PYmplY3RzIG9wdGlvbnMgaXMgbm90IGVuYWJsZWQhJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgciA9IHRoaXMub3B0aW9ucy5yZXR1cm5lZE9iamVjdEhhbmRsZXIgPyB0aGlzLm9wdGlvbnMucmV0dXJuZWRPYmplY3RIYW5kbGVyKHJlc1VzZWRLZXksIHJlc0Zvck9iakhuZGwsIHtcbiAgICAgICAgICAuLi5vcHQsXG4gICAgICAgICAgbnM6IG5hbWVzcGFjZXNcbiAgICAgICAgfSkgOiBga2V5ICcke2tleX0gKCR7dGhpcy5sYW5ndWFnZX0pJyByZXR1cm5lZCBhbiBvYmplY3QgaW5zdGVhZCBvZiBzdHJpbmcuYDtcbiAgICAgICAgaWYgKHJldHVybkRldGFpbHMpIHtcbiAgICAgICAgICByZXNvbHZlZC5yZXMgPSByO1xuICAgICAgICAgIHJlc29sdmVkLnVzZWRQYXJhbXMgPSB0aGlzLmdldFVzZWRQYXJhbXNEZXRhaWxzKG9wdCk7XG4gICAgICAgICAgcmV0dXJuIHJlc29sdmVkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByO1xuICAgICAgfVxuICAgICAgaWYgKGtleVNlcGFyYXRvcikge1xuICAgICAgICBjb25zdCByZXNUeXBlSXNBcnJheSA9IEFycmF5LmlzQXJyYXkocmVzRm9yT2JqSG5kbCk7XG4gICAgICAgIGNvbnN0IGNvcHkgPSByZXNUeXBlSXNBcnJheSA/IFtdIDoge307XG4gICAgICAgIGNvbnN0IG5ld0tleVRvVXNlID0gcmVzVHlwZUlzQXJyYXkgPyByZXNFeGFjdFVzZWRLZXkgOiByZXNVc2VkS2V5O1xuICAgICAgICBmb3IgKGNvbnN0IG0gaW4gcmVzRm9yT2JqSG5kbCkge1xuICAgICAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocmVzRm9yT2JqSG5kbCwgbSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGRlZXBLZXkgPSBgJHtuZXdLZXlUb1VzZX0ke2tleVNlcGFyYXRvcn0ke219YDtcbiAgICAgICAgICAgIGlmIChoYXNEZWZhdWx0VmFsdWUgJiYgIXJlcykge1xuICAgICAgICAgICAgICBjb3B5W21dID0gdGhpcy50cmFuc2xhdGUoZGVlcEtleSwge1xuICAgICAgICAgICAgICAgIC4uLm9wdCxcbiAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU6IHNob3VsZEhhbmRsZUFzT2JqZWN0KGRlZmF1bHRWYWx1ZSkgPyBkZWZhdWx0VmFsdWVbbV0gOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgLi4ue1xuICAgICAgICAgICAgICAgICAgam9pbkFycmF5czogZmFsc2UsXG4gICAgICAgICAgICAgICAgICBuczogbmFtZXNwYWNlc1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBjb3B5W21dID0gdGhpcy50cmFuc2xhdGUoZGVlcEtleSwge1xuICAgICAgICAgICAgICAgIC4uLm9wdCxcbiAgICAgICAgICAgICAgICAuLi57XG4gICAgICAgICAgICAgICAgICBqb2luQXJyYXlzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgIG5zOiBuYW1lc3BhY2VzXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjb3B5W21dID09PSBkZWVwS2V5KSBjb3B5W21dID0gcmVzRm9yT2JqSG5kbFttXTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmVzID0gY29weTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGhhbmRsZUFzT2JqZWN0SW5JMThuRm9ybWF0ICYmIGlzU3RyaW5nKGpvaW5BcnJheXMpICYmIEFycmF5LmlzQXJyYXkocmVzKSkge1xuICAgICAgcmVzID0gcmVzLmpvaW4oam9pbkFycmF5cyk7XG4gICAgICBpZiAocmVzKSByZXMgPSB0aGlzLmV4dGVuZFRyYW5zbGF0aW9uKHJlcywga2V5cywgb3B0LCBsYXN0S2V5KTtcbiAgICB9IGVsc2Uge1xuICAgICAgbGV0IHVzZWREZWZhdWx0ID0gZmFsc2U7XG4gICAgICBsZXQgdXNlZEtleSA9IGZhbHNlO1xuICAgICAgaWYgKCF0aGlzLmlzVmFsaWRMb29rdXAocmVzKSAmJiBoYXNEZWZhdWx0VmFsdWUpIHtcbiAgICAgICAgdXNlZERlZmF1bHQgPSB0cnVlO1xuICAgICAgICByZXMgPSBkZWZhdWx0VmFsdWU7XG4gICAgICB9XG4gICAgICBpZiAoIXRoaXMuaXNWYWxpZExvb2t1cChyZXMpKSB7XG4gICAgICAgIHVzZWRLZXkgPSB0cnVlO1xuICAgICAgICByZXMgPSBrZXk7XG4gICAgICB9XG4gICAgICBjb25zdCBtaXNzaW5nS2V5Tm9WYWx1ZUZhbGxiYWNrVG9LZXkgPSBvcHQubWlzc2luZ0tleU5vVmFsdWVGYWxsYmFja1RvS2V5IHx8IHRoaXMub3B0aW9ucy5taXNzaW5nS2V5Tm9WYWx1ZUZhbGxiYWNrVG9LZXk7XG4gICAgICBjb25zdCByZXNGb3JNaXNzaW5nID0gbWlzc2luZ0tleU5vVmFsdWVGYWxsYmFja1RvS2V5ICYmIHVzZWRLZXkgPyB1bmRlZmluZWQgOiByZXM7XG4gICAgICBjb25zdCB1cGRhdGVNaXNzaW5nID0gaGFzRGVmYXVsdFZhbHVlICYmIGRlZmF1bHRWYWx1ZSAhPT0gcmVzICYmIHRoaXMub3B0aW9ucy51cGRhdGVNaXNzaW5nO1xuICAgICAgaWYgKHVzZWRLZXkgfHwgdXNlZERlZmF1bHQgfHwgdXBkYXRlTWlzc2luZykge1xuICAgICAgICB0aGlzLmxvZ2dlci5sb2codXBkYXRlTWlzc2luZyA/ICd1cGRhdGVLZXknIDogJ21pc3NpbmdLZXknLCBsbmcsIG5hbWVzcGFjZSwgbmVlZHNQbHVyYWxIYW5kbGluZyAmJiAhdXBkYXRlTWlzc2luZyA/IGAke2tleX0ke3RoaXMucGx1cmFsUmVzb2x2ZXIuZ2V0U3VmZml4KGxuZywgb3B0LmNvdW50LCBvcHQpfWAgOiBrZXksIHVwZGF0ZU1pc3NpbmcgPyBkZWZhdWx0VmFsdWUgOiByZXMpO1xuICAgICAgICBpZiAoa2V5U2VwYXJhdG9yKSB7XG4gICAgICAgICAgY29uc3QgZmsgPSB0aGlzLnJlc29sdmUoa2V5LCB7XG4gICAgICAgICAgICAuLi5vcHQsXG4gICAgICAgICAgICBrZXlTZXBhcmF0b3I6IGZhbHNlXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgaWYgKGZrICYmIGZrLnJlcykgdGhpcy5sb2dnZXIud2FybignU2VlbXMgdGhlIGxvYWRlZCB0cmFuc2xhdGlvbnMgd2VyZSBpbiBmbGF0IEpTT04gZm9ybWF0IGluc3RlYWQgb2YgbmVzdGVkLiBFaXRoZXIgc2V0IGtleVNlcGFyYXRvcjogZmFsc2Ugb24gaW5pdCBvciBtYWtlIHN1cmUgeW91ciB0cmFuc2xhdGlvbnMgYXJlIHB1Ymxpc2hlZCBpbiBuZXN0ZWQgZm9ybWF0LicpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBsbmdzID0gW107XG4gICAgICAgIGNvbnN0IGZhbGxiYWNrTG5ncyA9IHRoaXMubGFuZ3VhZ2VVdGlscy5nZXRGYWxsYmFja0NvZGVzKHRoaXMub3B0aW9ucy5mYWxsYmFja0xuZywgb3B0LmxuZyB8fCB0aGlzLmxhbmd1YWdlKTtcbiAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5zYXZlTWlzc2luZ1RvID09PSAnZmFsbGJhY2snICYmIGZhbGxiYWNrTG5ncyAmJiBmYWxsYmFja0xuZ3NbMF0pIHtcbiAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZhbGxiYWNrTG5ncy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbG5ncy5wdXNoKGZhbGxiYWNrTG5nc1tpXSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMub3B0aW9ucy5zYXZlTWlzc2luZ1RvID09PSAnYWxsJykge1xuICAgICAgICAgIGxuZ3MgPSB0aGlzLmxhbmd1YWdlVXRpbHMudG9SZXNvbHZlSGllcmFyY2h5KG9wdC5sbmcgfHwgdGhpcy5sYW5ndWFnZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbG5ncy5wdXNoKG9wdC5sbmcgfHwgdGhpcy5sYW5ndWFnZSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc2VuZCA9IChsLCBrLCBzcGVjaWZpY0RlZmF1bHRWYWx1ZSkgPT4ge1xuICAgICAgICAgIGNvbnN0IGRlZmF1bHRGb3JNaXNzaW5nID0gaGFzRGVmYXVsdFZhbHVlICYmIHNwZWNpZmljRGVmYXVsdFZhbHVlICE9PSByZXMgPyBzcGVjaWZpY0RlZmF1bHRWYWx1ZSA6IHJlc0Zvck1pc3Npbmc7XG4gICAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5taXNzaW5nS2V5SGFuZGxlcikge1xuICAgICAgICAgICAgdGhpcy5vcHRpb25zLm1pc3NpbmdLZXlIYW5kbGVyKGwsIG5hbWVzcGFjZSwgaywgZGVmYXVsdEZvck1pc3NpbmcsIHVwZGF0ZU1pc3NpbmcsIG9wdCk7XG4gICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmJhY2tlbmRDb25uZWN0b3I/LnNhdmVNaXNzaW5nKSB7XG4gICAgICAgICAgICB0aGlzLmJhY2tlbmRDb25uZWN0b3Iuc2F2ZU1pc3NpbmcobCwgbmFtZXNwYWNlLCBrLCBkZWZhdWx0Rm9yTWlzc2luZywgdXBkYXRlTWlzc2luZywgb3B0KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5lbWl0KCdtaXNzaW5nS2V5JywgbCwgbmFtZXNwYWNlLCBrLCByZXMpO1xuICAgICAgICB9O1xuICAgICAgICBpZiAodGhpcy5vcHRpb25zLnNhdmVNaXNzaW5nKSB7XG4gICAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5zYXZlTWlzc2luZ1BsdXJhbHMgJiYgbmVlZHNQbHVyYWxIYW5kbGluZykge1xuICAgICAgICAgICAgbG5ncy5mb3JFYWNoKGxhbmd1YWdlID0+IHtcbiAgICAgICAgICAgICAgY29uc3Qgc3VmZml4ZXMgPSB0aGlzLnBsdXJhbFJlc29sdmVyLmdldFN1ZmZpeGVzKGxhbmd1YWdlLCBvcHQpO1xuICAgICAgICAgICAgICBpZiAobmVlZHNaZXJvU3VmZml4TG9va3VwICYmIG9wdFtgZGVmYXVsdFZhbHVlJHt0aGlzLm9wdGlvbnMucGx1cmFsU2VwYXJhdG9yfXplcm9gXSAmJiAhc3VmZml4ZXMuaW5jbHVkZXMoYCR7dGhpcy5vcHRpb25zLnBsdXJhbFNlcGFyYXRvcn16ZXJvYCkpIHtcbiAgICAgICAgICAgICAgICBzdWZmaXhlcy5wdXNoKGAke3RoaXMub3B0aW9ucy5wbHVyYWxTZXBhcmF0b3J9emVyb2ApO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHN1ZmZpeGVzLmZvckVhY2goc3VmZml4ID0+IHtcbiAgICAgICAgICAgICAgICBzZW5kKFtsYW5ndWFnZV0sIGtleSArIHN1ZmZpeCwgb3B0W2BkZWZhdWx0VmFsdWUke3N1ZmZpeH1gXSB8fCBkZWZhdWx0VmFsdWUpO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZW5kKGxuZ3MsIGtleSwgZGVmYXVsdFZhbHVlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlcyA9IHRoaXMuZXh0ZW5kVHJhbnNsYXRpb24ocmVzLCBrZXlzLCBvcHQsIHJlc29sdmVkLCBsYXN0S2V5KTtcbiAgICAgIGlmICh1c2VkS2V5ICYmIHJlcyA9PT0ga2V5ICYmIHRoaXMub3B0aW9ucy5hcHBlbmROYW1lc3BhY2VUb01pc3NpbmdLZXkpIHtcbiAgICAgICAgcmVzID0gYCR7bmFtZXNwYWNlfSR7bnNTZXBhcmF0b3J9JHtrZXl9YDtcbiAgICAgIH1cbiAgICAgIGlmICgodXNlZEtleSB8fCB1c2VkRGVmYXVsdCkgJiYgdGhpcy5vcHRpb25zLnBhcnNlTWlzc2luZ0tleUhhbmRsZXIpIHtcbiAgICAgICAgcmVzID0gdGhpcy5vcHRpb25zLnBhcnNlTWlzc2luZ0tleUhhbmRsZXIodGhpcy5vcHRpb25zLmFwcGVuZE5hbWVzcGFjZVRvTWlzc2luZ0tleSA/IGAke25hbWVzcGFjZX0ke25zU2VwYXJhdG9yfSR7a2V5fWAgOiBrZXksIHVzZWREZWZhdWx0ID8gcmVzIDogdW5kZWZpbmVkLCBvcHQpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAocmV0dXJuRGV0YWlscykge1xuICAgICAgcmVzb2x2ZWQucmVzID0gcmVzO1xuICAgICAgcmVzb2x2ZWQudXNlZFBhcmFtcyA9IHRoaXMuZ2V0VXNlZFBhcmFtc0RldGFpbHMob3B0KTtcbiAgICAgIHJldHVybiByZXNvbHZlZDtcbiAgICB9XG4gICAgcmV0dXJuIHJlcztcbiAgfVxuICBleHRlbmRUcmFuc2xhdGlvbihyZXMsIGtleSwgb3B0LCByZXNvbHZlZCwgbGFzdEtleSkge1xuICAgIGlmICh0aGlzLmkxOG5Gb3JtYXQ/LnBhcnNlKSB7XG4gICAgICByZXMgPSB0aGlzLmkxOG5Gb3JtYXQucGFyc2UocmVzLCB7XG4gICAgICAgIC4uLnRoaXMub3B0aW9ucy5pbnRlcnBvbGF0aW9uLmRlZmF1bHRWYXJpYWJsZXMsXG4gICAgICAgIC4uLm9wdFxuICAgICAgfSwgb3B0LmxuZyB8fCB0aGlzLmxhbmd1YWdlIHx8IHJlc29sdmVkLnVzZWRMbmcsIHJlc29sdmVkLnVzZWROUywgcmVzb2x2ZWQudXNlZEtleSwge1xuICAgICAgICByZXNvbHZlZFxuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmICghb3B0LnNraXBJbnRlcnBvbGF0aW9uKSB7XG4gICAgICBpZiAob3B0LmludGVycG9sYXRpb24pIHRoaXMuaW50ZXJwb2xhdG9yLmluaXQoe1xuICAgICAgICAuLi5vcHQsXG4gICAgICAgIC4uLntcbiAgICAgICAgICBpbnRlcnBvbGF0aW9uOiB7XG4gICAgICAgICAgICAuLi50aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvbixcbiAgICAgICAgICAgIC4uLm9wdC5pbnRlcnBvbGF0aW9uXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IHNraXBPblZhcmlhYmxlcyA9IGlzU3RyaW5nKHJlcykgJiYgKG9wdD8uaW50ZXJwb2xhdGlvbj8uc2tpcE9uVmFyaWFibGVzICE9PSB1bmRlZmluZWQgPyBvcHQuaW50ZXJwb2xhdGlvbi5za2lwT25WYXJpYWJsZXMgOiB0aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvbi5za2lwT25WYXJpYWJsZXMpO1xuICAgICAgbGV0IG5lc3RCZWY7XG4gICAgICBpZiAoc2tpcE9uVmFyaWFibGVzKSB7XG4gICAgICAgIGNvbnN0IG5iID0gcmVzLm1hdGNoKHRoaXMuaW50ZXJwb2xhdG9yLm5lc3RpbmdSZWdleHApO1xuICAgICAgICBuZXN0QmVmID0gbmIgJiYgbmIubGVuZ3RoO1xuICAgICAgfVxuICAgICAgbGV0IGRhdGEgPSBvcHQucmVwbGFjZSAmJiAhaXNTdHJpbmcob3B0LnJlcGxhY2UpID8gb3B0LnJlcGxhY2UgOiBvcHQ7XG4gICAgICBpZiAodGhpcy5vcHRpb25zLmludGVycG9sYXRpb24uZGVmYXVsdFZhcmlhYmxlcykgZGF0YSA9IHtcbiAgICAgICAgLi4udGhpcy5vcHRpb25zLmludGVycG9sYXRpb24uZGVmYXVsdFZhcmlhYmxlcyxcbiAgICAgICAgLi4uZGF0YVxuICAgICAgfTtcbiAgICAgIHJlcyA9IHRoaXMuaW50ZXJwb2xhdG9yLmludGVycG9sYXRlKHJlcywgZGF0YSwgb3B0LmxuZyB8fCB0aGlzLmxhbmd1YWdlIHx8IHJlc29sdmVkLnVzZWRMbmcsIG9wdCk7XG4gICAgICBpZiAoc2tpcE9uVmFyaWFibGVzKSB7XG4gICAgICAgIGNvbnN0IG5hID0gcmVzLm1hdGNoKHRoaXMuaW50ZXJwb2xhdG9yLm5lc3RpbmdSZWdleHApO1xuICAgICAgICBjb25zdCBuZXN0QWZ0ID0gbmEgJiYgbmEubGVuZ3RoO1xuICAgICAgICBpZiAobmVzdEJlZiA8IG5lc3RBZnQpIG9wdC5uZXN0ID0gZmFsc2U7XG4gICAgICB9XG4gICAgICBpZiAoIW9wdC5sbmcgJiYgcmVzb2x2ZWQgJiYgcmVzb2x2ZWQucmVzKSBvcHQubG5nID0gdGhpcy5sYW5ndWFnZSB8fCByZXNvbHZlZC51c2VkTG5nO1xuICAgICAgaWYgKG9wdC5uZXN0ICE9PSBmYWxzZSkgcmVzID0gdGhpcy5pbnRlcnBvbGF0b3IubmVzdChyZXMsICguLi5hcmdzKSA9PiB7XG4gICAgICAgIGlmIChsYXN0S2V5Py5bMF0gPT09IGFyZ3NbMF0gJiYgIW9wdC5jb250ZXh0KSB7XG4gICAgICAgICAgdGhpcy5sb2dnZXIud2FybihgSXQgc2VlbXMgeW91IGFyZSBuZXN0aW5nIHJlY3Vyc2l2ZWx5IGtleTogJHthcmdzWzBdfSBpbiBrZXk6ICR7a2V5WzBdfWApO1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnRyYW5zbGF0ZSguLi5hcmdzLCBrZXkpO1xuICAgICAgfSwgb3B0KTtcbiAgICAgIGlmIChvcHQuaW50ZXJwb2xhdGlvbikgdGhpcy5pbnRlcnBvbGF0b3IucmVzZXQoKTtcbiAgICB9XG4gICAgY29uc3QgcG9zdFByb2Nlc3MgPSBvcHQucG9zdFByb2Nlc3MgfHwgdGhpcy5vcHRpb25zLnBvc3RQcm9jZXNzO1xuICAgIGNvbnN0IHBvc3RQcm9jZXNzb3JOYW1lcyA9IGlzU3RyaW5nKHBvc3RQcm9jZXNzKSA/IFtwb3N0UHJvY2Vzc10gOiBwb3N0UHJvY2VzcztcbiAgICBpZiAocmVzICE9IG51bGwgJiYgcG9zdFByb2Nlc3Nvck5hbWVzPy5sZW5ndGggJiYgb3B0LmFwcGx5UG9zdFByb2Nlc3NvciAhPT0gZmFsc2UpIHtcbiAgICAgIHJlcyA9IHBvc3RQcm9jZXNzb3IuaGFuZGxlKHBvc3RQcm9jZXNzb3JOYW1lcywgcmVzLCBrZXksIHRoaXMub3B0aW9ucyAmJiB0aGlzLm9wdGlvbnMucG9zdFByb2Nlc3NQYXNzUmVzb2x2ZWQgPyB7XG4gICAgICAgIGkxOG5SZXNvbHZlZDoge1xuICAgICAgICAgIC4uLnJlc29sdmVkLFxuICAgICAgICAgIHVzZWRQYXJhbXM6IHRoaXMuZ2V0VXNlZFBhcmFtc0RldGFpbHMob3B0KVxuICAgICAgICB9LFxuICAgICAgICAuLi5vcHRcbiAgICAgIH0gOiBvcHQsIHRoaXMpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9XG4gIHJlc29sdmUoa2V5cywgb3B0ID0ge30pIHtcbiAgICBsZXQgZm91bmQ7XG4gICAgbGV0IHVzZWRLZXk7XG4gICAgbGV0IGV4YWN0VXNlZEtleTtcbiAgICBsZXQgdXNlZExuZztcbiAgICBsZXQgdXNlZE5TO1xuICAgIGlmIChpc1N0cmluZyhrZXlzKSkga2V5cyA9IFtrZXlzXTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShrZXlzKSkga2V5cyA9IGtleXMubWFwKGsgPT4gdHlwZW9mIGsgPT09ICdmdW5jdGlvbicgPyBrZXlzRnJvbVNlbGVjdG9yKGssIHtcbiAgICAgIC4uLnRoaXMub3B0aW9ucyxcbiAgICAgIC4uLm9wdFxuICAgIH0pIDogayk7XG4gICAga2V5cy5mb3JFYWNoKGsgPT4ge1xuICAgICAgaWYgKHRoaXMuaXNWYWxpZExvb2t1cChmb3VuZCkpIHJldHVybjtcbiAgICAgIGNvbnN0IGV4dHJhY3RlZCA9IHRoaXMuZXh0cmFjdEZyb21LZXkoaywgb3B0KTtcbiAgICAgIGNvbnN0IGtleSA9IGV4dHJhY3RlZC5rZXk7XG4gICAgICB1c2VkS2V5ID0ga2V5O1xuICAgICAgbGV0IG5hbWVzcGFjZXMgPSBleHRyYWN0ZWQubmFtZXNwYWNlcztcbiAgICAgIGlmICh0aGlzLm9wdGlvbnMuZmFsbGJhY2tOUykgbmFtZXNwYWNlcyA9IG5hbWVzcGFjZXMuY29uY2F0KHRoaXMub3B0aW9ucy5mYWxsYmFja05TKTtcbiAgICAgIGNvbnN0IG5lZWRzUGx1cmFsSGFuZGxpbmcgPSBvcHQuY291bnQgIT09IHVuZGVmaW5lZCAmJiAhaXNTdHJpbmcob3B0LmNvdW50KTtcbiAgICAgIGNvbnN0IG5lZWRzWmVyb1N1ZmZpeExvb2t1cCA9IG5lZWRzUGx1cmFsSGFuZGxpbmcgJiYgIW9wdC5vcmRpbmFsICYmIG9wdC5jb3VudCA9PT0gMDtcbiAgICAgIGNvbnN0IG5lZWRzQ29udGV4dEhhbmRsaW5nID0gb3B0LmNvbnRleHQgIT09IHVuZGVmaW5lZCAmJiAoaXNTdHJpbmcob3B0LmNvbnRleHQpIHx8IHR5cGVvZiBvcHQuY29udGV4dCA9PT0gJ251bWJlcicpICYmIG9wdC5jb250ZXh0ICE9PSAnJztcbiAgICAgIGNvbnN0IGNvZGVzID0gb3B0LmxuZ3MgPyBvcHQubG5ncyA6IHRoaXMubGFuZ3VhZ2VVdGlscy50b1Jlc29sdmVIaWVyYXJjaHkob3B0LmxuZyB8fCB0aGlzLmxhbmd1YWdlLCBvcHQuZmFsbGJhY2tMbmcpO1xuICAgICAgbmFtZXNwYWNlcy5mb3JFYWNoKG5zID0+IHtcbiAgICAgICAgaWYgKHRoaXMuaXNWYWxpZExvb2t1cChmb3VuZCkpIHJldHVybjtcbiAgICAgICAgdXNlZE5TID0gbnM7XG4gICAgICAgIGlmICghdGhpcy5jaGVja2VkTG9hZGVkRm9yW2Ake2NvZGVzWzBdfS0ke25zfWBdICYmIHRoaXMudXRpbHM/Lmhhc0xvYWRlZE5hbWVzcGFjZSAmJiAhdGhpcy51dGlscz8uaGFzTG9hZGVkTmFtZXNwYWNlKHVzZWROUykpIHtcbiAgICAgICAgICB0aGlzLmNoZWNrZWRMb2FkZWRGb3JbYCR7Y29kZXNbMF19LSR7bnN9YF0gPSB0cnVlO1xuICAgICAgICAgIHRoaXMubG9nZ2VyLndhcm4oYGtleSBcIiR7dXNlZEtleX1cIiBmb3IgbGFuZ3VhZ2VzIFwiJHtjb2Rlcy5qb2luKCcsICcpfVwiIHdvbid0IGdldCByZXNvbHZlZCBhcyBuYW1lc3BhY2UgXCIke3VzZWROU31cIiB3YXMgbm90IHlldCBsb2FkZWRgLCAnVGhpcyBtZWFucyBzb21ldGhpbmcgSVMgV1JPTkcgaW4geW91ciBzZXR1cC4gWW91IGFjY2VzcyB0aGUgdCBmdW5jdGlvbiBiZWZvcmUgaTE4bmV4dC5pbml0IC8gaTE4bmV4dC5sb2FkTmFtZXNwYWNlIC8gaTE4bmV4dC5jaGFuZ2VMYW5ndWFnZSB3YXMgZG9uZS4gV2FpdCBmb3IgdGhlIGNhbGxiYWNrIG9yIFByb21pc2UgdG8gcmVzb2x2ZSBiZWZvcmUgYWNjZXNzaW5nIGl0ISEhJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29kZXMuZm9yRWFjaChjb2RlID0+IHtcbiAgICAgICAgICBpZiAodGhpcy5pc1ZhbGlkTG9va3VwKGZvdW5kKSkgcmV0dXJuO1xuICAgICAgICAgIHVzZWRMbmcgPSBjb2RlO1xuICAgICAgICAgIGNvbnN0IGZpbmFsS2V5cyA9IFtrZXldO1xuICAgICAgICAgIGlmICh0aGlzLmkxOG5Gb3JtYXQ/LmFkZExvb2t1cEtleXMpIHtcbiAgICAgICAgICAgIHRoaXMuaTE4bkZvcm1hdC5hZGRMb29rdXBLZXlzKGZpbmFsS2V5cywga2V5LCBjb2RlLCBucywgb3B0KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbGV0IHBsdXJhbFN1ZmZpeDtcbiAgICAgICAgICAgIGlmIChuZWVkc1BsdXJhbEhhbmRsaW5nKSBwbHVyYWxTdWZmaXggPSB0aGlzLnBsdXJhbFJlc29sdmVyLmdldFN1ZmZpeChjb2RlLCBvcHQuY291bnQsIG9wdCk7XG4gICAgICAgICAgICBjb25zdCB6ZXJvU3VmZml4ID0gYCR7dGhpcy5vcHRpb25zLnBsdXJhbFNlcGFyYXRvcn16ZXJvYDtcbiAgICAgICAgICAgIGNvbnN0IG9yZGluYWxQcmVmaXggPSBgJHt0aGlzLm9wdGlvbnMucGx1cmFsU2VwYXJhdG9yfW9yZGluYWwke3RoaXMub3B0aW9ucy5wbHVyYWxTZXBhcmF0b3J9YDtcbiAgICAgICAgICAgIGlmIChuZWVkc1BsdXJhbEhhbmRsaW5nKSB7XG4gICAgICAgICAgICAgIGlmIChvcHQub3JkaW5hbCAmJiBwbHVyYWxTdWZmaXguc3RhcnRzV2l0aChvcmRpbmFsUHJlZml4KSkge1xuICAgICAgICAgICAgICAgIGZpbmFsS2V5cy5wdXNoKGtleSArIHBsdXJhbFN1ZmZpeC5yZXBsYWNlKG9yZGluYWxQcmVmaXgsIHRoaXMub3B0aW9ucy5wbHVyYWxTZXBhcmF0b3IpKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBmaW5hbEtleXMucHVzaChrZXkgKyBwbHVyYWxTdWZmaXgpO1xuICAgICAgICAgICAgICBpZiAobmVlZHNaZXJvU3VmZml4TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgZmluYWxLZXlzLnB1c2goa2V5ICsgemVyb1N1ZmZpeCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChuZWVkc0NvbnRleHRIYW5kbGluZykge1xuICAgICAgICAgICAgICBjb25zdCBjb250ZXh0S2V5ID0gYCR7a2V5fSR7dGhpcy5vcHRpb25zLmNvbnRleHRTZXBhcmF0b3IgfHwgJ18nfSR7b3B0LmNvbnRleHR9YDtcbiAgICAgICAgICAgICAgZmluYWxLZXlzLnB1c2goY29udGV4dEtleSk7XG4gICAgICAgICAgICAgIGlmIChuZWVkc1BsdXJhbEhhbmRsaW5nKSB7XG4gICAgICAgICAgICAgICAgaWYgKG9wdC5vcmRpbmFsICYmIHBsdXJhbFN1ZmZpeC5zdGFydHNXaXRoKG9yZGluYWxQcmVmaXgpKSB7XG4gICAgICAgICAgICAgICAgICBmaW5hbEtleXMucHVzaChjb250ZXh0S2V5ICsgcGx1cmFsU3VmZml4LnJlcGxhY2Uob3JkaW5hbFByZWZpeCwgdGhpcy5vcHRpb25zLnBsdXJhbFNlcGFyYXRvcikpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmaW5hbEtleXMucHVzaChjb250ZXh0S2V5ICsgcGx1cmFsU3VmZml4KTtcbiAgICAgICAgICAgICAgICBpZiAobmVlZHNaZXJvU3VmZml4TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgICBmaW5hbEtleXMucHVzaChjb250ZXh0S2V5ICsgemVyb1N1ZmZpeCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGxldCBwb3NzaWJsZUtleTtcbiAgICAgICAgICB3aGlsZSAocG9zc2libGVLZXkgPSBmaW5hbEtleXMucG9wKCkpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5pc1ZhbGlkTG9va3VwKGZvdW5kKSkge1xuICAgICAgICAgICAgICBleGFjdFVzZWRLZXkgPSBwb3NzaWJsZUtleTtcbiAgICAgICAgICAgICAgZm91bmQgPSB0aGlzLmdldFJlc291cmNlKGNvZGUsIG5zLCBwb3NzaWJsZUtleSwgb3B0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHJlczogZm91bmQsXG4gICAgICB1c2VkS2V5LFxuICAgICAgZXhhY3RVc2VkS2V5LFxuICAgICAgdXNlZExuZyxcbiAgICAgIHVzZWROU1xuICAgIH07XG4gIH1cbiAgaXNWYWxpZExvb2t1cChyZXMpIHtcbiAgICByZXR1cm4gcmVzICE9PSB1bmRlZmluZWQgJiYgISghdGhpcy5vcHRpb25zLnJldHVybk51bGwgJiYgcmVzID09PSBudWxsKSAmJiAhKCF0aGlzLm9wdGlvbnMucmV0dXJuRW1wdHlTdHJpbmcgJiYgcmVzID09PSAnJyk7XG4gIH1cbiAgZ2V0UmVzb3VyY2UoY29kZSwgbnMsIGtleSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgaWYgKHRoaXMuaTE4bkZvcm1hdD8uZ2V0UmVzb3VyY2UpIHJldHVybiB0aGlzLmkxOG5Gb3JtYXQuZ2V0UmVzb3VyY2UoY29kZSwgbnMsIGtleSwgb3B0aW9ucyk7XG4gICAgcmV0dXJuIHRoaXMucmVzb3VyY2VTdG9yZS5nZXRSZXNvdXJjZShjb2RlLCBucywga2V5LCBvcHRpb25zKTtcbiAgfVxuICBnZXRVc2VkUGFyYW1zRGV0YWlscyhvcHRpb25zID0ge30pIHtcbiAgICBjb25zdCBvcHRpb25zS2V5cyA9IFsnZGVmYXVsdFZhbHVlJywgJ29yZGluYWwnLCAnY29udGV4dCcsICdyZXBsYWNlJywgJ2xuZycsICdsbmdzJywgJ2ZhbGxiYWNrTG5nJywgJ25zJywgJ2tleVNlcGFyYXRvcicsICduc1NlcGFyYXRvcicsICdyZXR1cm5PYmplY3RzJywgJ3JldHVybkRldGFpbHMnLCAnam9pbkFycmF5cycsICdwb3N0UHJvY2VzcycsICdpbnRlcnBvbGF0aW9uJ107XG4gICAgY29uc3QgdXNlT3B0aW9uc1JlcGxhY2VGb3JEYXRhID0gb3B0aW9ucy5yZXBsYWNlICYmICFpc1N0cmluZyhvcHRpb25zLnJlcGxhY2UpO1xuICAgIGxldCBkYXRhID0gdXNlT3B0aW9uc1JlcGxhY2VGb3JEYXRhID8gb3B0aW9ucy5yZXBsYWNlIDogb3B0aW9ucztcbiAgICBpZiAodXNlT3B0aW9uc1JlcGxhY2VGb3JEYXRhICYmIHR5cGVvZiBvcHRpb25zLmNvdW50ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgZGF0YSA9IHtcbiAgICAgICAgLi4uZGF0YSxcbiAgICAgICAgY291bnQ6IG9wdGlvbnMuY291bnRcbiAgICAgIH07XG4gICAgfVxuICAgIGlmICh0aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvbi5kZWZhdWx0VmFyaWFibGVzKSB7XG4gICAgICBkYXRhID0ge1xuICAgICAgICAuLi50aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvbi5kZWZhdWx0VmFyaWFibGVzLFxuICAgICAgICAuLi5kYXRhXG4gICAgICB9O1xuICAgIH1cbiAgICBpZiAoIXVzZU9wdGlvbnNSZXBsYWNlRm9yRGF0YSkge1xuICAgICAgZGF0YSA9IHtcbiAgICAgICAgLi4uZGF0YVxuICAgICAgfTtcbiAgICAgIGZvciAoY29uc3Qga2V5IG9mIG9wdGlvbnNLZXlzKSB7XG4gICAgICAgIGRlbGV0ZSBkYXRhW2tleV07XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBkYXRhO1xuICB9XG4gIHN0YXRpYyBoYXNEZWZhdWx0VmFsdWUob3B0aW9ucykge1xuICAgIGNvbnN0IHByZWZpeCA9ICdkZWZhdWx0VmFsdWUnO1xuICAgIGZvciAoY29uc3Qgb3B0aW9uIGluIG9wdGlvbnMpIHtcbiAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob3B0aW9ucywgb3B0aW9uKSAmJiBvcHRpb24uc3RhcnRzV2l0aChwcmVmaXgpICYmIHVuZGVmaW5lZCAhPT0gb3B0aW9uc1tvcHRpb25dKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuY2xhc3MgTGFuZ3VhZ2VVdGlsIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy5zdXBwb3J0ZWRMbmdzID0gdGhpcy5vcHRpb25zLnN1cHBvcnRlZExuZ3MgfHwgZmFsc2U7XG4gICAgdGhpcy5sb2dnZXIgPSBiYXNlTG9nZ2VyLmNyZWF0ZSgnbGFuZ3VhZ2VVdGlscycpO1xuICB9XG4gIGdldFNjcmlwdFBhcnRGcm9tQ29kZShjb2RlKSB7XG4gICAgY29kZSA9IGdldENsZWFuZWRDb2RlKGNvZGUpO1xuICAgIGlmICghY29kZSB8fCAhY29kZS5pbmNsdWRlcygnLScpKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBwID0gY29kZS5zcGxpdCgnLScpO1xuICAgIGlmIChwLmxlbmd0aCA9PT0gMikgcmV0dXJuIG51bGw7XG4gICAgcC5wb3AoKTtcbiAgICBpZiAocFtwLmxlbmd0aCAtIDFdLnRvTG93ZXJDYXNlKCkgPT09ICd4JykgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIHRoaXMuZm9ybWF0TGFuZ3VhZ2VDb2RlKHAuam9pbignLScpKTtcbiAgfVxuICBnZXRMYW5ndWFnZVBhcnRGcm9tQ29kZShjb2RlKSB7XG4gICAgY29kZSA9IGdldENsZWFuZWRDb2RlKGNvZGUpO1xuICAgIGlmICghY29kZSB8fCAhY29kZS5pbmNsdWRlcygnLScpKSByZXR1cm4gY29kZTtcbiAgICBjb25zdCBwID0gY29kZS5zcGxpdCgnLScpO1xuICAgIHJldHVybiB0aGlzLmZvcm1hdExhbmd1YWdlQ29kZShwWzBdKTtcbiAgfVxuICBmb3JtYXRMYW5ndWFnZUNvZGUoY29kZSkge1xuICAgIGlmIChpc1N0cmluZyhjb2RlKSAmJiBjb2RlLmluY2x1ZGVzKCctJykpIHtcbiAgICAgIGxldCBmb3JtYXR0ZWRDb2RlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZm9ybWF0dGVkQ29kZSA9IEludGwuZ2V0Q2Fub25pY2FsTG9jYWxlcyhjb2RlKVswXTtcbiAgICAgIH0gY2F0Y2ggKGUpIHt9XG4gICAgICBpZiAoZm9ybWF0dGVkQ29kZSAmJiB0aGlzLm9wdGlvbnMubG93ZXJDYXNlTG5nKSB7XG4gICAgICAgIGZvcm1hdHRlZENvZGUgPSBmb3JtYXR0ZWRDb2RlLnRvTG93ZXJDYXNlKCk7XG4gICAgICB9XG4gICAgICBpZiAoZm9ybWF0dGVkQ29kZSkgcmV0dXJuIGZvcm1hdHRlZENvZGU7XG4gICAgICBpZiAodGhpcy5vcHRpb25zLmxvd2VyQ2FzZUxuZykge1xuICAgICAgICByZXR1cm4gY29kZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGNvZGU7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm9wdGlvbnMuY2xlYW5Db2RlIHx8IHRoaXMub3B0aW9ucy5sb3dlckNhc2VMbmcgPyBjb2RlLnRvTG93ZXJDYXNlKCkgOiBjb2RlO1xuICB9XG4gIGlzU3VwcG9ydGVkQ29kZShjb2RlKSB7XG4gICAgaWYgKHRoaXMub3B0aW9ucy5sb2FkID09PSAnbGFuZ3VhZ2VPbmx5JyB8fCB0aGlzLm9wdGlvbnMubm9uRXhwbGljaXRTdXBwb3J0ZWRMbmdzKSB7XG4gICAgICBjb2RlID0gdGhpcy5nZXRMYW5ndWFnZVBhcnRGcm9tQ29kZShjb2RlKTtcbiAgICB9XG4gICAgcmV0dXJuICF0aGlzLnN1cHBvcnRlZExuZ3MgfHwgIXRoaXMuc3VwcG9ydGVkTG5ncy5sZW5ndGggfHwgdGhpcy5zdXBwb3J0ZWRMbmdzLmluY2x1ZGVzKGNvZGUpO1xuICB9XG4gIGdldEJlc3RNYXRjaEZyb21Db2Rlcyhjb2Rlcykge1xuICAgIGlmICghY29kZXMpIHJldHVybiBudWxsO1xuICAgIGxldCBmb3VuZDtcbiAgICBjb2Rlcy5mb3JFYWNoKGNvZGUgPT4ge1xuICAgICAgaWYgKGZvdW5kKSByZXR1cm47XG4gICAgICBjb25zdCBjbGVhbmVkTG5nID0gdGhpcy5mb3JtYXRMYW5ndWFnZUNvZGUoY29kZSk7XG4gICAgICBpZiAoIXRoaXMub3B0aW9ucy5zdXBwb3J0ZWRMbmdzIHx8IHRoaXMuaXNTdXBwb3J0ZWRDb2RlKGNsZWFuZWRMbmcpKSBmb3VuZCA9IGNsZWFuZWRMbmc7XG4gICAgfSk7XG4gICAgaWYgKCFmb3VuZCAmJiB0aGlzLm9wdGlvbnMuc3VwcG9ydGVkTG5ncykge1xuICAgICAgY29kZXMuZm9yRWFjaChjb2RlID0+IHtcbiAgICAgICAgaWYgKGZvdW5kKSByZXR1cm47XG4gICAgICAgIGNvbnN0IGxuZ1NjT25seSA9IHRoaXMuZ2V0U2NyaXB0UGFydEZyb21Db2RlKGNvZGUpO1xuICAgICAgICBpZiAodGhpcy5pc1N1cHBvcnRlZENvZGUobG5nU2NPbmx5KSkgcmV0dXJuIGZvdW5kID0gbG5nU2NPbmx5O1xuICAgICAgICBjb25zdCBsbmdPbmx5ID0gdGhpcy5nZXRMYW5ndWFnZVBhcnRGcm9tQ29kZShjb2RlKTtcbiAgICAgICAgaWYgKHRoaXMuaXNTdXBwb3J0ZWRDb2RlKGxuZ09ubHkpKSByZXR1cm4gZm91bmQgPSBsbmdPbmx5O1xuICAgICAgICBmb3VuZCA9IHRoaXMub3B0aW9ucy5zdXBwb3J0ZWRMbmdzLmZpbmQoc3VwcG9ydGVkTG5nID0+IHtcbiAgICAgICAgICBpZiAoc3VwcG9ydGVkTG5nID09PSBsbmdPbmx5KSByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICBpZiAoIXN1cHBvcnRlZExuZy5pbmNsdWRlcygnLScpICYmICFsbmdPbmx5LmluY2x1ZGVzKCctJykpIHJldHVybiBmYWxzZTtcbiAgICAgICAgICBpZiAoc3VwcG9ydGVkTG5nLmluY2x1ZGVzKCctJykgJiYgIWxuZ09ubHkuaW5jbHVkZXMoJy0nKSAmJiBzdXBwb3J0ZWRMbmcuc2xpY2UoMCwgc3VwcG9ydGVkTG5nLmluZGV4T2YoJy0nKSkgPT09IGxuZ09ubHkpIHJldHVybiB0cnVlO1xuICAgICAgICAgIGlmIChzdXBwb3J0ZWRMbmcuc3RhcnRzV2l0aChsbmdPbmx5KSAmJiBsbmdPbmx5Lmxlbmd0aCA+IDEpIHJldHVybiB0cnVlO1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKCFmb3VuZCkgZm91bmQgPSB0aGlzLmdldEZhbGxiYWNrQ29kZXModGhpcy5vcHRpb25zLmZhbGxiYWNrTG5nKVswXTtcbiAgICByZXR1cm4gZm91bmQ7XG4gIH1cbiAgZ2V0RmFsbGJhY2tDb2RlcyhmYWxsYmFja3MsIGNvZGUpIHtcbiAgICBpZiAoIWZhbGxiYWNrcykgcmV0dXJuIFtdO1xuICAgIGlmICh0eXBlb2YgZmFsbGJhY2tzID09PSAnZnVuY3Rpb24nKSBmYWxsYmFja3MgPSBmYWxsYmFja3MoY29kZSk7XG4gICAgaWYgKGlzU3RyaW5nKGZhbGxiYWNrcykpIGZhbGxiYWNrcyA9IFtmYWxsYmFja3NdO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGZhbGxiYWNrcykpIHJldHVybiBmYWxsYmFja3M7XG4gICAgaWYgKCFjb2RlKSByZXR1cm4gZmFsbGJhY2tzLmRlZmF1bHQgfHwgW107XG4gICAgbGV0IGZvdW5kID0gZmFsbGJhY2tzW2NvZGVdO1xuICAgIGlmICghZm91bmQpIGZvdW5kID0gZmFsbGJhY2tzW3RoaXMuZ2V0U2NyaXB0UGFydEZyb21Db2RlKGNvZGUpXTtcbiAgICBpZiAoIWZvdW5kKSBmb3VuZCA9IGZhbGxiYWNrc1t0aGlzLmZvcm1hdExhbmd1YWdlQ29kZShjb2RlKV07XG4gICAgaWYgKCFmb3VuZCkgZm91bmQgPSBmYWxsYmFja3NbdGhpcy5nZXRMYW5ndWFnZVBhcnRGcm9tQ29kZShjb2RlKV07XG4gICAgaWYgKCFmb3VuZCkgZm91bmQgPSBmYWxsYmFja3MuZGVmYXVsdDtcbiAgICByZXR1cm4gZm91bmQgfHwgW107XG4gIH1cbiAgdG9SZXNvbHZlSGllcmFyY2h5KGNvZGUsIGZhbGxiYWNrQ29kZSkge1xuICAgIGNvbnN0IGZhbGxiYWNrQ29kZXMgPSB0aGlzLmdldEZhbGxiYWNrQ29kZXMoKGZhbGxiYWNrQ29kZSA9PT0gZmFsc2UgPyBbXSA6IGZhbGxiYWNrQ29kZSkgfHwgdGhpcy5vcHRpb25zLmZhbGxiYWNrTG5nIHx8IFtdLCBjb2RlKTtcbiAgICBjb25zdCBjb2RlcyA9IFtdO1xuICAgIGNvbnN0IGFkZENvZGUgPSBjID0+IHtcbiAgICAgIGlmICghYykgcmV0dXJuO1xuICAgICAgaWYgKHRoaXMuaXNTdXBwb3J0ZWRDb2RlKGMpKSB7XG4gICAgICAgIGNvZGVzLnB1c2goYyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmxvZ2dlci53YXJuKGByZWplY3RpbmcgbGFuZ3VhZ2UgY29kZSBub3QgZm91bmQgaW4gc3VwcG9ydGVkTG5nczogJHtjfWApO1xuICAgICAgfVxuICAgIH07XG4gICAgaWYgKGlzU3RyaW5nKGNvZGUpICYmIChjb2RlLmluY2x1ZGVzKCctJykgfHwgY29kZS5pbmNsdWRlcygnXycpKSkge1xuICAgICAgaWYgKHRoaXMub3B0aW9ucy5sb2FkICE9PSAnbGFuZ3VhZ2VPbmx5JykgYWRkQ29kZSh0aGlzLmZvcm1hdExhbmd1YWdlQ29kZShjb2RlKSk7XG4gICAgICBpZiAodGhpcy5vcHRpb25zLmxvYWQgIT09ICdsYW5ndWFnZU9ubHknICYmIHRoaXMub3B0aW9ucy5sb2FkICE9PSAnY3VycmVudE9ubHknKSBhZGRDb2RlKHRoaXMuZ2V0U2NyaXB0UGFydEZyb21Db2RlKGNvZGUpKTtcbiAgICAgIGlmICh0aGlzLm9wdGlvbnMubG9hZCAhPT0gJ2N1cnJlbnRPbmx5JykgYWRkQ29kZSh0aGlzLmdldExhbmd1YWdlUGFydEZyb21Db2RlKGNvZGUpKTtcbiAgICB9IGVsc2UgaWYgKGlzU3RyaW5nKGNvZGUpKSB7XG4gICAgICBhZGRDb2RlKHRoaXMuZm9ybWF0TGFuZ3VhZ2VDb2RlKGNvZGUpKTtcbiAgICB9XG4gICAgZmFsbGJhY2tDb2Rlcy5mb3JFYWNoKGZjID0+IHtcbiAgICAgIGlmICghY29kZXMuaW5jbHVkZXMoZmMpKSBhZGRDb2RlKHRoaXMuZm9ybWF0TGFuZ3VhZ2VDb2RlKGZjKSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGNvZGVzO1xuICB9XG59XG5cbmNvbnN0IHN1ZmZpeGVzT3JkZXIgPSB7XG4gIHplcm86IDAsXG4gIG9uZTogMSxcbiAgdHdvOiAyLFxuICBmZXc6IDMsXG4gIG1hbnk6IDQsXG4gIG90aGVyOiA1XG59O1xuY29uc3QgZHVtbXlSdWxlID0ge1xuICBzZWxlY3Q6IGNvdW50ID0+IGNvdW50ID09PSAxID8gJ29uZScgOiAnb3RoZXInLFxuICByZXNvbHZlZE9wdGlvbnM6ICgpID0+ICh7XG4gICAgcGx1cmFsQ2F0ZWdvcmllczogWydvbmUnLCAnb3RoZXInXVxuICB9KVxufTtcbmNsYXNzIFBsdXJhbFJlc29sdmVyIHtcbiAgY29uc3RydWN0b3IobGFuZ3VhZ2VVdGlscywgb3B0aW9ucyA9IHt9KSB7XG4gICAgdGhpcy5sYW5ndWFnZVV0aWxzID0gbGFuZ3VhZ2VVdGlscztcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMubG9nZ2VyID0gYmFzZUxvZ2dlci5jcmVhdGUoJ3BsdXJhbFJlc29sdmVyJyk7XG4gICAgdGhpcy5wbHVyYWxSdWxlc0NhY2hlID0ge307XG4gIH1cbiAgY2xlYXJDYWNoZSgpIHtcbiAgICB0aGlzLnBsdXJhbFJ1bGVzQ2FjaGUgPSB7fTtcbiAgfVxuICBnZXRSdWxlKGNvZGUsIG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IGNsZWFuZWRDb2RlID0gZ2V0Q2xlYW5lZENvZGUoY29kZSA9PT0gJ2RldicgPyAnZW4nIDogY29kZSk7XG4gICAgY29uc3QgdHlwZSA9IG9wdGlvbnMub3JkaW5hbCA/ICdvcmRpbmFsJyA6ICdjYXJkaW5hbCc7XG4gICAgY29uc3QgY2FjaGVLZXkgPSBKU09OLnN0cmluZ2lmeSh7XG4gICAgICBjbGVhbmVkQ29kZSxcbiAgICAgIHR5cGVcbiAgICB9KTtcbiAgICBpZiAoY2FjaGVLZXkgaW4gdGhpcy5wbHVyYWxSdWxlc0NhY2hlKSB7XG4gICAgICByZXR1cm4gdGhpcy5wbHVyYWxSdWxlc0NhY2hlW2NhY2hlS2V5XTtcbiAgICB9XG4gICAgbGV0IHJ1bGU7XG4gICAgdHJ5IHtcbiAgICAgIHJ1bGUgPSBuZXcgSW50bC5QbHVyYWxSdWxlcyhjbGVhbmVkQ29kZSwge1xuICAgICAgICB0eXBlXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmICh0eXBlb2YgSW50bCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgdGhpcy5sb2dnZXIuZXJyb3IoJ05vIEludGwgc3VwcG9ydCwgcGxlYXNlIHVzZSBhbiBJbnRsIHBvbHlmaWxsIScpO1xuICAgICAgICByZXR1cm4gZHVtbXlSdWxlO1xuICAgICAgfVxuICAgICAgaWYgKCFjb2RlLm1hdGNoKC8tfF8vKSkgcmV0dXJuIGR1bW15UnVsZTtcbiAgICAgIGNvbnN0IGxuZ1BhcnQgPSB0aGlzLmxhbmd1YWdlVXRpbHMuZ2V0TGFuZ3VhZ2VQYXJ0RnJvbUNvZGUoY29kZSk7XG4gICAgICBydWxlID0gdGhpcy5nZXRSdWxlKGxuZ1BhcnQsIG9wdGlvbnMpO1xuICAgIH1cbiAgICB0aGlzLnBsdXJhbFJ1bGVzQ2FjaGVbY2FjaGVLZXldID0gcnVsZTtcbiAgICByZXR1cm4gcnVsZTtcbiAgfVxuICBuZWVkc1BsdXJhbChjb2RlLCBvcHRpb25zID0ge30pIHtcbiAgICBsZXQgcnVsZSA9IHRoaXMuZ2V0UnVsZShjb2RlLCBvcHRpb25zKTtcbiAgICBpZiAoIXJ1bGUpIHJ1bGUgPSB0aGlzLmdldFJ1bGUoJ2RldicsIG9wdGlvbnMpO1xuICAgIHJldHVybiBydWxlPy5yZXNvbHZlZE9wdGlvbnMoKS5wbHVyYWxDYXRlZ29yaWVzLmxlbmd0aCA+IDE7XG4gIH1cbiAgZ2V0UGx1cmFsRm9ybXNPZktleShjb2RlLCBrZXksIG9wdGlvbnMgPSB7fSkge1xuICAgIHJldHVybiB0aGlzLmdldFN1ZmZpeGVzKGNvZGUsIG9wdGlvbnMpLm1hcChzdWZmaXggPT4gYCR7a2V5fSR7c3VmZml4fWApO1xuICB9XG4gIGdldFN1ZmZpeGVzKGNvZGUsIG9wdGlvbnMgPSB7fSkge1xuICAgIGxldCBydWxlID0gdGhpcy5nZXRSdWxlKGNvZGUsIG9wdGlvbnMpO1xuICAgIGlmICghcnVsZSkgcnVsZSA9IHRoaXMuZ2V0UnVsZSgnZGV2Jywgb3B0aW9ucyk7XG4gICAgaWYgKCFydWxlKSByZXR1cm4gW107XG4gICAgcmV0dXJuIHJ1bGUucmVzb2x2ZWRPcHRpb25zKCkucGx1cmFsQ2F0ZWdvcmllcy5zb3J0KChwbHVyYWxDYXRlZ29yeTEsIHBsdXJhbENhdGVnb3J5MikgPT4gc3VmZml4ZXNPcmRlcltwbHVyYWxDYXRlZ29yeTFdIC0gc3VmZml4ZXNPcmRlcltwbHVyYWxDYXRlZ29yeTJdKS5tYXAocGx1cmFsQ2F0ZWdvcnkgPT4gYCR7dGhpcy5vcHRpb25zLnByZXBlbmR9JHtvcHRpb25zLm9yZGluYWwgPyBgb3JkaW5hbCR7dGhpcy5vcHRpb25zLnByZXBlbmR9YCA6ICcnfSR7cGx1cmFsQ2F0ZWdvcnl9YCk7XG4gIH1cbiAgZ2V0U3VmZml4KGNvZGUsIGNvdW50LCBvcHRpb25zID0ge30pIHtcbiAgICBjb25zdCBydWxlID0gdGhpcy5nZXRSdWxlKGNvZGUsIG9wdGlvbnMpO1xuICAgIGlmIChydWxlKSB7XG4gICAgICByZXR1cm4gYCR7dGhpcy5vcHRpb25zLnByZXBlbmR9JHtvcHRpb25zLm9yZGluYWwgPyBgb3JkaW5hbCR7dGhpcy5vcHRpb25zLnByZXBlbmR9YCA6ICcnfSR7cnVsZS5zZWxlY3QoY291bnQpfWA7XG4gICAgfVxuICAgIHRoaXMubG9nZ2VyLndhcm4oYG5vIHBsdXJhbCBydWxlIGZvdW5kIGZvcjogJHtjb2RlfWApO1xuICAgIHJldHVybiB0aGlzLmdldFN1ZmZpeCgnZGV2JywgY291bnQsIG9wdGlvbnMpO1xuICB9XG59XG5cbmNvbnN0IGRlZXBGaW5kV2l0aERlZmF1bHRzID0gKGRhdGEsIGRlZmF1bHREYXRhLCBrZXksIGtleVNlcGFyYXRvciA9ICcuJywgaWdub3JlSlNPTlN0cnVjdHVyZSA9IHRydWUpID0+IHtcbiAgbGV0IHBhdGggPSBnZXRQYXRoV2l0aERlZmF1bHRzKGRhdGEsIGRlZmF1bHREYXRhLCBrZXkpO1xuICBpZiAoIXBhdGggJiYgaWdub3JlSlNPTlN0cnVjdHVyZSAmJiBpc1N0cmluZyhrZXkpKSB7XG4gICAgcGF0aCA9IGRlZXBGaW5kKGRhdGEsIGtleSwga2V5U2VwYXJhdG9yKTtcbiAgICBpZiAocGF0aCA9PT0gdW5kZWZpbmVkKSBwYXRoID0gZGVlcEZpbmQoZGVmYXVsdERhdGEsIGtleSwga2V5U2VwYXJhdG9yKTtcbiAgfVxuICByZXR1cm4gcGF0aDtcbn07XG5jb25zdCByZWdleFNhZmUgPSB2YWwgPT4gdmFsLnJlcGxhY2UoL1xcJC9nLCAnJCQkJCcpO1xuY2xhc3MgSW50ZXJwb2xhdG9yIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgdGhpcy5sb2dnZXIgPSBiYXNlTG9nZ2VyLmNyZWF0ZSgnaW50ZXJwb2xhdG9yJyk7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB0aGlzLmZvcm1hdCA9IG9wdGlvbnM/LmludGVycG9sYXRpb24/LmZvcm1hdCB8fCAodmFsdWUgPT4gdmFsdWUpO1xuICAgIHRoaXMuaW5pdChvcHRpb25zKTtcbiAgfVxuICBpbml0KG9wdGlvbnMgPSB7fSkge1xuICAgIGlmICghb3B0aW9ucy5pbnRlcnBvbGF0aW9uKSBvcHRpb25zLmludGVycG9sYXRpb24gPSB7XG4gICAgICBlc2NhcGVWYWx1ZTogdHJ1ZVxuICAgIH07XG4gICAgY29uc3Qge1xuICAgICAgZXNjYXBlOiBlc2NhcGUkMSxcbiAgICAgIGVzY2FwZVZhbHVlLFxuICAgICAgdXNlUmF3VmFsdWVUb0VzY2FwZSxcbiAgICAgIHByZWZpeCxcbiAgICAgIHByZWZpeEVzY2FwZWQsXG4gICAgICBzdWZmaXgsXG4gICAgICBzdWZmaXhFc2NhcGVkLFxuICAgICAgZm9ybWF0U2VwYXJhdG9yLFxuICAgICAgdW5lc2NhcGVTdWZmaXgsXG4gICAgICB1bmVzY2FwZVByZWZpeCxcbiAgICAgIG5lc3RpbmdQcmVmaXgsXG4gICAgICBuZXN0aW5nUHJlZml4RXNjYXBlZCxcbiAgICAgIG5lc3RpbmdTdWZmaXgsXG4gICAgICBuZXN0aW5nU3VmZml4RXNjYXBlZCxcbiAgICAgIG5lc3RpbmdPcHRpb25zU2VwYXJhdG9yLFxuICAgICAgbWF4UmVwbGFjZXMsXG4gICAgICBhbHdheXNGb3JtYXRcbiAgICB9ID0gb3B0aW9ucy5pbnRlcnBvbGF0aW9uO1xuICAgIHRoaXMuZXNjYXBlID0gZXNjYXBlJDEgIT09IHVuZGVmaW5lZCA/IGVzY2FwZSQxIDogZXNjYXBlO1xuICAgIHRoaXMuZXNjYXBlVmFsdWUgPSBlc2NhcGVWYWx1ZSAhPT0gdW5kZWZpbmVkID8gZXNjYXBlVmFsdWUgOiB0cnVlO1xuICAgIHRoaXMudXNlUmF3VmFsdWVUb0VzY2FwZSA9IHVzZVJhd1ZhbHVlVG9Fc2NhcGUgIT09IHVuZGVmaW5lZCA/IHVzZVJhd1ZhbHVlVG9Fc2NhcGUgOiBmYWxzZTtcbiAgICB0aGlzLnByZWZpeCA9IHByZWZpeCA/IHJlZ2V4RXNjYXBlKHByZWZpeCkgOiBwcmVmaXhFc2NhcGVkIHx8ICd7eyc7XG4gICAgdGhpcy5zdWZmaXggPSBzdWZmaXggPyByZWdleEVzY2FwZShzdWZmaXgpIDogc3VmZml4RXNjYXBlZCB8fCAnfX0nO1xuICAgIHRoaXMuZm9ybWF0U2VwYXJhdG9yID0gZm9ybWF0U2VwYXJhdG9yIHx8ICcsJztcbiAgICB0aGlzLnVuZXNjYXBlUHJlZml4ID0gdW5lc2NhcGVTdWZmaXggPyAnJyA6IHVuZXNjYXBlUHJlZml4ID8gcmVnZXhFc2NhcGUodW5lc2NhcGVQcmVmaXgpIDogJy0nO1xuICAgIHRoaXMudW5lc2NhcGVTdWZmaXggPSB0aGlzLnVuZXNjYXBlUHJlZml4ID8gJycgOiB1bmVzY2FwZVN1ZmZpeCA/IHJlZ2V4RXNjYXBlKHVuZXNjYXBlU3VmZml4KSA6ICcnO1xuICAgIHRoaXMubmVzdGluZ1ByZWZpeCA9IG5lc3RpbmdQcmVmaXggPyByZWdleEVzY2FwZShuZXN0aW5nUHJlZml4KSA6IG5lc3RpbmdQcmVmaXhFc2NhcGVkIHx8IHJlZ2V4RXNjYXBlKCckdCgnKTtcbiAgICB0aGlzLm5lc3RpbmdTdWZmaXggPSBuZXN0aW5nU3VmZml4ID8gcmVnZXhFc2NhcGUobmVzdGluZ1N1ZmZpeCkgOiBuZXN0aW5nU3VmZml4RXNjYXBlZCB8fCByZWdleEVzY2FwZSgnKScpO1xuICAgIHRoaXMubmVzdGluZ09wdGlvbnNTZXBhcmF0b3IgPSBuZXN0aW5nT3B0aW9uc1NlcGFyYXRvciB8fCAnLCc7XG4gICAgdGhpcy5tYXhSZXBsYWNlcyA9IG1heFJlcGxhY2VzIHx8IDEwMDA7XG4gICAgdGhpcy5hbHdheXNGb3JtYXQgPSBhbHdheXNGb3JtYXQgIT09IHVuZGVmaW5lZCA/IGFsd2F5c0Zvcm1hdCA6IGZhbHNlO1xuICAgIHRoaXMucmVzZXRSZWdFeHAoKTtcbiAgfVxuICByZXNldCgpIHtcbiAgICBpZiAodGhpcy5vcHRpb25zKSB0aGlzLmluaXQodGhpcy5vcHRpb25zKTtcbiAgfVxuICByZXNldFJlZ0V4cCgpIHtcbiAgICBjb25zdCBnZXRPclJlc2V0UmVnRXhwID0gKGV4aXN0aW5nUmVnRXhwLCBwYXR0ZXJuKSA9PiB7XG4gICAgICBpZiAoZXhpc3RpbmdSZWdFeHA/LnNvdXJjZSA9PT0gcGF0dGVybikge1xuICAgICAgICBleGlzdGluZ1JlZ0V4cC5sYXN0SW5kZXggPSAwO1xuICAgICAgICByZXR1cm4gZXhpc3RpbmdSZWdFeHA7XG4gICAgICB9XG4gICAgICByZXR1cm4gbmV3IFJlZ0V4cChwYXR0ZXJuLCAnZycpO1xuICAgIH07XG4gICAgdGhpcy5yZWdleHAgPSBnZXRPclJlc2V0UmVnRXhwKHRoaXMucmVnZXhwLCBgJHt0aGlzLnByZWZpeH0oLis/KSR7dGhpcy5zdWZmaXh9YCk7XG4gICAgdGhpcy5yZWdleHBVbmVzY2FwZSA9IGdldE9yUmVzZXRSZWdFeHAodGhpcy5yZWdleHBVbmVzY2FwZSwgYCR7dGhpcy5wcmVmaXh9JHt0aGlzLnVuZXNjYXBlUHJlZml4fSguKz8pJHt0aGlzLnVuZXNjYXBlU3VmZml4fSR7dGhpcy5zdWZmaXh9YCk7XG4gICAgdGhpcy5uZXN0aW5nUmVnZXhwID0gZ2V0T3JSZXNldFJlZ0V4cCh0aGlzLm5lc3RpbmdSZWdleHAsIGAke3RoaXMubmVzdGluZ1ByZWZpeH0oKD86W14oKVwiJ10rfFwiW15cIl0qXCJ8J1teJ10qJ3xcXFxcKCg/OlteKCldfFwiW15cIl0qXCJ8J1teJ10qJykqXFxcXCkpKj8pJHt0aGlzLm5lc3RpbmdTdWZmaXh9YCk7XG4gIH1cbiAgaW50ZXJwb2xhdGUoc3RyLCBkYXRhLCBsbmcsIG9wdGlvbnMpIHtcbiAgICBsZXQgbWF0Y2g7XG4gICAgbGV0IHZhbHVlO1xuICAgIGxldCByZXBsYWNlcztcbiAgICBjb25zdCBkZWZhdWx0RGF0YSA9IHRoaXMub3B0aW9ucyAmJiB0aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvbiAmJiB0aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvbi5kZWZhdWx0VmFyaWFibGVzIHx8IHt9O1xuICAgIGNvbnN0IGhhbmRsZUZvcm1hdCA9IGtleSA9PiB7XG4gICAgICBpZiAoIWtleS5pbmNsdWRlcyh0aGlzLmZvcm1hdFNlcGFyYXRvcikpIHtcbiAgICAgICAgY29uc3QgcGF0aCA9IGRlZXBGaW5kV2l0aERlZmF1bHRzKGRhdGEsIGRlZmF1bHREYXRhLCBrZXksIHRoaXMub3B0aW9ucy5rZXlTZXBhcmF0b3IsIHRoaXMub3B0aW9ucy5pZ25vcmVKU09OU3RydWN0dXJlKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuYWx3YXlzRm9ybWF0ID8gdGhpcy5mb3JtYXQocGF0aCwgdW5kZWZpbmVkLCBsbmcsIHtcbiAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgIC4uLmRhdGEsXG4gICAgICAgICAgaW50ZXJwb2xhdGlvbmtleToga2V5XG4gICAgICAgIH0pIDogcGF0aDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHAgPSBrZXkuc3BsaXQodGhpcy5mb3JtYXRTZXBhcmF0b3IpO1xuICAgICAgY29uc3QgayA9IHAuc2hpZnQoKS50cmltKCk7XG4gICAgICBjb25zdCBmID0gcC5qb2luKHRoaXMuZm9ybWF0U2VwYXJhdG9yKS50cmltKCk7XG4gICAgICByZXR1cm4gdGhpcy5mb3JtYXQoZGVlcEZpbmRXaXRoRGVmYXVsdHMoZGF0YSwgZGVmYXVsdERhdGEsIGssIHRoaXMub3B0aW9ucy5rZXlTZXBhcmF0b3IsIHRoaXMub3B0aW9ucy5pZ25vcmVKU09OU3RydWN0dXJlKSwgZiwgbG5nLCB7XG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIC4uLmRhdGEsXG4gICAgICAgIGludGVycG9sYXRpb25rZXk6IGtcbiAgICAgIH0pO1xuICAgIH07XG4gICAgdGhpcy5yZXNldFJlZ0V4cCgpO1xuICAgIGlmICghdGhpcy5lc2NhcGVWYWx1ZSAmJiB0eXBlb2Ygc3RyID09PSAnc3RyaW5nJyAmJiAvXFwkdFxcKFteKV0qXFx7W159XSpcXHtcXHsvLnRlc3Qoc3RyKSkge1xuICAgICAgdGhpcy5sb2dnZXIud2FybignbmVzdGluZyBvcHRpb25zIHN0cmluZyBjb250YWlucyBpbnRlcnBvbGF0ZWQgdmFyaWFibGVzIHdpdGggZXNjYXBlVmFsdWU6IGZhbHNlIOKAlCAnICsgJ2lmIGFueSBvZiB0aG9zZSB2YWx1ZXMgYXJlIGF0dGFja2VyLWNvbnRyb2xsZWQgdGhleSBjYW4gaW5qZWN0IGFkZGl0aW9uYWwgJyArICduZXN0aW5nIG9wdGlvbnMgKGUuZy4gcmVkaXJlY3QgbG5nL25zKS4gU2FuaXRpc2UgdW50cnVzdGVkIGlucHV0IGJlZm9yZSBwYXNzaW5nICcgKyAnaXQgdG8gdCgpLCBvciBrZWVwIGVzY2FwZVZhbHVlOiB0cnVlLicpO1xuICAgIH1cbiAgICBjb25zdCBtaXNzaW5nSW50ZXJwb2xhdGlvbkhhbmRsZXIgPSBvcHRpb25zPy5taXNzaW5nSW50ZXJwb2xhdGlvbkhhbmRsZXIgfHwgdGhpcy5vcHRpb25zLm1pc3NpbmdJbnRlcnBvbGF0aW9uSGFuZGxlcjtcbiAgICBjb25zdCBza2lwT25WYXJpYWJsZXMgPSBvcHRpb25zPy5pbnRlcnBvbGF0aW9uPy5za2lwT25WYXJpYWJsZXMgIT09IHVuZGVmaW5lZCA/IG9wdGlvbnMuaW50ZXJwb2xhdGlvbi5za2lwT25WYXJpYWJsZXMgOiB0aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvbi5za2lwT25WYXJpYWJsZXM7XG4gICAgY29uc3QgdG9kb3MgPSBbe1xuICAgICAgcmVnZXg6IHRoaXMucmVnZXhwVW5lc2NhcGUsXG4gICAgICBzYWZlVmFsdWU6IHZhbCA9PiB2YWxcbiAgICB9LCB7XG4gICAgICByZWdleDogdGhpcy5yZWdleHAsXG4gICAgICBzYWZlVmFsdWU6IHZhbCA9PiB0aGlzLmVzY2FwZVZhbHVlID8gdGhpcy5lc2NhcGUodmFsKSA6IHZhbFxuICAgIH1dO1xuICAgIHRvZG9zLmZvckVhY2godG9kbyA9PiB7XG4gICAgICByZXBsYWNlcyA9IDA7XG4gICAgICB3aGlsZSAobWF0Y2ggPSB0b2RvLnJlZ2V4LmV4ZWMoc3RyKSkge1xuICAgICAgICBjb25zdCBtYXRjaGVkVmFyID0gbWF0Y2hbMV0udHJpbSgpO1xuICAgICAgICB2YWx1ZSA9IGhhbmRsZUZvcm1hdChtYXRjaGVkVmFyKTtcbiAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBpZiAodHlwZW9mIG1pc3NpbmdJbnRlcnBvbGF0aW9uSGFuZGxlciA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgY29uc3QgdGVtcCA9IG1pc3NpbmdJbnRlcnBvbGF0aW9uSGFuZGxlcihzdHIsIG1hdGNoLCBvcHRpb25zKTtcbiAgICAgICAgICAgIHZhbHVlID0gaXNTdHJpbmcodGVtcCkgPyB0ZW1wIDogJyc7XG4gICAgICAgICAgfSBlbHNlIGlmIChvcHRpb25zICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvcHRpb25zLCBtYXRjaGVkVmFyKSkge1xuICAgICAgICAgICAgdmFsdWUgPSAnJztcbiAgICAgICAgICB9IGVsc2UgaWYgKHNraXBPblZhcmlhYmxlcykge1xuICAgICAgICAgICAgdmFsdWUgPSBtYXRjaFswXTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmxvZ2dlci53YXJuKGBtaXNzZWQgdG8gcGFzcyBpbiB2YXJpYWJsZSAke21hdGNoZWRWYXJ9IGZvciBpbnRlcnBvbGF0aW5nICR7c3RyfWApO1xuICAgICAgICAgICAgdmFsdWUgPSAnJztcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoIWlzU3RyaW5nKHZhbHVlKSAmJiAhdGhpcy51c2VSYXdWYWx1ZVRvRXNjYXBlKSB7XG4gICAgICAgICAgdmFsdWUgPSBtYWtlU3RyaW5nKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzYWZlVmFsdWUgPSB0b2RvLnNhZmVWYWx1ZSh2YWx1ZSk7XG4gICAgICAgIHN0ciA9IHN0ci5yZXBsYWNlKG1hdGNoWzBdLCByZWdleFNhZmUoc2FmZVZhbHVlKSk7XG4gICAgICAgIGlmIChza2lwT25WYXJpYWJsZXMpIHtcbiAgICAgICAgICB0b2RvLnJlZ2V4Lmxhc3RJbmRleCArPSBzYWZlVmFsdWUubGVuZ3RoO1xuICAgICAgICAgIHRvZG8ucmVnZXgubGFzdEluZGV4IC09IG1hdGNoWzBdLmxlbmd0aDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0b2RvLnJlZ2V4Lmxhc3RJbmRleCA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgcmVwbGFjZXMrKztcbiAgICAgICAgaWYgKHJlcGxhY2VzID49IHRoaXMubWF4UmVwbGFjZXMpIHtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBzdHI7XG4gIH1cbiAgbmVzdChzdHIsIGZjLCBvcHRpb25zID0ge30pIHtcbiAgICBsZXQgbWF0Y2g7XG4gICAgbGV0IHZhbHVlO1xuICAgIGxldCBjbG9uZWRPcHRpb25zO1xuICAgIGNvbnN0IGhhbmRsZUhhc09wdGlvbnMgPSAoa2V5LCBpbmhlcml0ZWRPcHRpb25zKSA9PiB7XG4gICAgICBjb25zdCBzZXAgPSB0aGlzLm5lc3RpbmdPcHRpb25zU2VwYXJhdG9yO1xuICAgICAgaWYgKCFrZXkuaW5jbHVkZXMoc2VwKSkgcmV0dXJuIGtleTtcbiAgICAgIGNvbnN0IGMgPSBrZXkuc3BsaXQobmV3IFJlZ0V4cChgJHtyZWdleEVzY2FwZShzZXApfVsgXSp7YCkpO1xuICAgICAgbGV0IG9wdGlvbnNTdHJpbmcgPSBgeyR7Y1sxXX1gO1xuICAgICAga2V5ID0gY1swXTtcbiAgICAgIG9wdGlvbnNTdHJpbmcgPSB0aGlzLmludGVycG9sYXRlKG9wdGlvbnNTdHJpbmcsIGNsb25lZE9wdGlvbnMpO1xuICAgICAgY29uc3QgbWF0Y2hlZFNpbmdsZVF1b3RlcyA9IG9wdGlvbnNTdHJpbmcubWF0Y2goLycvZyk7XG4gICAgICBjb25zdCBtYXRjaGVkRG91YmxlUXVvdGVzID0gb3B0aW9uc1N0cmluZy5tYXRjaCgvXCIvZyk7XG4gICAgICBpZiAoKG1hdGNoZWRTaW5nbGVRdW90ZXM/Lmxlbmd0aCA/PyAwKSAlIDIgPT09IDAgJiYgIW1hdGNoZWREb3VibGVRdW90ZXMgfHwgKG1hdGNoZWREb3VibGVRdW90ZXM/Lmxlbmd0aCA/PyAwKSAlIDIgIT09IDApIHtcbiAgICAgICAgb3B0aW9uc1N0cmluZyA9IG9wdGlvbnNTdHJpbmcucmVwbGFjZSgvJy9nLCAnXCInKTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNsb25lZE9wdGlvbnMgPSBKU09OLnBhcnNlKG9wdGlvbnNTdHJpbmcpO1xuICAgICAgICBpZiAoaW5oZXJpdGVkT3B0aW9ucykgY2xvbmVkT3B0aW9ucyA9IHtcbiAgICAgICAgICAuLi5pbmhlcml0ZWRPcHRpb25zLFxuICAgICAgICAgIC4uLmNsb25lZE9wdGlvbnNcbiAgICAgICAgfTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdGhpcy5sb2dnZXIud2FybihgZmFpbGVkIHBhcnNpbmcgb3B0aW9ucyBzdHJpbmcgaW4gbmVzdGluZyBmb3Iga2V5ICR7a2V5fWAsIGUpO1xuICAgICAgICByZXR1cm4gYCR7a2V5fSR7c2VwfSR7b3B0aW9uc1N0cmluZ31gO1xuICAgICAgfVxuICAgICAgaWYgKGNsb25lZE9wdGlvbnMuZGVmYXVsdFZhbHVlICYmIGNsb25lZE9wdGlvbnMuZGVmYXVsdFZhbHVlLmluY2x1ZGVzKHRoaXMucHJlZml4KSkgZGVsZXRlIGNsb25lZE9wdGlvbnMuZGVmYXVsdFZhbHVlO1xuICAgICAgcmV0dXJuIGtleTtcbiAgICB9O1xuICAgIHdoaWxlIChtYXRjaCA9IHRoaXMubmVzdGluZ1JlZ2V4cC5leGVjKHN0cikpIHtcbiAgICAgIGxldCBmb3JtYXR0ZXJzID0gW107XG4gICAgICBjbG9uZWRPcHRpb25zID0ge1xuICAgICAgICAuLi5vcHRpb25zXG4gICAgICB9O1xuICAgICAgY2xvbmVkT3B0aW9ucyA9IGNsb25lZE9wdGlvbnMucmVwbGFjZSAmJiAhaXNTdHJpbmcoY2xvbmVkT3B0aW9ucy5yZXBsYWNlKSA/IGNsb25lZE9wdGlvbnMucmVwbGFjZSA6IGNsb25lZE9wdGlvbnM7XG4gICAgICBjbG9uZWRPcHRpb25zLmFwcGx5UG9zdFByb2Nlc3NvciA9IGZhbHNlO1xuICAgICAgZGVsZXRlIGNsb25lZE9wdGlvbnMuZGVmYXVsdFZhbHVlO1xuICAgICAgY29uc3Qga2V5RW5kSW5kZXggPSAvey4qfS9zLnRlc3QobWF0Y2hbMV0pID8gbWF0Y2hbMV0ubGFzdEluZGV4T2YoJ30nKSArIDEgOiBtYXRjaFsxXS5pbmRleE9mKHRoaXMuZm9ybWF0U2VwYXJhdG9yKTtcbiAgICAgIGlmIChrZXlFbmRJbmRleCAhPT0gLTEpIHtcbiAgICAgICAgZm9ybWF0dGVycyA9IG1hdGNoWzFdLnNsaWNlKGtleUVuZEluZGV4KS5zcGxpdCh0aGlzLmZvcm1hdFNlcGFyYXRvcikubWFwKGVsZW0gPT4gZWxlbS50cmltKCkpLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgbWF0Y2hbMV0gPSBtYXRjaFsxXS5zbGljZSgwLCBrZXlFbmRJbmRleCk7XG4gICAgICB9XG4gICAgICB2YWx1ZSA9IGZjKGhhbmRsZUhhc09wdGlvbnMuY2FsbCh0aGlzLCBtYXRjaFsxXS50cmltKCksIGNsb25lZE9wdGlvbnMpLCBjbG9uZWRPcHRpb25zKTtcbiAgICAgIGlmICh2YWx1ZSAmJiBtYXRjaFswXSA9PT0gc3RyICYmICFpc1N0cmluZyh2YWx1ZSkpIHJldHVybiB2YWx1ZTtcbiAgICAgIGlmICghaXNTdHJpbmcodmFsdWUpKSB2YWx1ZSA9IG1ha2VTdHJpbmcodmFsdWUpO1xuICAgICAgaWYgKCF2YWx1ZSkge1xuICAgICAgICB0aGlzLmxvZ2dlci53YXJuKGBtaXNzZWQgdG8gcmVzb2x2ZSAke21hdGNoWzFdfSBmb3IgbmVzdGluZyAke3N0cn1gKTtcbiAgICAgICAgdmFsdWUgPSAnJztcbiAgICAgIH1cbiAgICAgIGlmIChmb3JtYXR0ZXJzLmxlbmd0aCkge1xuICAgICAgICB2YWx1ZSA9IGZvcm1hdHRlcnMucmVkdWNlKCh2LCBmKSA9PiB0aGlzLmZvcm1hdCh2LCBmLCBvcHRpb25zLmxuZywge1xuICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgaW50ZXJwb2xhdGlvbmtleTogbWF0Y2hbMV0udHJpbSgpXG4gICAgICAgIH0pLCB2YWx1ZS50cmltKCkpO1xuICAgICAgfVxuICAgICAgc3RyID0gc3RyLnJlcGxhY2UobWF0Y2hbMF0sIHZhbHVlKTtcbiAgICAgIHRoaXMucmVnZXhwLmxhc3RJbmRleCA9IDA7XG4gICAgfVxuICAgIHJldHVybiBzdHI7XG4gIH1cbn1cblxuY29uc3QgcGFyc2VGb3JtYXRTdHIgPSBmb3JtYXRTdHIgPT4ge1xuICBsZXQgZm9ybWF0TmFtZSA9IGZvcm1hdFN0ci50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcbiAgY29uc3QgZm9ybWF0T3B0aW9ucyA9IHt9O1xuICBpZiAoZm9ybWF0U3RyLmluY2x1ZGVzKCcoJykpIHtcbiAgICBjb25zdCBwID0gZm9ybWF0U3RyLnNwbGl0KCcoJyk7XG4gICAgZm9ybWF0TmFtZSA9IHBbMF0udG9Mb3dlckNhc2UoKS50cmltKCk7XG4gICAgY29uc3Qgb3B0U3RyID0gcFsxXS5zbGljZSgwLCAtMSk7XG4gICAgaWYgKGZvcm1hdE5hbWUgPT09ICdjdXJyZW5jeScgJiYgIW9wdFN0ci5pbmNsdWRlcygnOicpKSB7XG4gICAgICBpZiAoIWZvcm1hdE9wdGlvbnMuY3VycmVuY3kpIGZvcm1hdE9wdGlvbnMuY3VycmVuY3kgPSBvcHRTdHIudHJpbSgpO1xuICAgIH0gZWxzZSBpZiAoZm9ybWF0TmFtZSA9PT0gJ3JlbGF0aXZldGltZScgJiYgIW9wdFN0ci5pbmNsdWRlcygnOicpKSB7XG4gICAgICBpZiAoIWZvcm1hdE9wdGlvbnMucmFuZ2UpIGZvcm1hdE9wdGlvbnMucmFuZ2UgPSBvcHRTdHIudHJpbSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvcHRzID0gb3B0U3RyLnNwbGl0KCc7Jyk7XG4gICAgICBvcHRzLmZvckVhY2gob3B0ID0+IHtcbiAgICAgICAgaWYgKG9wdCkge1xuICAgICAgICAgIGNvbnN0IFtrZXksIC4uLnJlc3RdID0gb3B0LnNwbGl0KCc6Jyk7XG4gICAgICAgICAgY29uc3QgdmFsID0gcmVzdC5qb2luKCc6JykudHJpbSgpLnJlcGxhY2UoL14nK3wnKyQvZywgJycpO1xuICAgICAgICAgIGNvbnN0IHRyaW1tZWRLZXkgPSBrZXkudHJpbSgpO1xuICAgICAgICAgIGlmICghZm9ybWF0T3B0aW9uc1t0cmltbWVkS2V5XSkgZm9ybWF0T3B0aW9uc1t0cmltbWVkS2V5XSA9IHZhbDtcbiAgICAgICAgICBpZiAodmFsID09PSAnZmFsc2UnKSBmb3JtYXRPcHRpb25zW3RyaW1tZWRLZXldID0gZmFsc2U7XG4gICAgICAgICAgaWYgKHZhbCA9PT0gJ3RydWUnKSBmb3JtYXRPcHRpb25zW3RyaW1tZWRLZXldID0gdHJ1ZTtcbiAgICAgICAgICBpZiAoIWlzTmFOKHZhbCkpIGZvcm1hdE9wdGlvbnNbdHJpbW1lZEtleV0gPSBwYXJzZUludCh2YWwsIDEwKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgZm9ybWF0TmFtZSxcbiAgICBmb3JtYXRPcHRpb25zXG4gIH07XG59O1xuY29uc3QgY3JlYXRlQ2FjaGVkRm9ybWF0dGVyID0gZm4gPT4ge1xuICBjb25zdCBjYWNoZSA9IHt9O1xuICByZXR1cm4gKHYsIGwsIG8pID0+IHtcbiAgICBsZXQgb3B0Rm9yQ2FjaGUgPSBvO1xuICAgIGlmIChvICYmIG8uaW50ZXJwb2xhdGlvbmtleSAmJiBvLmZvcm1hdFBhcmFtcyAmJiBvLmZvcm1hdFBhcmFtc1tvLmludGVycG9sYXRpb25rZXldICYmIG9bby5pbnRlcnBvbGF0aW9ua2V5XSkge1xuICAgICAgb3B0Rm9yQ2FjaGUgPSB7XG4gICAgICAgIC4uLm9wdEZvckNhY2hlLFxuICAgICAgICBbby5pbnRlcnBvbGF0aW9ua2V5XTogdW5kZWZpbmVkXG4gICAgICB9O1xuICAgIH1cbiAgICBjb25zdCBrZXkgPSBsICsgSlNPTi5zdHJpbmdpZnkob3B0Rm9yQ2FjaGUpO1xuICAgIGxldCBmcm0gPSBjYWNoZVtrZXldO1xuICAgIGlmICghZnJtKSB7XG4gICAgICBmcm0gPSBmbihnZXRDbGVhbmVkQ29kZShsKSwgbyk7XG4gICAgICBjYWNoZVtrZXldID0gZnJtO1xuICAgIH1cbiAgICByZXR1cm4gZnJtKHYpO1xuICB9O1xufTtcbmNvbnN0IGNyZWF0ZU5vbkNhY2hlZEZvcm1hdHRlciA9IGZuID0+ICh2LCBsLCBvKSA9PiBmbihnZXRDbGVhbmVkQ29kZShsKSwgbykodik7XG5jbGFzcyBGb3JtYXR0ZXIge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30pIHtcbiAgICB0aGlzLmxvZ2dlciA9IGJhc2VMb2dnZXIuY3JlYXRlKCdmb3JtYXR0ZXInKTtcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMuaW5pdChvcHRpb25zKTtcbiAgfVxuICBpbml0KHNlcnZpY2VzLCBvcHRpb25zID0ge1xuICAgIGludGVycG9sYXRpb246IHt9XG4gIH0pIHtcbiAgICB0aGlzLmZvcm1hdFNlcGFyYXRvciA9IG9wdGlvbnMuaW50ZXJwb2xhdGlvbi5mb3JtYXRTZXBhcmF0b3IgfHwgJywnO1xuICAgIGNvbnN0IGNmID0gb3B0aW9ucy5jYWNoZUluQnVpbHRGb3JtYXRzID8gY3JlYXRlQ2FjaGVkRm9ybWF0dGVyIDogY3JlYXRlTm9uQ2FjaGVkRm9ybWF0dGVyO1xuICAgIHRoaXMuZm9ybWF0cyA9IHtcbiAgICAgIG51bWJlcjogY2YoKGxuZywgb3B0KSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlciA9IG5ldyBJbnRsLk51bWJlckZvcm1hdChsbmcsIHtcbiAgICAgICAgICAuLi5vcHRcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB2YWwgPT4gZm9ybWF0dGVyLmZvcm1hdCh2YWwpO1xuICAgICAgfSksXG4gICAgICBjdXJyZW5jeTogY2YoKGxuZywgb3B0KSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlciA9IG5ldyBJbnRsLk51bWJlckZvcm1hdChsbmcsIHtcbiAgICAgICAgICAuLi5vcHQsXG4gICAgICAgICAgc3R5bGU6ICdjdXJyZW5jeSdcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB2YWwgPT4gZm9ybWF0dGVyLmZvcm1hdCh2YWwpO1xuICAgICAgfSksXG4gICAgICBkYXRldGltZTogY2YoKGxuZywgb3B0KSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlciA9IG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KGxuZywge1xuICAgICAgICAgIC4uLm9wdFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHZhbCA9PiBmb3JtYXR0ZXIuZm9ybWF0KHZhbCk7XG4gICAgICB9KSxcbiAgICAgIHJlbGF0aXZldGltZTogY2YoKGxuZywgb3B0KSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlciA9IG5ldyBJbnRsLlJlbGF0aXZlVGltZUZvcm1hdChsbmcsIHtcbiAgICAgICAgICAuLi5vcHRcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB2YWwgPT4gZm9ybWF0dGVyLmZvcm1hdCh2YWwsIG9wdC5yYW5nZSB8fCAnZGF5Jyk7XG4gICAgICB9KSxcbiAgICAgIGxpc3Q6IGNmKChsbmcsIG9wdCkgPT4ge1xuICAgICAgICBjb25zdCBmb3JtYXR0ZXIgPSBuZXcgSW50bC5MaXN0Rm9ybWF0KGxuZywge1xuICAgICAgICAgIC4uLm9wdFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHZhbCA9PiBmb3JtYXR0ZXIuZm9ybWF0KHZhbCk7XG4gICAgICB9KVxuICAgIH07XG4gIH1cbiAgYWRkKG5hbWUsIGZjKSB7XG4gICAgdGhpcy5mb3JtYXRzW25hbWUudG9Mb3dlckNhc2UoKS50cmltKCldID0gZmM7XG4gIH1cbiAgYWRkQ2FjaGVkKG5hbWUsIGZjKSB7XG4gICAgdGhpcy5mb3JtYXRzW25hbWUudG9Mb3dlckNhc2UoKS50cmltKCldID0gY3JlYXRlQ2FjaGVkRm9ybWF0dGVyKGZjKTtcbiAgfVxuICBmb3JtYXQodmFsdWUsIGZvcm1hdCwgbG5nLCBvcHRpb25zID0ge30pIHtcbiAgICBpZiAoIWZvcm1hdCkgcmV0dXJuIHZhbHVlO1xuICAgIGlmICh2YWx1ZSA9PSBudWxsKSByZXR1cm4gdmFsdWU7XG4gICAgY29uc3QgcmF3Rm9ybWF0cyA9IGZvcm1hdC5zcGxpdCh0aGlzLmZvcm1hdFNlcGFyYXRvcik7XG4gICAgY29uc3QgZm9ybWF0cyA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmF3Rm9ybWF0cy5sZW5ndGg7IGkrKykge1xuICAgICAgbGV0IGYgPSByYXdGb3JtYXRzW2ldO1xuICAgICAgd2hpbGUgKGYuaW5kZXhPZignKCcpID4gLTEgJiYgIWYuaW5jbHVkZXMoJyknKSAmJiBpICsgMSA8IHJhd0Zvcm1hdHMubGVuZ3RoKSB7XG4gICAgICAgIGYgPSBgJHtmfSR7dGhpcy5mb3JtYXRTZXBhcmF0b3J9JHtyYXdGb3JtYXRzWysraV19YDtcbiAgICAgIH1cbiAgICAgIGZvcm1hdHMucHVzaChmKTtcbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0gZm9ybWF0cy5yZWR1Y2UoKG1lbSwgZikgPT4ge1xuICAgICAgY29uc3Qge1xuICAgICAgICBmb3JtYXROYW1lLFxuICAgICAgICBmb3JtYXRPcHRpb25zXG4gICAgICB9ID0gcGFyc2VGb3JtYXRTdHIoZik7XG4gICAgICBpZiAodGhpcy5mb3JtYXRzW2Zvcm1hdE5hbWVdKSB7XG4gICAgICAgIGxldCBmb3JtYXR0ZWQgPSBtZW07XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgdmFsT3B0aW9ucyA9IG9wdGlvbnM/LmZvcm1hdFBhcmFtcz8uW29wdGlvbnMuaW50ZXJwb2xhdGlvbmtleV0gfHwge307XG4gICAgICAgICAgY29uc3QgbCA9IHZhbE9wdGlvbnMubG9jYWxlIHx8IHZhbE9wdGlvbnMubG5nIHx8IG9wdGlvbnMubG9jYWxlIHx8IG9wdGlvbnMubG5nIHx8IGxuZztcbiAgICAgICAgICBmb3JtYXR0ZWQgPSB0aGlzLmZvcm1hdHNbZm9ybWF0TmFtZV0obWVtLCBsLCB7XG4gICAgICAgICAgICAuLi5mb3JtYXRPcHRpb25zLFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIC4uLnZhbE9wdGlvbnNcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICB0aGlzLmxvZ2dlci53YXJuKGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZm9ybWF0dGVkO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5sb2dnZXIud2FybihgdGhlcmUgd2FzIG5vIGZvcm1hdCBmdW5jdGlvbiBmb3IgJHtmb3JtYXROYW1lfWApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG1lbTtcbiAgICB9LCB2YWx1ZSk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxufVxuXG5jb25zdCByZW1vdmVQZW5kaW5nID0gKHEsIG5hbWUpID0+IHtcbiAgaWYgKHEucGVuZGluZ1tuYW1lXSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgZGVsZXRlIHEucGVuZGluZ1tuYW1lXTtcbiAgICBxLnBlbmRpbmdDb3VudC0tO1xuICB9XG59O1xuY2xhc3MgQ29ubmVjdG9yIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3IoYmFja2VuZCwgc3RvcmUsIHNlcnZpY2VzLCBvcHRpb25zID0ge30pIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuYmFja2VuZCA9IGJhY2tlbmQ7XG4gICAgdGhpcy5zdG9yZSA9IHN0b3JlO1xuICAgIHRoaXMuc2VydmljZXMgPSBzZXJ2aWNlcztcbiAgICB0aGlzLmxhbmd1YWdlVXRpbHMgPSBzZXJ2aWNlcy5sYW5ndWFnZVV0aWxzO1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy5sb2dnZXIgPSBiYXNlTG9nZ2VyLmNyZWF0ZSgnYmFja2VuZENvbm5lY3RvcicpO1xuICAgIHRoaXMud2FpdGluZ1JlYWRzID0gW107XG4gICAgdGhpcy5tYXhQYXJhbGxlbFJlYWRzID0gb3B0aW9ucy5tYXhQYXJhbGxlbFJlYWRzIHx8IDEwO1xuICAgIHRoaXMucmVhZGluZ0NhbGxzID0gMDtcbiAgICB0aGlzLm1heFJldHJpZXMgPSBvcHRpb25zLm1heFJldHJpZXMgPj0gMCA/IG9wdGlvbnMubWF4UmV0cmllcyA6IDU7XG4gICAgdGhpcy5yZXRyeVRpbWVvdXQgPSBvcHRpb25zLnJldHJ5VGltZW91dCA+PSAxID8gb3B0aW9ucy5yZXRyeVRpbWVvdXQgOiAzNTA7XG4gICAgdGhpcy5zdGF0ZSA9IHt9O1xuICAgIHRoaXMucXVldWUgPSBbXTtcbiAgICB0aGlzLmJhY2tlbmQ/LmluaXQ/LihzZXJ2aWNlcywgb3B0aW9ucy5iYWNrZW5kLCBvcHRpb25zKTtcbiAgfVxuICBxdWV1ZUxvYWQobGFuZ3VhZ2VzLCBuYW1lc3BhY2VzLCBvcHRpb25zLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IHRvTG9hZCA9IHt9O1xuICAgIGNvbnN0IHBlbmRpbmcgPSB7fTtcbiAgICBjb25zdCB0b0xvYWRMYW5ndWFnZXMgPSB7fTtcbiAgICBjb25zdCB0b0xvYWROYW1lc3BhY2VzID0ge307XG4gICAgbGFuZ3VhZ2VzLmZvckVhY2gobG5nID0+IHtcbiAgICAgIGxldCBoYXNBbGxOYW1lc3BhY2VzID0gdHJ1ZTtcbiAgICAgIG5hbWVzcGFjZXMuZm9yRWFjaChucyA9PiB7XG4gICAgICAgIGNvbnN0IG5hbWUgPSBgJHtsbmd9fCR7bnN9YDtcbiAgICAgICAgaWYgKCFvcHRpb25zLnJlbG9hZCAmJiB0aGlzLnN0b3JlLmhhc1Jlc291cmNlQnVuZGxlKGxuZywgbnMpKSB7XG4gICAgICAgICAgdGhpcy5zdGF0ZVtuYW1lXSA9IDI7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5zdGF0ZVtuYW1lXSA8IDApIDsgZWxzZSBpZiAodGhpcy5zdGF0ZVtuYW1lXSA9PT0gMSkge1xuICAgICAgICAgIGlmIChwZW5kaW5nW25hbWVdID09PSB1bmRlZmluZWQpIHBlbmRpbmdbbmFtZV0gPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuc3RhdGVbbmFtZV0gPSAxO1xuICAgICAgICAgIGhhc0FsbE5hbWVzcGFjZXMgPSBmYWxzZTtcbiAgICAgICAgICBpZiAocGVuZGluZ1tuYW1lXSA9PT0gdW5kZWZpbmVkKSBwZW5kaW5nW25hbWVdID0gdHJ1ZTtcbiAgICAgICAgICBpZiAodG9Mb2FkW25hbWVdID09PSB1bmRlZmluZWQpIHRvTG9hZFtuYW1lXSA9IHRydWU7XG4gICAgICAgICAgaWYgKHRvTG9hZE5hbWVzcGFjZXNbbnNdID09PSB1bmRlZmluZWQpIHRvTG9hZE5hbWVzcGFjZXNbbnNdID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBpZiAoIWhhc0FsbE5hbWVzcGFjZXMpIHRvTG9hZExhbmd1YWdlc1tsbmddID0gdHJ1ZTtcbiAgICB9KTtcbiAgICBpZiAoT2JqZWN0LmtleXModG9Mb2FkKS5sZW5ndGggfHwgT2JqZWN0LmtleXMocGVuZGluZykubGVuZ3RoKSB7XG4gICAgICB0aGlzLnF1ZXVlLnB1c2goe1xuICAgICAgICBwZW5kaW5nLFxuICAgICAgICBwZW5kaW5nQ291bnQ6IE9iamVjdC5rZXlzKHBlbmRpbmcpLmxlbmd0aCxcbiAgICAgICAgbG9hZGVkOiB7fSxcbiAgICAgICAgZXJyb3JzOiBbXSxcbiAgICAgICAgY2FsbGJhY2tcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgdG9Mb2FkOiBPYmplY3Qua2V5cyh0b0xvYWQpLFxuICAgICAgcGVuZGluZzogT2JqZWN0LmtleXMocGVuZGluZyksXG4gICAgICB0b0xvYWRMYW5ndWFnZXM6IE9iamVjdC5rZXlzKHRvTG9hZExhbmd1YWdlcyksXG4gICAgICB0b0xvYWROYW1lc3BhY2VzOiBPYmplY3Qua2V5cyh0b0xvYWROYW1lc3BhY2VzKVxuICAgIH07XG4gIH1cbiAgbG9hZGVkKG5hbWUsIGVyciwgZGF0YSkge1xuICAgIGNvbnN0IHMgPSBuYW1lLnNwbGl0KCd8Jyk7XG4gICAgY29uc3QgbG5nID0gc1swXTtcbiAgICBjb25zdCBucyA9IHNbMV07XG4gICAgaWYgKGVycikgdGhpcy5lbWl0KCdmYWlsZWRMb2FkaW5nJywgbG5nLCBucywgZXJyKTtcbiAgICBpZiAoIWVyciAmJiBkYXRhKSB7XG4gICAgICB0aGlzLnN0b3JlLmFkZFJlc291cmNlQnVuZGxlKGxuZywgbnMsIGRhdGEsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB7XG4gICAgICAgIHNraXBDb3B5OiB0cnVlXG4gICAgICB9KTtcbiAgICB9XG4gICAgdGhpcy5zdGF0ZVtuYW1lXSA9IGVyciA/IC0xIDogMjtcbiAgICBpZiAoZXJyICYmIGRhdGEpIHRoaXMuc3RhdGVbbmFtZV0gPSAwO1xuICAgIGNvbnN0IGxvYWRlZCA9IHt9O1xuICAgIHRoaXMucXVldWUuZm9yRWFjaChxID0+IHtcbiAgICAgIHB1c2hQYXRoKHEubG9hZGVkLCBbbG5nXSwgbnMpO1xuICAgICAgcmVtb3ZlUGVuZGluZyhxLCBuYW1lKTtcbiAgICAgIGlmIChlcnIpIHEuZXJyb3JzLnB1c2goZXJyKTtcbiAgICAgIGlmIChxLnBlbmRpbmdDb3VudCA9PT0gMCAmJiAhcS5kb25lKSB7XG4gICAgICAgIE9iamVjdC5rZXlzKHEubG9hZGVkKS5mb3JFYWNoKGwgPT4ge1xuICAgICAgICAgIGlmICghbG9hZGVkW2xdKSBsb2FkZWRbbF0gPSB7fTtcbiAgICAgICAgICBjb25zdCBsb2FkZWRLZXlzID0gcS5sb2FkZWRbbF07XG4gICAgICAgICAgaWYgKGxvYWRlZEtleXMubGVuZ3RoKSB7XG4gICAgICAgICAgICBsb2FkZWRLZXlzLmZvckVhY2gobiA9PiB7XG4gICAgICAgICAgICAgIGlmIChsb2FkZWRbbF1bbl0gPT09IHVuZGVmaW5lZCkgbG9hZGVkW2xdW25dID0gdHJ1ZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHEuZG9uZSA9IHRydWU7XG4gICAgICAgIGlmIChxLmVycm9ycy5sZW5ndGgpIHtcbiAgICAgICAgICBxLmNhbGxiYWNrKHEuZXJyb3JzKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBxLmNhbGxiYWNrKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgICB0aGlzLmVtaXQoJ2xvYWRlZCcsIGxvYWRlZCk7XG4gICAgdGhpcy5xdWV1ZSA9IHRoaXMucXVldWUuZmlsdGVyKHEgPT4gIXEuZG9uZSk7XG4gIH1cbiAgcmVhZChsbmcsIG5zLCBmY05hbWUsIHRyaWVkID0gMCwgd2FpdCA9IHRoaXMucmV0cnlUaW1lb3V0LCBjYWxsYmFjaykge1xuICAgIGlmICghbG5nLmxlbmd0aCkgcmV0dXJuIGNhbGxiYWNrKG51bGwsIHt9KTtcbiAgICBpZiAodGhpcy5yZWFkaW5nQ2FsbHMgPj0gdGhpcy5tYXhQYXJhbGxlbFJlYWRzKSB7XG4gICAgICB0aGlzLndhaXRpbmdSZWFkcy5wdXNoKHtcbiAgICAgICAgbG5nLFxuICAgICAgICBucyxcbiAgICAgICAgZmNOYW1lLFxuICAgICAgICB0cmllZCxcbiAgICAgICAgd2FpdCxcbiAgICAgICAgY2FsbGJhY2tcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnJlYWRpbmdDYWxscysrO1xuICAgIGNvbnN0IHJlc29sdmVyID0gKGVyciwgZGF0YSkgPT4ge1xuICAgICAgdGhpcy5yZWFkaW5nQ2FsbHMtLTtcbiAgICAgIGlmICh0aGlzLndhaXRpbmdSZWFkcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IG5leHQgPSB0aGlzLndhaXRpbmdSZWFkcy5zaGlmdCgpO1xuICAgICAgICB0aGlzLnJlYWQobmV4dC5sbmcsIG5leHQubnMsIG5leHQuZmNOYW1lLCBuZXh0LnRyaWVkLCBuZXh0LndhaXQsIG5leHQuY2FsbGJhY2spO1xuICAgICAgfVxuICAgICAgaWYgKGVyciAmJiBkYXRhICYmIHRyaWVkIDwgdGhpcy5tYXhSZXRyaWVzKSB7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHRoaXMucmVhZChsbmcsIG5zLCBmY05hbWUsIHRyaWVkICsgMSwgd2FpdCAqIDIsIGNhbGxiYWNrKTtcbiAgICAgICAgfSwgd2FpdCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNhbGxiYWNrKGVyciwgZGF0YSk7XG4gICAgfTtcbiAgICBjb25zdCBmYyA9IHRoaXMuYmFja2VuZFtmY05hbWVdLmJpbmQodGhpcy5iYWNrZW5kKTtcbiAgICBpZiAoZmMubGVuZ3RoID09PSAyKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByID0gZmMobG5nLCBucyk7XG4gICAgICAgIGlmIChyICYmIHR5cGVvZiByLnRoZW4gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICByLnRoZW4oZGF0YSA9PiByZXNvbHZlcihudWxsLCBkYXRhKSkuY2F0Y2gocmVzb2x2ZXIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmVyKG51bGwsIHIpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgcmVzb2x2ZXIoZXJyKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmV0dXJuIGZjKGxuZywgbnMsIHJlc29sdmVyKTtcbiAgfVxuICBwcmVwYXJlTG9hZGluZyhsYW5ndWFnZXMsIG5hbWVzcGFjZXMsIG9wdGlvbnMgPSB7fSwgY2FsbGJhY2spIHtcbiAgICBpZiAoIXRoaXMuYmFja2VuZCkge1xuICAgICAgdGhpcy5sb2dnZXIud2FybignTm8gYmFja2VuZCB3YXMgYWRkZWQgdmlhIGkxOG5leHQudXNlLiBXaWxsIG5vdCBsb2FkIHJlc291cmNlcy4nKTtcbiAgICAgIHJldHVybiBjYWxsYmFjayAmJiBjYWxsYmFjaygpO1xuICAgIH1cbiAgICBpZiAoaXNTdHJpbmcobGFuZ3VhZ2VzKSkgbGFuZ3VhZ2VzID0gdGhpcy5sYW5ndWFnZVV0aWxzLnRvUmVzb2x2ZUhpZXJhcmNoeShsYW5ndWFnZXMpO1xuICAgIGlmIChpc1N0cmluZyhuYW1lc3BhY2VzKSkgbmFtZXNwYWNlcyA9IFtuYW1lc3BhY2VzXTtcbiAgICBjb25zdCB0b0xvYWQgPSB0aGlzLnF1ZXVlTG9hZChsYW5ndWFnZXMsIG5hbWVzcGFjZXMsIG9wdGlvbnMsIGNhbGxiYWNrKTtcbiAgICBpZiAoIXRvTG9hZC50b0xvYWQubGVuZ3RoKSB7XG4gICAgICBpZiAoIXRvTG9hZC5wZW5kaW5nLmxlbmd0aCkgY2FsbGJhY2soKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICB0b0xvYWQudG9Mb2FkLmZvckVhY2gobmFtZSA9PiB7XG4gICAgICB0aGlzLmxvYWRPbmUobmFtZSk7XG4gICAgfSk7XG4gIH1cbiAgbG9hZChsYW5ndWFnZXMsIG5hbWVzcGFjZXMsIGNhbGxiYWNrKSB7XG4gICAgdGhpcy5wcmVwYXJlTG9hZGluZyhsYW5ndWFnZXMsIG5hbWVzcGFjZXMsIHt9LCBjYWxsYmFjayk7XG4gIH1cbiAgcmVsb2FkKGxhbmd1YWdlcywgbmFtZXNwYWNlcywgY2FsbGJhY2spIHtcbiAgICB0aGlzLnByZXBhcmVMb2FkaW5nKGxhbmd1YWdlcywgbmFtZXNwYWNlcywge1xuICAgICAgcmVsb2FkOiB0cnVlXG4gICAgfSwgY2FsbGJhY2spO1xuICB9XG4gIGxvYWRPbmUobmFtZSwgcHJlZml4ID0gJycpIHtcbiAgICBjb25zdCBzID0gbmFtZS5zcGxpdCgnfCcpO1xuICAgIGNvbnN0IGxuZyA9IHNbMF07XG4gICAgY29uc3QgbnMgPSBzWzFdO1xuICAgIHRoaXMucmVhZChsbmcsIG5zLCAncmVhZCcsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCAoZXJyLCBkYXRhKSA9PiB7XG4gICAgICBpZiAoZXJyKSB0aGlzLmxvZ2dlci53YXJuKGAke3ByZWZpeH1sb2FkaW5nIG5hbWVzcGFjZSAke25zfSBmb3IgbGFuZ3VhZ2UgJHtsbmd9IGZhaWxlZGAsIGVycik7XG4gICAgICBpZiAoIWVyciAmJiBkYXRhKSB0aGlzLmxvZ2dlci5sb2coYCR7cHJlZml4fWxvYWRlZCBuYW1lc3BhY2UgJHtuc30gZm9yIGxhbmd1YWdlICR7bG5nfWAsIGRhdGEpO1xuICAgICAgdGhpcy5sb2FkZWQobmFtZSwgZXJyLCBkYXRhKTtcbiAgICB9KTtcbiAgfVxuICBzYXZlTWlzc2luZyhsYW5ndWFnZXMsIG5hbWVzcGFjZSwga2V5LCBmYWxsYmFja1ZhbHVlLCBpc1VwZGF0ZSwgb3B0aW9ucyA9IHt9LCBjbGIgPSAoKSA9PiB7fSkge1xuICAgIGlmICh0aGlzLnNlcnZpY2VzPy51dGlscz8uaGFzTG9hZGVkTmFtZXNwYWNlICYmICF0aGlzLnNlcnZpY2VzPy51dGlscz8uaGFzTG9hZGVkTmFtZXNwYWNlKG5hbWVzcGFjZSkpIHtcbiAgICAgIHRoaXMubG9nZ2VyLndhcm4oYGRpZCBub3Qgc2F2ZSBrZXkgXCIke2tleX1cIiBhcyB0aGUgbmFtZXNwYWNlIFwiJHtuYW1lc3BhY2V9XCIgd2FzIG5vdCB5ZXQgbG9hZGVkYCwgJ1RoaXMgbWVhbnMgc29tZXRoaW5nIElTIFdST05HIGluIHlvdXIgc2V0dXAuIFlvdSBhY2Nlc3MgdGhlIHQgZnVuY3Rpb24gYmVmb3JlIGkxOG5leHQuaW5pdCAvIGkxOG5leHQubG9hZE5hbWVzcGFjZSAvIGkxOG5leHQuY2hhbmdlTGFuZ3VhZ2Ugd2FzIGRvbmUuIFdhaXQgZm9yIHRoZSBjYWxsYmFjayBvciBQcm9taXNlIHRvIHJlc29sdmUgYmVmb3JlIGFjY2Vzc2luZyBpdCEhIScpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoa2V5ID09PSB1bmRlZmluZWQgfHwga2V5ID09PSBudWxsIHx8IGtleSA9PT0gJycpIHJldHVybjtcbiAgICBpZiAodGhpcy5iYWNrZW5kPy5jcmVhdGUpIHtcbiAgICAgIGNvbnN0IG9wdHMgPSB7XG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIGlzVXBkYXRlXG4gICAgICB9O1xuICAgICAgY29uc3QgZmMgPSB0aGlzLmJhY2tlbmQuY3JlYXRlLmJpbmQodGhpcy5iYWNrZW5kKTtcbiAgICAgIGlmIChmYy5sZW5ndGggPCA2KSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGV0IHI7XG4gICAgICAgICAgaWYgKGZjLmxlbmd0aCA9PT0gNSkge1xuICAgICAgICAgICAgciA9IGZjKGxhbmd1YWdlcywgbmFtZXNwYWNlLCBrZXksIGZhbGxiYWNrVmFsdWUsIG9wdHMpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByID0gZmMobGFuZ3VhZ2VzLCBuYW1lc3BhY2UsIGtleSwgZmFsbGJhY2tWYWx1ZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChyICYmIHR5cGVvZiByLnRoZW4gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHIudGhlbihkYXRhID0+IGNsYihudWxsLCBkYXRhKSkuY2F0Y2goY2xiKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2xiKG51bGwsIHIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgY2xiKGVycik7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGZjKGxhbmd1YWdlcywgbmFtZXNwYWNlLCBrZXksIGZhbGxiYWNrVmFsdWUsIGNsYiwgb3B0cyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghbGFuZ3VhZ2VzIHx8ICFsYW5ndWFnZXNbMF0pIHJldHVybjtcbiAgICB0aGlzLnN0b3JlLmFkZFJlc291cmNlKGxhbmd1YWdlc1swXSwgbmFtZXNwYWNlLCBrZXksIGZhbGxiYWNrVmFsdWUpO1xuICB9XG59XG5cbmNvbnN0IGdldCA9ICgpID0+ICh7XG4gIGRlYnVnOiBmYWxzZSxcbiAgaW5pdEFzeW5jOiB0cnVlLFxuICBuczogWyd0cmFuc2xhdGlvbiddLFxuICBkZWZhdWx0TlM6IFsndHJhbnNsYXRpb24nXSxcbiAgZmFsbGJhY2tMbmc6IFsnZGV2J10sXG4gIGZhbGxiYWNrTlM6IGZhbHNlLFxuICBzdXBwb3J0ZWRMbmdzOiBmYWxzZSxcbiAgbm9uRXhwbGljaXRTdXBwb3J0ZWRMbmdzOiBmYWxzZSxcbiAgbG9hZDogJ2FsbCcsXG4gIHByZWxvYWQ6IGZhbHNlLFxuICBrZXlTZXBhcmF0b3I6ICcuJyxcbiAgbnNTZXBhcmF0b3I6ICc6JyxcbiAgcGx1cmFsU2VwYXJhdG9yOiAnXycsXG4gIGNvbnRleHRTZXBhcmF0b3I6ICdfJyxcbiAgZW5hYmxlU2VsZWN0b3I6IGZhbHNlLFxuICBwYXJ0aWFsQnVuZGxlZExhbmd1YWdlczogZmFsc2UsXG4gIHNhdmVNaXNzaW5nOiBmYWxzZSxcbiAgdXBkYXRlTWlzc2luZzogZmFsc2UsXG4gIHNhdmVNaXNzaW5nVG86ICdmYWxsYmFjaycsXG4gIHNhdmVNaXNzaW5nUGx1cmFsczogdHJ1ZSxcbiAgbWlzc2luZ0tleUhhbmRsZXI6IGZhbHNlLFxuICBtaXNzaW5nSW50ZXJwb2xhdGlvbkhhbmRsZXI6IGZhbHNlLFxuICBwb3N0UHJvY2VzczogZmFsc2UsXG4gIHBvc3RQcm9jZXNzUGFzc1Jlc29sdmVkOiBmYWxzZSxcbiAgcmV0dXJuTnVsbDogZmFsc2UsXG4gIHJldHVybkVtcHR5U3RyaW5nOiB0cnVlLFxuICByZXR1cm5PYmplY3RzOiBmYWxzZSxcbiAgam9pbkFycmF5czogZmFsc2UsXG4gIHJldHVybmVkT2JqZWN0SGFuZGxlcjogZmFsc2UsXG4gIHBhcnNlTWlzc2luZ0tleUhhbmRsZXI6IGZhbHNlLFxuICBhcHBlbmROYW1lc3BhY2VUb01pc3NpbmdLZXk6IGZhbHNlLFxuICBhcHBlbmROYW1lc3BhY2VUb0NJTW9kZTogZmFsc2UsXG4gIG92ZXJsb2FkVHJhbnNsYXRpb25PcHRpb25IYW5kbGVyOiBhcmdzID0+IHtcbiAgICBsZXQgcmV0ID0ge307XG4gICAgaWYgKHR5cGVvZiBhcmdzWzFdID09PSAnb2JqZWN0JykgcmV0ID0gYXJnc1sxXTtcbiAgICBpZiAoaXNTdHJpbmcoYXJnc1sxXSkpIHJldC5kZWZhdWx0VmFsdWUgPSBhcmdzWzFdO1xuICAgIGlmIChpc1N0cmluZyhhcmdzWzJdKSkgcmV0LnREZXNjcmlwdGlvbiA9IGFyZ3NbMl07XG4gICAgaWYgKHR5cGVvZiBhcmdzWzJdID09PSAnb2JqZWN0JyB8fCB0eXBlb2YgYXJnc1szXSA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGNvbnN0IG9wdGlvbnMgPSBhcmdzWzNdIHx8IGFyZ3NbMl07XG4gICAgICBPYmplY3Qua2V5cyhvcHRpb25zKS5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgIHJldFtrZXldID0gb3B0aW9uc1trZXldO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiByZXQ7XG4gIH0sXG4gIGludGVycG9sYXRpb246IHtcbiAgICBlc2NhcGVWYWx1ZTogdHJ1ZSxcbiAgICBwcmVmaXg6ICd7eycsXG4gICAgc3VmZml4OiAnfX0nLFxuICAgIGZvcm1hdFNlcGFyYXRvcjogJywnLFxuICAgIHVuZXNjYXBlUHJlZml4OiAnLScsXG4gICAgbmVzdGluZ1ByZWZpeDogJyR0KCcsXG4gICAgbmVzdGluZ1N1ZmZpeDogJyknLFxuICAgIG5lc3RpbmdPcHRpb25zU2VwYXJhdG9yOiAnLCcsXG4gICAgbWF4UmVwbGFjZXM6IDEwMDAsXG4gICAgc2tpcE9uVmFyaWFibGVzOiB0cnVlXG4gIH0sXG4gIGNhY2hlSW5CdWlsdEZvcm1hdHM6IHRydWVcbn0pO1xuY29uc3QgdHJhbnNmb3JtT3B0aW9ucyA9IG9wdGlvbnMgPT4ge1xuICBpZiAoaXNTdHJpbmcob3B0aW9ucy5ucykpIG9wdGlvbnMubnMgPSBbb3B0aW9ucy5uc107XG4gIGlmIChpc1N0cmluZyhvcHRpb25zLmZhbGxiYWNrTG5nKSkgb3B0aW9ucy5mYWxsYmFja0xuZyA9IFtvcHRpb25zLmZhbGxiYWNrTG5nXTtcbiAgaWYgKGlzU3RyaW5nKG9wdGlvbnMuZmFsbGJhY2tOUykpIG9wdGlvbnMuZmFsbGJhY2tOUyA9IFtvcHRpb25zLmZhbGxiYWNrTlNdO1xuICBpZiAob3B0aW9ucy5zdXBwb3J0ZWRMbmdzICYmICFvcHRpb25zLnN1cHBvcnRlZExuZ3MuaW5jbHVkZXMoJ2NpbW9kZScpKSB7XG4gICAgb3B0aW9ucy5zdXBwb3J0ZWRMbmdzID0gb3B0aW9ucy5zdXBwb3J0ZWRMbmdzLmNvbmNhdChbJ2NpbW9kZSddKTtcbiAgfVxuICByZXR1cm4gb3B0aW9ucztcbn07XG5cbmNvbnN0IG5vb3AgPSAoKSA9PiB7fTtcbmNvbnN0IGJpbmRNZW1iZXJGdW5jdGlvbnMgPSBpbnN0ID0+IHtcbiAgY29uc3QgbWVtcyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKE9iamVjdC5nZXRQcm90b3R5cGVPZihpbnN0KSk7XG4gIG1lbXMuZm9yRWFjaChtZW0gPT4ge1xuICAgIGlmICh0eXBlb2YgaW5zdFttZW1dID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBpbnN0W21lbV0gPSBpbnN0W21lbV0uYmluZChpbnN0KTtcbiAgICB9XG4gIH0pO1xufTtcbmNsYXNzIEkxOG4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30sIGNhbGxiYWNrKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLm9wdGlvbnMgPSB0cmFuc2Zvcm1PcHRpb25zKG9wdGlvbnMpO1xuICAgIHRoaXMuc2VydmljZXMgPSB7fTtcbiAgICB0aGlzLmxvZ2dlciA9IGJhc2VMb2dnZXI7XG4gICAgdGhpcy5tb2R1bGVzID0ge1xuICAgICAgZXh0ZXJuYWw6IFtdXG4gICAgfTtcbiAgICBiaW5kTWVtYmVyRnVuY3Rpb25zKHRoaXMpO1xuICAgIGlmIChjYWxsYmFjayAmJiAhdGhpcy5pc0luaXRpYWxpemVkICYmICFvcHRpb25zLmlzQ2xvbmUpIHtcbiAgICAgIGlmICghdGhpcy5vcHRpb25zLmluaXRBc3luYykge1xuICAgICAgICB0aGlzLmluaXQob3B0aW9ucywgY2FsbGJhY2spO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH1cbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLmluaXQob3B0aW9ucywgY2FsbGJhY2spO1xuICAgICAgfSwgMCk7XG4gICAgfVxuICB9XG4gIGluaXQob3B0aW9ucyA9IHt9LCBjYWxsYmFjaykge1xuICAgIHRoaXMuaXNJbml0aWFsaXppbmcgPSB0cnVlO1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY2FsbGJhY2sgPSBvcHRpb25zO1xuICAgICAgb3B0aW9ucyA9IHt9O1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5kZWZhdWx0TlMgPT0gbnVsbCAmJiBvcHRpb25zLm5zKSB7XG4gICAgICBpZiAoaXNTdHJpbmcob3B0aW9ucy5ucykpIHtcbiAgICAgICAgb3B0aW9ucy5kZWZhdWx0TlMgPSBvcHRpb25zLm5zO1xuICAgICAgfSBlbHNlIGlmICghb3B0aW9ucy5ucy5pbmNsdWRlcygndHJhbnNsYXRpb24nKSkge1xuICAgICAgICBvcHRpb25zLmRlZmF1bHROUyA9IG9wdGlvbnMubnNbMF07XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGRlZk9wdHMgPSBnZXQoKTtcbiAgICB0aGlzLm9wdGlvbnMgPSB7XG4gICAgICAuLi5kZWZPcHRzLFxuICAgICAgLi4udGhpcy5vcHRpb25zLFxuICAgICAgLi4udHJhbnNmb3JtT3B0aW9ucyhvcHRpb25zKVxuICAgIH07XG4gICAgdGhpcy5vcHRpb25zLmludGVycG9sYXRpb24gPSB7XG4gICAgICAuLi5kZWZPcHRzLmludGVycG9sYXRpb24sXG4gICAgICAuLi50aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvblxuICAgIH07XG4gICAgaWYgKG9wdGlvbnMua2V5U2VwYXJhdG9yICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMub3B0aW9ucy51c2VyRGVmaW5lZEtleVNlcGFyYXRvciA9IG9wdGlvbnMua2V5U2VwYXJhdG9yO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5uc1NlcGFyYXRvciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLm9wdGlvbnMudXNlckRlZmluZWROc1NlcGFyYXRvciA9IG9wdGlvbnMubnNTZXBhcmF0b3I7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgdGhpcy5vcHRpb25zLm92ZXJsb2FkVHJhbnNsYXRpb25PcHRpb25IYW5kbGVyICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICB0aGlzLm9wdGlvbnMub3ZlcmxvYWRUcmFuc2xhdGlvbk9wdGlvbkhhbmRsZXIgPSBkZWZPcHRzLm92ZXJsb2FkVHJhbnNsYXRpb25PcHRpb25IYW5kbGVyO1xuICAgIH1cbiAgICBjb25zdCBjcmVhdGVDbGFzc09uRGVtYW5kID0gQ2xhc3NPck9iamVjdCA9PiB7XG4gICAgICBpZiAoIUNsYXNzT3JPYmplY3QpIHJldHVybiBudWxsO1xuICAgICAgaWYgKHR5cGVvZiBDbGFzc09yT2JqZWN0ID09PSAnZnVuY3Rpb24nKSByZXR1cm4gbmV3IENsYXNzT3JPYmplY3QoKTtcbiAgICAgIHJldHVybiBDbGFzc09yT2JqZWN0O1xuICAgIH07XG4gICAgaWYgKCF0aGlzLm9wdGlvbnMuaXNDbG9uZSkge1xuICAgICAgaWYgKHRoaXMubW9kdWxlcy5sb2dnZXIpIHtcbiAgICAgICAgYmFzZUxvZ2dlci5pbml0KGNyZWF0ZUNsYXNzT25EZW1hbmQodGhpcy5tb2R1bGVzLmxvZ2dlciksIHRoaXMub3B0aW9ucyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBiYXNlTG9nZ2VyLmluaXQobnVsbCwgdGhpcy5vcHRpb25zKTtcbiAgICAgIH1cbiAgICAgIGxldCBmb3JtYXR0ZXI7XG4gICAgICBpZiAodGhpcy5tb2R1bGVzLmZvcm1hdHRlcikge1xuICAgICAgICBmb3JtYXR0ZXIgPSB0aGlzLm1vZHVsZXMuZm9ybWF0dGVyO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZm9ybWF0dGVyID0gRm9ybWF0dGVyO1xuICAgICAgfVxuICAgICAgY29uc3QgbHUgPSBuZXcgTGFuZ3VhZ2VVdGlsKHRoaXMub3B0aW9ucyk7XG4gICAgICB0aGlzLnN0b3JlID0gbmV3IFJlc291cmNlU3RvcmUodGhpcy5vcHRpb25zLnJlc291cmNlcywgdGhpcy5vcHRpb25zKTtcbiAgICAgIGNvbnN0IHMgPSB0aGlzLnNlcnZpY2VzO1xuICAgICAgcy5sb2dnZXIgPSBiYXNlTG9nZ2VyO1xuICAgICAgcy5yZXNvdXJjZVN0b3JlID0gdGhpcy5zdG9yZTtcbiAgICAgIHMubGFuZ3VhZ2VVdGlscyA9IGx1O1xuICAgICAgcy5wbHVyYWxSZXNvbHZlciA9IG5ldyBQbHVyYWxSZXNvbHZlcihsdSwge1xuICAgICAgICBwcmVwZW5kOiB0aGlzLm9wdGlvbnMucGx1cmFsU2VwYXJhdG9yXG4gICAgICB9KTtcbiAgICAgIGlmIChmb3JtYXR0ZXIpIHtcbiAgICAgICAgcy5mb3JtYXR0ZXIgPSBjcmVhdGVDbGFzc09uRGVtYW5kKGZvcm1hdHRlcik7XG4gICAgICAgIGlmIChzLmZvcm1hdHRlci5pbml0KSBzLmZvcm1hdHRlci5pbml0KHMsIHRoaXMub3B0aW9ucyk7XG4gICAgICAgIHRoaXMub3B0aW9ucy5pbnRlcnBvbGF0aW9uLmZvcm1hdCA9IHMuZm9ybWF0dGVyLmZvcm1hdC5iaW5kKHMuZm9ybWF0dGVyKTtcbiAgICAgIH1cbiAgICAgIHMuaW50ZXJwb2xhdG9yID0gbmV3IEludGVycG9sYXRvcih0aGlzLm9wdGlvbnMpO1xuICAgICAgcy51dGlscyA9IHtcbiAgICAgICAgaGFzTG9hZGVkTmFtZXNwYWNlOiB0aGlzLmhhc0xvYWRlZE5hbWVzcGFjZS5iaW5kKHRoaXMpXG4gICAgICB9O1xuICAgICAgcy5iYWNrZW5kQ29ubmVjdG9yID0gbmV3IENvbm5lY3RvcihjcmVhdGVDbGFzc09uRGVtYW5kKHRoaXMubW9kdWxlcy5iYWNrZW5kKSwgcy5yZXNvdXJjZVN0b3JlLCBzLCB0aGlzLm9wdGlvbnMpO1xuICAgICAgcy5iYWNrZW5kQ29ubmVjdG9yLm9uKCcqJywgKGV2ZW50LCAuLi5hcmdzKSA9PiB7XG4gICAgICAgIHRoaXMuZW1pdChldmVudCwgLi4uYXJncyk7XG4gICAgICB9KTtcbiAgICAgIGlmICh0aGlzLm1vZHVsZXMubGFuZ3VhZ2VEZXRlY3Rvcikge1xuICAgICAgICBzLmxhbmd1YWdlRGV0ZWN0b3IgPSBjcmVhdGVDbGFzc09uRGVtYW5kKHRoaXMubW9kdWxlcy5sYW5ndWFnZURldGVjdG9yKTtcbiAgICAgICAgaWYgKHMubGFuZ3VhZ2VEZXRlY3Rvci5pbml0KSBzLmxhbmd1YWdlRGV0ZWN0b3IuaW5pdChzLCB0aGlzLm9wdGlvbnMuZGV0ZWN0aW9uLCB0aGlzLm9wdGlvbnMpO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMubW9kdWxlcy5pMThuRm9ybWF0KSB7XG4gICAgICAgIHMuaTE4bkZvcm1hdCA9IGNyZWF0ZUNsYXNzT25EZW1hbmQodGhpcy5tb2R1bGVzLmkxOG5Gb3JtYXQpO1xuICAgICAgICBpZiAocy5pMThuRm9ybWF0LmluaXQpIHMuaTE4bkZvcm1hdC5pbml0KHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhpcy50cmFuc2xhdG9yID0gbmV3IFRyYW5zbGF0b3IodGhpcy5zZXJ2aWNlcywgdGhpcy5vcHRpb25zKTtcbiAgICAgIHRoaXMudHJhbnNsYXRvci5vbignKicsIChldmVudCwgLi4uYXJncykgPT4ge1xuICAgICAgICB0aGlzLmVtaXQoZXZlbnQsIC4uLmFyZ3MpO1xuICAgICAgfSk7XG4gICAgICB0aGlzLm1vZHVsZXMuZXh0ZXJuYWwuZm9yRWFjaChtID0+IHtcbiAgICAgICAgaWYgKG0uaW5pdCkgbS5pbml0KHRoaXMpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHRoaXMuZm9ybWF0ID0gdGhpcy5vcHRpb25zLmludGVycG9sYXRpb24uZm9ybWF0O1xuICAgIGlmICghY2FsbGJhY2spIGNhbGxiYWNrID0gbm9vcDtcbiAgICBpZiAodGhpcy5vcHRpb25zLmZhbGxiYWNrTG5nICYmICF0aGlzLnNlcnZpY2VzLmxhbmd1YWdlRGV0ZWN0b3IgJiYgIXRoaXMub3B0aW9ucy5sbmcpIHtcbiAgICAgIGNvbnN0IGNvZGVzID0gdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZVV0aWxzLmdldEZhbGxiYWNrQ29kZXModGhpcy5vcHRpb25zLmZhbGxiYWNrTG5nKTtcbiAgICAgIGlmIChjb2Rlcy5sZW5ndGggPiAwICYmIGNvZGVzWzBdICE9PSAnZGV2JykgdGhpcy5vcHRpb25zLmxuZyA9IGNvZGVzWzBdO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3RvciAmJiAhdGhpcy5vcHRpb25zLmxuZykge1xuICAgICAgdGhpcy5sb2dnZXIud2FybignaW5pdDogbm8gbGFuZ3VhZ2VEZXRlY3RvciBpcyB1c2VkIGFuZCBubyBsbmcgaXMgZGVmaW5lZCcpO1xuICAgIH1cbiAgICBjb25zdCBzdG9yZUFwaSA9IFsnZ2V0UmVzb3VyY2UnLCAnaGFzUmVzb3VyY2VCdW5kbGUnLCAnZ2V0UmVzb3VyY2VCdW5kbGUnLCAnZ2V0RGF0YUJ5TGFuZ3VhZ2UnXTtcbiAgICBzdG9yZUFwaS5mb3JFYWNoKGZjTmFtZSA9PiB7XG4gICAgICB0aGlzW2ZjTmFtZV0gPSAoLi4uYXJncykgPT4gdGhpcy5zdG9yZVtmY05hbWVdKC4uLmFyZ3MpO1xuICAgIH0pO1xuICAgIGNvbnN0IHN0b3JlQXBpQ2hhaW5lZCA9IFsnYWRkUmVzb3VyY2UnLCAnYWRkUmVzb3VyY2VzJywgJ2FkZFJlc291cmNlQnVuZGxlJywgJ3JlbW92ZVJlc291cmNlQnVuZGxlJ107XG4gICAgc3RvcmVBcGlDaGFpbmVkLmZvckVhY2goZmNOYW1lID0+IHtcbiAgICAgIHRoaXNbZmNOYW1lXSA9ICguLi5hcmdzKSA9PiB7XG4gICAgICAgIHRoaXMuc3RvcmVbZmNOYW1lXSguLi5hcmdzKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9O1xuICAgIH0pO1xuICAgIGNvbnN0IGRlZmVycmVkID0gZGVmZXIoKTtcbiAgICBjb25zdCBsb2FkID0gKCkgPT4ge1xuICAgICAgY29uc3QgZmluaXNoID0gKGVyciwgdCkgPT4ge1xuICAgICAgICB0aGlzLmlzSW5pdGlhbGl6aW5nID0gZmFsc2U7XG4gICAgICAgIGlmICh0aGlzLmlzSW5pdGlhbGl6ZWQgJiYgIXRoaXMuaW5pdGlhbGl6ZWRTdG9yZU9uY2UpIHRoaXMubG9nZ2VyLndhcm4oJ2luaXQ6IGkxOG5leHQgaXMgYWxyZWFkeSBpbml0aWFsaXplZC4gWW91IHNob3VsZCBjYWxsIGluaXQganVzdCBvbmNlIScpO1xuICAgICAgICB0aGlzLmlzSW5pdGlhbGl6ZWQgPSB0cnVlO1xuICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5pc0Nsb25lKSB0aGlzLmxvZ2dlci5sb2coJ2luaXRpYWxpemVkJywgdGhpcy5vcHRpb25zKTtcbiAgICAgICAgdGhpcy5lbWl0KCdpbml0aWFsaXplZCcsIHRoaXMub3B0aW9ucyk7XG4gICAgICAgIGRlZmVycmVkLnJlc29sdmUodCk7XG4gICAgICAgIGNhbGxiYWNrKGVyciwgdCk7XG4gICAgICB9O1xuICAgICAgaWYgKCh0aGlzLmxhbmd1YWdlcyB8fCB0aGlzLmlzTGFuZ3VhZ2VDaGFuZ2luZ1RvKSAmJiAhdGhpcy5pc0luaXRpYWxpemVkKSByZXR1cm4gZmluaXNoKG51bGwsIHRoaXMudC5iaW5kKHRoaXMpKTtcbiAgICAgIHRoaXMuY2hhbmdlTGFuZ3VhZ2UodGhpcy5vcHRpb25zLmxuZywgZmluaXNoKTtcbiAgICB9O1xuICAgIGlmICh0aGlzLm9wdGlvbnMucmVzb3VyY2VzIHx8ICF0aGlzLm9wdGlvbnMuaW5pdEFzeW5jKSB7XG4gICAgICBsb2FkKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldFRpbWVvdXQobG9hZCwgMCk7XG4gICAgfVxuICAgIHJldHVybiBkZWZlcnJlZDtcbiAgfVxuICBsb2FkUmVzb3VyY2VzKGxhbmd1YWdlLCBjYWxsYmFjayA9IG5vb3ApIHtcbiAgICBsZXQgdXNlZENhbGxiYWNrID0gY2FsbGJhY2s7XG4gICAgY29uc3QgdXNlZExuZyA9IGlzU3RyaW5nKGxhbmd1YWdlKSA/IGxhbmd1YWdlIDogdGhpcy5sYW5ndWFnZTtcbiAgICBpZiAodHlwZW9mIGxhbmd1YWdlID09PSAnZnVuY3Rpb24nKSB1c2VkQ2FsbGJhY2sgPSBsYW5ndWFnZTtcbiAgICBpZiAoIXRoaXMub3B0aW9ucy5yZXNvdXJjZXMgfHwgdGhpcy5vcHRpb25zLnBhcnRpYWxCdW5kbGVkTGFuZ3VhZ2VzKSB7XG4gICAgICBpZiAodXNlZExuZz8udG9Mb3dlckNhc2UoKSA9PT0gJ2NpbW9kZScgJiYgKCF0aGlzLm9wdGlvbnMucHJlbG9hZCB8fCB0aGlzLm9wdGlvbnMucHJlbG9hZC5sZW5ndGggPT09IDApKSByZXR1cm4gdXNlZENhbGxiYWNrKCk7XG4gICAgICBjb25zdCB0b0xvYWQgPSBbXTtcbiAgICAgIGNvbnN0IGFwcGVuZCA9IGxuZyA9PiB7XG4gICAgICAgIGlmICghbG5nKSByZXR1cm47XG4gICAgICAgIGlmIChsbmcgPT09ICdjaW1vZGUnKSByZXR1cm47XG4gICAgICAgIGNvbnN0IGxuZ3MgPSB0aGlzLnNlcnZpY2VzLmxhbmd1YWdlVXRpbHMudG9SZXNvbHZlSGllcmFyY2h5KGxuZyk7XG4gICAgICAgIGxuZ3MuZm9yRWFjaChsID0+IHtcbiAgICAgICAgICBpZiAobCA9PT0gJ2NpbW9kZScpIHJldHVybjtcbiAgICAgICAgICBpZiAoIXRvTG9hZC5pbmNsdWRlcyhsKSkgdG9Mb2FkLnB1c2gobCk7XG4gICAgICAgIH0pO1xuICAgICAgfTtcbiAgICAgIGlmICghdXNlZExuZykge1xuICAgICAgICBjb25zdCBmYWxsYmFja3MgPSB0aGlzLnNlcnZpY2VzLmxhbmd1YWdlVXRpbHMuZ2V0RmFsbGJhY2tDb2Rlcyh0aGlzLm9wdGlvbnMuZmFsbGJhY2tMbmcpO1xuICAgICAgICBmYWxsYmFja3MuZm9yRWFjaChsID0+IGFwcGVuZChsKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhcHBlbmQodXNlZExuZyk7XG4gICAgICB9XG4gICAgICB0aGlzLm9wdGlvbnMucHJlbG9hZD8uZm9yRWFjaD8uKGwgPT4gYXBwZW5kKGwpKTtcbiAgICAgIHRoaXMuc2VydmljZXMuYmFja2VuZENvbm5lY3Rvci5sb2FkKHRvTG9hZCwgdGhpcy5vcHRpb25zLm5zLCBlID0+IHtcbiAgICAgICAgaWYgKCFlICYmICF0aGlzLnJlc29sdmVkTGFuZ3VhZ2UgJiYgdGhpcy5sYW5ndWFnZSkgdGhpcy5zZXRSZXNvbHZlZExhbmd1YWdlKHRoaXMubGFuZ3VhZ2UpO1xuICAgICAgICB1c2VkQ2FsbGJhY2soZSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdXNlZENhbGxiYWNrKG51bGwpO1xuICAgIH1cbiAgfVxuICByZWxvYWRSZXNvdXJjZXMobG5ncywgbnMsIGNhbGxiYWNrKSB7XG4gICAgY29uc3QgZGVmZXJyZWQgPSBkZWZlcigpO1xuICAgIGlmICh0eXBlb2YgbG5ncyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY2FsbGJhY2sgPSBsbmdzO1xuICAgICAgbG5ncyA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBucyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY2FsbGJhY2sgPSBucztcbiAgICAgIG5zID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAoIWxuZ3MpIGxuZ3MgPSB0aGlzLmxhbmd1YWdlcztcbiAgICBpZiAoIW5zKSBucyA9IHRoaXMub3B0aW9ucy5ucztcbiAgICBpZiAoIWNhbGxiYWNrKSBjYWxsYmFjayA9IG5vb3A7XG4gICAgdGhpcy5zZXJ2aWNlcy5iYWNrZW5kQ29ubmVjdG9yLnJlbG9hZChsbmdzLCBucywgZXJyID0+IHtcbiAgICAgIGRlZmVycmVkLnJlc29sdmUoKTtcbiAgICAgIGNhbGxiYWNrKGVycik7XG4gICAgfSk7XG4gICAgcmV0dXJuIGRlZmVycmVkO1xuICB9XG4gIHVzZShtb2R1bGUpIHtcbiAgICBpZiAoIW1vZHVsZSkgdGhyb3cgbmV3IEVycm9yKCdZb3UgYXJlIHBhc3NpbmcgYW4gdW5kZWZpbmVkIG1vZHVsZSEgUGxlYXNlIGNoZWNrIHRoZSBvYmplY3QgeW91IGFyZSBwYXNzaW5nIHRvIGkxOG5leHQudXNlKCknKTtcbiAgICBpZiAoIW1vZHVsZS50eXBlKSB0aHJvdyBuZXcgRXJyb3IoJ1lvdSBhcmUgcGFzc2luZyBhIHdyb25nIG1vZHVsZSEgUGxlYXNlIGNoZWNrIHRoZSBvYmplY3QgeW91IGFyZSBwYXNzaW5nIHRvIGkxOG5leHQudXNlKCknKTtcbiAgICBpZiAobW9kdWxlLnR5cGUgPT09ICdiYWNrZW5kJykge1xuICAgICAgdGhpcy5tb2R1bGVzLmJhY2tlbmQgPSBtb2R1bGU7XG4gICAgfVxuICAgIGlmIChtb2R1bGUudHlwZSA9PT0gJ2xvZ2dlcicgfHwgbW9kdWxlLmxvZyAmJiBtb2R1bGUud2FybiAmJiBtb2R1bGUuZXJyb3IpIHtcbiAgICAgIHRoaXMubW9kdWxlcy5sb2dnZXIgPSBtb2R1bGU7XG4gICAgfVxuICAgIGlmIChtb2R1bGUudHlwZSA9PT0gJ2xhbmd1YWdlRGV0ZWN0b3InKSB7XG4gICAgICB0aGlzLm1vZHVsZXMubGFuZ3VhZ2VEZXRlY3RvciA9IG1vZHVsZTtcbiAgICB9XG4gICAgaWYgKG1vZHVsZS50eXBlID09PSAnaTE4bkZvcm1hdCcpIHtcbiAgICAgIHRoaXMubW9kdWxlcy5pMThuRm9ybWF0ID0gbW9kdWxlO1xuICAgIH1cbiAgICBpZiAobW9kdWxlLnR5cGUgPT09ICdwb3N0UHJvY2Vzc29yJykge1xuICAgICAgcG9zdFByb2Nlc3Nvci5hZGRQb3N0UHJvY2Vzc29yKG1vZHVsZSk7XG4gICAgfVxuICAgIGlmIChtb2R1bGUudHlwZSA9PT0gJ2Zvcm1hdHRlcicpIHtcbiAgICAgIHRoaXMubW9kdWxlcy5mb3JtYXR0ZXIgPSBtb2R1bGU7XG4gICAgfVxuICAgIGlmIChtb2R1bGUudHlwZSA9PT0gJzNyZFBhcnR5Jykge1xuICAgICAgdGhpcy5tb2R1bGVzLmV4dGVybmFsLnB1c2gobW9kdWxlKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgc2V0UmVzb2x2ZWRMYW5ndWFnZShsKSB7XG4gICAgaWYgKCFsIHx8ICF0aGlzLmxhbmd1YWdlcykgcmV0dXJuO1xuICAgIGlmIChbJ2NpbW9kZScsICdkZXYnXS5pbmNsdWRlcyhsKSkgcmV0dXJuO1xuICAgIGZvciAobGV0IGxpID0gMDsgbGkgPCB0aGlzLmxhbmd1YWdlcy5sZW5ndGg7IGxpKyspIHtcbiAgICAgIGNvbnN0IGxuZ0luTG5ncyA9IHRoaXMubGFuZ3VhZ2VzW2xpXTtcbiAgICAgIGlmIChbJ2NpbW9kZScsICdkZXYnXS5pbmNsdWRlcyhsbmdJbkxuZ3MpKSBjb250aW51ZTtcbiAgICAgIGlmICh0aGlzLnN0b3JlLmhhc0xhbmd1YWdlU29tZVRyYW5zbGF0aW9ucyhsbmdJbkxuZ3MpKSB7XG4gICAgICAgIHRoaXMucmVzb2x2ZWRMYW5ndWFnZSA9IGxuZ0luTG5ncztcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghdGhpcy5yZXNvbHZlZExhbmd1YWdlICYmICF0aGlzLmxhbmd1YWdlcy5pbmNsdWRlcyhsKSAmJiB0aGlzLnN0b3JlLmhhc0xhbmd1YWdlU29tZVRyYW5zbGF0aW9ucyhsKSkge1xuICAgICAgdGhpcy5yZXNvbHZlZExhbmd1YWdlID0gbDtcbiAgICAgIHRoaXMubGFuZ3VhZ2VzLnVuc2hpZnQobCk7XG4gICAgfVxuICB9XG4gIGNoYW5nZUxhbmd1YWdlKGxuZywgY2FsbGJhY2spIHtcbiAgICB0aGlzLmlzTGFuZ3VhZ2VDaGFuZ2luZ1RvID0gbG5nO1xuICAgIGNvbnN0IGRlZmVycmVkID0gZGVmZXIoKTtcbiAgICB0aGlzLmVtaXQoJ2xhbmd1YWdlQ2hhbmdpbmcnLCBsbmcpO1xuICAgIGNvbnN0IHNldExuZ1Byb3BzID0gbCA9PiB7XG4gICAgICB0aGlzLmxhbmd1YWdlID0gbDtcbiAgICAgIHRoaXMubGFuZ3VhZ2VzID0gdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZVV0aWxzLnRvUmVzb2x2ZUhpZXJhcmNoeShsKTtcbiAgICAgIHRoaXMucmVzb2x2ZWRMYW5ndWFnZSA9IHVuZGVmaW5lZDtcbiAgICAgIHRoaXMuc2V0UmVzb2x2ZWRMYW5ndWFnZShsKTtcbiAgICB9O1xuICAgIGNvbnN0IGRvbmUgPSAoZXJyLCBsKSA9PiB7XG4gICAgICBpZiAobCkge1xuICAgICAgICBpZiAodGhpcy5pc0xhbmd1YWdlQ2hhbmdpbmdUbyA9PT0gbG5nKSB7XG4gICAgICAgICAgc2V0TG5nUHJvcHMobCk7XG4gICAgICAgICAgdGhpcy50cmFuc2xhdG9yLmNoYW5nZUxhbmd1YWdlKGwpO1xuICAgICAgICAgIHRoaXMuaXNMYW5ndWFnZUNoYW5naW5nVG8gPSB1bmRlZmluZWQ7XG4gICAgICAgICAgdGhpcy5lbWl0KCdsYW5ndWFnZUNoYW5nZWQnLCBsKTtcbiAgICAgICAgICB0aGlzLmxvZ2dlci5sb2coJ2xhbmd1YWdlQ2hhbmdlZCcsIGwpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmlzTGFuZ3VhZ2VDaGFuZ2luZ1RvID0gdW5kZWZpbmVkO1xuICAgICAgfVxuICAgICAgZGVmZXJyZWQucmVzb2x2ZSgoLi4uYXJncykgPT4gdGhpcy50KC4uLmFyZ3MpKTtcbiAgICAgIGlmIChjYWxsYmFjaykgY2FsbGJhY2soZXJyLCAoLi4uYXJncykgPT4gdGhpcy50KC4uLmFyZ3MpKTtcbiAgICB9O1xuICAgIGNvbnN0IHNldExuZyA9IGxuZ3MgPT4ge1xuICAgICAgaWYgKCFsbmcgJiYgIWxuZ3MgJiYgdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZURldGVjdG9yKSBsbmdzID0gW107XG4gICAgICBjb25zdCBmbCA9IGlzU3RyaW5nKGxuZ3MpID8gbG5ncyA6IGxuZ3MgJiYgbG5nc1swXTtcbiAgICAgIGNvbnN0IGwgPSB0aGlzLnN0b3JlLmhhc0xhbmd1YWdlU29tZVRyYW5zbGF0aW9ucyhmbCkgPyBmbCA6IHRoaXMuc2VydmljZXMubGFuZ3VhZ2VVdGlscy5nZXRCZXN0TWF0Y2hGcm9tQ29kZXMoaXNTdHJpbmcobG5ncykgPyBbbG5nc10gOiBsbmdzKTtcbiAgICAgIGlmIChsKSB7XG4gICAgICAgIGlmICghdGhpcy5sYW5ndWFnZSkge1xuICAgICAgICAgIHNldExuZ1Byb3BzKGwpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy50cmFuc2xhdG9yLmxhbmd1YWdlKSB0aGlzLnRyYW5zbGF0b3IuY2hhbmdlTGFuZ3VhZ2UobCk7XG4gICAgICAgIHRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3Rvcj8uY2FjaGVVc2VyTGFuZ3VhZ2U/LihsKTtcbiAgICAgIH1cbiAgICAgIHRoaXMubG9hZFJlc291cmNlcyhsLCBlcnIgPT4ge1xuICAgICAgICBkb25lKGVyciwgbCk7XG4gICAgICB9KTtcbiAgICB9O1xuICAgIGlmICghbG5nICYmIHRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3RvciAmJiAhdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZURldGVjdG9yLmFzeW5jKSB7XG4gICAgICBzZXRMbmcodGhpcy5zZXJ2aWNlcy5sYW5ndWFnZURldGVjdG9yLmRldGVjdCgpKTtcbiAgICB9IGVsc2UgaWYgKCFsbmcgJiYgdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZURldGVjdG9yICYmIHRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3Rvci5hc3luYykge1xuICAgICAgaWYgKHRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3Rvci5kZXRlY3QubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3Rvci5kZXRlY3QoKS50aGVuKHNldExuZyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnNlcnZpY2VzLmxhbmd1YWdlRGV0ZWN0b3IuZGV0ZWN0KHNldExuZyk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldExuZyhsbmcpO1xuICAgIH1cbiAgICByZXR1cm4gZGVmZXJyZWQ7XG4gIH1cbiAgZ2V0Rml4ZWRUKGxuZywgbnMsIGtleVByZWZpeCwgZml4ZWRPcHRzKSB7XG4gICAgY29uc3Qgc2NvcGVOcyA9IGZpeGVkT3B0cz8uc2NvcGVOcztcbiAgICBjb25zdCBmaXhlZFQgPSAoa2V5LCBvcHRzLCAuLi5yZXN0KSA9PiB7XG4gICAgICBsZXQgbztcbiAgICAgIGlmICh0eXBlb2Ygb3B0cyAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgbyA9IHRoaXMub3B0aW9ucy5vdmVybG9hZFRyYW5zbGF0aW9uT3B0aW9uSGFuZGxlcihba2V5LCBvcHRzXS5jb25jYXQocmVzdCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbyA9IHtcbiAgICAgICAgICAuLi5vcHRzXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBvLmxuZyA9IG8ubG5nIHx8IGZpeGVkVC5sbmc7XG4gICAgICBvLmxuZ3MgPSBvLmxuZ3MgfHwgZml4ZWRULmxuZ3M7XG4gICAgICBjb25zdCBleHBsaWNpdENhbGxOcyA9IG8ubnMgIT09IHVuZGVmaW5lZCAmJiBvLm5zICE9PSBudWxsO1xuICAgICAgby5ucyA9IG8ubnMgfHwgZml4ZWRULm5zO1xuICAgICAgaWYgKG8ua2V5UHJlZml4ICE9PSAnJykgby5rZXlQcmVmaXggPSBvLmtleVByZWZpeCB8fCBrZXlQcmVmaXggfHwgZml4ZWRULmtleVByZWZpeDtcbiAgICAgIGNvbnN0IHNlbGVjdG9yT3B0cyA9IHtcbiAgICAgICAgLi4udGhpcy5vcHRpb25zLFxuICAgICAgICAuLi5vXG4gICAgICB9O1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoc2NvcGVOcykgJiYgIWV4cGxpY2l0Q2FsbE5zKSBzZWxlY3Rvck9wdHMubnMgPSBzY29wZU5zO1xuICAgICAgaWYgKHR5cGVvZiBvLmtleVByZWZpeCA9PT0gJ2Z1bmN0aW9uJykgby5rZXlQcmVmaXggPSBrZXlzRnJvbVNlbGVjdG9yKG8ua2V5UHJlZml4LCBzZWxlY3Rvck9wdHMpO1xuICAgICAgY29uc3Qga2V5U2VwYXJhdG9yID0gdGhpcy5vcHRpb25zLmtleVNlcGFyYXRvciB8fCAnLic7XG4gICAgICBsZXQgcmVzdWx0S2V5O1xuICAgICAgaWYgKG8ua2V5UHJlZml4ICYmIEFycmF5LmlzQXJyYXkoa2V5KSkge1xuICAgICAgICByZXN1bHRLZXkgPSBrZXkubWFwKGsgPT4ge1xuICAgICAgICAgIGlmICh0eXBlb2YgayA9PT0gJ2Z1bmN0aW9uJykgayA9IGtleXNGcm9tU2VsZWN0b3Ioaywgc2VsZWN0b3JPcHRzKTtcbiAgICAgICAgICByZXR1cm4gYCR7by5rZXlQcmVmaXh9JHtrZXlTZXBhcmF0b3J9JHtrfWA7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHR5cGVvZiBrZXkgPT09ICdmdW5jdGlvbicpIGtleSA9IGtleXNGcm9tU2VsZWN0b3Ioa2V5LCBzZWxlY3Rvck9wdHMpO1xuICAgICAgICByZXN1bHRLZXkgPSBvLmtleVByZWZpeCA/IGAke28ua2V5UHJlZml4fSR7a2V5U2VwYXJhdG9yfSR7a2V5fWAgOiBrZXk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy50KHJlc3VsdEtleSwgbyk7XG4gICAgfTtcbiAgICBpZiAoaXNTdHJpbmcobG5nKSkge1xuICAgICAgZml4ZWRULmxuZyA9IGxuZztcbiAgICB9IGVsc2Uge1xuICAgICAgZml4ZWRULmxuZ3MgPSBsbmc7XG4gICAgfVxuICAgIGZpeGVkVC5ucyA9IG5zO1xuICAgIGZpeGVkVC5rZXlQcmVmaXggPSBrZXlQcmVmaXg7XG4gICAgcmV0dXJuIGZpeGVkVDtcbiAgfVxuICB0KC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2xhdG9yPy50cmFuc2xhdGUoLi4uYXJncyk7XG4gIH1cbiAgZXhpc3RzKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2xhdG9yPy5leGlzdHMoLi4uYXJncyk7XG4gIH1cbiAgc2V0RGVmYXVsdE5hbWVzcGFjZShucykge1xuICAgIHRoaXMub3B0aW9ucy5kZWZhdWx0TlMgPSBucztcbiAgfVxuICBoYXNMb2FkZWROYW1lc3BhY2UobnMsIG9wdGlvbnMgPSB7fSkge1xuICAgIGlmICghdGhpcy5pc0luaXRpYWxpemVkKSB7XG4gICAgICB0aGlzLmxvZ2dlci53YXJuKCdoYXNMb2FkZWROYW1lc3BhY2U6IGkxOG5leHQgd2FzIG5vdCBpbml0aWFsaXplZCcsIHRoaXMubGFuZ3VhZ2VzKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKCF0aGlzLmxhbmd1YWdlcyB8fCAhdGhpcy5sYW5ndWFnZXMubGVuZ3RoKSB7XG4gICAgICB0aGlzLmxvZ2dlci53YXJuKCdoYXNMb2FkZWROYW1lc3BhY2U6IGkxOG4ubGFuZ3VhZ2VzIHdlcmUgdW5kZWZpbmVkIG9yIGVtcHR5JywgdGhpcy5sYW5ndWFnZXMpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBsbmcgPSBvcHRpb25zLmxuZyB8fCB0aGlzLnJlc29sdmVkTGFuZ3VhZ2UgfHwgdGhpcy5sYW5ndWFnZXNbMF07XG4gICAgY29uc3QgZmFsbGJhY2tMbmcgPSB0aGlzLm9wdGlvbnMgPyB0aGlzLm9wdGlvbnMuZmFsbGJhY2tMbmcgOiBmYWxzZTtcbiAgICBjb25zdCBsYXN0TG5nID0gdGhpcy5sYW5ndWFnZXNbdGhpcy5sYW5ndWFnZXMubGVuZ3RoIC0gMV07XG4gICAgaWYgKGxuZy50b0xvd2VyQ2FzZSgpID09PSAnY2ltb2RlJykgcmV0dXJuIHRydWU7XG4gICAgY29uc3QgbG9hZE5vdFBlbmRpbmcgPSAobCwgbikgPT4ge1xuICAgICAgY29uc3QgbG9hZFN0YXRlID0gdGhpcy5zZXJ2aWNlcy5iYWNrZW5kQ29ubmVjdG9yLnN0YXRlW2Ake2x9fCR7bn1gXTtcbiAgICAgIHJldHVybiBsb2FkU3RhdGUgPT09IC0xIHx8IGxvYWRTdGF0ZSA9PT0gMCB8fCBsb2FkU3RhdGUgPT09IDI7XG4gICAgfTtcbiAgICBpZiAob3B0aW9ucy5wcmVjaGVjaykge1xuICAgICAgY29uc3QgcHJlUmVzdWx0ID0gb3B0aW9ucy5wcmVjaGVjayh0aGlzLCBsb2FkTm90UGVuZGluZyk7XG4gICAgICBpZiAocHJlUmVzdWx0ICE9PSB1bmRlZmluZWQpIHJldHVybiBwcmVSZXN1bHQ7XG4gICAgfVxuICAgIGlmICh0aGlzLmhhc1Jlc291cmNlQnVuZGxlKGxuZywgbnMpKSByZXR1cm4gdHJ1ZTtcbiAgICBpZiAoIXRoaXMuc2VydmljZXMuYmFja2VuZENvbm5lY3Rvci5iYWNrZW5kIHx8IHRoaXMub3B0aW9ucy5yZXNvdXJjZXMgJiYgIXRoaXMub3B0aW9ucy5wYXJ0aWFsQnVuZGxlZExhbmd1YWdlcykgcmV0dXJuIHRydWU7XG4gICAgaWYgKGxvYWROb3RQZW5kaW5nKGxuZywgbnMpICYmICghZmFsbGJhY2tMbmcgfHwgbG9hZE5vdFBlbmRpbmcobGFzdExuZywgbnMpKSkgcmV0dXJuIHRydWU7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGxvYWROYW1lc3BhY2VzKG5zLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IGRlZmVycmVkID0gZGVmZXIoKTtcbiAgICBpZiAoIXRoaXMub3B0aW9ucy5ucykge1xuICAgICAgaWYgKGNhbGxiYWNrKSBjYWxsYmFjaygpO1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgICBpZiAoaXNTdHJpbmcobnMpKSBucyA9IFtuc107XG4gICAgbnMuZm9yRWFjaChuID0+IHtcbiAgICAgIGlmICghdGhpcy5vcHRpb25zLm5zLmluY2x1ZGVzKG4pKSB0aGlzLm9wdGlvbnMubnMucHVzaChuKTtcbiAgICB9KTtcbiAgICB0aGlzLmxvYWRSZXNvdXJjZXMoZXJyID0+IHtcbiAgICAgIGRlZmVycmVkLnJlc29sdmUoKTtcbiAgICAgIGlmIChjYWxsYmFjaykgY2FsbGJhY2soZXJyKTtcbiAgICB9KTtcbiAgICByZXR1cm4gZGVmZXJyZWQ7XG4gIH1cbiAgbG9hZExhbmd1YWdlcyhsbmdzLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IGRlZmVycmVkID0gZGVmZXIoKTtcbiAgICBpZiAoaXNTdHJpbmcobG5ncykpIGxuZ3MgPSBbbG5nc107XG4gICAgY29uc3QgcHJlbG9hZGVkID0gdGhpcy5vcHRpb25zLnByZWxvYWQgfHwgW107XG4gICAgY29uc3QgbmV3TG5ncyA9IGxuZ3MuZmlsdGVyKGxuZyA9PiAhcHJlbG9hZGVkLmluY2x1ZGVzKGxuZykgJiYgdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZVV0aWxzLmlzU3VwcG9ydGVkQ29kZShsbmcpKTtcbiAgICBpZiAoIW5ld0xuZ3MubGVuZ3RoKSB7XG4gICAgICBpZiAoY2FsbGJhY2spIGNhbGxiYWNrKCk7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfVxuICAgIHRoaXMub3B0aW9ucy5wcmVsb2FkID0gcHJlbG9hZGVkLmNvbmNhdChuZXdMbmdzKTtcbiAgICB0aGlzLmxvYWRSZXNvdXJjZXMoZXJyID0+IHtcbiAgICAgIGRlZmVycmVkLnJlc29sdmUoKTtcbiAgICAgIGlmIChjYWxsYmFjaykgY2FsbGJhY2soZXJyKTtcbiAgICB9KTtcbiAgICByZXR1cm4gZGVmZXJyZWQ7XG4gIH1cbiAgZGlyKGxuZykge1xuICAgIGlmICghbG5nKSBsbmcgPSB0aGlzLnJlc29sdmVkTGFuZ3VhZ2UgfHwgKHRoaXMubGFuZ3VhZ2VzPy5sZW5ndGggPiAwID8gdGhpcy5sYW5ndWFnZXNbMF0gOiB0aGlzLmxhbmd1YWdlKTtcbiAgICBpZiAoIWxuZykgcmV0dXJuICdydGwnO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBsID0gbmV3IEludGwuTG9jYWxlKGxuZyk7XG4gICAgICBpZiAobCAmJiBsLmdldFRleHRJbmZvKSB7XG4gICAgICAgIGNvbnN0IHRpID0gbC5nZXRUZXh0SW5mbygpO1xuICAgICAgICBpZiAodGkgJiYgdGkuZGlyZWN0aW9uKSByZXR1cm4gdGkuZGlyZWN0aW9uO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHt9XG4gICAgY29uc3QgcnRsTG5ncyA9IFsnYXInLCAnc2h1JywgJ3NxcicsICdzc2gnLCAneGFhJywgJ3loZCcsICd5dWQnLCAnYWFvJywgJ2FiaCcsICdhYnYnLCAnYWNtJywgJ2FjcScsICdhY3cnLCAnYWN4JywgJ2FjeScsICdhZGYnLCAnYWRzJywgJ2FlYicsICdhZWMnLCAnYWZiJywgJ2FqcCcsICdhcGMnLCAnYXBkJywgJ2FyYicsICdhcnEnLCAnYXJzJywgJ2FyeScsICdhcnonLCAnYXV6JywgJ2F2bCcsICdheWgnLCAnYXlsJywgJ2F5bicsICdheXAnLCAnYmJ6JywgJ3BnYScsICdoZScsICdpdycsICdwcycsICdwYnQnLCAncGJ1JywgJ3BzdCcsICdwcnAnLCAncHJkJywgJ3VnJywgJ3VyJywgJ3lkZCcsICd5ZHMnLCAneWloJywgJ2ppJywgJ3lpJywgJ2hibycsICdtZW4nLCAneG1uJywgJ2ZhJywgJ2pwcicsICdwZW8nLCAncGVzJywgJ3BycycsICdkdicsICdzYW0nLCAnY2tiJ107XG4gICAgY29uc3QgbGFuZ3VhZ2VVdGlscyA9IHRoaXMuc2VydmljZXM/Lmxhbmd1YWdlVXRpbHMgfHwgbmV3IExhbmd1YWdlVXRpbChnZXQoKSk7XG4gICAgaWYgKGxuZy50b0xvd2VyQ2FzZSgpLmluZGV4T2YoJy1sYXRuJykgPiAxKSByZXR1cm4gJ2x0cic7XG4gICAgcmV0dXJuIHJ0bExuZ3MuaW5jbHVkZXMobGFuZ3VhZ2VVdGlscy5nZXRMYW5ndWFnZVBhcnRGcm9tQ29kZShsbmcpKSB8fCBsbmcudG9Mb3dlckNhc2UoKS5pbmRleE9mKCctYXJhYicpID4gMSA/ICdydGwnIDogJ2x0cic7XG4gIH1cbiAgc3RhdGljIGNyZWF0ZUluc3RhbmNlKG9wdGlvbnMgPSB7fSwgY2FsbGJhY2spIHtcbiAgICBjb25zdCBpbnN0YW5jZSA9IG5ldyBJMThuKG9wdGlvbnMsIGNhbGxiYWNrKTtcbiAgICBpbnN0YW5jZS5jcmVhdGVJbnN0YW5jZSA9IEkxOG4uY3JlYXRlSW5zdGFuY2U7XG4gICAgcmV0dXJuIGluc3RhbmNlO1xuICB9XG4gIGNsb25lSW5zdGFuY2Uob3B0aW9ucyA9IHt9LCBjYWxsYmFjayA9IG5vb3ApIHtcbiAgICBjb25zdCBmb3JrUmVzb3VyY2VTdG9yZSA9IG9wdGlvbnMuZm9ya1Jlc291cmNlU3RvcmU7XG4gICAgaWYgKGZvcmtSZXNvdXJjZVN0b3JlKSBkZWxldGUgb3B0aW9ucy5mb3JrUmVzb3VyY2VTdG9yZTtcbiAgICBjb25zdCBtZXJnZWRPcHRpb25zID0ge1xuICAgICAgLi4udGhpcy5vcHRpb25zLFxuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIC4uLntcbiAgICAgICAgaXNDbG9uZTogdHJ1ZVxuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgY2xvbmUgPSBuZXcgSTE4bihtZXJnZWRPcHRpb25zKTtcbiAgICBpZiAob3B0aW9ucy5kZWJ1ZyAhPT0gdW5kZWZpbmVkIHx8IG9wdGlvbnMucHJlZml4ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGNsb25lLmxvZ2dlciA9IGNsb25lLmxvZ2dlci5jbG9uZShvcHRpb25zKTtcbiAgICB9XG4gICAgY29uc3QgbWVtYmVyc1RvQ29weSA9IFsnc3RvcmUnLCAnc2VydmljZXMnLCAnbGFuZ3VhZ2UnXTtcbiAgICBtZW1iZXJzVG9Db3B5LmZvckVhY2gobSA9PiB7XG4gICAgICBjbG9uZVttXSA9IHRoaXNbbV07XG4gICAgfSk7XG4gICAgY2xvbmUuc2VydmljZXMgPSB7XG4gICAgICAuLi50aGlzLnNlcnZpY2VzXG4gICAgfTtcbiAgICBjbG9uZS5zZXJ2aWNlcy51dGlscyA9IHtcbiAgICAgIGhhc0xvYWRlZE5hbWVzcGFjZTogY2xvbmUuaGFzTG9hZGVkTmFtZXNwYWNlLmJpbmQoY2xvbmUpXG4gICAgfTtcbiAgICBpZiAoZm9ya1Jlc291cmNlU3RvcmUpIHtcbiAgICAgIGNvbnN0IGNsb25lZERhdGEgPSBPYmplY3Qua2V5cyh0aGlzLnN0b3JlLmRhdGEpLnJlZHVjZSgocHJldiwgbCkgPT4ge1xuICAgICAgICBwcmV2W2xdID0ge1xuICAgICAgICAgIC4uLnRoaXMuc3RvcmUuZGF0YVtsXVxuICAgICAgICB9O1xuICAgICAgICBwcmV2W2xdID0gT2JqZWN0LmtleXMocHJldltsXSkucmVkdWNlKChhY2MsIG4pID0+IHtcbiAgICAgICAgICBhY2Nbbl0gPSB7XG4gICAgICAgICAgICAuLi5wcmV2W2xdW25dXG4gICAgICAgICAgfTtcbiAgICAgICAgICByZXR1cm4gYWNjO1xuICAgICAgICB9LCBwcmV2W2xdKTtcbiAgICAgICAgcmV0dXJuIHByZXY7XG4gICAgICB9LCB7fSk7XG4gICAgICBjbG9uZS5zdG9yZSA9IG5ldyBSZXNvdXJjZVN0b3JlKGNsb25lZERhdGEsIG1lcmdlZE9wdGlvbnMpO1xuICAgICAgY2xvbmUuc2VydmljZXMucmVzb3VyY2VTdG9yZSA9IGNsb25lLnN0b3JlO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5pbnRlcnBvbGF0aW9uKSB7XG4gICAgICBjb25zdCBkZWZPcHRzID0gZ2V0KCk7XG4gICAgICBjb25zdCBtZXJnZWRJbnRlcnBvbGF0aW9uID0ge1xuICAgICAgICAuLi5kZWZPcHRzLmludGVycG9sYXRpb24sXG4gICAgICAgIC4uLnRoaXMub3B0aW9ucy5pbnRlcnBvbGF0aW9uLFxuICAgICAgICAuLi5vcHRpb25zLmludGVycG9sYXRpb25cbiAgICAgIH07XG4gICAgICBjb25zdCBtZXJnZWRGb3JJbnRlcnBvbGF0b3IgPSB7XG4gICAgICAgIC4uLm1lcmdlZE9wdGlvbnMsXG4gICAgICAgIGludGVycG9sYXRpb246IG1lcmdlZEludGVycG9sYXRpb25cbiAgICAgIH07XG4gICAgICBjbG9uZS5zZXJ2aWNlcy5pbnRlcnBvbGF0b3IgPSBuZXcgSW50ZXJwb2xhdG9yKG1lcmdlZEZvckludGVycG9sYXRvcik7XG4gICAgfVxuICAgIGNsb25lLnRyYW5zbGF0b3IgPSBuZXcgVHJhbnNsYXRvcihjbG9uZS5zZXJ2aWNlcywgbWVyZ2VkT3B0aW9ucyk7XG4gICAgY2xvbmUudHJhbnNsYXRvci5vbignKicsIChldmVudCwgLi4uYXJncykgPT4ge1xuICAgICAgY2xvbmUuZW1pdChldmVudCwgLi4uYXJncyk7XG4gICAgfSk7XG4gICAgY2xvbmUuaW5pdChtZXJnZWRPcHRpb25zLCBjYWxsYmFjayk7XG4gICAgY2xvbmUudHJhbnNsYXRvci5vcHRpb25zID0gbWVyZ2VkT3B0aW9ucztcbiAgICBjbG9uZS50cmFuc2xhdG9yLmJhY2tlbmRDb25uZWN0b3Iuc2VydmljZXMudXRpbHMgPSB7XG4gICAgICBoYXNMb2FkZWROYW1lc3BhY2U6IGNsb25lLmhhc0xvYWRlZE5hbWVzcGFjZS5iaW5kKGNsb25lKVxuICAgIH07XG4gICAgcmV0dXJuIGNsb25lO1xuICB9XG4gIHRvSlNPTigpIHtcbiAgICByZXR1cm4ge1xuICAgICAgb3B0aW9uczogdGhpcy5vcHRpb25zLFxuICAgICAgc3RvcmU6IHRoaXMuc3RvcmUsXG4gICAgICBsYW5ndWFnZTogdGhpcy5sYW5ndWFnZSxcbiAgICAgIGxhbmd1YWdlczogdGhpcy5sYW5ndWFnZXMsXG4gICAgICByZXNvbHZlZExhbmd1YWdlOiB0aGlzLnJlc29sdmVkTGFuZ3VhZ2VcbiAgICB9O1xuICB9XG59XG5jb25zdCBpbnN0YW5jZSA9IEkxOG4uY3JlYXRlSW5zdGFuY2UoKTtcblxuY29uc3QgY3JlYXRlSW5zdGFuY2UgPSBpbnN0YW5jZS5jcmVhdGVJbnN0YW5jZTtcbmNvbnN0IGRpciA9IGluc3RhbmNlLmRpcjtcbmNvbnN0IGluaXQgPSBpbnN0YW5jZS5pbml0O1xuY29uc3QgbG9hZFJlc291cmNlcyA9IGluc3RhbmNlLmxvYWRSZXNvdXJjZXM7XG5jb25zdCByZWxvYWRSZXNvdXJjZXMgPSBpbnN0YW5jZS5yZWxvYWRSZXNvdXJjZXM7XG5jb25zdCB1c2UgPSBpbnN0YW5jZS51c2U7XG5jb25zdCBjaGFuZ2VMYW5ndWFnZSA9IGluc3RhbmNlLmNoYW5nZUxhbmd1YWdlO1xuY29uc3QgZ2V0Rml4ZWRUID0gaW5zdGFuY2UuZ2V0Rml4ZWRUO1xuY29uc3QgdCA9IGluc3RhbmNlLnQ7XG5jb25zdCBleGlzdHMgPSBpbnN0YW5jZS5leGlzdHM7XG5jb25zdCBzZXREZWZhdWx0TmFtZXNwYWNlID0gaW5zdGFuY2Uuc2V0RGVmYXVsdE5hbWVzcGFjZTtcbmNvbnN0IGhhc0xvYWRlZE5hbWVzcGFjZSA9IGluc3RhbmNlLmhhc0xvYWRlZE5hbWVzcGFjZTtcbmNvbnN0IGxvYWROYW1lc3BhY2VzID0gaW5zdGFuY2UubG9hZE5hbWVzcGFjZXM7XG5jb25zdCBsb2FkTGFuZ3VhZ2VzID0gaW5zdGFuY2UubG9hZExhbmd1YWdlcztcblxuZXhwb3J0IHsgY2hhbmdlTGFuZ3VhZ2UsIGNyZWF0ZUluc3RhbmNlLCBpbnN0YW5jZSBhcyBkZWZhdWx0LCBkaXIsIGV4aXN0cywgZ2V0Rml4ZWRULCBoYXNMb2FkZWROYW1lc3BhY2UsIGluaXQsIGtleXNGcm9tU2VsZWN0b3IgYXMga2V5RnJvbVNlbGVjdG9yLCBsb2FkTGFuZ3VhZ2VzLCBsb2FkTmFtZXNwYWNlcywgbG9hZFJlc291cmNlcywgcmVsb2FkUmVzb3VyY2VzLCBzZXREZWZhdWx0TmFtZXNwYWNlLCB0LCB1c2UgfTtcbiJdLCJtYXBwaW5ncyI6IjtBQUFBLElBQU0sWUFBVyxRQUFPLE9BQU8sUUFBUTtBQUN2QyxJQUFNLGNBQWM7Q0FDbEIsSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLFVBQVUsSUFBSSxTQUFTLFNBQVMsV0FBVztFQUMvQyxNQUFNO0VBQ04sTUFBTTtDQUNSLENBQUM7Q0FDRCxRQUFRLFVBQVU7Q0FDbEIsUUFBUSxTQUFTO0NBQ2pCLE9BQU87QUFDVDtBQUNBLElBQU0sY0FBYSxXQUFVO0NBQzNCLElBQUksVUFBVSxNQUFNLE9BQU87Q0FDM0IsT0FBTyxPQUFPLE1BQU07QUFDdEI7QUFDQSxJQUFNLFFBQVEsR0FBRyxHQUFHLE1BQU07Q0FDeEIsRUFBRSxTQUFRLE1BQUs7RUFDYixJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRTtDQUNyQixDQUFDO0FBQ0g7QUFDQSxJQUFNLDRCQUE0QjtBQUNsQyxJQUFNLFlBQVcsUUFBTyxPQUFPLElBQUksU0FBUyxLQUFLLElBQUksSUFBSSxRQUFRLDJCQUEyQixHQUFHLElBQUk7QUFDbkcsSUFBTSx3QkFBdUIsV0FBVSxDQUFDLFVBQVUsU0FBUyxNQUFNO0FBQ2pFLElBQU0saUJBQWlCLFFBQVEsTUFBTSxVQUFVO0NBQzdDLE1BQU0sUUFBUSxDQUFDLFNBQVMsSUFBSSxJQUFJLE9BQU8sS0FBSyxNQUFNLEdBQUc7Q0FDckQsSUFBSSxhQUFhO0NBQ2pCLE9BQU8sYUFBYSxNQUFNLFNBQVMsR0FBRztFQUNwQyxJQUFJLHFCQUFxQixNQUFNLEdBQUcsT0FBTyxDQUFDO0VBQzFDLE1BQU0sTUFBTSxTQUFTLE1BQU0sV0FBVztFQUN0QyxJQUFJLENBQUMsT0FBTyxRQUFRLE9BQU8sT0FBTyxPQUFPLElBQUksTUFBTTtFQUNuRCxJQUFJLE9BQU8sVUFBVSxlQUFlLEtBQUssUUFBUSxHQUFHLEdBQ2xELFNBQVMsT0FBTztPQUVoQixTQUFTLENBQUM7RUFFWixFQUFFO0NBQ0o7Q0FDQSxJQUFJLHFCQUFxQixNQUFNLEdBQUcsT0FBTyxDQUFDO0NBQzFDLE9BQU87RUFDTCxLQUFLO0VBQ0wsR0FBRyxTQUFTLE1BQU0sV0FBVztDQUMvQjtBQUNGO0FBQ0EsSUFBTSxXQUFXLFFBQVEsTUFBTSxhQUFhO0NBQzFDLE1BQU0sRUFDSixLQUNBLE1BQ0UsY0FBYyxRQUFRLE1BQU0sTUFBTTtDQUN0QyxJQUFJLFFBQVEsS0FBQSxLQUFhLEtBQUssV0FBVyxHQUFHO0VBQzFDLElBQUksS0FBSztFQUNUO0NBQ0Y7Q0FDQSxJQUFJLElBQUksS0FBSyxLQUFLLFNBQVM7Q0FDM0IsSUFBSSxJQUFJLEtBQUssTUFBTSxHQUFHLEtBQUssU0FBUyxDQUFDO0NBQ3JDLElBQUksT0FBTyxjQUFjLFFBQVEsR0FBRyxNQUFNO0NBQzFDLE9BQU8sS0FBSyxRQUFRLEtBQUEsS0FBYSxFQUFFLFFBQVE7RUFDekMsSUFBSSxHQUFHLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRztFQUMxQixJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUUsU0FBUyxDQUFDO0VBQzNCLE9BQU8sY0FBYyxRQUFRLEdBQUcsTUFBTTtFQUN0QyxJQUFJLE1BQU0sT0FBTyxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssRUFBRSxHQUFHLFNBQVMsYUFDckQsS0FBSyxNQUFNLEtBQUE7Q0FFZjtDQUNBLEtBQUssSUFBSSxHQUFHLEtBQUssRUFBRSxHQUFHLE9BQU87QUFDL0I7QUFDQSxJQUFNLFlBQVksUUFBUSxNQUFNLFVBQVUsV0FBVztDQUNuRCxNQUFNLEVBQ0osS0FDQSxNQUNFLGNBQWMsUUFBUSxNQUFNLE1BQU07Q0FDdEMsSUFBSSxLQUFLLElBQUksTUFBTSxDQUFDO0NBQ3BCLElBQUksRUFBRSxDQUFDLEtBQUssUUFBUTtBQUN0QjtBQUNBLElBQU0sV0FBVyxRQUFRLFNBQVM7Q0FDaEMsTUFBTSxFQUNKLEtBQ0EsTUFDRSxjQUFjLFFBQVEsSUFBSTtDQUM5QixJQUFJLENBQUMsS0FBSyxPQUFPLEtBQUE7Q0FDakIsSUFBSSxDQUFDLE9BQU8sVUFBVSxlQUFlLEtBQUssS0FBSyxDQUFDLEdBQUcsT0FBTyxLQUFBO0NBQzFELE9BQU8sSUFBSTtBQUNiO0FBQ0EsSUFBTSx1QkFBdUIsTUFBTSxhQUFhLFFBQVE7Q0FDdEQsTUFBTSxRQUFRLFFBQVEsTUFBTSxHQUFHO0NBQy9CLElBQUksVUFBVSxLQUFBLEdBQ1osT0FBTztDQUVULE9BQU8sUUFBUSxhQUFhLEdBQUc7QUFDakM7QUFDQSxJQUFNLGNBQWMsUUFBUSxRQUFRLGNBQWM7Q0FDaEQsS0FBSyxNQUFNLFFBQVEsUUFDakIsSUFBSSxTQUFTLGVBQWUsU0FBUyxlQUNuQyxJQUFJLE9BQU8sVUFBVSxlQUFlLEtBQUssUUFBUSxJQUFJLEdBQ25ELElBQUksU0FBUyxPQUFPLEtBQUssS0FBSyxPQUFPLGlCQUFpQixVQUFVLFNBQVMsT0FBTyxLQUFLLEtBQUssT0FBTyxpQkFBaUIsUUFDNUc7TUFBQSxXQUFXLE9BQU8sUUFBUSxPQUFPO0NBQUEsT0FFckMsV0FBVyxPQUFPLE9BQU8sT0FBTyxPQUFPLFNBQVM7TUFHbEQsT0FBTyxRQUFRLE9BQU87Q0FJNUIsT0FBTztBQUNUO0FBQ0EsSUFBTSxlQUFjLFFBQU8sSUFBSSxRQUFRLHVDQUF1QyxNQUFNO0FBQ3BGLElBQU0sYUFBYTtDQUNqQixLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxNQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7QUFDUDtBQUNBLElBQU0sVUFBUyxTQUFRO0NBQ3JCLElBQUksU0FBUyxJQUFJLEdBQ2YsT0FBTyxLQUFLLFFBQVEsZUFBYyxNQUFLLFdBQVcsRUFBRTtDQUV0RCxPQUFPO0FBQ1Q7QUFDQSxJQUFNLGNBQU4sTUFBa0I7Q0FDaEIsWUFBWSxVQUFVO0VBQ3BCLEtBQUssV0FBVztFQUNoQixLQUFLLDRCQUFZLElBQUksSUFBSTtFQUN6QixLQUFLLGNBQWMsQ0FBQztDQUN0QjtDQUNBLFVBQVUsU0FBUztFQUNqQixNQUFNLGtCQUFrQixLQUFLLFVBQVUsSUFBSSxPQUFPO0VBQ2xELElBQUksb0JBQW9CLEtBQUEsR0FDdEIsT0FBTztFQUVULE1BQU0sWUFBWSxJQUFJLE9BQU8sT0FBTztFQUNwQyxJQUFJLEtBQUssWUFBWSxXQUFXLEtBQUssVUFDbkMsS0FBSyxVQUFVLE9BQU8sS0FBSyxZQUFZLE1BQU0sQ0FBQztFQUVoRCxLQUFLLFVBQVUsSUFBSSxTQUFTLFNBQVM7RUFDckMsS0FBSyxZQUFZLEtBQUssT0FBTztFQUM3QixPQUFPO0NBQ1Q7QUFDRjtBQUNBLElBQU0sUUFBUTtDQUFDO0NBQUs7Q0FBSztDQUFLO0NBQUs7QUFBRztBQUN0QyxJQUFNLGlDQUFpQyxJQUFJLFlBQVksRUFBRTtBQUN6RCxJQUFNLHVCQUF1QixLQUFLLGFBQWEsaUJBQWlCO0NBQzlELGNBQWMsZUFBZTtDQUM3QixlQUFlLGdCQUFnQjtDQUMvQixNQUFNLGdCQUFnQixNQUFNLFFBQU8sTUFBSyxDQUFDLFlBQVksU0FBUyxDQUFDLEtBQUssQ0FBQyxhQUFhLFNBQVMsQ0FBQyxDQUFDO0NBQzdGLElBQUksY0FBYyxXQUFXLEdBQUcsT0FBTztDQUN2QyxNQUFNLElBQUksK0JBQStCLFVBQVUsSUFBSSxjQUFjLEtBQUksTUFBSyxNQUFNLE1BQU0sUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxFQUFFO0NBQ2pILElBQUksVUFBVSxDQUFDLEVBQUUsS0FBSyxHQUFHO0NBQ3pCLElBQUksQ0FBQyxTQUFTO0VBQ1osTUFBTSxLQUFLLElBQUksUUFBUSxZQUFZO0VBQ25DLElBQUksS0FBSyxLQUFLLENBQUMsRUFBRSxLQUFLLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQyxHQUN4QyxVQUFVO0NBRWQ7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxJQUFNLFlBQVksS0FBSyxNQUFNLGVBQWUsUUFBUTtDQUNsRCxJQUFJLENBQUMsS0FBSyxPQUFPLEtBQUE7Q0FDakIsSUFBSSxJQUFJLE9BQU87RUFDYixJQUFJLENBQUMsT0FBTyxVQUFVLGVBQWUsS0FBSyxLQUFLLElBQUksR0FBRyxPQUFPLEtBQUE7RUFDN0QsT0FBTyxJQUFJO0NBQ2I7Q0FDQSxNQUFNLFNBQVMsS0FBSyxNQUFNLFlBQVk7Q0FDdEMsSUFBSSxVQUFVO0NBQ2QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sU0FBUztFQUNsQyxJQUFJLENBQUMsV0FBVyxPQUFPLFlBQVksVUFDakM7RUFFRixJQUFJO0VBQ0osSUFBSSxXQUFXO0VBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxFQUFFLEdBQUc7R0FDdEMsSUFBSSxNQUFNLEdBQ1IsWUFBWTtHQUVkLFlBQVksT0FBTztHQUNuQixPQUFPLFFBQVE7R0FDZixJQUFJLFNBQVMsS0FBQSxHQUFXO0lBQ3RCLElBQUk7S0FBQztLQUFVO0tBQVU7SUFBUyxDQUFDLENBQUMsU0FBUyxPQUFPLElBQUksS0FBSyxJQUFJLE9BQU8sU0FBUyxHQUMvRTtJQUVGLEtBQUssSUFBSSxJQUFJO0lBQ2I7R0FDRjtFQUNGO0VBQ0EsVUFBVTtDQUNaO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBTSxrQkFBaUIsU0FBUSxNQUFNLFFBQVEsTUFBTSxHQUFHO0FBRXRELElBQU0sZ0JBQWdCO0NBQ3BCLE1BQU07Q0FDTixJQUFJLE1BQU07RUFDUixLQUFLLE9BQU8sT0FBTyxJQUFJO0NBQ3pCO0NBQ0EsS0FBSyxNQUFNO0VBQ1QsS0FBSyxPQUFPLFFBQVEsSUFBSTtDQUMxQjtDQUNBLE1BQU0sTUFBTTtFQUNWLEtBQUssT0FBTyxTQUFTLElBQUk7Q0FDM0I7Q0FDQSxPQUFPLE1BQU0sTUFBTTtFQUNqQixVQUFVLEtBQUssRUFBRSxRQUFRLFNBQVMsSUFBSTtDQUN4QztBQUNGO0FBMkNBLElBQUksYUFBYSxJQUFJLE1BMUNmLE9BQU87Q0FDWCxZQUFZLGdCQUFnQixVQUFVLENBQUMsR0FBRztFQUN4QyxLQUFLLEtBQUssZ0JBQWdCLE9BQU87Q0FDbkM7Q0FDQSxLQUFLLGdCQUFnQixVQUFVLENBQUMsR0FBRztFQUNqQyxLQUFLLFNBQVMsUUFBUSxVQUFVO0VBQ2hDLEtBQUssU0FBUyxrQkFBa0I7RUFDaEMsS0FBSyxVQUFVO0VBQ2YsS0FBSyxRQUFRLFFBQVE7Q0FDdkI7Q0FDQSxJQUFJLEdBQUcsTUFBTTtFQUNYLE9BQU8sS0FBSyxRQUFRLE1BQU0sT0FBTyxJQUFJLElBQUk7Q0FDM0M7Q0FDQSxLQUFLLEdBQUcsTUFBTTtFQUNaLE9BQU8sS0FBSyxRQUFRLE1BQU0sUUFBUSxJQUFJLElBQUk7Q0FDNUM7Q0FDQSxNQUFNLEdBQUcsTUFBTTtFQUNiLE9BQU8sS0FBSyxRQUFRLE1BQU0sU0FBUyxFQUFFO0NBQ3ZDO0NBQ0EsVUFBVSxHQUFHLE1BQU07RUFDakIsT0FBTyxLQUFLLFFBQVEsTUFBTSxRQUFRLHdCQUF3QixJQUFJO0NBQ2hFO0NBQ0EsUUFBUSxNQUFNLEtBQUssUUFBUSxXQUFXO0VBQ3BDLElBQUksYUFBYSxDQUFDLEtBQUssT0FBTyxPQUFPO0VBQ3JDLE9BQU8sS0FBSyxLQUFJLE1BQUssU0FBUyxDQUFDLElBQUksRUFBRSxRQUFRLHdCQUF3QixHQUFHLElBQUksQ0FBQztFQUM3RSxJQUFJLFNBQVMsS0FBSyxFQUFFLEdBQUcsS0FBSyxLQUFLLEdBQUcsU0FBUyxLQUFLLE9BQU8sR0FBRyxLQUFLO0VBQ2pFLE9BQU8sS0FBSyxPQUFPLElBQUksQ0FBQyxJQUFJO0NBQzlCO0NBQ0EsT0FBTyxZQUFZO0VBQ2pCLE9BQU8sSUFBSSxPQUFPLEtBQUssUUFBUTtHQUUzQixRQUFRLEdBQUcsS0FBSyxPQUFPLEdBQUcsV0FBVztHQUV2QyxHQUFHLEtBQUs7RUFDVixDQUFDO0NBQ0g7Q0FDQSxNQUFNLFNBQVM7RUFDYixVQUFVLFdBQVcsS0FBSztFQUMxQixRQUFRLFNBQVMsUUFBUSxVQUFVLEtBQUs7RUFDeEMsT0FBTyxJQUFJLE9BQU8sS0FBSyxRQUFRLE9BQU87Q0FDeEM7QUFDRixFQUM0QjtBQUU1QixJQUFNLGVBQU4sTUFBbUI7Q0FDakIsY0FBYztFQUNaLEtBQUssWUFBWSxDQUFDO0NBQ3BCO0NBQ0EsR0FBRyxRQUFRLFVBQVU7RUFDbkIsT0FBTyxNQUFNLEdBQUcsQ0FBQyxDQUFDLFNBQVEsVUFBUztHQUNqQyxJQUFJLENBQUMsS0FBSyxVQUFVLFFBQVEsS0FBSyxVQUFVLHlCQUFTLElBQUksSUFBSTtHQUM1RCxNQUFNLGVBQWUsS0FBSyxVQUFVLE1BQU0sQ0FBQyxJQUFJLFFBQVEsS0FBSztHQUM1RCxLQUFLLFVBQVUsTUFBTSxDQUFDLElBQUksVUFBVSxlQUFlLENBQUM7RUFDdEQsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTyxVQUFVO0VBQ25CLElBQUksQ0FBQyxLQUFLLFVBQVUsUUFBUTtFQUM1QixJQUFJLENBQUMsVUFBVTtHQUNiLE9BQU8sS0FBSyxVQUFVO0dBQ3RCO0VBQ0Y7RUFDQSxLQUFLLFVBQVUsTUFBTSxDQUFDLE9BQU8sUUFBUTtDQUN2QztDQUNBLEtBQUssT0FBTyxVQUFVO0VBQ3BCLE1BQU0sV0FBVyxHQUFHLFNBQVM7R0FDM0IsU0FBUyxHQUFHLElBQUk7R0FDaEIsS0FBSyxJQUFJLE9BQU8sT0FBTztFQUN6QjtFQUNBLEtBQUssR0FBRyxPQUFPLE9BQU87RUFDdEIsT0FBTztDQUNUO0NBQ0EsS0FBSyxPQUFPLEdBQUcsTUFBTTtFQUNuQixJQUFJLEtBQUssVUFBVSxRQUVqQixNQURxQixLQUFLLEtBQUssVUFBVSxNQUFNLENBQUMsUUFBUSxDQUNuRCxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsbUJBQW1CO0dBQzVDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLEtBQ2pDLFNBQVMsR0FBRyxJQUFJO0VBRXBCLENBQUM7RUFFSCxJQUFJLEtBQUssVUFBVSxNQUVqQixNQURxQixLQUFLLEtBQUssVUFBVSxJQUFJLENBQUMsUUFBUSxDQUNqRCxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsbUJBQW1CO0dBQzVDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLEtBQ2pDLFNBQVMsT0FBTyxHQUFHLElBQUk7RUFFM0IsQ0FBQztDQUVMO0FBQ0Y7QUFFQSxJQUFNLGdCQUFOLGNBQTRCLGFBQWE7Q0FDdkMsWUFBWSxNQUFNLFVBQVU7RUFDMUIsSUFBSSxDQUFDLGFBQWE7RUFDbEIsV0FBVztDQUNiLEdBQUc7RUFDRCxNQUFNO0VBQ04sS0FBSyxPQUFPLFFBQVEsQ0FBQztFQUNyQixLQUFLLFVBQVU7RUFDZixJQUFJLEtBQUssUUFBUSxpQkFBaUIsS0FBQSxHQUNoQyxLQUFLLFFBQVEsZUFBZTtFQUU5QixJQUFJLEtBQUssUUFBUSx3QkFBd0IsS0FBQSxHQUN2QyxLQUFLLFFBQVEsc0JBQXNCO0NBRXZDO0NBQ0EsY0FBYyxJQUFJO0VBQ2hCLElBQUksQ0FBQyxLQUFLLFFBQVEsR0FBRyxTQUFTLEVBQUUsR0FDOUIsS0FBSyxRQUFRLEdBQUcsS0FBSyxFQUFFO0NBRTNCO0NBQ0EsaUJBQWlCLElBQUk7RUFDbkIsTUFBTSxRQUFRLEtBQUssUUFBUSxHQUFHLFFBQVEsRUFBRTtFQUN4QyxJQUFJLFFBQVEsSUFDVixLQUFLLFFBQVEsR0FBRyxPQUFPLE9BQU8sQ0FBQztDQUVuQztDQUNBLFlBQVksS0FBSyxJQUFJLEtBQUssVUFBVSxDQUFDLEdBQUc7RUFDdEMsTUFBTSxlQUFlLFFBQVEsaUJBQWlCLEtBQUEsSUFBWSxRQUFRLGVBQWUsS0FBSyxRQUFRO0VBQzlGLE1BQU0sc0JBQXNCLFFBQVEsd0JBQXdCLEtBQUEsSUFBWSxRQUFRLHNCQUFzQixLQUFLLFFBQVE7RUFDbkgsSUFBSTtFQUNKLElBQUksSUFBSSxTQUFTLEdBQUcsR0FDbEIsT0FBTyxJQUFJLE1BQU0sR0FBRztPQUNmO0dBQ0wsT0FBTyxDQUFDLEtBQUssRUFBRTtHQUNmLElBQUksS0FDRixJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQ25CLEtBQUssS0FBSyxHQUFHLEdBQUc7UUFDWCxJQUFJLFNBQVMsR0FBRyxLQUFLLGNBQzFCLEtBQUssS0FBSyxHQUFHLElBQUksTUFBTSxZQUFZLENBQUM7UUFFcEMsS0FBSyxLQUFLLEdBQUc7RUFHbkI7RUFDQSxNQUFNLFNBQVMsUUFBUSxLQUFLLE1BQU0sSUFBSTtFQUN0QyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLElBQUksU0FBUyxHQUFHLEdBQUc7R0FDL0MsTUFBTSxLQUFLO0dBQ1gsS0FBSyxLQUFLO0dBQ1YsTUFBTSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHO0VBQzlCO0VBQ0EsSUFBSSxVQUFVLENBQUMsdUJBQXVCLENBQUMsU0FBUyxHQUFHLEdBQUcsT0FBTztFQUM3RCxPQUFPLFNBQVMsS0FBSyxPQUFPLElBQUksR0FBRyxLQUFLLEtBQUssWUFBWTtDQUMzRDtDQUNBLFlBQVksS0FBSyxJQUFJLEtBQUssT0FBTyxVQUFVLEVBQ3pDLFFBQVEsTUFDVixHQUFHO0VBQ0QsTUFBTSxlQUFlLFFBQVEsaUJBQWlCLEtBQUEsSUFBWSxRQUFRLGVBQWUsS0FBSyxRQUFRO0VBQzlGLElBQUksT0FBTyxDQUFDLEtBQUssRUFBRTtFQUNuQixJQUFJLEtBQUssT0FBTyxLQUFLLE9BQU8sZUFBZSxJQUFJLE1BQU0sWUFBWSxJQUFJLEdBQUc7RUFDeEUsSUFBSSxJQUFJLFNBQVMsR0FBRyxHQUFHO0dBQ3JCLE9BQU8sSUFBSSxNQUFNLEdBQUc7R0FDcEIsUUFBUTtHQUNSLEtBQUssS0FBSztFQUNaO0VBQ0EsS0FBSyxjQUFjLEVBQUU7RUFDckIsUUFBUSxLQUFLLE1BQU0sTUFBTSxLQUFLO0VBQzlCLElBQUksQ0FBQyxRQUFRLFFBQVEsS0FBSyxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssS0FBSztDQUM3RDtDQUNBLGFBQWEsS0FBSyxJQUFJLFdBQVcsVUFBVSxFQUN6QyxRQUFRLE1BQ1YsR0FBRztFQUNELEtBQUssTUFBTSxLQUFLLFdBQ2QsSUFBSSxTQUFTLFVBQVUsRUFBRSxLQUFLLE1BQU0sUUFBUSxVQUFVLEVBQUUsR0FBRyxLQUFLLFlBQVksS0FBSyxJQUFJLEdBQUcsVUFBVSxJQUFJLEVBQ3BHLFFBQVEsS0FDVixDQUFDO0VBRUgsSUFBSSxDQUFDLFFBQVEsUUFBUSxLQUFLLEtBQUssU0FBUyxLQUFLLElBQUksU0FBUztDQUM1RDtDQUNBLGtCQUFrQixLQUFLLElBQUksV0FBVyxNQUFNLFdBQVcsVUFBVTtFQUMvRCxRQUFRO0VBQ1IsVUFBVTtDQUNaLEdBQUc7RUFDRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUU7RUFDbkIsSUFBSSxJQUFJLFNBQVMsR0FBRyxHQUFHO0dBQ3JCLE9BQU8sSUFBSSxNQUFNLEdBQUc7R0FDcEIsT0FBTztHQUNQLFlBQVk7R0FDWixLQUFLLEtBQUs7RUFDWjtFQUNBLEtBQUssY0FBYyxFQUFFO0VBQ3JCLElBQUksT0FBTyxRQUFRLEtBQUssTUFBTSxJQUFJLEtBQUssQ0FBQztFQUN4QyxJQUFJLENBQUMsUUFBUSxVQUFVLFlBQVksS0FBSyxNQUFNLEtBQUssVUFBVSxTQUFTLENBQUM7RUFDdkUsSUFBSSxNQUNGLFdBQVcsTUFBTSxXQUFXLFNBQVM7T0FFckMsT0FBTztHQUNMLEdBQUc7R0FDSCxHQUFHO0VBQ0w7RUFFRixRQUFRLEtBQUssTUFBTSxNQUFNLElBQUk7RUFDN0IsSUFBSSxDQUFDLFFBQVEsUUFBUSxLQUFLLEtBQUssU0FBUyxLQUFLLElBQUksU0FBUztDQUM1RDtDQUNBLHFCQUFxQixLQUFLLElBQUk7RUFDNUIsSUFBSSxLQUFLLGtCQUFrQixLQUFLLEVBQUUsR0FDaEMsT0FBTyxLQUFLLEtBQUssSUFBSSxDQUFDO0VBRXhCLEtBQUssaUJBQWlCLEVBQUU7RUFDeEIsS0FBSyxLQUFLLFdBQVcsS0FBSyxFQUFFO0NBQzlCO0NBQ0Esa0JBQWtCLEtBQUssSUFBSTtFQUN6QixPQUFPLEtBQUssWUFBWSxLQUFLLEVBQUUsTUFBTSxLQUFBO0NBQ3ZDO0NBQ0Esa0JBQWtCLEtBQUssSUFBSTtFQUN6QixJQUFJLENBQUMsSUFBSSxLQUFLLEtBQUssUUFBUTtFQUMzQixPQUFPLEtBQUssWUFBWSxLQUFLLEVBQUU7Q0FDakM7Q0FDQSxrQkFBa0IsS0FBSztFQUNyQixPQUFPLEtBQUssS0FBSztDQUNuQjtDQUNBLDRCQUE0QixLQUFLO0VBQy9CLE1BQU0sT0FBTyxLQUFLLGtCQUFrQixHQUFHO0VBRXZDLE9BQU8sQ0FBQyxFQURFLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxDQUFDLEVBQUEsQ0FDN0IsTUFBSyxNQUFLLEtBQUssTUFBTSxPQUFPLEtBQUssS0FBSyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUM7Q0FDakU7Q0FDQSxTQUFTO0VBQ1AsT0FBTyxLQUFLO0NBQ2Q7QUFDRjtBQUVBLElBQUksZ0JBQWdCO0NBQ2xCLFlBQVksQ0FBQztDQUNiLGlCQUFpQixRQUFRO0VBQ3ZCLEtBQUssV0FBVyxPQUFPLFFBQVE7Q0FDakM7Q0FDQSxPQUFPLFlBQVksT0FBTyxLQUFLLFNBQVMsWUFBWTtFQUNsRCxXQUFXLFNBQVEsY0FBYTtHQUM5QixRQUFRLEtBQUssV0FBVyxVQUFVLEVBQUUsUUFBUSxPQUFPLEtBQUssU0FBUyxVQUFVLEtBQUs7RUFDbEYsQ0FBQztFQUNELE9BQU87Q0FDVDtBQUNGO0FBRUEsSUFBTSxXQUFXLE9BQU8sa0JBQWtCO0FBQzFDLFNBQVMsY0FBYztDQUNyQixNQUFNLFFBQVEsQ0FBQztDQUNmLE1BQU0sVUFBVSxPQUFPLE9BQU8sSUFBSTtDQUNsQyxJQUFJO0NBQ0osUUFBUSxPQUFPLFFBQVEsUUFBUTtFQUM3QixPQUFPLFNBQVM7RUFDaEIsSUFBSSxRQUFRLFVBQVUsT0FBTztFQUM3QixNQUFNLEtBQUssR0FBRztFQUNkLFFBQVEsTUFBTSxVQUFVLFFBQVEsT0FBTztFQUN2QyxPQUFPLE1BQU07Q0FDZjtDQUNBLE9BQU8sTUFBTSxVQUFVLE9BQU8sT0FBTyxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUM7QUFDdkQ7QUFDQSxTQUFTLGlCQUFpQixVQUFVLE1BQU07Q0FDeEMsTUFBTSxHQUNILFdBQVcsU0FDVixTQUFTLFlBQVksQ0FBQztDQUMxQixNQUFNLGVBQWUsTUFBTSxnQkFBZ0I7Q0FDM0MsTUFBTSxjQUFjLE1BQU0sZUFBZTtDQUN6QyxNQUFNLFNBQVMsTUFBTSxtQkFBbUI7Q0FDeEMsSUFBSSxLQUFLLFNBQVMsS0FBSyxhQUFhO0VBQ2xDLE1BQU0sS0FBSyxNQUFNO0VBQ2pCLE1BQU0sU0FBUyxTQUFTLE1BQU0sUUFBUSxFQUFFLElBQUksS0FBSyxLQUFLLENBQUMsRUFBRSxJQUFJLE9BQU8sTUFBTSxRQUFRLEVBQUUsSUFBSSxLQUFLO0VBQzdGLElBQUksUUFDaUI7UUFBQSxTQUFTLFNBQVMsT0FBTyxTQUFTLElBQUksT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUEsQ0FDN0QsU0FBUyxLQUFLLEVBQUUsR0FDN0IsT0FBTyxHQUFHLEtBQUssS0FBSyxjQUFjLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLFlBQVk7RUFBQTtDQUd2RTtDQUNBLE9BQU8sS0FBSyxLQUFLLFlBQVk7QUFDL0I7QUFFQSxJQUFNLHdCQUF1QixRQUFPLENBQUMsU0FBUyxHQUFHLEtBQUssT0FBTyxRQUFRLGFBQWEsT0FBTyxRQUFRO0FBQ2pHLElBQU0sYUFBTixNQUFNLG1CQUFtQixhQUFhO0NBQ3BDLFlBQVksVUFBVSxVQUFVLENBQUMsR0FBRztFQUNsQyxNQUFNO0VBQ04sS0FBSztHQUFDO0dBQWlCO0dBQWlCO0dBQWtCO0dBQWdCO0dBQW9CO0dBQWM7RUFBTyxHQUFHLFVBQVUsSUFBSTtFQUNwSSxLQUFLLFVBQVU7RUFDZixJQUFJLEtBQUssUUFBUSxpQkFBaUIsS0FBQSxHQUNoQyxLQUFLLFFBQVEsZUFBZTtFQUU5QixLQUFLLFNBQVMsV0FBVyxPQUFPLFlBQVk7RUFDNUMsS0FBSyxtQkFBbUIsQ0FBQztDQUMzQjtDQUNBLGVBQWUsS0FBSztFQUNsQixJQUFJLEtBQUssS0FBSyxXQUFXO0NBQzNCO0NBQ0EsT0FBTyxLQUFLLElBQUksRUFDZCxlQUFlLENBQUMsRUFDbEIsR0FBRztFQUNELE1BQU0sTUFBTSxFQUNWLEdBQUcsRUFDTDtFQUNBLElBQUksT0FBTyxNQUFNLE9BQU87RUFDeEIsTUFBTSxXQUFXLEtBQUssUUFBUSxLQUFLLEdBQUc7RUFDdEMsSUFBSSxVQUFVLFFBQVEsS0FBQSxHQUFXLE9BQU87RUFDeEMsTUFBTSxXQUFXLHFCQUFxQixTQUFTLEdBQUc7RUFDbEQsSUFBSSxJQUFJLGtCQUFrQixTQUFTLFVBQ2pDLE9BQU87RUFFVCxPQUFPO0NBQ1Q7Q0FDQSxlQUFlLEtBQUssS0FBSztFQUN2QixJQUFJLGNBQWMsSUFBSSxnQkFBZ0IsS0FBQSxJQUFZLElBQUksY0FBYyxLQUFLLFFBQVE7RUFDakYsSUFBSSxnQkFBZ0IsS0FBQSxHQUFXLGNBQWM7RUFDN0MsTUFBTSxlQUFlLElBQUksaUJBQWlCLEtBQUEsSUFBWSxJQUFJLGVBQWUsS0FBSyxRQUFRO0VBQ3RGLElBQUksYUFBYSxJQUFJLE1BQU0sS0FBSyxRQUFRLGFBQWEsQ0FBQztFQUN0RCxNQUFNLHVCQUF1QixlQUFlLElBQUksU0FBUyxXQUFXO0VBQ3BFLE1BQU0sdUJBQXVCLENBQUMsS0FBSyxRQUFRLDJCQUEyQixDQUFDLElBQUksZ0JBQWdCLENBQUMsS0FBSyxRQUFRLDBCQUEwQixDQUFDLElBQUksZUFBZSxDQUFDLG9CQUFvQixLQUFLLGFBQWEsWUFBWTtFQUMxTSxJQUFJLHdCQUF3QixDQUFDLHNCQUFzQjtHQUNqRCxNQUFNLElBQUksSUFBSSxNQUFNLEtBQUssYUFBYSxhQUFhO0dBQ25ELElBQUksS0FBSyxFQUFFLFNBQVMsR0FDbEIsT0FBTztJQUNMO0lBQ0EsWUFBWSxTQUFTLFVBQVUsSUFBSSxDQUFDLFVBQVUsSUFBSTtHQUNwRDtHQUVGLE1BQU0sUUFBUSxJQUFJLE1BQU0sV0FBVztHQUNuQyxJQUFJLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLGdCQUFnQixLQUFLLFFBQVEsR0FBRyxTQUFTLE1BQU0sRUFBRSxHQUFHLGFBQWEsTUFBTSxNQUFNO0dBQ2pJLE1BQU0sTUFBTSxLQUFLLFlBQVk7RUFDL0I7RUFDQSxPQUFPO0dBQ0w7R0FDQSxZQUFZLFNBQVMsVUFBVSxJQUFJLENBQUMsVUFBVSxJQUFJO0VBQ3BEO0NBQ0Y7Q0FDQSxVQUFVLE1BQU0sR0FBRyxTQUFTO0VBQzFCLElBQUksTUFBTSxPQUFPLE1BQU0sV0FBVyxFQUNoQyxHQUFHLEVBQ0wsSUFBSTtFQUNKLElBQUksT0FBTyxRQUFRLFlBQVksS0FBSyxRQUFRLGtDQUMxQyxNQUFNLEtBQUssUUFBUSxpQ0FBaUMsU0FBUztFQUUvRCxJQUFJLE9BQU8sUUFBUSxVQUFVLE1BQU0sRUFDakMsR0FBRyxJQUNMO0VBQ0EsSUFBSSxDQUFDLEtBQUssTUFBTSxDQUFDO0VBQ2pCLElBQUksUUFBUSxNQUFNLE9BQU87RUFDekIsSUFBSSxPQUFPLFNBQVMsWUFBWSxPQUFPLGlCQUFpQixNQUFNO0dBQzVELEdBQUcsS0FBSztHQUNSLEdBQUc7RUFDTCxDQUFDO0VBQ0QsSUFBSSxDQUFDLE1BQU0sUUFBUSxJQUFJLEdBQUcsT0FBTyxDQUFDLE9BQU8sSUFBSSxDQUFDO0VBQzlDLE9BQU8sS0FBSyxLQUFJLE1BQUssT0FBTyxNQUFNLGFBQWEsaUJBQWlCLEdBQUc7R0FDakUsR0FBRyxLQUFLO0dBQ1IsR0FBRztFQUNMLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQztFQUNkLE1BQU0sZ0JBQWdCLElBQUksa0JBQWtCLEtBQUEsSUFBWSxJQUFJLGdCQUFnQixLQUFLLFFBQVE7RUFDekYsTUFBTSxlQUFlLElBQUksaUJBQWlCLEtBQUEsSUFBWSxJQUFJLGVBQWUsS0FBSyxRQUFRO0VBQ3RGLE1BQU0sRUFDSixLQUNBLGVBQ0UsS0FBSyxlQUFlLEtBQUssS0FBSyxTQUFTLElBQUksR0FBRztFQUNsRCxNQUFNLFlBQVksV0FBVyxXQUFXLFNBQVM7RUFDakQsSUFBSSxjQUFjLElBQUksZ0JBQWdCLEtBQUEsSUFBWSxJQUFJLGNBQWMsS0FBSyxRQUFRO0VBQ2pGLElBQUksZ0JBQWdCLEtBQUEsR0FBVyxjQUFjO0VBQzdDLE1BQU0sTUFBTSxJQUFJLE9BQU8sS0FBSztFQUM1QixNQUFNLDBCQUEwQixJQUFJLDJCQUEyQixLQUFLLFFBQVE7RUFDNUUsSUFBSSxLQUFLLFlBQVksTUFBTSxVQUFVO0dBQ25DLElBQUkseUJBQXlCO0lBQzNCLElBQUksZUFDRixPQUFPO0tBQ0wsS0FBSyxHQUFHLFlBQVksY0FBYztLQUNsQyxTQUFTO0tBQ1QsY0FBYztLQUNkLFNBQVM7S0FDVCxRQUFRO0tBQ1IsWUFBWSxLQUFLLHFCQUFxQixHQUFHO0lBQzNDO0lBRUYsT0FBTyxHQUFHLFlBQVksY0FBYztHQUN0QztHQUNBLElBQUksZUFDRixPQUFPO0lBQ0wsS0FBSztJQUNMLFNBQVM7SUFDVCxjQUFjO0lBQ2QsU0FBUztJQUNULFFBQVE7SUFDUixZQUFZLEtBQUsscUJBQXFCLEdBQUc7R0FDM0M7R0FFRixPQUFPO0VBQ1Q7RUFDQSxNQUFNLFdBQVcsS0FBSyxRQUFRLE1BQU0sR0FBRztFQUN2QyxJQUFJLE1BQU0sVUFBVTtFQUNwQixNQUFNLGFBQWEsVUFBVSxXQUFXO0VBQ3hDLE1BQU0sa0JBQWtCLFVBQVUsZ0JBQWdCO0VBQ2xELE1BQU0sV0FBVztHQUFDO0dBQW1CO0dBQXFCO0VBQWlCO0VBQzNFLE1BQU0sYUFBYSxJQUFJLGVBQWUsS0FBQSxJQUFZLElBQUksYUFBYSxLQUFLLFFBQVE7RUFDaEYsTUFBTSw2QkFBNkIsQ0FBQyxLQUFLLGNBQWMsS0FBSyxXQUFXO0VBQ3ZFLE1BQU0sc0JBQXNCLElBQUksVUFBVSxLQUFBLEtBQWEsQ0FBQyxTQUFTLElBQUksS0FBSztFQUMxRSxNQUFNLGtCQUFrQixXQUFXLGdCQUFnQixHQUFHO0VBQ3RELE1BQU0scUJBQXFCLHNCQUFzQixLQUFLLGVBQWUsVUFBVSxLQUFLLElBQUksT0FBTyxHQUFHLElBQUk7RUFDdEcsTUFBTSxvQ0FBb0MsSUFBSSxXQUFXLHNCQUFzQixLQUFLLGVBQWUsVUFBVSxLQUFLLElBQUksT0FBTyxFQUMzSCxTQUFTLE1BQ1gsQ0FBQyxJQUFJO0VBQ0wsTUFBTSx3QkFBd0IsdUJBQXVCLENBQUMsSUFBSSxXQUFXLElBQUksVUFBVTtFQUNuRixNQUFNLGVBQWUseUJBQXlCLElBQUksZUFBZSxLQUFLLFFBQVEsZ0JBQWdCLFVBQVUsSUFBSSxlQUFlLHlCQUF5QixJQUFJLGVBQWUsd0NBQXdDLElBQUk7RUFDbk4sSUFBSSxnQkFBZ0I7RUFDcEIsSUFBSSw4QkFBOEIsQ0FBQyxPQUFPLGlCQUN4QyxnQkFBZ0I7RUFFbEIsTUFBTSxpQkFBaUIscUJBQXFCLGFBQWE7RUFDekQsTUFBTSxVQUFVLE9BQU8sVUFBVSxTQUFTLE1BQU0sYUFBYTtFQUM3RCxJQUFJLDhCQUE4QixpQkFBaUIsa0JBQWtCLENBQUMsU0FBUyxTQUFTLE9BQU8sS0FBSyxFQUFFLFNBQVMsVUFBVSxLQUFLLE1BQU0sUUFBUSxhQUFhLElBQUk7R0FDM0osSUFBSSxDQUFDLElBQUksaUJBQWlCLENBQUMsS0FBSyxRQUFRLGVBQWU7SUFDckQsSUFBSSxDQUFDLEtBQUssUUFBUSx1QkFDaEIsS0FBSyxPQUFPLEtBQUssaUVBQWlFO0lBRXBGLE1BQU0sSUFBSSxLQUFLLFFBQVEsd0JBQXdCLEtBQUssUUFBUSxzQkFBc0IsWUFBWSxlQUFlO0tBQzNHLEdBQUc7S0FDSCxJQUFJO0lBQ04sQ0FBQyxJQUFJLFFBQVEsSUFBSSxJQUFJLEtBQUssU0FBUztJQUNuQyxJQUFJLGVBQWU7S0FDakIsU0FBUyxNQUFNO0tBQ2YsU0FBUyxhQUFhLEtBQUsscUJBQXFCLEdBQUc7S0FDbkQsT0FBTztJQUNUO0lBQ0EsT0FBTztHQUNUO0dBQ0EsSUFBSSxjQUFjO0lBQ2hCLE1BQU0saUJBQWlCLE1BQU0sUUFBUSxhQUFhO0lBQ2xELE1BQU0sT0FBTyxpQkFBaUIsQ0FBQyxJQUFJLENBQUM7SUFDcEMsTUFBTSxjQUFjLGlCQUFpQixrQkFBa0I7SUFDdkQsS0FBSyxNQUFNLEtBQUssZUFDZCxJQUFJLE9BQU8sVUFBVSxlQUFlLEtBQUssZUFBZSxDQUFDLEdBQUc7S0FDMUQsTUFBTSxVQUFVLEdBQUcsY0FBYyxlQUFlO0tBQ2hELElBQUksbUJBQW1CLENBQUMsS0FDdEIsS0FBSyxLQUFLLEtBQUssVUFBVSxTQUFTO01BQ2hDLEdBQUc7TUFDSCxjQUFjLHFCQUFxQixZQUFZLElBQUksYUFBYSxLQUFLLEtBQUE7TUFFbkUsWUFBWTtNQUNaLElBQUk7S0FFUixDQUFDO1VBRUQsS0FBSyxLQUFLLEtBQUssVUFBVSxTQUFTO01BQ2hDLEdBQUc7TUFFRCxZQUFZO01BQ1osSUFBSTtLQUVSLENBQUM7S0FFSCxJQUFJLEtBQUssT0FBTyxTQUFTLEtBQUssS0FBSyxjQUFjO0lBQ25EO0lBRUYsTUFBTTtHQUNSO0VBQ0YsT0FBTyxJQUFJLDhCQUE4QixTQUFTLFVBQVUsS0FBSyxNQUFNLFFBQVEsR0FBRyxHQUFHO0dBQ25GLE1BQU0sSUFBSSxLQUFLLFVBQVU7R0FDekIsSUFBSSxLQUFLLE1BQU0sS0FBSyxrQkFBa0IsS0FBSyxNQUFNLEtBQUssT0FBTztFQUMvRCxPQUFPO0dBQ0wsSUFBSSxjQUFjO0dBQ2xCLElBQUksVUFBVTtHQUNkLElBQUksQ0FBQyxLQUFLLGNBQWMsR0FBRyxLQUFLLGlCQUFpQjtJQUMvQyxjQUFjO0lBQ2QsTUFBTTtHQUNSO0dBQ0EsSUFBSSxDQUFDLEtBQUssY0FBYyxHQUFHLEdBQUc7SUFDNUIsVUFBVTtJQUNWLE1BQU07R0FDUjtHQUVBLE1BQU0saUJBRGlDLElBQUksa0NBQWtDLEtBQUssUUFBUSxtQ0FDbEMsVUFBVSxLQUFBLElBQVk7R0FDOUUsTUFBTSxnQkFBZ0IsbUJBQW1CLGlCQUFpQixPQUFPLEtBQUssUUFBUTtHQUM5RSxJQUFJLFdBQVcsZUFBZSxlQUFlO0lBQzNDLEtBQUssT0FBTyxJQUFJLGdCQUFnQixjQUFjLGNBQWMsS0FBSyxXQUFXLHVCQUF1QixDQUFDLGdCQUFnQixHQUFHLE1BQU0sS0FBSyxlQUFlLFVBQVUsS0FBSyxJQUFJLE9BQU8sR0FBRyxNQUFNLEtBQUssZ0JBQWdCLGVBQWUsR0FBRztJQUMzTixJQUFJLGNBQWM7S0FDaEIsTUFBTSxLQUFLLEtBQUssUUFBUSxLQUFLO01BQzNCLEdBQUc7TUFDSCxjQUFjO0tBQ2hCLENBQUM7S0FDRCxJQUFJLE1BQU0sR0FBRyxLQUFLLEtBQUssT0FBTyxLQUFLLGlMQUFpTDtJQUN0TjtJQUNBLElBQUksT0FBTyxDQUFDO0lBQ1osTUFBTSxlQUFlLEtBQUssY0FBYyxpQkFBaUIsS0FBSyxRQUFRLGFBQWEsSUFBSSxPQUFPLEtBQUssUUFBUTtJQUMzRyxJQUFJLEtBQUssUUFBUSxrQkFBa0IsY0FBYyxnQkFBZ0IsYUFBYSxJQUM1RSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEtBQ3ZDLEtBQUssS0FBSyxhQUFhLEVBQUU7U0FFdEIsSUFBSSxLQUFLLFFBQVEsa0JBQWtCLE9BQ3hDLE9BQU8sS0FBSyxjQUFjLG1CQUFtQixJQUFJLE9BQU8sS0FBSyxRQUFRO1NBRXJFLEtBQUssS0FBSyxJQUFJLE9BQU8sS0FBSyxRQUFRO0lBRXBDLE1BQU0sUUFBUSxHQUFHLEdBQUcseUJBQXlCO0tBQzNDLE1BQU0sb0JBQW9CLG1CQUFtQix5QkFBeUIsTUFBTSx1QkFBdUI7S0FDbkcsSUFBSSxLQUFLLFFBQVEsbUJBQ2YsS0FBSyxRQUFRLGtCQUFrQixHQUFHLFdBQVcsR0FBRyxtQkFBbUIsZUFBZSxHQUFHO1VBQ2hGLElBQUksS0FBSyxrQkFBa0IsYUFDaEMsS0FBSyxpQkFBaUIsWUFBWSxHQUFHLFdBQVcsR0FBRyxtQkFBbUIsZUFBZSxHQUFHO0tBRTFGLEtBQUssS0FBSyxjQUFjLEdBQUcsV0FBVyxHQUFHLEdBQUc7SUFDOUM7SUFDQSxJQUFJLEtBQUssUUFBUSxhQUNmLElBQUksS0FBSyxRQUFRLHNCQUFzQixxQkFDckMsS0FBSyxTQUFRLGFBQVk7S0FDdkIsTUFBTSxXQUFXLEtBQUssZUFBZSxZQUFZLFVBQVUsR0FBRztLQUM5RCxJQUFJLHlCQUF5QixJQUFJLGVBQWUsS0FBSyxRQUFRLGdCQUFnQixVQUFVLENBQUMsU0FBUyxTQUFTLEdBQUcsS0FBSyxRQUFRLGdCQUFnQixLQUFLLEdBQzdJLFNBQVMsS0FBSyxHQUFHLEtBQUssUUFBUSxnQkFBZ0IsS0FBSztLQUVyRCxTQUFTLFNBQVEsV0FBVTtNQUN6QixLQUFLLENBQUMsUUFBUSxHQUFHLE1BQU0sUUFBUSxJQUFJLGVBQWUsYUFBYSxZQUFZO0tBQzdFLENBQUM7SUFDSCxDQUFDO1NBRUQsS0FBSyxNQUFNLEtBQUssWUFBWTtHQUdsQztHQUNBLE1BQU0sS0FBSyxrQkFBa0IsS0FBSyxNQUFNLEtBQUssVUFBVSxPQUFPO0dBQzlELElBQUksV0FBVyxRQUFRLE9BQU8sS0FBSyxRQUFRLDZCQUN6QyxNQUFNLEdBQUcsWUFBWSxjQUFjO0dBRXJDLEtBQUssV0FBVyxnQkFBZ0IsS0FBSyxRQUFRLHdCQUMzQyxNQUFNLEtBQUssUUFBUSx1QkFBdUIsS0FBSyxRQUFRLDhCQUE4QixHQUFHLFlBQVksY0FBYyxRQUFRLEtBQUssY0FBYyxNQUFNLEtBQUEsR0FBVyxHQUFHO0VBRXJLO0VBQ0EsSUFBSSxlQUFlO0dBQ2pCLFNBQVMsTUFBTTtHQUNmLFNBQVMsYUFBYSxLQUFLLHFCQUFxQixHQUFHO0dBQ25ELE9BQU87RUFDVDtFQUNBLE9BQU87Q0FDVDtDQUNBLGtCQUFrQixLQUFLLEtBQUssS0FBSyxVQUFVLFNBQVM7RUFDbEQsSUFBSSxLQUFLLFlBQVksT0FDbkIsTUFBTSxLQUFLLFdBQVcsTUFBTSxLQUFLO0dBQy9CLEdBQUcsS0FBSyxRQUFRLGNBQWM7R0FDOUIsR0FBRztFQUNMLEdBQUcsSUFBSSxPQUFPLEtBQUssWUFBWSxTQUFTLFNBQVMsU0FBUyxRQUFRLFNBQVMsU0FBUyxFQUNsRixTQUNGLENBQUM7T0FDSSxJQUFJLENBQUMsSUFBSSxtQkFBbUI7R0FDakMsSUFBSSxJQUFJLGVBQWUsS0FBSyxhQUFhLEtBQUs7SUFDNUMsR0FBRztJQUVELGVBQWU7S0FDYixHQUFHLEtBQUssUUFBUTtLQUNoQixHQUFHLElBQUk7SUFDVDtHQUVKLENBQUM7R0FDRCxNQUFNLGtCQUFrQixTQUFTLEdBQUcsTUFBTSxLQUFLLGVBQWUsb0JBQW9CLEtBQUEsSUFBWSxJQUFJLGNBQWMsa0JBQWtCLEtBQUssUUFBUSxjQUFjO0dBQzdKLElBQUk7R0FDSixJQUFJLGlCQUFpQjtJQUNuQixNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssYUFBYSxhQUFhO0lBQ3BELFVBQVUsTUFBTSxHQUFHO0dBQ3JCO0dBQ0EsSUFBSSxPQUFPLElBQUksV0FBVyxDQUFDLFNBQVMsSUFBSSxPQUFPLElBQUksSUFBSSxVQUFVO0dBQ2pFLElBQUksS0FBSyxRQUFRLGNBQWMsa0JBQWtCLE9BQU87SUFDdEQsR0FBRyxLQUFLLFFBQVEsY0FBYztJQUM5QixHQUFHO0dBQ0w7R0FDQSxNQUFNLEtBQUssYUFBYSxZQUFZLEtBQUssTUFBTSxJQUFJLE9BQU8sS0FBSyxZQUFZLFNBQVMsU0FBUyxHQUFHO0dBQ2hHLElBQUksaUJBQWlCO0lBQ25CLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxhQUFhLGFBQWE7SUFDcEQsTUFBTSxVQUFVLE1BQU0sR0FBRztJQUN6QixJQUFJLFVBQVUsU0FBUyxJQUFJLE9BQU87R0FDcEM7R0FDQSxJQUFJLENBQUMsSUFBSSxPQUFPLFlBQVksU0FBUyxLQUFLLElBQUksTUFBTSxLQUFLLFlBQVksU0FBUztHQUM5RSxJQUFJLElBQUksU0FBUyxPQUFPLE1BQU0sS0FBSyxhQUFhLEtBQUssTUFBTSxHQUFHLFNBQVM7SUFDckUsSUFBSSxVQUFVLE9BQU8sS0FBSyxNQUFNLENBQUMsSUFBSSxTQUFTO0tBQzVDLEtBQUssT0FBTyxLQUFLLDZDQUE2QyxLQUFLLEdBQUcsV0FBVyxJQUFJLElBQUk7S0FDekYsT0FBTztJQUNUO0lBQ0EsT0FBTyxLQUFLLFVBQVUsR0FBRyxNQUFNLEdBQUc7R0FDcEMsR0FBRyxHQUFHO0dBQ04sSUFBSSxJQUFJLGVBQWUsS0FBSyxhQUFhLE1BQU07RUFDakQ7RUFDQSxNQUFNLGNBQWMsSUFBSSxlQUFlLEtBQUssUUFBUTtFQUNwRCxNQUFNLHFCQUFxQixTQUFTLFdBQVcsSUFBSSxDQUFDLFdBQVcsSUFBSTtFQUNuRSxJQUFJLE9BQU8sUUFBUSxvQkFBb0IsVUFBVSxJQUFJLHVCQUF1QixPQUMxRSxNQUFNLGNBQWMsT0FBTyxvQkFBb0IsS0FBSyxLQUFLLEtBQUssV0FBVyxLQUFLLFFBQVEsMEJBQTBCO0dBQzlHLGNBQWM7SUFDWixHQUFHO0lBQ0gsWUFBWSxLQUFLLHFCQUFxQixHQUFHO0dBQzNDO0dBQ0EsR0FBRztFQUNMLElBQUksS0FBSyxJQUFJO0VBRWYsT0FBTztDQUNUO0NBQ0EsUUFBUSxNQUFNLE1BQU0sQ0FBQyxHQUFHO0VBQ3RCLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSSxTQUFTLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSTtFQUNoQyxJQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUcsT0FBTyxLQUFLLEtBQUksTUFBSyxPQUFPLE1BQU0sYUFBYSxpQkFBaUIsR0FBRztHQUMxRixHQUFHLEtBQUs7R0FDUixHQUFHO0VBQ0wsQ0FBQyxJQUFJLENBQUM7RUFDTixLQUFLLFNBQVEsTUFBSztHQUNoQixJQUFJLEtBQUssY0FBYyxLQUFLLEdBQUc7R0FDL0IsTUFBTSxZQUFZLEtBQUssZUFBZSxHQUFHLEdBQUc7R0FDNUMsTUFBTSxNQUFNLFVBQVU7R0FDdEIsVUFBVTtHQUNWLElBQUksYUFBYSxVQUFVO0dBQzNCLElBQUksS0FBSyxRQUFRLFlBQVksYUFBYSxXQUFXLE9BQU8sS0FBSyxRQUFRLFVBQVU7R0FDbkYsTUFBTSxzQkFBc0IsSUFBSSxVQUFVLEtBQUEsS0FBYSxDQUFDLFNBQVMsSUFBSSxLQUFLO0dBQzFFLE1BQU0sd0JBQXdCLHVCQUF1QixDQUFDLElBQUksV0FBVyxJQUFJLFVBQVU7R0FDbkYsTUFBTSx1QkFBdUIsSUFBSSxZQUFZLEtBQUEsTUFBYyxTQUFTLElBQUksT0FBTyxLQUFLLE9BQU8sSUFBSSxZQUFZLGFBQWEsSUFBSSxZQUFZO0dBQ3hJLE1BQU0sUUFBUSxJQUFJLE9BQU8sSUFBSSxPQUFPLEtBQUssY0FBYyxtQkFBbUIsSUFBSSxPQUFPLEtBQUssVUFBVSxJQUFJLFdBQVc7R0FDbkgsV0FBVyxTQUFRLE9BQU07SUFDdkIsSUFBSSxLQUFLLGNBQWMsS0FBSyxHQUFHO0lBQy9CLFNBQVM7SUFDVCxJQUFJLENBQUMsS0FBSyxpQkFBaUIsR0FBRyxNQUFNLEdBQUcsR0FBRyxTQUFTLEtBQUssT0FBTyxzQkFBc0IsQ0FBQyxLQUFLLE9BQU8sbUJBQW1CLE1BQU0sR0FBRztLQUM1SCxLQUFLLGlCQUFpQixHQUFHLE1BQU0sR0FBRyxHQUFHLFFBQVE7S0FDN0MsS0FBSyxPQUFPLEtBQUssUUFBUSxRQUFRLG1CQUFtQixNQUFNLEtBQUssSUFBSSxFQUFFLHFDQUFxQyxPQUFPLHVCQUF1QiwwTkFBME47SUFDcFc7SUFDQSxNQUFNLFNBQVEsU0FBUTtLQUNwQixJQUFJLEtBQUssY0FBYyxLQUFLLEdBQUc7S0FDL0IsVUFBVTtLQUNWLE1BQU0sWUFBWSxDQUFDLEdBQUc7S0FDdEIsSUFBSSxLQUFLLFlBQVksZUFDbkIsS0FBSyxXQUFXLGNBQWMsV0FBVyxLQUFLLE1BQU0sSUFBSSxHQUFHO1VBQ3REO01BQ0wsSUFBSTtNQUNKLElBQUkscUJBQXFCLGVBQWUsS0FBSyxlQUFlLFVBQVUsTUFBTSxJQUFJLE9BQU8sR0FBRztNQUMxRixNQUFNLGFBQWEsR0FBRyxLQUFLLFFBQVEsZ0JBQWdCO01BQ25ELE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxRQUFRLGdCQUFnQixTQUFTLEtBQUssUUFBUTtNQUM1RSxJQUFJLHFCQUFxQjtPQUN2QixJQUFJLElBQUksV0FBVyxhQUFhLFdBQVcsYUFBYSxHQUN0RCxVQUFVLEtBQUssTUFBTSxhQUFhLFFBQVEsZUFBZSxLQUFLLFFBQVEsZUFBZSxDQUFDO09BRXhGLFVBQVUsS0FBSyxNQUFNLFlBQVk7T0FDakMsSUFBSSx1QkFDRixVQUFVLEtBQUssTUFBTSxVQUFVO01BRW5DO01BQ0EsSUFBSSxzQkFBc0I7T0FDeEIsTUFBTSxhQUFhLEdBQUcsTUFBTSxLQUFLLFFBQVEsb0JBQW9CLE1BQU0sSUFBSTtPQUN2RSxVQUFVLEtBQUssVUFBVTtPQUN6QixJQUFJLHFCQUFxQjtRQUN2QixJQUFJLElBQUksV0FBVyxhQUFhLFdBQVcsYUFBYSxHQUN0RCxVQUFVLEtBQUssYUFBYSxhQUFhLFFBQVEsZUFBZSxLQUFLLFFBQVEsZUFBZSxDQUFDO1FBRS9GLFVBQVUsS0FBSyxhQUFhLFlBQVk7UUFDeEMsSUFBSSx1QkFDRixVQUFVLEtBQUssYUFBYSxVQUFVO09BRTFDO01BQ0Y7S0FDRjtLQUNBLElBQUk7S0FDSixPQUFPLGNBQWMsVUFBVSxJQUFJLEdBQ2pDLElBQUksQ0FBQyxLQUFLLGNBQWMsS0FBSyxHQUFHO01BQzlCLGVBQWU7TUFDZixRQUFRLEtBQUssWUFBWSxNQUFNLElBQUksYUFBYSxHQUFHO0tBQ3JEO0lBRUosQ0FBQztHQUNILENBQUM7RUFDSCxDQUFDO0VBQ0QsT0FBTztHQUNMLEtBQUs7R0FDTDtHQUNBO0dBQ0E7R0FDQTtFQUNGO0NBQ0Y7Q0FDQSxjQUFjLEtBQUs7RUFDakIsT0FBTyxRQUFRLEtBQUEsS0FBYSxFQUFFLENBQUMsS0FBSyxRQUFRLGNBQWMsUUFBUSxTQUFTLEVBQUUsQ0FBQyxLQUFLLFFBQVEscUJBQXFCLFFBQVE7Q0FDMUg7Q0FDQSxZQUFZLE1BQU0sSUFBSSxLQUFLLFVBQVUsQ0FBQyxHQUFHO0VBQ3ZDLElBQUksS0FBSyxZQUFZLGFBQWEsT0FBTyxLQUFLLFdBQVcsWUFBWSxNQUFNLElBQUksS0FBSyxPQUFPO0VBQzNGLE9BQU8sS0FBSyxjQUFjLFlBQVksTUFBTSxJQUFJLEtBQUssT0FBTztDQUM5RDtDQUNBLHFCQUFxQixVQUFVLENBQUMsR0FBRztFQUNqQyxNQUFNLGNBQWM7R0FBQztHQUFnQjtHQUFXO0dBQVc7R0FBVztHQUFPO0dBQVE7R0FBZTtHQUFNO0dBQWdCO0dBQWU7R0FBaUI7R0FBaUI7R0FBYztHQUFlO0VBQWU7RUFDdk4sTUFBTSwyQkFBMkIsUUFBUSxXQUFXLENBQUMsU0FBUyxRQUFRLE9BQU87RUFDN0UsSUFBSSxPQUFPLDJCQUEyQixRQUFRLFVBQVU7RUFDeEQsSUFBSSw0QkFBNEIsT0FBTyxRQUFRLFVBQVUsYUFDdkQsT0FBTztHQUNMLEdBQUc7R0FDSCxPQUFPLFFBQVE7RUFDakI7RUFFRixJQUFJLEtBQUssUUFBUSxjQUFjLGtCQUM3QixPQUFPO0dBQ0wsR0FBRyxLQUFLLFFBQVEsY0FBYztHQUM5QixHQUFHO0VBQ0w7RUFFRixJQUFJLENBQUMsMEJBQTBCO0dBQzdCLE9BQU8sRUFDTCxHQUFHLEtBQ0w7R0FDQSxLQUFLLE1BQU0sT0FBTyxhQUNoQixPQUFPLEtBQUs7RUFFaEI7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLGdCQUFnQixTQUFTO0VBQzlCLE1BQU0sU0FBUztFQUNmLEtBQUssTUFBTSxVQUFVLFNBQ25CLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxTQUFTLE1BQU0sS0FBSyxPQUFPLFdBQVcsTUFBTSxLQUFLLEtBQUEsTUFBYyxRQUFRLFNBQzlHLE9BQU87RUFHWCxPQUFPO0NBQ1Q7QUFDRjtBQUVBLElBQU0sZUFBTixNQUFtQjtDQUNqQixZQUFZLFNBQVM7RUFDbkIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxnQkFBZ0IsS0FBSyxRQUFRLGlCQUFpQjtFQUNuRCxLQUFLLFNBQVMsV0FBVyxPQUFPLGVBQWU7Q0FDakQ7Q0FDQSxzQkFBc0IsTUFBTTtFQUMxQixPQUFPLGVBQWUsSUFBSTtFQUMxQixJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssU0FBUyxHQUFHLEdBQUcsT0FBTztFQUN6QyxNQUFNLElBQUksS0FBSyxNQUFNLEdBQUc7RUFDeEIsSUFBSSxFQUFFLFdBQVcsR0FBRyxPQUFPO0VBQzNCLEVBQUUsSUFBSTtFQUNOLElBQUksRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDLFlBQVksTUFBTSxLQUFLLE9BQU87RUFDbEQsT0FBTyxLQUFLLG1CQUFtQixFQUFFLEtBQUssR0FBRyxDQUFDO0NBQzVDO0NBQ0Esd0JBQXdCLE1BQU07RUFDNUIsT0FBTyxlQUFlLElBQUk7RUFDMUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHLE9BQU87RUFDekMsTUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHO0VBQ3hCLE9BQU8sS0FBSyxtQkFBbUIsRUFBRSxFQUFFO0NBQ3JDO0NBQ0EsbUJBQW1CLE1BQU07RUFDdkIsSUFBSSxTQUFTLElBQUksS0FBSyxLQUFLLFNBQVMsR0FBRyxHQUFHO0dBQ3hDLElBQUk7R0FDSixJQUFJO0lBQ0YsZ0JBQWdCLEtBQUssb0JBQW9CLElBQUksQ0FBQyxDQUFDO0dBQ2pELFNBQVMsR0FBRyxDQUFDO0dBQ2IsSUFBSSxpQkFBaUIsS0FBSyxRQUFRLGNBQ2hDLGdCQUFnQixjQUFjLFlBQVk7R0FFNUMsSUFBSSxlQUFlLE9BQU87R0FDMUIsSUFBSSxLQUFLLFFBQVEsY0FDZixPQUFPLEtBQUssWUFBWTtHQUUxQixPQUFPO0VBQ1Q7RUFDQSxPQUFPLEtBQUssUUFBUSxhQUFhLEtBQUssUUFBUSxlQUFlLEtBQUssWUFBWSxJQUFJO0NBQ3BGO0NBQ0EsZ0JBQWdCLE1BQU07RUFDcEIsSUFBSSxLQUFLLFFBQVEsU0FBUyxrQkFBa0IsS0FBSyxRQUFRLDBCQUN2RCxPQUFPLEtBQUssd0JBQXdCLElBQUk7RUFFMUMsT0FBTyxDQUFDLEtBQUssaUJBQWlCLENBQUMsS0FBSyxjQUFjLFVBQVUsS0FBSyxjQUFjLFNBQVMsSUFBSTtDQUM5RjtDQUNBLHNCQUFzQixPQUFPO0VBQzNCLElBQUksQ0FBQyxPQUFPLE9BQU87RUFDbkIsSUFBSTtFQUNKLE1BQU0sU0FBUSxTQUFRO0dBQ3BCLElBQUksT0FBTztHQUNYLE1BQU0sYUFBYSxLQUFLLG1CQUFtQixJQUFJO0dBQy9DLElBQUksQ0FBQyxLQUFLLFFBQVEsaUJBQWlCLEtBQUssZ0JBQWdCLFVBQVUsR0FBRyxRQUFRO0VBQy9FLENBQUM7RUFDRCxJQUFJLENBQUMsU0FBUyxLQUFLLFFBQVEsZUFDekIsTUFBTSxTQUFRLFNBQVE7R0FDcEIsSUFBSSxPQUFPO0dBQ1gsTUFBTSxZQUFZLEtBQUssc0JBQXNCLElBQUk7R0FDakQsSUFBSSxLQUFLLGdCQUFnQixTQUFTLEdBQUcsT0FBTyxRQUFRO0dBQ3BELE1BQU0sVUFBVSxLQUFLLHdCQUF3QixJQUFJO0dBQ2pELElBQUksS0FBSyxnQkFBZ0IsT0FBTyxHQUFHLE9BQU8sUUFBUTtHQUNsRCxRQUFRLEtBQUssUUFBUSxjQUFjLE1BQUssaUJBQWdCO0lBQ3RELElBQUksaUJBQWlCLFNBQVMsT0FBTztJQUNyQyxJQUFJLENBQUMsYUFBYSxTQUFTLEdBQUcsS0FBSyxDQUFDLFFBQVEsU0FBUyxHQUFHLEdBQUcsT0FBTztJQUNsRSxJQUFJLGFBQWEsU0FBUyxHQUFHLEtBQUssQ0FBQyxRQUFRLFNBQVMsR0FBRyxLQUFLLGFBQWEsTUFBTSxHQUFHLGFBQWEsUUFBUSxHQUFHLENBQUMsTUFBTSxTQUFTLE9BQU87SUFDakksSUFBSSxhQUFhLFdBQVcsT0FBTyxLQUFLLFFBQVEsU0FBUyxHQUFHLE9BQU87SUFDbkUsT0FBTztHQUNULENBQUM7RUFDSCxDQUFDO0VBRUgsSUFBSSxDQUFDLE9BQU8sUUFBUSxLQUFLLGlCQUFpQixLQUFLLFFBQVEsV0FBVyxDQUFDLENBQUM7RUFDcEUsT0FBTztDQUNUO0NBQ0EsaUJBQWlCLFdBQVcsTUFBTTtFQUNoQyxJQUFJLENBQUMsV0FBVyxPQUFPLENBQUM7RUFDeEIsSUFBSSxPQUFPLGNBQWMsWUFBWSxZQUFZLFVBQVUsSUFBSTtFQUMvRCxJQUFJLFNBQVMsU0FBUyxHQUFHLFlBQVksQ0FBQyxTQUFTO0VBQy9DLElBQUksTUFBTSxRQUFRLFNBQVMsR0FBRyxPQUFPO0VBQ3JDLElBQUksQ0FBQyxNQUFNLE9BQU8sVUFBVSxXQUFXLENBQUM7RUFDeEMsSUFBSSxRQUFRLFVBQVU7RUFDdEIsSUFBSSxDQUFDLE9BQU8sUUFBUSxVQUFVLEtBQUssc0JBQXNCLElBQUk7RUFDN0QsSUFBSSxDQUFDLE9BQU8sUUFBUSxVQUFVLEtBQUssbUJBQW1CLElBQUk7RUFDMUQsSUFBSSxDQUFDLE9BQU8sUUFBUSxVQUFVLEtBQUssd0JBQXdCLElBQUk7RUFDL0QsSUFBSSxDQUFDLE9BQU8sUUFBUSxVQUFVO0VBQzlCLE9BQU8sU0FBUyxDQUFDO0NBQ25CO0NBQ0EsbUJBQW1CLE1BQU0sY0FBYztFQUNyQyxNQUFNLGdCQUFnQixLQUFLLGtCQUFrQixpQkFBaUIsUUFBUSxDQUFDLElBQUksaUJBQWlCLEtBQUssUUFBUSxlQUFlLENBQUMsR0FBRyxJQUFJO0VBQ2hJLE1BQU0sUUFBUSxDQUFDO0VBQ2YsTUFBTSxXQUFVLE1BQUs7R0FDbkIsSUFBSSxDQUFDLEdBQUc7R0FDUixJQUFJLEtBQUssZ0JBQWdCLENBQUMsR0FDeEIsTUFBTSxLQUFLLENBQUM7UUFFWixLQUFLLE9BQU8sS0FBSyx1REFBdUQsR0FBRztFQUUvRTtFQUNBLElBQUksU0FBUyxJQUFJLE1BQU0sS0FBSyxTQUFTLEdBQUcsS0FBSyxLQUFLLFNBQVMsR0FBRyxJQUFJO0dBQ2hFLElBQUksS0FBSyxRQUFRLFNBQVMsZ0JBQWdCLFFBQVEsS0FBSyxtQkFBbUIsSUFBSSxDQUFDO0dBQy9FLElBQUksS0FBSyxRQUFRLFNBQVMsa0JBQWtCLEtBQUssUUFBUSxTQUFTLGVBQWUsUUFBUSxLQUFLLHNCQUFzQixJQUFJLENBQUM7R0FDekgsSUFBSSxLQUFLLFFBQVEsU0FBUyxlQUFlLFFBQVEsS0FBSyx3QkFBd0IsSUFBSSxDQUFDO0VBQ3JGLE9BQU8sSUFBSSxTQUFTLElBQUksR0FDdEIsUUFBUSxLQUFLLG1CQUFtQixJQUFJLENBQUM7RUFFdkMsY0FBYyxTQUFRLE9BQU07R0FDMUIsSUFBSSxDQUFDLE1BQU0sU0FBUyxFQUFFLEdBQUcsUUFBUSxLQUFLLG1CQUFtQixFQUFFLENBQUM7RUFDOUQsQ0FBQztFQUNELE9BQU87Q0FDVDtBQUNGO0FBRUEsSUFBTSxnQkFBZ0I7Q0FDcEIsTUFBTTtDQUNOLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLE1BQU07Q0FDTixPQUFPO0FBQ1Q7QUFDQSxJQUFNLFlBQVk7Q0FDaEIsU0FBUSxVQUFTLFVBQVUsSUFBSSxRQUFRO0NBQ3ZDLHdCQUF3QixFQUN0QixrQkFBa0IsQ0FBQyxPQUFPLE9BQU8sRUFDbkM7QUFDRjtBQUNBLElBQU0saUJBQU4sTUFBcUI7Q0FDbkIsWUFBWSxlQUFlLFVBQVUsQ0FBQyxHQUFHO0VBQ3ZDLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssVUFBVTtFQUNmLEtBQUssU0FBUyxXQUFXLE9BQU8sZ0JBQWdCO0VBQ2hELEtBQUssbUJBQW1CLENBQUM7Q0FDM0I7Q0FDQSxhQUFhO0VBQ1gsS0FBSyxtQkFBbUIsQ0FBQztDQUMzQjtDQUNBLFFBQVEsTUFBTSxVQUFVLENBQUMsR0FBRztFQUMxQixNQUFNLGNBQWMsZUFBZSxTQUFTLFFBQVEsT0FBTyxJQUFJO0VBQy9ELE1BQU0sT0FBTyxRQUFRLFVBQVUsWUFBWTtFQUMzQyxNQUFNLFdBQVcsS0FBSyxVQUFVO0dBQzlCO0dBQ0E7RUFDRixDQUFDO0VBQ0QsSUFBSSxZQUFZLEtBQUssa0JBQ25CLE9BQU8sS0FBSyxpQkFBaUI7RUFFL0IsSUFBSTtFQUNKLElBQUk7R0FDRixPQUFPLElBQUksS0FBSyxZQUFZLGFBQWEsRUFDdkMsS0FDRixDQUFDO0VBQ0gsU0FBUyxLQUFLO0dBQ1osSUFBSSxPQUFPLFNBQVMsYUFBYTtJQUMvQixLQUFLLE9BQU8sTUFBTSwrQ0FBK0M7SUFDakUsT0FBTztHQUNUO0dBQ0EsSUFBSSxDQUFDLEtBQUssTUFBTSxLQUFLLEdBQUcsT0FBTztHQUMvQixNQUFNLFVBQVUsS0FBSyxjQUFjLHdCQUF3QixJQUFJO0dBQy9ELE9BQU8sS0FBSyxRQUFRLFNBQVMsT0FBTztFQUN0QztFQUNBLEtBQUssaUJBQWlCLFlBQVk7RUFDbEMsT0FBTztDQUNUO0NBQ0EsWUFBWSxNQUFNLFVBQVUsQ0FBQyxHQUFHO0VBQzlCLElBQUksT0FBTyxLQUFLLFFBQVEsTUFBTSxPQUFPO0VBQ3JDLElBQUksQ0FBQyxNQUFNLE9BQU8sS0FBSyxRQUFRLE9BQU8sT0FBTztFQUM3QyxPQUFPLE1BQU0sZ0JBQWdCLENBQUMsQ0FBQyxpQkFBaUIsU0FBUztDQUMzRDtDQUNBLG9CQUFvQixNQUFNLEtBQUssVUFBVSxDQUFDLEdBQUc7RUFDM0MsT0FBTyxLQUFLLFlBQVksTUFBTSxPQUFPLENBQUMsQ0FBQyxLQUFJLFdBQVUsR0FBRyxNQUFNLFFBQVE7Q0FDeEU7Q0FDQSxZQUFZLE1BQU0sVUFBVSxDQUFDLEdBQUc7RUFDOUIsSUFBSSxPQUFPLEtBQUssUUFBUSxNQUFNLE9BQU87RUFDckMsSUFBSSxDQUFDLE1BQU0sT0FBTyxLQUFLLFFBQVEsT0FBTyxPQUFPO0VBQzdDLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQztFQUNuQixPQUFPLEtBQUssZ0JBQWdCLENBQUMsQ0FBQyxpQkFBaUIsTUFBTSxpQkFBaUIsb0JBQW9CLGNBQWMsbUJBQW1CLGNBQWMsZ0JBQWdCLENBQUMsQ0FBQyxLQUFJLG1CQUFrQixHQUFHLEtBQUssUUFBUSxVQUFVLFFBQVEsVUFBVSxVQUFVLEtBQUssUUFBUSxZQUFZLEtBQUssZ0JBQWdCO0NBQ3ZSO0NBQ0EsVUFBVSxNQUFNLE9BQU8sVUFBVSxDQUFDLEdBQUc7RUFDbkMsTUFBTSxPQUFPLEtBQUssUUFBUSxNQUFNLE9BQU87RUFDdkMsSUFBSSxNQUNGLE9BQU8sR0FBRyxLQUFLLFFBQVEsVUFBVSxRQUFRLFVBQVUsVUFBVSxLQUFLLFFBQVEsWUFBWSxLQUFLLEtBQUssT0FBTyxLQUFLO0VBRTlHLEtBQUssT0FBTyxLQUFLLDZCQUE2QixNQUFNO0VBQ3BELE9BQU8sS0FBSyxVQUFVLE9BQU8sT0FBTyxPQUFPO0NBQzdDO0FBQ0Y7QUFFQSxJQUFNLHdCQUF3QixNQUFNLGFBQWEsS0FBSyxlQUFlLEtBQUssc0JBQXNCLFNBQVM7Q0FDdkcsSUFBSSxPQUFPLG9CQUFvQixNQUFNLGFBQWEsR0FBRztDQUNyRCxJQUFJLENBQUMsUUFBUSx1QkFBdUIsU0FBUyxHQUFHLEdBQUc7RUFDakQsT0FBTyxTQUFTLE1BQU0sS0FBSyxZQUFZO0VBQ3ZDLElBQUksU0FBUyxLQUFBLEdBQVcsT0FBTyxTQUFTLGFBQWEsS0FBSyxZQUFZO0NBQ3hFO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBTSxhQUFZLFFBQU8sSUFBSSxRQUFRLE9BQU8sTUFBTTtBQUNsRCxJQUFNLGVBQU4sTUFBbUI7Q0FDakIsWUFBWSxVQUFVLENBQUMsR0FBRztFQUN4QixLQUFLLFNBQVMsV0FBVyxPQUFPLGNBQWM7RUFDOUMsS0FBSyxVQUFVO0VBQ2YsS0FBSyxTQUFTLFNBQVMsZUFBZSxZQUFXLFVBQVM7RUFDMUQsS0FBSyxLQUFLLE9BQU87Q0FDbkI7Q0FDQSxLQUFLLFVBQVUsQ0FBQyxHQUFHO0VBQ2pCLElBQUksQ0FBQyxRQUFRLGVBQWUsUUFBUSxnQkFBZ0IsRUFDbEQsYUFBYSxLQUNmO0VBQ0EsTUFBTSxFQUNKLFFBQVEsVUFDUixhQUNBLHFCQUNBLFFBQ0EsZUFDQSxRQUNBLGVBQ0EsaUJBQ0EsZ0JBQ0EsZ0JBQ0EsZUFDQSxzQkFDQSxlQUNBLHNCQUNBLHlCQUNBLGFBQ0EsaUJBQ0UsUUFBUTtFQUNaLEtBQUssU0FBUyxhQUFhLEtBQUEsSUFBWSxXQUFXO0VBQ2xELEtBQUssY0FBYyxnQkFBZ0IsS0FBQSxJQUFZLGNBQWM7RUFDN0QsS0FBSyxzQkFBc0Isd0JBQXdCLEtBQUEsSUFBWSxzQkFBc0I7RUFDckYsS0FBSyxTQUFTLFNBQVMsWUFBWSxNQUFNLElBQUksaUJBQWlCO0VBQzlELEtBQUssU0FBUyxTQUFTLFlBQVksTUFBTSxJQUFJLGlCQUFpQjtFQUM5RCxLQUFLLGtCQUFrQixtQkFBbUI7RUFDMUMsS0FBSyxpQkFBaUIsaUJBQWlCLEtBQUssaUJBQWlCLFlBQVksY0FBYyxJQUFJO0VBQzNGLEtBQUssaUJBQWlCLEtBQUssaUJBQWlCLEtBQUssaUJBQWlCLFlBQVksY0FBYyxJQUFJO0VBQ2hHLEtBQUssZ0JBQWdCLGdCQUFnQixZQUFZLGFBQWEsSUFBSSx3QkFBd0IsWUFBWSxLQUFLO0VBQzNHLEtBQUssZ0JBQWdCLGdCQUFnQixZQUFZLGFBQWEsSUFBSSx3QkFBd0IsWUFBWSxHQUFHO0VBQ3pHLEtBQUssMEJBQTBCLDJCQUEyQjtFQUMxRCxLQUFLLGNBQWMsZUFBZTtFQUNsQyxLQUFLLGVBQWUsaUJBQWlCLEtBQUEsSUFBWSxlQUFlO0VBQ2hFLEtBQUssWUFBWTtDQUNuQjtDQUNBLFFBQVE7RUFDTixJQUFJLEtBQUssU0FBUyxLQUFLLEtBQUssS0FBSyxPQUFPO0NBQzFDO0NBQ0EsY0FBYztFQUNaLE1BQU0sb0JBQW9CLGdCQUFnQixZQUFZO0dBQ3BELElBQUksZ0JBQWdCLFdBQVcsU0FBUztJQUN0QyxlQUFlLFlBQVk7SUFDM0IsT0FBTztHQUNUO0dBQ0EsT0FBTyxJQUFJLE9BQU8sU0FBUyxHQUFHO0VBQ2hDO0VBQ0EsS0FBSyxTQUFTLGlCQUFpQixLQUFLLFFBQVEsR0FBRyxLQUFLLE9BQU8sT0FBTyxLQUFLLFFBQVE7RUFDL0UsS0FBSyxpQkFBaUIsaUJBQWlCLEtBQUssZ0JBQWdCLEdBQUcsS0FBSyxTQUFTLEtBQUssZUFBZSxPQUFPLEtBQUssaUJBQWlCLEtBQUssUUFBUTtFQUMzSSxLQUFLLGdCQUFnQixpQkFBaUIsS0FBSyxlQUFlLEdBQUcsS0FBSyxjQUFjLG1FQUFtRSxLQUFLLGVBQWU7Q0FDeks7Q0FDQSxZQUFZLEtBQUssTUFBTSxLQUFLLFNBQVM7RUFDbkMsSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0osTUFBTSxjQUFjLEtBQUssV0FBVyxLQUFLLFFBQVEsaUJBQWlCLEtBQUssUUFBUSxjQUFjLG9CQUFvQixDQUFDO0VBQ2xILE1BQU0sZ0JBQWUsUUFBTztHQUMxQixJQUFJLENBQUMsSUFBSSxTQUFTLEtBQUssZUFBZSxHQUFHO0lBQ3ZDLE1BQU0sT0FBTyxxQkFBcUIsTUFBTSxhQUFhLEtBQUssS0FBSyxRQUFRLGNBQWMsS0FBSyxRQUFRLG1CQUFtQjtJQUNySCxPQUFPLEtBQUssZUFBZSxLQUFLLE9BQU8sTUFBTSxLQUFBLEdBQVcsS0FBSztLQUMzRCxHQUFHO0tBQ0gsR0FBRztLQUNILGtCQUFrQjtJQUNwQixDQUFDLElBQUk7R0FDUDtHQUNBLE1BQU0sSUFBSSxJQUFJLE1BQU0sS0FBSyxlQUFlO0dBQ3hDLE1BQU0sSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDLEtBQUs7R0FDekIsTUFBTSxJQUFJLEVBQUUsS0FBSyxLQUFLLGVBQWUsQ0FBQyxDQUFDLEtBQUs7R0FDNUMsT0FBTyxLQUFLLE9BQU8scUJBQXFCLE1BQU0sYUFBYSxHQUFHLEtBQUssUUFBUSxjQUFjLEtBQUssUUFBUSxtQkFBbUIsR0FBRyxHQUFHLEtBQUs7SUFDbEksR0FBRztJQUNILEdBQUc7SUFDSCxrQkFBa0I7R0FDcEIsQ0FBQztFQUNIO0VBQ0EsS0FBSyxZQUFZO0VBQ2pCLElBQUksQ0FBQyxLQUFLLGVBQWUsT0FBTyxRQUFRLFlBQVksd0JBQXdCLEtBQUssR0FBRyxHQUNsRixLQUFLLE9BQU8sS0FBSyxrUkFBaVM7RUFFcFQsTUFBTSw4QkFBOEIsU0FBUywrQkFBK0IsS0FBSyxRQUFRO0VBQ3pGLE1BQU0sa0JBQWtCLFNBQVMsZUFBZSxvQkFBb0IsS0FBQSxJQUFZLFFBQVEsY0FBYyxrQkFBa0IsS0FBSyxRQUFRLGNBQWM7RUFRbkosQ0FQZTtHQUNiLE9BQU8sS0FBSztHQUNaLFlBQVcsUUFBTztFQUNwQixHQUFHO0dBQ0QsT0FBTyxLQUFLO0dBQ1osWUFBVyxRQUFPLEtBQUssY0FBYyxLQUFLLE9BQU8sR0FBRyxJQUFJO0VBQzFELENBQ0ksQ0FBQyxDQUFDLFNBQVEsU0FBUTtHQUNwQixXQUFXO0dBQ1gsT0FBTyxRQUFRLEtBQUssTUFBTSxLQUFLLEdBQUcsR0FBRztJQUNuQyxNQUFNLGFBQWEsTUFBTSxFQUFFLENBQUMsS0FBSztJQUNqQyxRQUFRLGFBQWEsVUFBVTtJQUMvQixJQUFJLFVBQVUsS0FBQSxHQUNaLElBQUksT0FBTyxnQ0FBZ0MsWUFBWTtLQUNyRCxNQUFNLE9BQU8sNEJBQTRCLEtBQUssT0FBTyxPQUFPO0tBQzVELFFBQVEsU0FBUyxJQUFJLElBQUksT0FBTztJQUNsQyxPQUFPLElBQUksV0FBVyxPQUFPLFVBQVUsZUFBZSxLQUFLLFNBQVMsVUFBVSxHQUM1RSxRQUFRO1NBQ0gsSUFBSSxpQkFBaUI7S0FDMUIsUUFBUSxNQUFNO0tBQ2Q7SUFDRixPQUFPO0tBQ0wsS0FBSyxPQUFPLEtBQUssOEJBQThCLFdBQVcscUJBQXFCLEtBQUs7S0FDcEYsUUFBUTtJQUNWO1NBQ0ssSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUMsS0FBSyxxQkFDbkMsUUFBUSxXQUFXLEtBQUs7SUFFMUIsTUFBTSxZQUFZLEtBQUssVUFBVSxLQUFLO0lBQ3RDLE1BQU0sSUFBSSxRQUFRLE1BQU0sSUFBSSxVQUFVLFNBQVMsQ0FBQztJQUNoRCxJQUFJLGlCQUFpQjtLQUNuQixLQUFLLE1BQU0sYUFBYSxVQUFVO0tBQ2xDLEtBQUssTUFBTSxhQUFhLE1BQU0sRUFBRSxDQUFDO0lBQ25DLE9BQ0UsS0FBSyxNQUFNLFlBQVk7SUFFekI7SUFDQSxJQUFJLFlBQVksS0FBSyxhQUNuQjtHQUVKO0VBQ0YsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLEtBQUssS0FBSyxJQUFJLFVBQVUsQ0FBQyxHQUFHO0VBQzFCLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0sb0JBQW9CLEtBQUsscUJBQXFCO0dBQ2xELE1BQU0sTUFBTSxLQUFLO0dBQ2pCLElBQUksQ0FBQyxJQUFJLFNBQVMsR0FBRyxHQUFHLE9BQU87R0FDL0IsTUFBTSxJQUFJLElBQUksTUFBTSxJQUFJLE9BQU8sR0FBRyxZQUFZLEdBQUcsRUFBRSxNQUFNLENBQUM7R0FDMUQsSUFBSSxnQkFBZ0IsSUFBSSxFQUFFO0dBQzFCLE1BQU0sRUFBRTtHQUNSLGdCQUFnQixLQUFLLFlBQVksZUFBZSxhQUFhO0dBQzdELE1BQU0sc0JBQXNCLGNBQWMsTUFBTSxJQUFJO0dBQ3BELE1BQU0sc0JBQXNCLGNBQWMsTUFBTSxJQUFJO0dBQ3BELEtBQUsscUJBQXFCLFVBQVUsS0FBSyxNQUFNLEtBQUssQ0FBQyx3QkFBd0IscUJBQXFCLFVBQVUsS0FBSyxNQUFNLEdBQ3JILGdCQUFnQixjQUFjLFFBQVEsTUFBTSxJQUFHO0dBRWpELElBQUk7SUFDRixnQkFBZ0IsS0FBSyxNQUFNLGFBQWE7SUFDeEMsSUFBSSxrQkFBa0IsZ0JBQWdCO0tBQ3BDLEdBQUc7S0FDSCxHQUFHO0lBQ0w7R0FDRixTQUFTLEdBQUc7SUFDVixLQUFLLE9BQU8sS0FBSyxvREFBb0QsT0FBTyxDQUFDO0lBQzdFLE9BQU8sR0FBRyxNQUFNLE1BQU07R0FDeEI7R0FDQSxJQUFJLGNBQWMsZ0JBQWdCLGNBQWMsYUFBYSxTQUFTLEtBQUssTUFBTSxHQUFHLE9BQU8sY0FBYztHQUN6RyxPQUFPO0VBQ1Q7RUFDQSxPQUFPLFFBQVEsS0FBSyxjQUFjLEtBQUssR0FBRyxHQUFHO0dBQzNDLElBQUksYUFBYSxDQUFDO0dBQ2xCLGdCQUFnQixFQUNkLEdBQUcsUUFDTDtHQUNBLGdCQUFnQixjQUFjLFdBQVcsQ0FBQyxTQUFTLGNBQWMsT0FBTyxJQUFJLGNBQWMsVUFBVTtHQUNwRyxjQUFjLHFCQUFxQjtHQUNuQyxPQUFPLGNBQWM7R0FDckIsTUFBTSxjQUFjLFFBQVEsS0FBSyxNQUFNLEVBQUUsSUFBSSxNQUFNLEVBQUUsQ0FBQyxZQUFZLEdBQUcsSUFBSSxJQUFJLE1BQU0sRUFBRSxDQUFDLFFBQVEsS0FBSyxlQUFlO0dBQ2xILElBQUksZ0JBQWdCLElBQUk7SUFDdEIsYUFBYSxNQUFNLEVBQUUsQ0FBQyxNQUFNLFdBQVcsQ0FBQyxDQUFDLE1BQU0sS0FBSyxlQUFlLENBQUMsQ0FBQyxLQUFJLFNBQVEsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTztJQUM1RyxNQUFNLEtBQUssTUFBTSxFQUFFLENBQUMsTUFBTSxHQUFHLFdBQVc7R0FDMUM7R0FDQSxRQUFRLEdBQUcsaUJBQWlCLEtBQUssTUFBTSxNQUFNLEVBQUUsQ0FBQyxLQUFLLEdBQUcsYUFBYSxHQUFHLGFBQWE7R0FDckYsSUFBSSxTQUFTLE1BQU0sT0FBTyxPQUFPLENBQUMsU0FBUyxLQUFLLEdBQUcsT0FBTztHQUMxRCxJQUFJLENBQUMsU0FBUyxLQUFLLEdBQUcsUUFBUSxXQUFXLEtBQUs7R0FDOUMsSUFBSSxDQUFDLE9BQU87SUFDVixLQUFLLE9BQU8sS0FBSyxxQkFBcUIsTUFBTSxHQUFHLGVBQWUsS0FBSztJQUNuRSxRQUFRO0dBQ1Y7R0FDQSxJQUFJLFdBQVcsUUFDYixRQUFRLFdBQVcsUUFBUSxHQUFHLE1BQU0sS0FBSyxPQUFPLEdBQUcsR0FBRyxRQUFRLEtBQUs7SUFDakUsR0FBRztJQUNILGtCQUFrQixNQUFNLEVBQUUsQ0FBQyxLQUFLO0dBQ2xDLENBQUMsR0FBRyxNQUFNLEtBQUssQ0FBQztHQUVsQixNQUFNLElBQUksUUFBUSxNQUFNLElBQUksS0FBSztHQUNqQyxLQUFLLE9BQU8sWUFBWTtFQUMxQjtFQUNBLE9BQU87Q0FDVDtBQUNGO0FBRUEsSUFBTSxrQkFBaUIsY0FBYTtDQUNsQyxJQUFJLGFBQWEsVUFBVSxZQUFZLENBQUMsQ0FBQyxLQUFLO0NBQzlDLE1BQU0sZ0JBQWdCLENBQUM7Q0FDdkIsSUFBSSxVQUFVLFNBQVMsR0FBRyxHQUFHO0VBQzNCLE1BQU0sSUFBSSxVQUFVLE1BQU0sR0FBRztFQUM3QixhQUFhLEVBQUUsRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDLEtBQUs7RUFDckMsTUFBTSxTQUFTLEVBQUUsRUFBRSxDQUFDLE1BQU0sR0FBRyxFQUFFO0VBQy9CLElBQUksZUFBZSxjQUFjLENBQUMsT0FBTyxTQUFTLEdBQUcsR0FDL0M7T0FBQSxDQUFDLGNBQWMsVUFBVSxjQUFjLFdBQVcsT0FBTyxLQUFLO0VBQUEsT0FDN0QsSUFBSSxlQUFlLGtCQUFrQixDQUFDLE9BQU8sU0FBUyxHQUFHLEdBQzFEO09BQUEsQ0FBQyxjQUFjLE9BQU8sY0FBYyxRQUFRLE9BQU8sS0FBSztFQUFBLE9BRzVELE9BRG9CLE1BQU0sR0FDdkIsQ0FBQyxDQUFDLFNBQVEsUUFBTztHQUNsQixJQUFJLEtBQUs7SUFDUCxNQUFNLENBQUMsS0FBSyxHQUFHLFFBQVEsSUFBSSxNQUFNLEdBQUc7SUFDcEMsTUFBTSxNQUFNLEtBQUssS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLFlBQVksRUFBRTtJQUN4RCxNQUFNLGFBQWEsSUFBSSxLQUFLO0lBQzVCLElBQUksQ0FBQyxjQUFjLGFBQWEsY0FBYyxjQUFjO0lBQzVELElBQUksUUFBUSxTQUFTLGNBQWMsY0FBYztJQUNqRCxJQUFJLFFBQVEsUUFBUSxjQUFjLGNBQWM7SUFDaEQsSUFBSSxDQUFDLE1BQU0sR0FBRyxHQUFHLGNBQWMsY0FBYyxTQUFTLEtBQUssRUFBRTtHQUMvRDtFQUNGLENBQUM7Q0FFTDtDQUNBLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUNBLElBQU0seUJBQXdCLE9BQU07Q0FDbEMsTUFBTSxRQUFRLENBQUM7Q0FDZixRQUFRLEdBQUcsR0FBRyxNQUFNO0VBQ2xCLElBQUksY0FBYztFQUNsQixJQUFJLEtBQUssRUFBRSxvQkFBb0IsRUFBRSxnQkFBZ0IsRUFBRSxhQUFhLEVBQUUscUJBQXFCLEVBQUUsRUFBRSxtQkFDekYsY0FBYztHQUNaLEdBQUc7SUFDRixFQUFFLG1CQUFtQixLQUFBO0VBQ3hCO0VBRUYsTUFBTSxNQUFNLElBQUksS0FBSyxVQUFVLFdBQVc7RUFDMUMsSUFBSSxNQUFNLE1BQU07RUFDaEIsSUFBSSxDQUFDLEtBQUs7R0FDUixNQUFNLEdBQUcsZUFBZSxDQUFDLEdBQUcsQ0FBQztHQUM3QixNQUFNLE9BQU87RUFDZjtFQUNBLE9BQU8sSUFBSSxDQUFDO0NBQ2Q7QUFDRjtBQUNBLElBQU0sNEJBQTJCLFFBQU8sR0FBRyxHQUFHLE1BQU0sR0FBRyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlFLElBQU0sWUFBTixNQUFnQjtDQUNkLFlBQVksVUFBVSxDQUFDLEdBQUc7RUFDeEIsS0FBSyxTQUFTLFdBQVcsT0FBTyxXQUFXO0VBQzNDLEtBQUssVUFBVTtFQUNmLEtBQUssS0FBSyxPQUFPO0NBQ25CO0NBQ0EsS0FBSyxVQUFVLFVBQVUsRUFDdkIsZUFBZSxDQUFDLEVBQ2xCLEdBQUc7RUFDRCxLQUFLLGtCQUFrQixRQUFRLGNBQWMsbUJBQW1CO0VBQ2hFLE1BQU0sS0FBSyxRQUFRLHNCQUFzQix3QkFBd0I7RUFDakUsS0FBSyxVQUFVO0dBQ2IsUUFBUSxJQUFJLEtBQUssUUFBUTtJQUN2QixNQUFNLFlBQVksSUFBSSxLQUFLLGFBQWEsS0FBSyxFQUMzQyxHQUFHLElBQ0wsQ0FBQztJQUNELFFBQU8sUUFBTyxVQUFVLE9BQU8sR0FBRztHQUNwQyxDQUFDO0dBQ0QsVUFBVSxJQUFJLEtBQUssUUFBUTtJQUN6QixNQUFNLFlBQVksSUFBSSxLQUFLLGFBQWEsS0FBSztLQUMzQyxHQUFHO0tBQ0gsT0FBTztJQUNULENBQUM7SUFDRCxRQUFPLFFBQU8sVUFBVSxPQUFPLEdBQUc7R0FDcEMsQ0FBQztHQUNELFVBQVUsSUFBSSxLQUFLLFFBQVE7SUFDekIsTUFBTSxZQUFZLElBQUksS0FBSyxlQUFlLEtBQUssRUFDN0MsR0FBRyxJQUNMLENBQUM7SUFDRCxRQUFPLFFBQU8sVUFBVSxPQUFPLEdBQUc7R0FDcEMsQ0FBQztHQUNELGNBQWMsSUFBSSxLQUFLLFFBQVE7SUFDN0IsTUFBTSxZQUFZLElBQUksS0FBSyxtQkFBbUIsS0FBSyxFQUNqRCxHQUFHLElBQ0wsQ0FBQztJQUNELFFBQU8sUUFBTyxVQUFVLE9BQU8sS0FBSyxJQUFJLFNBQVMsS0FBSztHQUN4RCxDQUFDO0dBQ0QsTUFBTSxJQUFJLEtBQUssUUFBUTtJQUNyQixNQUFNLFlBQVksSUFBSSxLQUFLLFdBQVcsS0FBSyxFQUN6QyxHQUFHLElBQ0wsQ0FBQztJQUNELFFBQU8sUUFBTyxVQUFVLE9BQU8sR0FBRztHQUNwQyxDQUFDO0VBQ0g7Q0FDRjtDQUNBLElBQUksTUFBTSxJQUFJO0VBQ1osS0FBSyxRQUFRLEtBQUssWUFBWSxDQUFDLENBQUMsS0FBSyxLQUFLO0NBQzVDO0NBQ0EsVUFBVSxNQUFNLElBQUk7RUFDbEIsS0FBSyxRQUFRLEtBQUssWUFBWSxDQUFDLENBQUMsS0FBSyxLQUFLLHNCQUFzQixFQUFFO0NBQ3BFO0NBQ0EsT0FBTyxPQUFPLFFBQVEsS0FBSyxVQUFVLENBQUMsR0FBRztFQUN2QyxJQUFJLENBQUMsUUFBUSxPQUFPO0VBQ3BCLElBQUksU0FBUyxNQUFNLE9BQU87RUFDMUIsTUFBTSxhQUFhLE9BQU8sTUFBTSxLQUFLLGVBQWU7RUFDcEQsTUFBTSxVQUFVLENBQUM7RUFDakIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFdBQVcsUUFBUSxLQUFLO0dBQzFDLElBQUksSUFBSSxXQUFXO0dBQ25CLE9BQU8sRUFBRSxRQUFRLEdBQUcsSUFBSSxNQUFNLENBQUMsRUFBRSxTQUFTLEdBQUcsS0FBSyxJQUFJLElBQUksV0FBVyxRQUNuRSxJQUFJLEdBQUcsSUFBSSxLQUFLLGtCQUFrQixXQUFXLEVBQUU7R0FFakQsUUFBUSxLQUFLLENBQUM7RUFDaEI7RUF5QkEsT0F4QmUsUUFBUSxRQUFRLEtBQUssTUFBTTtHQUN4QyxNQUFNLEVBQ0osWUFDQSxrQkFDRSxlQUFlLENBQUM7R0FDcEIsSUFBSSxLQUFLLFFBQVEsYUFBYTtJQUM1QixJQUFJLFlBQVk7SUFDaEIsSUFBSTtLQUNGLE1BQU0sYUFBYSxTQUFTLGVBQWUsUUFBUSxxQkFBcUIsQ0FBQztLQUN6RSxNQUFNLElBQUksV0FBVyxVQUFVLFdBQVcsT0FBTyxRQUFRLFVBQVUsUUFBUSxPQUFPO0tBQ2xGLFlBQVksS0FBSyxRQUFRLFdBQVcsQ0FBQyxLQUFLLEdBQUc7TUFDM0MsR0FBRztNQUNILEdBQUc7TUFDSCxHQUFHO0tBQ0wsQ0FBQztJQUNILFNBQVMsT0FBTztLQUNkLEtBQUssT0FBTyxLQUFLLEtBQUs7SUFDeEI7SUFDQSxPQUFPO0dBQ1QsT0FDRSxLQUFLLE9BQU8sS0FBSyxvQ0FBb0MsWUFBWTtHQUVuRSxPQUFPO0VBQ1QsR0FBRyxLQUNTO0NBQ2Q7QUFDRjtBQUVBLElBQU0saUJBQWlCLEdBQUcsU0FBUztDQUNqQyxJQUFJLEVBQUUsUUFBUSxVQUFVLEtBQUEsR0FBVztFQUNqQyxPQUFPLEVBQUUsUUFBUTtFQUNqQixFQUFFO0NBQ0o7QUFDRjtBQUNBLElBQU0sWUFBTixjQUF3QixhQUFhO0NBQ25DLFlBQVksU0FBUyxPQUFPLFVBQVUsVUFBVSxDQUFDLEdBQUc7RUFDbEQsTUFBTTtFQUNOLEtBQUssVUFBVTtFQUNmLEtBQUssUUFBUTtFQUNiLEtBQUssV0FBVztFQUNoQixLQUFLLGdCQUFnQixTQUFTO0VBQzlCLEtBQUssVUFBVTtFQUNmLEtBQUssU0FBUyxXQUFXLE9BQU8sa0JBQWtCO0VBQ2xELEtBQUssZUFBZSxDQUFDO0VBQ3JCLEtBQUssbUJBQW1CLFFBQVEsb0JBQW9CO0VBQ3BELEtBQUssZUFBZTtFQUNwQixLQUFLLGFBQWEsUUFBUSxjQUFjLElBQUksUUFBUSxhQUFhO0VBQ2pFLEtBQUssZUFBZSxRQUFRLGdCQUFnQixJQUFJLFFBQVEsZUFBZTtFQUN2RSxLQUFLLFFBQVEsQ0FBQztFQUNkLEtBQUssUUFBUSxDQUFDO0VBQ2QsS0FBSyxTQUFTLE9BQU8sVUFBVSxRQUFRLFNBQVMsT0FBTztDQUN6RDtDQUNBLFVBQVUsV0FBVyxZQUFZLFNBQVMsVUFBVTtFQUNsRCxNQUFNLFNBQVMsQ0FBQztFQUNoQixNQUFNLFVBQVUsQ0FBQztFQUNqQixNQUFNLGtCQUFrQixDQUFDO0VBQ3pCLE1BQU0sbUJBQW1CLENBQUM7RUFDMUIsVUFBVSxTQUFRLFFBQU87R0FDdkIsSUFBSSxtQkFBbUI7R0FDdkIsV0FBVyxTQUFRLE9BQU07SUFDdkIsTUFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHO0lBQ3ZCLElBQUksQ0FBQyxRQUFRLFVBQVUsS0FBSyxNQUFNLGtCQUFrQixLQUFLLEVBQUUsR0FDekQsS0FBSyxNQUFNLFFBQVE7U0FDZCxJQUFJLEtBQUssTUFBTSxRQUFRO1NBQVUsSUFBSSxLQUFLLE1BQU0sVUFBVSxHQUMzRDtTQUFBLFFBQVEsVUFBVSxLQUFBLEdBQVcsUUFBUSxRQUFRO0lBQUEsT0FDNUM7S0FDTCxLQUFLLE1BQU0sUUFBUTtLQUNuQixtQkFBbUI7S0FDbkIsSUFBSSxRQUFRLFVBQVUsS0FBQSxHQUFXLFFBQVEsUUFBUTtLQUNqRCxJQUFJLE9BQU8sVUFBVSxLQUFBLEdBQVcsT0FBTyxRQUFRO0tBQy9DLElBQUksaUJBQWlCLFFBQVEsS0FBQSxHQUFXLGlCQUFpQixNQUFNO0lBQ2pFO0dBQ0YsQ0FBQztHQUNELElBQUksQ0FBQyxrQkFBa0IsZ0JBQWdCLE9BQU87RUFDaEQsQ0FBQztFQUNELElBQUksT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFVBQVUsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFFBQ3JELEtBQUssTUFBTSxLQUFLO0dBQ2Q7R0FDQSxjQUFjLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQztHQUNuQyxRQUFRLENBQUM7R0FDVCxRQUFRLENBQUM7R0FDVDtFQUNGLENBQUM7RUFFSCxPQUFPO0dBQ0wsUUFBUSxPQUFPLEtBQUssTUFBTTtHQUMxQixTQUFTLE9BQU8sS0FBSyxPQUFPO0dBQzVCLGlCQUFpQixPQUFPLEtBQUssZUFBZTtHQUM1QyxrQkFBa0IsT0FBTyxLQUFLLGdCQUFnQjtFQUNoRDtDQUNGO0NBQ0EsT0FBTyxNQUFNLEtBQUssTUFBTTtFQUN0QixNQUFNLElBQUksS0FBSyxNQUFNLEdBQUc7RUFDeEIsTUFBTSxNQUFNLEVBQUU7RUFDZCxNQUFNLEtBQUssRUFBRTtFQUNiLElBQUksS0FBSyxLQUFLLEtBQUssaUJBQWlCLEtBQUssSUFBSSxHQUFHO0VBQ2hELElBQUksQ0FBQyxPQUFPLE1BQ1YsS0FBSyxNQUFNLGtCQUFrQixLQUFLLElBQUksTUFBTSxLQUFBLEdBQVcsS0FBQSxHQUFXLEVBQ2hFLFVBQVUsS0FDWixDQUFDO0VBRUgsS0FBSyxNQUFNLFFBQVEsTUFBTSxLQUFLO0VBQzlCLElBQUksT0FBTyxNQUFNLEtBQUssTUFBTSxRQUFRO0VBQ3BDLE1BQU0sU0FBUyxDQUFDO0VBQ2hCLEtBQUssTUFBTSxTQUFRLE1BQUs7R0FDdEIsU0FBUyxFQUFFLFFBQVEsQ0FBQyxHQUFHLEdBQUcsRUFBRTtHQUM1QixjQUFjLEdBQUcsSUFBSTtHQUNyQixJQUFJLEtBQUssRUFBRSxPQUFPLEtBQUssR0FBRztHQUMxQixJQUFJLEVBQUUsaUJBQWlCLEtBQUssQ0FBQyxFQUFFLE1BQU07SUFDbkMsT0FBTyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUMsU0FBUSxNQUFLO0tBQ2pDLElBQUksQ0FBQyxPQUFPLElBQUksT0FBTyxLQUFLLENBQUM7S0FDN0IsTUFBTSxhQUFhLEVBQUUsT0FBTztLQUM1QixJQUFJLFdBQVcsUUFDYixXQUFXLFNBQVEsTUFBSztNQUN0QixJQUFJLE9BQU8sRUFBRSxDQUFDLE9BQU8sS0FBQSxHQUFXLE9BQU8sRUFBRSxDQUFDLEtBQUs7S0FDakQsQ0FBQztJQUVMLENBQUM7SUFDRCxFQUFFLE9BQU87SUFDVCxJQUFJLEVBQUUsT0FBTyxRQUNYLEVBQUUsU0FBUyxFQUFFLE1BQU07U0FFbkIsRUFBRSxTQUFTO0dBRWY7RUFDRixDQUFDO0VBQ0QsS0FBSyxLQUFLLFVBQVUsTUFBTTtFQUMxQixLQUFLLFFBQVEsS0FBSyxNQUFNLFFBQU8sTUFBSyxDQUFDLEVBQUUsSUFBSTtDQUM3QztDQUNBLEtBQUssS0FBSyxJQUFJLFFBQVEsUUFBUSxHQUFHLE9BQU8sS0FBSyxjQUFjLFVBQVU7RUFDbkUsSUFBSSxDQUFDLElBQUksUUFBUSxPQUFPLFNBQVMsTUFBTSxDQUFDLENBQUM7RUFDekMsSUFBSSxLQUFLLGdCQUFnQixLQUFLLGtCQUFrQjtHQUM5QyxLQUFLLGFBQWEsS0FBSztJQUNyQjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDRixDQUFDO0dBQ0Q7RUFDRjtFQUNBLEtBQUs7RUFDTCxNQUFNLFlBQVksS0FBSyxTQUFTO0dBQzlCLEtBQUs7R0FDTCxJQUFJLEtBQUssYUFBYSxTQUFTLEdBQUc7SUFDaEMsTUFBTSxPQUFPLEtBQUssYUFBYSxNQUFNO0lBQ3JDLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssUUFBUSxLQUFLLE9BQU8sS0FBSyxNQUFNLEtBQUssUUFBUTtHQUNoRjtHQUNBLElBQUksT0FBTyxRQUFRLFFBQVEsS0FBSyxZQUFZO0lBQzFDLGlCQUFpQjtLQUNmLEtBQUssS0FBSyxLQUFLLElBQUksUUFBUSxRQUFRLEdBQUcsT0FBTyxHQUFHLFFBQVE7SUFDMUQsR0FBRyxJQUFJO0lBQ1A7R0FDRjtHQUNBLFNBQVMsS0FBSyxJQUFJO0VBQ3BCO0VBQ0EsTUFBTSxLQUFLLEtBQUssUUFBUSxPQUFPLENBQUMsS0FBSyxLQUFLLE9BQU87RUFDakQsSUFBSSxHQUFHLFdBQVcsR0FBRztHQUNuQixJQUFJO0lBQ0YsTUFBTSxJQUFJLEdBQUcsS0FBSyxFQUFFO0lBQ3BCLElBQUksS0FBSyxPQUFPLEVBQUUsU0FBUyxZQUN6QixFQUFFLE1BQUssU0FBUSxTQUFTLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLFFBQVE7U0FFbkQsU0FBUyxNQUFNLENBQUM7R0FFcEIsU0FBUyxLQUFLO0lBQ1osU0FBUyxHQUFHO0dBQ2Q7R0FDQTtFQUNGO0VBQ0EsT0FBTyxHQUFHLEtBQUssSUFBSSxRQUFRO0NBQzdCO0NBQ0EsZUFBZSxXQUFXLFlBQVksVUFBVSxDQUFDLEdBQUcsVUFBVTtFQUM1RCxJQUFJLENBQUMsS0FBSyxTQUFTO0dBQ2pCLEtBQUssT0FBTyxLQUFLLGdFQUFnRTtHQUNqRixPQUFPLFlBQVksU0FBUztFQUM5QjtFQUNBLElBQUksU0FBUyxTQUFTLEdBQUcsWUFBWSxLQUFLLGNBQWMsbUJBQW1CLFNBQVM7RUFDcEYsSUFBSSxTQUFTLFVBQVUsR0FBRyxhQUFhLENBQUMsVUFBVTtFQUNsRCxNQUFNLFNBQVMsS0FBSyxVQUFVLFdBQVcsWUFBWSxTQUFTLFFBQVE7RUFDdEUsSUFBSSxDQUFDLE9BQU8sT0FBTyxRQUFRO0dBQ3pCLElBQUksQ0FBQyxPQUFPLFFBQVEsUUFBUSxTQUFTO0dBQ3JDLE9BQU87RUFDVDtFQUNBLE9BQU8sT0FBTyxTQUFRLFNBQVE7R0FDNUIsS0FBSyxRQUFRLElBQUk7RUFDbkIsQ0FBQztDQUNIO0NBQ0EsS0FBSyxXQUFXLFlBQVksVUFBVTtFQUNwQyxLQUFLLGVBQWUsV0FBVyxZQUFZLENBQUMsR0FBRyxRQUFRO0NBQ3pEO0NBQ0EsT0FBTyxXQUFXLFlBQVksVUFBVTtFQUN0QyxLQUFLLGVBQWUsV0FBVyxZQUFZLEVBQ3pDLFFBQVEsS0FDVixHQUFHLFFBQVE7Q0FDYjtDQUNBLFFBQVEsTUFBTSxTQUFTLElBQUk7RUFDekIsTUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHO0VBQ3hCLE1BQU0sTUFBTSxFQUFFO0VBQ2QsTUFBTSxLQUFLLEVBQUU7RUFDYixLQUFLLEtBQUssS0FBSyxJQUFJLFFBQVEsS0FBQSxHQUFXLEtBQUEsSUFBWSxLQUFLLFNBQVM7R0FDOUQsSUFBSSxLQUFLLEtBQUssT0FBTyxLQUFLLEdBQUcsT0FBTyxvQkFBb0IsR0FBRyxnQkFBZ0IsSUFBSSxVQUFVLEdBQUc7R0FDNUYsSUFBSSxDQUFDLE9BQU8sTUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFHLE9BQU8sbUJBQW1CLEdBQUcsZ0JBQWdCLE9BQU8sSUFBSTtHQUM3RixLQUFLLE9BQU8sTUFBTSxLQUFLLElBQUk7RUFDN0IsQ0FBQztDQUNIO0NBQ0EsWUFBWSxXQUFXLFdBQVcsS0FBSyxlQUFlLFVBQVUsVUFBVSxDQUFDLEdBQUcsWUFBWSxDQUFDLEdBQUc7RUFDNUYsSUFBSSxLQUFLLFVBQVUsT0FBTyxzQkFBc0IsQ0FBQyxLQUFLLFVBQVUsT0FBTyxtQkFBbUIsU0FBUyxHQUFHO0dBQ3BHLEtBQUssT0FBTyxLQUFLLHFCQUFxQixJQUFJLHNCQUFzQixVQUFVLHVCQUF1QiwwTkFBME47R0FDM1Q7RUFDRjtFQUNBLElBQUksUUFBUSxLQUFBLEtBQWEsUUFBUSxRQUFRLFFBQVEsSUFBSTtFQUNyRCxJQUFJLEtBQUssU0FBUyxRQUFRO0dBQ3hCLE1BQU0sT0FBTztJQUNYLEdBQUc7SUFDSDtHQUNGO0dBQ0EsTUFBTSxLQUFLLEtBQUssUUFBUSxPQUFPLEtBQUssS0FBSyxPQUFPO0dBQ2hELElBQUksR0FBRyxTQUFTLEdBQ2QsSUFBSTtJQUNGLElBQUk7SUFDSixJQUFJLEdBQUcsV0FBVyxHQUNoQixJQUFJLEdBQUcsV0FBVyxXQUFXLEtBQUssZUFBZSxJQUFJO1NBRXJELElBQUksR0FBRyxXQUFXLFdBQVcsS0FBSyxhQUFhO0lBRWpELElBQUksS0FBSyxPQUFPLEVBQUUsU0FBUyxZQUN6QixFQUFFLE1BQUssU0FBUSxJQUFJLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUc7U0FFekMsSUFBSSxNQUFNLENBQUM7R0FFZixTQUFTLEtBQUs7SUFDWixJQUFJLEdBQUc7R0FDVDtRQUVBLEdBQUcsV0FBVyxXQUFXLEtBQUssZUFBZSxLQUFLLElBQUk7RUFFMUQ7RUFDQSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsSUFBSTtFQUNqQyxLQUFLLE1BQU0sWUFBWSxVQUFVLElBQUksV0FBVyxLQUFLLGFBQWE7Q0FDcEU7QUFDRjtBQUVBLElBQU0sYUFBYTtDQUNqQixPQUFPO0NBQ1AsV0FBVztDQUNYLElBQUksQ0FBQyxhQUFhO0NBQ2xCLFdBQVcsQ0FBQyxhQUFhO0NBQ3pCLGFBQWEsQ0FBQyxLQUFLO0NBQ25CLFlBQVk7Q0FDWixlQUFlO0NBQ2YsMEJBQTBCO0NBQzFCLE1BQU07Q0FDTixTQUFTO0NBQ1QsY0FBYztDQUNkLGFBQWE7Q0FDYixpQkFBaUI7Q0FDakIsa0JBQWtCO0NBQ2xCLGdCQUFnQjtDQUNoQix5QkFBeUI7Q0FDekIsYUFBYTtDQUNiLGVBQWU7Q0FDZixlQUFlO0NBQ2Ysb0JBQW9CO0NBQ3BCLG1CQUFtQjtDQUNuQiw2QkFBNkI7Q0FDN0IsYUFBYTtDQUNiLHlCQUF5QjtDQUN6QixZQUFZO0NBQ1osbUJBQW1CO0NBQ25CLGVBQWU7Q0FDZixZQUFZO0NBQ1osdUJBQXVCO0NBQ3ZCLHdCQUF3QjtDQUN4Qiw2QkFBNkI7Q0FDN0IseUJBQXlCO0NBQ3pCLG1DQUFrQyxTQUFRO0VBQ3hDLElBQUksTUFBTSxDQUFDO0VBQ1gsSUFBSSxPQUFPLEtBQUssT0FBTyxVQUFVLE1BQU0sS0FBSztFQUM1QyxJQUFJLFNBQVMsS0FBSyxFQUFFLEdBQUcsSUFBSSxlQUFlLEtBQUs7RUFDL0MsSUFBSSxTQUFTLEtBQUssRUFBRSxHQUFHLElBQUksZUFBZSxLQUFLO0VBQy9DLElBQUksT0FBTyxLQUFLLE9BQU8sWUFBWSxPQUFPLEtBQUssT0FBTyxVQUFVO0dBQzlELE1BQU0sVUFBVSxLQUFLLE1BQU0sS0FBSztHQUNoQyxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUSxRQUFPO0lBQ2xDLElBQUksT0FBTyxRQUFRO0dBQ3JCLENBQUM7RUFDSDtFQUNBLE9BQU87Q0FDVDtDQUNBLGVBQWU7RUFDYixhQUFhO0VBQ2IsUUFBUTtFQUNSLFFBQVE7RUFDUixpQkFBaUI7RUFDakIsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixlQUFlO0VBQ2YseUJBQXlCO0VBQ3pCLGFBQWE7RUFDYixpQkFBaUI7Q0FDbkI7Q0FDQSxxQkFBcUI7QUFDdkI7QUFDQSxJQUFNLG9CQUFtQixZQUFXO0NBQ2xDLElBQUksU0FBUyxRQUFRLEVBQUUsR0FBRyxRQUFRLEtBQUssQ0FBQyxRQUFRLEVBQUU7Q0FDbEQsSUFBSSxTQUFTLFFBQVEsV0FBVyxHQUFHLFFBQVEsY0FBYyxDQUFDLFFBQVEsV0FBVztDQUM3RSxJQUFJLFNBQVMsUUFBUSxVQUFVLEdBQUcsUUFBUSxhQUFhLENBQUMsUUFBUSxVQUFVO0NBQzFFLElBQUksUUFBUSxpQkFBaUIsQ0FBQyxRQUFRLGNBQWMsU0FBUyxRQUFRLEdBQ25FLFFBQVEsZ0JBQWdCLFFBQVEsY0FBYyxPQUFPLENBQUMsUUFBUSxDQUFDO0NBRWpFLE9BQU87QUFDVDtBQUVBLElBQU0sYUFBYSxDQUFDO0FBQ3BCLElBQU0sdUJBQXNCLFNBQVE7Q0FFbEMsT0FEb0Isb0JBQW9CLE9BQU8sZUFBZSxJQUFJLENBQy9ELENBQUMsQ0FBQyxTQUFRLFFBQU87RUFDbEIsSUFBSSxPQUFPLEtBQUssU0FBUyxZQUN2QixLQUFLLE9BQU8sS0FBSyxJQUFJLENBQUMsS0FBSyxJQUFJO0NBRW5DLENBQUM7QUFDSDtBQW1mQSxJQUFNLFdBQVcsTUFsZlgsYUFBYSxhQUFhO0NBQzlCLFlBQVksVUFBVSxDQUFDLEdBQUcsVUFBVTtFQUNsQyxNQUFNO0VBQ04sS0FBSyxVQUFVLGlCQUFpQixPQUFPO0VBQ3ZDLEtBQUssV0FBVyxDQUFDO0VBQ2pCLEtBQUssU0FBUztFQUNkLEtBQUssVUFBVSxFQUNiLFVBQVUsQ0FBQyxFQUNiO0VBQ0Esb0JBQW9CLElBQUk7RUFDeEIsSUFBSSxZQUFZLENBQUMsS0FBSyxpQkFBaUIsQ0FBQyxRQUFRLFNBQVM7R0FDdkQsSUFBSSxDQUFDLEtBQUssUUFBUSxXQUFXO0lBQzNCLEtBQUssS0FBSyxTQUFTLFFBQVE7SUFDM0IsT0FBTztHQUNUO0dBQ0EsaUJBQWlCO0lBQ2YsS0FBSyxLQUFLLFNBQVMsUUFBUTtHQUM3QixHQUFHLENBQUM7RUFDTjtDQUNGO0NBQ0EsS0FBSyxVQUFVLENBQUMsR0FBRyxVQUFVO0VBQzNCLEtBQUssaUJBQWlCO0VBQ3RCLElBQUksT0FBTyxZQUFZLFlBQVk7R0FDakMsV0FBVztHQUNYLFVBQVUsQ0FBQztFQUNiO0VBQ0EsSUFBSSxRQUFRLGFBQWEsUUFBUSxRQUFRLElBQ25DO09BQUEsU0FBUyxRQUFRLEVBQUUsR0FDckIsUUFBUSxZQUFZLFFBQVE7UUFDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLGFBQWEsR0FDM0MsUUFBUSxZQUFZLFFBQVEsR0FBRztFQUFBO0VBR25DLE1BQU0sVUFBVSxJQUFJO0VBQ3BCLEtBQUssVUFBVTtHQUNiLEdBQUc7R0FDSCxHQUFHLEtBQUs7R0FDUixHQUFHLGlCQUFpQixPQUFPO0VBQzdCO0VBQ0EsS0FBSyxRQUFRLGdCQUFnQjtHQUMzQixHQUFHLFFBQVE7R0FDWCxHQUFHLEtBQUssUUFBUTtFQUNsQjtFQUNBLElBQUksUUFBUSxpQkFBaUIsS0FBQSxHQUMzQixLQUFLLFFBQVEsMEJBQTBCLFFBQVE7RUFFakQsSUFBSSxRQUFRLGdCQUFnQixLQUFBLEdBQzFCLEtBQUssUUFBUSx5QkFBeUIsUUFBUTtFQUVoRCxJQUFJLE9BQU8sS0FBSyxRQUFRLHFDQUFxQyxZQUMzRCxLQUFLLFFBQVEsbUNBQW1DLFFBQVE7RUFFMUQsTUFBTSx1QkFBc0Isa0JBQWlCO0dBQzNDLElBQUksQ0FBQyxlQUFlLE9BQU87R0FDM0IsSUFBSSxPQUFPLGtCQUFrQixZQUFZLE9BQU8sSUFBSSxjQUFjO0dBQ2xFLE9BQU87RUFDVDtFQUNBLElBQUksQ0FBQyxLQUFLLFFBQVEsU0FBUztHQUN6QixJQUFJLEtBQUssUUFBUSxRQUNmLFdBQVcsS0FBSyxvQkFBb0IsS0FBSyxRQUFRLE1BQU0sR0FBRyxLQUFLLE9BQU87UUFFdEUsV0FBVyxLQUFLLE1BQU0sS0FBSyxPQUFPO0dBRXBDLElBQUk7R0FDSixJQUFJLEtBQUssUUFBUSxXQUNmLFlBQVksS0FBSyxRQUFRO1FBRXpCLFlBQVk7R0FFZCxNQUFNLEtBQUssSUFBSSxhQUFhLEtBQUssT0FBTztHQUN4QyxLQUFLLFFBQVEsSUFBSSxjQUFjLEtBQUssUUFBUSxXQUFXLEtBQUssT0FBTztHQUNuRSxNQUFNLElBQUksS0FBSztHQUNmLEVBQUUsU0FBUztHQUNYLEVBQUUsZ0JBQWdCLEtBQUs7R0FDdkIsRUFBRSxnQkFBZ0I7R0FDbEIsRUFBRSxpQkFBaUIsSUFBSSxlQUFlLElBQUksRUFDeEMsU0FBUyxLQUFLLFFBQVEsZ0JBQ3hCLENBQUM7R0FDRCxJQUFJLFdBQVc7SUFDYixFQUFFLFlBQVksb0JBQW9CLFNBQVM7SUFDM0MsSUFBSSxFQUFFLFVBQVUsTUFBTSxFQUFFLFVBQVUsS0FBSyxHQUFHLEtBQUssT0FBTztJQUN0RCxLQUFLLFFBQVEsY0FBYyxTQUFTLEVBQUUsVUFBVSxPQUFPLEtBQUssRUFBRSxTQUFTO0dBQ3pFO0dBQ0EsRUFBRSxlQUFlLElBQUksYUFBYSxLQUFLLE9BQU87R0FDOUMsRUFBRSxRQUFRLEVBQ1Isb0JBQW9CLEtBQUssbUJBQW1CLEtBQUssSUFBSSxFQUN2RDtHQUNBLEVBQUUsbUJBQW1CLElBQUksVUFBVSxvQkFBb0IsS0FBSyxRQUFRLE9BQU8sR0FBRyxFQUFFLGVBQWUsR0FBRyxLQUFLLE9BQU87R0FDOUcsRUFBRSxpQkFBaUIsR0FBRyxNQUFNLE9BQU8sR0FBRyxTQUFTO0lBQzdDLEtBQUssS0FBSyxPQUFPLEdBQUcsSUFBSTtHQUMxQixDQUFDO0dBQ0QsSUFBSSxLQUFLLFFBQVEsa0JBQWtCO0lBQ2pDLEVBQUUsbUJBQW1CLG9CQUFvQixLQUFLLFFBQVEsZ0JBQWdCO0lBQ3RFLElBQUksRUFBRSxpQkFBaUIsTUFBTSxFQUFFLGlCQUFpQixLQUFLLEdBQUcsS0FBSyxRQUFRLFdBQVcsS0FBSyxPQUFPO0dBQzlGO0dBQ0EsSUFBSSxLQUFLLFFBQVEsWUFBWTtJQUMzQixFQUFFLGFBQWEsb0JBQW9CLEtBQUssUUFBUSxVQUFVO0lBQzFELElBQUksRUFBRSxXQUFXLE1BQU0sRUFBRSxXQUFXLEtBQUssSUFBSTtHQUMvQztHQUNBLEtBQUssYUFBYSxJQUFJLFdBQVcsS0FBSyxVQUFVLEtBQUssT0FBTztHQUM1RCxLQUFLLFdBQVcsR0FBRyxNQUFNLE9BQU8sR0FBRyxTQUFTO0lBQzFDLEtBQUssS0FBSyxPQUFPLEdBQUcsSUFBSTtHQUMxQixDQUFDO0dBQ0QsS0FBSyxRQUFRLFNBQVMsU0FBUSxNQUFLO0lBQ2pDLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxJQUFJO0dBQ3pCLENBQUM7RUFDSDtFQUNBLEtBQUssU0FBUyxLQUFLLFFBQVEsY0FBYztFQUN6QyxJQUFJLENBQUMsVUFBVSxXQUFXO0VBQzFCLElBQUksS0FBSyxRQUFRLGVBQWUsQ0FBQyxLQUFLLFNBQVMsb0JBQW9CLENBQUMsS0FBSyxRQUFRLEtBQUs7R0FDcEYsTUFBTSxRQUFRLEtBQUssU0FBUyxjQUFjLGlCQUFpQixLQUFLLFFBQVEsV0FBVztHQUNuRixJQUFJLE1BQU0sU0FBUyxLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssUUFBUSxNQUFNLE1BQU07RUFDdkU7RUFDQSxJQUFJLENBQUMsS0FBSyxTQUFTLG9CQUFvQixDQUFDLEtBQUssUUFBUSxLQUNuRCxLQUFLLE9BQU8sS0FBSyx5REFBeUQ7RUFHNUU7R0FEa0I7R0FBZTtHQUFxQjtHQUFxQjtFQUNwRSxDQUFDLENBQUMsU0FBUSxXQUFVO0dBQ3pCLEtBQUssV0FBVyxHQUFHLFNBQVMsS0FBSyxNQUFNLE9BQU8sQ0FBQyxHQUFHLElBQUk7RUFDeEQsQ0FBQztFQUVEO0dBRHlCO0dBQWU7R0FBZ0I7R0FBcUI7RUFDL0QsQ0FBQyxDQUFDLFNBQVEsV0FBVTtHQUNoQyxLQUFLLFdBQVcsR0FBRyxTQUFTO0lBQzFCLEtBQUssTUFBTSxPQUFPLENBQUMsR0FBRyxJQUFJO0lBQzFCLE9BQU87R0FDVDtFQUNGLENBQUM7RUFDRCxNQUFNLFdBQVcsTUFBTTtFQUN2QixNQUFNLGFBQWE7R0FDakIsTUFBTSxVQUFVLEtBQUssTUFBTTtJQUN6QixLQUFLLGlCQUFpQjtJQUN0QixJQUFJLEtBQUssaUJBQWlCLENBQUMsS0FBSyxzQkFBc0IsS0FBSyxPQUFPLEtBQUssdUVBQXVFO0lBQzlJLEtBQUssZ0JBQWdCO0lBQ3JCLElBQUksQ0FBQyxLQUFLLFFBQVEsU0FBUyxLQUFLLE9BQU8sSUFBSSxlQUFlLEtBQUssT0FBTztJQUN0RSxLQUFLLEtBQUssZUFBZSxLQUFLLE9BQU87SUFDckMsU0FBUyxRQUFRLENBQUM7SUFDbEIsU0FBUyxLQUFLLENBQUM7R0FDakI7R0FDQSxLQUFLLEtBQUssYUFBYSxLQUFLLHlCQUF5QixDQUFDLEtBQUssZUFBZSxPQUFPLE9BQU8sTUFBTSxLQUFLLEVBQUUsS0FBSyxJQUFJLENBQUM7R0FDL0csS0FBSyxlQUFlLEtBQUssUUFBUSxLQUFLLE1BQU07RUFDOUM7RUFDQSxJQUFJLEtBQUssUUFBUSxhQUFhLENBQUMsS0FBSyxRQUFRLFdBQzFDLEtBQUs7T0FFTCxXQUFXLE1BQU0sQ0FBQztFQUVwQixPQUFPO0NBQ1Q7Q0FDQSxjQUFjLFVBQVUsV0FBVyxNQUFNO0VBQ3ZDLElBQUksZUFBZTtFQUNuQixNQUFNLFVBQVUsU0FBUyxRQUFRLElBQUksV0FBVyxLQUFLO0VBQ3JELElBQUksT0FBTyxhQUFhLFlBQVksZUFBZTtFQUNuRCxJQUFJLENBQUMsS0FBSyxRQUFRLGFBQWEsS0FBSyxRQUFRLHlCQUF5QjtHQUNuRSxJQUFJLFNBQVMsWUFBWSxNQUFNLGFBQWEsQ0FBQyxLQUFLLFFBQVEsV0FBVyxLQUFLLFFBQVEsUUFBUSxXQUFXLElBQUksT0FBTyxhQUFhO0dBQzdILE1BQU0sU0FBUyxDQUFDO0dBQ2hCLE1BQU0sVUFBUyxRQUFPO0lBQ3BCLElBQUksQ0FBQyxLQUFLO0lBQ1YsSUFBSSxRQUFRLFVBQVU7SUFFdEIsS0FEa0IsU0FBUyxjQUFjLG1CQUFtQixHQUN6RCxDQUFDLENBQUMsU0FBUSxNQUFLO0tBQ2hCLElBQUksTUFBTSxVQUFVO0tBQ3BCLElBQUksQ0FBQyxPQUFPLFNBQVMsQ0FBQyxHQUFHLE9BQU8sS0FBSyxDQUFDO0lBQ3hDLENBQUM7R0FDSDtHQUNBLElBQUksQ0FBQyxTQUVILEtBRHVCLFNBQVMsY0FBYyxpQkFBaUIsS0FBSyxRQUFRLFdBQ3BFLENBQUMsQ0FBQyxTQUFRLE1BQUssT0FBTyxDQUFDLENBQUM7UUFFaEMsT0FBTyxPQUFPO0dBRWhCLEtBQUssUUFBUSxTQUFTLFdBQVUsTUFBSyxPQUFPLENBQUMsQ0FBQztHQUM5QyxLQUFLLFNBQVMsaUJBQWlCLEtBQUssUUFBUSxLQUFLLFFBQVEsS0FBSSxNQUFLO0lBQ2hFLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxvQkFBb0IsS0FBSyxVQUFVLEtBQUssb0JBQW9CLEtBQUssUUFBUTtJQUN6RixhQUFhLENBQUM7R0FDaEIsQ0FBQztFQUNILE9BQ0UsYUFBYSxJQUFJO0NBRXJCO0NBQ0EsZ0JBQWdCLE1BQU0sSUFBSSxVQUFVO0VBQ2xDLE1BQU0sV0FBVyxNQUFNO0VBQ3ZCLElBQUksT0FBTyxTQUFTLFlBQVk7R0FDOUIsV0FBVztHQUNYLE9BQU8sS0FBQTtFQUNUO0VBQ0EsSUFBSSxPQUFPLE9BQU8sWUFBWTtHQUM1QixXQUFXO0dBQ1gsS0FBSyxLQUFBO0VBQ1A7RUFDQSxJQUFJLENBQUMsTUFBTSxPQUFPLEtBQUs7RUFDdkIsSUFBSSxDQUFDLElBQUksS0FBSyxLQUFLLFFBQVE7RUFDM0IsSUFBSSxDQUFDLFVBQVUsV0FBVztFQUMxQixLQUFLLFNBQVMsaUJBQWlCLE9BQU8sTUFBTSxLQUFJLFFBQU87R0FDckQsU0FBUyxRQUFRO0dBQ2pCLFNBQVMsR0FBRztFQUNkLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLFFBQVE7RUFDVixJQUFJLENBQUMsUUFBUSxNQUFNLElBQUksTUFBTSwrRkFBK0Y7RUFDNUgsSUFBSSxDQUFDLE9BQU8sTUFBTSxNQUFNLElBQUksTUFBTSwwRkFBMEY7RUFDNUgsSUFBSSxPQUFPLFNBQVMsV0FDbEIsS0FBSyxRQUFRLFVBQVU7RUFFekIsSUFBSSxPQUFPLFNBQVMsWUFBWSxPQUFPLE9BQU8sT0FBTyxRQUFRLE9BQU8sT0FDbEUsS0FBSyxRQUFRLFNBQVM7RUFFeEIsSUFBSSxPQUFPLFNBQVMsb0JBQ2xCLEtBQUssUUFBUSxtQkFBbUI7RUFFbEMsSUFBSSxPQUFPLFNBQVMsY0FDbEIsS0FBSyxRQUFRLGFBQWE7RUFFNUIsSUFBSSxPQUFPLFNBQVMsaUJBQ2xCLGNBQWMsaUJBQWlCLE1BQU07RUFFdkMsSUFBSSxPQUFPLFNBQVMsYUFDbEIsS0FBSyxRQUFRLFlBQVk7RUFFM0IsSUFBSSxPQUFPLFNBQVMsWUFDbEIsS0FBSyxRQUFRLFNBQVMsS0FBSyxNQUFNO0VBRW5DLE9BQU87Q0FDVDtDQUNBLG9CQUFvQixHQUFHO0VBQ3JCLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxXQUFXO0VBQzNCLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHO0VBQ25DLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFLLFVBQVUsUUFBUSxNQUFNO0dBQ2pELE1BQU0sWUFBWSxLQUFLLFVBQVU7R0FDakMsSUFBSSxDQUFDLFVBQVUsS0FBSyxDQUFDLENBQUMsU0FBUyxTQUFTLEdBQUc7R0FDM0MsSUFBSSxLQUFLLE1BQU0sNEJBQTRCLFNBQVMsR0FBRztJQUNyRCxLQUFLLG1CQUFtQjtJQUN4QjtHQUNGO0VBQ0Y7RUFDQSxJQUFJLENBQUMsS0FBSyxvQkFBb0IsQ0FBQyxLQUFLLFVBQVUsU0FBUyxDQUFDLEtBQUssS0FBSyxNQUFNLDRCQUE0QixDQUFDLEdBQUc7R0FDdEcsS0FBSyxtQkFBbUI7R0FDeEIsS0FBSyxVQUFVLFFBQVEsQ0FBQztFQUMxQjtDQUNGO0NBQ0EsZUFBZSxLQUFLLFVBQVU7RUFDNUIsS0FBSyx1QkFBdUI7RUFDNUIsTUFBTSxXQUFXLE1BQU07RUFDdkIsS0FBSyxLQUFLLG9CQUFvQixHQUFHO0VBQ2pDLE1BQU0sZUFBYyxNQUFLO0dBQ3ZCLEtBQUssV0FBVztHQUNoQixLQUFLLFlBQVksS0FBSyxTQUFTLGNBQWMsbUJBQW1CLENBQUM7R0FDakUsS0FBSyxtQkFBbUIsS0FBQTtHQUN4QixLQUFLLG9CQUFvQixDQUFDO0VBQzVCO0VBQ0EsTUFBTSxRQUFRLEtBQUssTUFBTTtHQUN2QixJQUFJLEdBQ0U7UUFBQSxLQUFLLHlCQUF5QixLQUFLO0tBQ3JDLFlBQVksQ0FBQztLQUNiLEtBQUssV0FBVyxlQUFlLENBQUM7S0FDaEMsS0FBSyx1QkFBdUIsS0FBQTtLQUM1QixLQUFLLEtBQUssbUJBQW1CLENBQUM7S0FDOUIsS0FBSyxPQUFPLElBQUksbUJBQW1CLENBQUM7SUFDdEM7VUFFQSxLQUFLLHVCQUF1QixLQUFBO0dBRTlCLFNBQVMsU0FBUyxHQUFHLFNBQVMsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDO0dBQzdDLElBQUksVUFBVSxTQUFTLE1BQU0sR0FBRyxTQUFTLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQztFQUMxRDtFQUNBLE1BQU0sVUFBUyxTQUFRO0dBQ3JCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxLQUFLLFNBQVMsa0JBQWtCLE9BQU8sQ0FBQztHQUM3RCxNQUFNLEtBQUssU0FBUyxJQUFJLElBQUksT0FBTyxRQUFRLEtBQUs7R0FDaEQsTUFBTSxJQUFJLEtBQUssTUFBTSw0QkFBNEIsRUFBRSxJQUFJLEtBQUssS0FBSyxTQUFTLGNBQWMsc0JBQXNCLFNBQVMsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUk7R0FDNUksSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLEtBQUssVUFDUixZQUFZLENBQUM7SUFFZixJQUFJLENBQUMsS0FBSyxXQUFXLFVBQVUsS0FBSyxXQUFXLGVBQWUsQ0FBQztJQUMvRCxLQUFLLFNBQVMsa0JBQWtCLG9CQUFvQixDQUFDO0dBQ3ZEO0dBQ0EsS0FBSyxjQUFjLElBQUcsUUFBTztJQUMzQixLQUFLLEtBQUssQ0FBQztHQUNiLENBQUM7RUFDSDtFQUNBLElBQUksQ0FBQyxPQUFPLEtBQUssU0FBUyxvQkFBb0IsQ0FBQyxLQUFLLFNBQVMsaUJBQWlCLE9BQzVFLE9BQU8sS0FBSyxTQUFTLGlCQUFpQixPQUFPLENBQUM7T0FDekMsSUFBSSxDQUFDLE9BQU8sS0FBSyxTQUFTLG9CQUFvQixLQUFLLFNBQVMsaUJBQWlCLE9BQ2xGLElBQUksS0FBSyxTQUFTLGlCQUFpQixPQUFPLFdBQVcsR0FDbkQsS0FBSyxTQUFTLGlCQUFpQixPQUFPLENBQUMsQ0FBQyxLQUFLLE1BQU07T0FFbkQsS0FBSyxTQUFTLGlCQUFpQixPQUFPLE1BQU07T0FHOUMsT0FBTyxHQUFHO0VBRVosT0FBTztDQUNUO0NBQ0EsVUFBVSxLQUFLLElBQUksV0FBVyxXQUFXO0VBQ3ZDLE1BQU0sVUFBVSxXQUFXO0VBQzNCLE1BQU0sVUFBVSxLQUFLLE1BQU0sR0FBRyxTQUFTO0dBQ3JDLElBQUk7R0FDSixJQUFJLE9BQU8sU0FBUyxVQUNsQixJQUFJLEtBQUssUUFBUSxpQ0FBaUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLE9BQU8sSUFBSSxDQUFDO1FBRTFFLElBQUksRUFDRixHQUFHLEtBQ0w7R0FFRixFQUFFLE1BQU0sRUFBRSxPQUFPLE9BQU87R0FDeEIsRUFBRSxPQUFPLEVBQUUsUUFBUSxPQUFPO0dBQzFCLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxLQUFBLEtBQWEsRUFBRSxPQUFPO0dBQ3RELEVBQUUsS0FBSyxFQUFFLE1BQU0sT0FBTztHQUN0QixJQUFJLEVBQUUsY0FBYyxJQUFJLEVBQUUsWUFBWSxFQUFFLGFBQWEsYUFBYSxPQUFPO0dBQ3pFLE1BQU0sZUFBZTtJQUNuQixHQUFHLEtBQUs7SUFDUixHQUFHO0dBQ0w7R0FDQSxJQUFJLE1BQU0sUUFBUSxPQUFPLEtBQUssQ0FBQyxnQkFBZ0IsYUFBYSxLQUFLO0dBQ2pFLElBQUksT0FBTyxFQUFFLGNBQWMsWUFBWSxFQUFFLFlBQVksaUJBQWlCLEVBQUUsV0FBVyxZQUFZO0dBQy9GLE1BQU0sZUFBZSxLQUFLLFFBQVEsZ0JBQWdCO0dBQ2xELElBQUk7R0FDSixJQUFJLEVBQUUsYUFBYSxNQUFNLFFBQVEsR0FBRyxHQUNsQyxZQUFZLElBQUksS0FBSSxNQUFLO0lBQ3ZCLElBQUksT0FBTyxNQUFNLFlBQVksSUFBSSxpQkFBaUIsR0FBRyxZQUFZO0lBQ2pFLE9BQU8sR0FBRyxFQUFFLFlBQVksZUFBZTtHQUN6QyxDQUFDO1FBQ0k7SUFDTCxJQUFJLE9BQU8sUUFBUSxZQUFZLE1BQU0saUJBQWlCLEtBQUssWUFBWTtJQUN2RSxZQUFZLEVBQUUsWUFBWSxHQUFHLEVBQUUsWUFBWSxlQUFlLFFBQVE7R0FDcEU7R0FDQSxPQUFPLEtBQUssRUFBRSxXQUFXLENBQUM7RUFDNUI7RUFDQSxJQUFJLFNBQVMsR0FBRyxHQUNkLE9BQU8sTUFBTTtPQUViLE9BQU8sT0FBTztFQUVoQixPQUFPLEtBQUs7RUFDWixPQUFPLFlBQVk7RUFDbkIsT0FBTztDQUNUO0NBQ0EsRUFBRSxHQUFHLE1BQU07RUFDVCxPQUFPLEtBQUssWUFBWSxVQUFVLEdBQUcsSUFBSTtDQUMzQztDQUNBLE9BQU8sR0FBRyxNQUFNO0VBQ2QsT0FBTyxLQUFLLFlBQVksT0FBTyxHQUFHLElBQUk7Q0FDeEM7Q0FDQSxvQkFBb0IsSUFBSTtFQUN0QixLQUFLLFFBQVEsWUFBWTtDQUMzQjtDQUNBLG1CQUFtQixJQUFJLFVBQVUsQ0FBQyxHQUFHO0VBQ25DLElBQUksQ0FBQyxLQUFLLGVBQWU7R0FDdkIsS0FBSyxPQUFPLEtBQUssbURBQW1ELEtBQUssU0FBUztHQUNsRixPQUFPO0VBQ1Q7RUFDQSxJQUFJLENBQUMsS0FBSyxhQUFhLENBQUMsS0FBSyxVQUFVLFFBQVE7R0FDN0MsS0FBSyxPQUFPLEtBQUssOERBQThELEtBQUssU0FBUztHQUM3RixPQUFPO0VBQ1Q7RUFDQSxNQUFNLE1BQU0sUUFBUSxPQUFPLEtBQUssb0JBQW9CLEtBQUssVUFBVTtFQUNuRSxNQUFNLGNBQWMsS0FBSyxVQUFVLEtBQUssUUFBUSxjQUFjO0VBQzlELE1BQU0sVUFBVSxLQUFLLFVBQVUsS0FBSyxVQUFVLFNBQVM7RUFDdkQsSUFBSSxJQUFJLFlBQVksTUFBTSxVQUFVLE9BQU87RUFDM0MsTUFBTSxrQkFBa0IsR0FBRyxNQUFNO0dBQy9CLE1BQU0sWUFBWSxLQUFLLFNBQVMsaUJBQWlCLE1BQU0sR0FBRyxFQUFFLEdBQUc7R0FDL0QsT0FBTyxjQUFjLE1BQU0sY0FBYyxLQUFLLGNBQWM7RUFDOUQ7RUFDQSxJQUFJLFFBQVEsVUFBVTtHQUNwQixNQUFNLFlBQVksUUFBUSxTQUFTLE1BQU0sY0FBYztHQUN2RCxJQUFJLGNBQWMsS0FBQSxHQUFXLE9BQU87RUFDdEM7RUFDQSxJQUFJLEtBQUssa0JBQWtCLEtBQUssRUFBRSxHQUFHLE9BQU87RUFDNUMsSUFBSSxDQUFDLEtBQUssU0FBUyxpQkFBaUIsV0FBVyxLQUFLLFFBQVEsYUFBYSxDQUFDLEtBQUssUUFBUSx5QkFBeUIsT0FBTztFQUN2SCxJQUFJLGVBQWUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxlQUFlLGVBQWUsU0FBUyxFQUFFLElBQUksT0FBTztFQUNyRixPQUFPO0NBQ1Q7Q0FDQSxlQUFlLElBQUksVUFBVTtFQUMzQixNQUFNLFdBQVcsTUFBTTtFQUN2QixJQUFJLENBQUMsS0FBSyxRQUFRLElBQUk7R0FDcEIsSUFBSSxVQUFVLFNBQVM7R0FDdkIsT0FBTyxRQUFRLFFBQVE7RUFDekI7RUFDQSxJQUFJLFNBQVMsRUFBRSxHQUFHLEtBQUssQ0FBQyxFQUFFO0VBQzFCLEdBQUcsU0FBUSxNQUFLO0dBQ2QsSUFBSSxDQUFDLEtBQUssUUFBUSxHQUFHLFNBQVMsQ0FBQyxHQUFHLEtBQUssUUFBUSxHQUFHLEtBQUssQ0FBQztFQUMxRCxDQUFDO0VBQ0QsS0FBSyxlQUFjLFFBQU87R0FDeEIsU0FBUyxRQUFRO0dBQ2pCLElBQUksVUFBVSxTQUFTLEdBQUc7RUFDNUIsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLGNBQWMsTUFBTSxVQUFVO0VBQzVCLE1BQU0sV0FBVyxNQUFNO0VBQ3ZCLElBQUksU0FBUyxJQUFJLEdBQUcsT0FBTyxDQUFDLElBQUk7RUFDaEMsTUFBTSxZQUFZLEtBQUssUUFBUSxXQUFXLENBQUM7RUFDM0MsTUFBTSxVQUFVLEtBQUssUUFBTyxRQUFPLENBQUMsVUFBVSxTQUFTLEdBQUcsS0FBSyxLQUFLLFNBQVMsY0FBYyxnQkFBZ0IsR0FBRyxDQUFDO0VBQy9HLElBQUksQ0FBQyxRQUFRLFFBQVE7R0FDbkIsSUFBSSxVQUFVLFNBQVM7R0FDdkIsT0FBTyxRQUFRLFFBQVE7RUFDekI7RUFDQSxLQUFLLFFBQVEsVUFBVSxVQUFVLE9BQU8sT0FBTztFQUMvQyxLQUFLLGVBQWMsUUFBTztHQUN4QixTQUFTLFFBQVE7R0FDakIsSUFBSSxVQUFVLFNBQVMsR0FBRztFQUM1QixDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0EsSUFBSSxLQUFLO0VBQ1AsSUFBSSxDQUFDLEtBQUssTUFBTSxLQUFLLHFCQUFxQixLQUFLLFdBQVcsU0FBUyxJQUFJLEtBQUssVUFBVSxLQUFLLEtBQUs7RUFDaEcsSUFBSSxDQUFDLEtBQUssT0FBTztFQUNqQixJQUFJO0dBQ0YsTUFBTSxJQUFJLElBQUksS0FBSyxPQUFPLEdBQUc7R0FDN0IsSUFBSSxLQUFLLEVBQUUsYUFBYTtJQUN0QixNQUFNLEtBQUssRUFBRSxZQUFZO0lBQ3pCLElBQUksTUFBTSxHQUFHLFdBQVcsT0FBTyxHQUFHO0dBQ3BDO0VBQ0YsU0FBUyxHQUFHLENBQUM7RUFDYixNQUFNLFVBQVU7R0FBQztHQUFNO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFNO0dBQU07R0FBTTtHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTTtHQUFNO0dBQU87R0FBTztHQUFPO0dBQU07R0FBTTtHQUFPO0dBQU87R0FBTztHQUFNO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTTtHQUFPO0VBQUs7RUFDdmIsTUFBTSxnQkFBZ0IsS0FBSyxVQUFVLGlCQUFpQixJQUFJLGFBQWEsSUFBSSxDQUFDO0VBQzVFLElBQUksSUFBSSxZQUFZLENBQUMsQ0FBQyxRQUFRLE9BQU8sSUFBSSxHQUFHLE9BQU87RUFDbkQsT0FBTyxRQUFRLFNBQVMsY0FBYyx3QkFBd0IsR0FBRyxDQUFDLEtBQUssSUFBSSxZQUFZLENBQUMsQ0FBQyxRQUFRLE9BQU8sSUFBSSxJQUFJLFFBQVE7Q0FDMUg7Q0FDQSxPQUFPLGVBQWUsVUFBVSxDQUFDLEdBQUcsVUFBVTtFQUM1QyxNQUFNLFdBQVcsSUFBSSxLQUFLLFNBQVMsUUFBUTtFQUMzQyxTQUFTLGlCQUFpQixLQUFLO0VBQy9CLE9BQU87Q0FDVDtDQUNBLGNBQWMsVUFBVSxDQUFDLEdBQUcsV0FBVyxNQUFNO0VBQzNDLE1BQU0sb0JBQW9CLFFBQVE7RUFDbEMsSUFBSSxtQkFBbUIsT0FBTyxRQUFRO0VBQ3RDLE1BQU0sZ0JBQWdCO0dBQ3BCLEdBQUcsS0FBSztHQUNSLEdBQUc7R0FFRCxTQUFTO0VBRWI7RUFDQSxNQUFNLFFBQVEsSUFBSSxLQUFLLGFBQWE7RUFDcEMsSUFBSSxRQUFRLFVBQVUsS0FBQSxLQUFhLFFBQVEsV0FBVyxLQUFBLEdBQ3BELE1BQU0sU0FBUyxNQUFNLE9BQU8sTUFBTSxPQUFPO0VBRzNDO0dBRHVCO0dBQVM7R0FBWTtFQUNoQyxDQUFDLENBQUMsU0FBUSxNQUFLO0dBQ3pCLE1BQU0sS0FBSyxLQUFLO0VBQ2xCLENBQUM7RUFDRCxNQUFNLFdBQVcsRUFDZixHQUFHLEtBQUssU0FDVjtFQUNBLE1BQU0sU0FBUyxRQUFRLEVBQ3JCLG9CQUFvQixNQUFNLG1CQUFtQixLQUFLLEtBQUssRUFDekQ7RUFDQSxJQUFJLG1CQUFtQjtHQWFyQixNQUFNLFFBQVEsSUFBSSxjQVpDLE9BQU8sS0FBSyxLQUFLLE1BQU0sSUFBSSxDQUFDLENBQUMsUUFBUSxNQUFNLE1BQU07SUFDbEUsS0FBSyxLQUFLLEVBQ1IsR0FBRyxLQUFLLE1BQU0sS0FBSyxHQUNyQjtJQUNBLEtBQUssS0FBSyxPQUFPLEtBQUssS0FBSyxFQUFFLENBQUMsQ0FBQyxRQUFRLEtBQUssTUFBTTtLQUNoRCxJQUFJLEtBQUssRUFDUCxHQUFHLEtBQUssRUFBRSxDQUFDLEdBQ2I7S0FDQSxPQUFPO0lBQ1QsR0FBRyxLQUFLLEVBQUU7SUFDVixPQUFPO0dBQ1QsR0FBRyxDQUFDLENBQzRCLEdBQVksYUFBYTtHQUN6RCxNQUFNLFNBQVMsZ0JBQWdCLE1BQU07RUFDdkM7RUFDQSxJQUFJLFFBQVEsZUFBZTtHQUV6QixNQUFNLHNCQUFzQjtJQUMxQixHQUZjLElBRUwsQ0FBQyxDQUFDO0lBQ1gsR0FBRyxLQUFLLFFBQVE7SUFDaEIsR0FBRyxRQUFRO0dBQ2I7R0FDQSxNQUFNLHdCQUF3QjtJQUM1QixHQUFHO0lBQ0gsZUFBZTtHQUNqQjtHQUNBLE1BQU0sU0FBUyxlQUFlLElBQUksYUFBYSxxQkFBcUI7RUFDdEU7RUFDQSxNQUFNLGFBQWEsSUFBSSxXQUFXLE1BQU0sVUFBVSxhQUFhO0VBQy9ELE1BQU0sV0FBVyxHQUFHLE1BQU0sT0FBTyxHQUFHLFNBQVM7R0FDM0MsTUFBTSxLQUFLLE9BQU8sR0FBRyxJQUFJO0VBQzNCLENBQUM7RUFDRCxNQUFNLEtBQUssZUFBZSxRQUFRO0VBQ2xDLE1BQU0sV0FBVyxVQUFVO0VBQzNCLE1BQU0sV0FBVyxpQkFBaUIsU0FBUyxRQUFRLEVBQ2pELG9CQUFvQixNQUFNLG1CQUFtQixLQUFLLEtBQUssRUFDekQ7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxTQUFTO0VBQ1AsT0FBTztHQUNMLFNBQVMsS0FBSztHQUNkLE9BQU8sS0FBSztHQUNaLFVBQVUsS0FBSztHQUNmLFdBQVcsS0FBSztHQUNoQixrQkFBa0IsS0FBSztFQUN6QjtDQUNGO0FBQ0YsRUFDc0IsZUFBZTtBQUVyQyxJQUFNLGlCQUFpQixTQUFTO0FBQ2hDLElBQU0sTUFBTSxTQUFTO0FBQ3JCLElBQU0sT0FBTyxTQUFTO0FBQ3RCLElBQU0sZ0JBQWdCLFNBQVM7QUFDL0IsSUFBTSxrQkFBa0IsU0FBUztBQUNqQyxJQUFNLE1BQU0sU0FBUztBQUNyQixJQUFNLGlCQUFpQixTQUFTO0FBQ2hDLElBQU0sWUFBWSxTQUFTO0FBQzNCLElBQU0sSUFBSSxTQUFTO0FBQ25CLElBQU0sU0FBUyxTQUFTO0FBQ3hCLElBQU0sc0JBQXNCLFNBQVM7QUFDckMsSUFBTSxxQkFBcUIsU0FBUztBQUNwQyxJQUFNLGlCQUFpQixTQUFTO0FBQ2hDLElBQU0sZ0JBQWdCLFNBQVMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19