import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/NavigationTabs.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=aa845dd0";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Compass, Wallet, Receipt, Calculator } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/layout/NavigationTabs.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const NavigationTabs = () => {
	_s();
	const { t } = useTranslation();
	const navItems = [
		{
			path: "/",
			label: t("nav.trips", "Chuyến đi"),
			icon: Compass
		},
		{
			path: "/funds",
			label: t("nav.fund", "Quỹ nhóm"),
			icon: Wallet
		},
		{
			path: "/expenses",
			label: t("nav.expenses", "Chi tiêu"),
			icon: Receipt
		},
		{
			path: "/settlement",
			label: t("nav.settlement", "Quyết toán"),
			icon: Calculator
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "hidden md:block bg-white border-b border-slate-200/80",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: /* @__PURE__ */ _jsxDEV("nav", {
				className: "flex space-x-1 sm:space-x-4 py-2",
				children: navItems.map((item) => {
					const Icon = item.icon;
					return /* @__PURE__ */ _jsxDEV(NavLink, {
						to: item.path,
						className: ({ isActive }) => `flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold transition-all duration-200 min-h-[44px] ${isActive ? "bg-indigo-50 text-indigo-700 shadow-xs" : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"}`,
						children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.label }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 17
						}, this)]
					}, item.path, true, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
};
_s(NavigationTabs, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c = NavigationTabs;
var _c;
$RefreshReg$(_c, "NavigationTabs");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/NavigationTabs.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/layout/NavigationTabs.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/layout/NavigationTabs.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/layout/NavigationTabs.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZUFBZTtBQUN4QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLFNBQVMsUUFBUSxTQUFTLGtCQUFrQjs7OztBQUVyRCxPQUFPLE1BQU0sdUJBQXVCOztDQUNsQyxNQUFNLEVBQUUsTUFBTSxlQUFlO0NBRTdCLE1BQU0sV0FBVztFQUNmO0dBQUUsTUFBTTtHQUFLLE9BQU8sRUFBRSxhQUFhLFdBQVc7R0FBRyxNQUFNO0VBQVE7RUFDL0Q7R0FBRSxNQUFNO0dBQVUsT0FBTyxFQUFFLFlBQVksVUFBVTtHQUFHLE1BQU07RUFBTztFQUNqRTtHQUFFLE1BQU07R0FBYSxPQUFPLEVBQUUsZ0JBQWdCLFVBQVU7R0FBRyxNQUFNO0VBQVE7RUFDekU7R0FBRSxNQUFNO0dBQWUsT0FBTyxFQUFFLGtCQUFrQixZQUFZO0dBQUcsTUFBTTtFQUFXO0NBQ3BGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWixTQUFTLEtBQUssU0FBUztLQUN0QixNQUFNLE9BQU8sS0FBSztLQUNsQixPQUNFLHdCQUFDLFNBQUQ7TUFFRSxJQUFJLEtBQUs7TUFDVCxZQUFZLEVBQUUsZUFDWiw2R0FDRSxXQUNJLDJDQUNBO2dCQVBWLENBV0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7OztnQkFDM0Isd0JBQUMsUUFBRCxZQUFPLEtBQUssTUFBWTs7OztjQUNqQjtRQVpGLEtBQUs7Ozs7WUFZSDtJQUViLENBQUM7R0FDRTs7Ozs7RUFDRjs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJOYXZpZ2F0aW9uVGFicy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IE5hdkxpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSAncmVhY3QtaTE4bmV4dCc7XG5pbXBvcnQgeyBDb21wYXNzLCBXYWxsZXQsIFJlY2VpcHQsIENhbGN1bGF0b3IgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgY29uc3QgTmF2aWdhdGlvblRhYnMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcblxuICBjb25zdCBuYXZJdGVtcyA9IFtcbiAgICB7IHBhdGg6ICcvJywgbGFiZWw6IHQoJ25hdi50cmlwcycsICdDaHV54bq/biDEkWknKSwgaWNvbjogQ29tcGFzcyB9LFxuICAgIHsgcGF0aDogJy9mdW5kcycsIGxhYmVsOiB0KCduYXYuZnVuZCcsICdRdeG7uSBuaMOzbScpLCBpY29uOiBXYWxsZXQgfSxcbiAgICB7IHBhdGg6ICcvZXhwZW5zZXMnLCBsYWJlbDogdCgnbmF2LmV4cGVuc2VzJywgJ0NoaSB0acOqdScpLCBpY29uOiBSZWNlaXB0IH0sXG4gICAgeyBwYXRoOiAnL3NldHRsZW1lbnQnLCBsYWJlbDogdCgnbmF2LnNldHRsZW1lbnQnLCAnUXV54bq/dCB0b8OhbicpLCBpY29uOiBDYWxjdWxhdG9yIH0sXG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBtZDpibG9jayBiZy13aGl0ZSBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwLzgwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTEgc206c3BhY2UteC00IHB5LTJcIj5cbiAgICAgICAgICB7bmF2SXRlbXMubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBJY29uID0gaXRlbS5pY29uO1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ucGF0aH1cbiAgICAgICAgICAgICAgICB0bz17aXRlbS5wYXRofVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgIGBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIuNSByb3VuZGVkLXhsIHRleHQtc20gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBtaW4taC1bNDRweF0gJHtcbiAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1pbmRpZ28tNTAgdGV4dC1pbmRpZ28tNzAwIHNoYWRvdy14cydcbiAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTYwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS01MCdcbiAgICAgICAgICAgICAgICAgIH1gXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0ubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICA8L05hdkxpbms+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L25hdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==