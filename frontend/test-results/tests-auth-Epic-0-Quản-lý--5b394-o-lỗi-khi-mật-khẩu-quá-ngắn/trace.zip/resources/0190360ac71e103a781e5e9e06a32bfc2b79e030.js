import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/MobileNavigation.jsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=aa845dd0";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Compass, Wallet, Receipt, Calculator } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/components/layout/MobileNavigation.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const MobileNavigation = () => {
	_s();
	const { t } = useTranslation();
	const navItems = [
		{
			path: "/",
			label: t("nav.trips", "Chuyến đi"),
			icon: Compass
		},
		{
			path: "/funds",
			label: t("nav.fund", "Quỹ nhóm"),
			icon: Wallet
		},
		{
			path: "/expenses",
			label: t("nav.expenses", "Chi tiêu"),
			icon: Receipt
		},
		{
			path: "/settlement",
			label: t("nav.settlement", "Quyết toán"),
			icon: Calculator
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/80 shadow-lg px-2 py-1",
		children: /* @__PURE__ */ _jsxDEV("nav", {
			className: "flex justify-around items-center h-14",
			children: navItems.map((item) => {
				const Icon = item.icon;
				return /* @__PURE__ */ _jsxDEV(NavLink, {
					to: item.path,
					className: ({ isActive }) => `flex flex-col items-center justify-center flex-1 h-full py-1 text-[11px] font-semibold transition-colors min-h-[44px] ${isActive ? "text-indigo-600 font-bold" : "text-slate-500 hover:text-slate-800"}`,
					children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-5 h-5 mb-0.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.label }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 15
					}, this)]
				}, item.path, true, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 13
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
};
_s(MobileNavigation, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c = MobileNavigation;
var _c;
$RefreshReg$(_c, "MobileNavigation");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/MobileNavigation.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/components/layout/MobileNavigation.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/components/layout/MobileNavigation.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/components/layout/MobileNavigation.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZUFBZTtBQUN4QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLFNBQVMsUUFBUSxTQUFTLGtCQUFrQjs7OztBQUVyRCxPQUFPLE1BQU0seUJBQXlCOztDQUNwQyxNQUFNLEVBQUUsTUFBTSxlQUFlO0NBRTdCLE1BQU0sV0FBVztFQUNmO0dBQUUsTUFBTTtHQUFLLE9BQU8sRUFBRSxhQUFhLFdBQVc7R0FBRyxNQUFNO0VBQVE7RUFDL0Q7R0FBRSxNQUFNO0dBQVUsT0FBTyxFQUFFLFlBQVksVUFBVTtHQUFHLE1BQU07RUFBTztFQUNqRTtHQUFFLE1BQU07R0FBYSxPQUFPLEVBQUUsZ0JBQWdCLFVBQVU7R0FBRyxNQUFNO0VBQVE7RUFDekU7R0FBRSxNQUFNO0dBQWUsT0FBTyxFQUFFLGtCQUFrQixZQUFZO0dBQUcsTUFBTTtFQUFXO0NBQ3BGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1osU0FBUyxLQUFLLFNBQVM7SUFDdEIsTUFBTSxPQUFPLEtBQUs7SUFDbEIsT0FDRSx3QkFBQyxTQUFEO0tBRUUsSUFBSSxLQUFLO0tBQ1QsWUFBWSxFQUFFLGVBQ1oseUhBQ0UsV0FBVyw4QkFBOEI7ZUFML0MsQ0FTRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxpQkFBa0I7Ozs7ZUFDbEMsd0JBQUMsUUFBRCxZQUFPLEtBQUssTUFBWTs7OzthQUNqQjtPQVZGLEtBQUs7Ozs7V0FVSDtHQUViLENBQUM7RUFDRTs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJNb2JpbGVOYXZpZ2F0aW9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTmF2TGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tICdyZWFjdC1pMThuZXh0JztcbmltcG9ydCB7IENvbXBhc3MsIFdhbGxldCwgUmVjZWlwdCwgQ2FsY3VsYXRvciB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBNb2JpbGVOYXZpZ2F0aW9uID0gKCkgPT4ge1xuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XG5cbiAgY29uc3QgbmF2SXRlbXMgPSBbXG4gICAgeyBwYXRoOiAnLycsIGxhYmVsOiB0KCduYXYudHJpcHMnLCAnQ2h1eeG6v24gxJFpJyksIGljb246IENvbXBhc3MgfSxcbiAgICB7IHBhdGg6ICcvZnVuZHMnLCBsYWJlbDogdCgnbmF2LmZ1bmQnLCAnUXXhu7kgbmjDs20nKSwgaWNvbjogV2FsbGV0IH0sXG4gICAgeyBwYXRoOiAnL2V4cGVuc2VzJywgbGFiZWw6IHQoJ25hdi5leHBlbnNlcycsICdDaGkgdGnDqnUnKSwgaWNvbjogUmVjZWlwdCB9LFxuICAgIHsgcGF0aDogJy9zZXR0bGVtZW50JywgbGFiZWw6IHQoJ25hdi5zZXR0bGVtZW50JywgJ1F1eeG6v3QgdG/DoW4nKSwgaWNvbjogQ2FsY3VsYXRvciB9LFxuICBdO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtZDpoaWRkZW4gZml4ZWQgYm90dG9tLTAgbGVmdC0wIHJpZ2h0LTAgei00MCBiZy13aGl0ZS85NSBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAvODAgc2hhZG93LWxnIHB4LTIgcHktMVwiPlxuICAgICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYXJvdW5kIGl0ZW1zLWNlbnRlciBoLTE0XCI+XG4gICAgICAgIHtuYXZJdGVtcy5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICBjb25zdCBJY29uID0gaXRlbS5pY29uO1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8TmF2TGlua1xuICAgICAgICAgICAgICBrZXk9e2l0ZW0ucGF0aH1cbiAgICAgICAgICAgICAgdG89e2l0ZW0ucGF0aH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxuICAgICAgICAgICAgICAgIGBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LTEgaC1mdWxsIHB5LTEgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBtaW4taC1bNDRweF0gJHtcbiAgICAgICAgICAgICAgICAgIGlzQWN0aXZlID8gJ3RleHQtaW5kaWdvLTYwMCBmb250LWJvbGQnIDogJ3RleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgIH1gXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy01IGgtNSBtYi0wLjVcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICA8L05hdkxpbms+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L25hdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=