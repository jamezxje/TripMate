import api from "/src/services/api.js";
export const tripApi = {
	createTrip: (name) => api.post("/trips", { name }),
	joinTrip: (joinCode) => api.post("/trips/join", { joinCode }),
	getTripDetail: (tripId) => api.get(`/trips/${tripId}`),
	getUserTrips: () => api.get("/trips/me")
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTO0FBRWhCLE9BQU8sTUFBTSxVQUFVO0NBQ3JCLGFBQWEsU0FBUyxJQUFJLEtBQUssVUFBVSxFQUFFLEtBQUssQ0FBQztDQUNqRCxXQUFXLGFBQWEsSUFBSSxLQUFLLGVBQWUsRUFBRSxTQUFTLENBQUM7Q0FDNUQsZ0JBQWdCLFdBQVcsSUFBSSxJQUFJLFVBQVUsUUFBUTtDQUNyRCxvQkFBb0IsSUFBSSxJQUFJLFdBQVc7QUFDekMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidHJpcEFwaS5qcyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXBpIGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaSc7XG5cbmV4cG9ydCBjb25zdCB0cmlwQXBpID0ge1xuICBjcmVhdGVUcmlwOiAobmFtZSkgPT4gYXBpLnBvc3QoJy90cmlwcycsIHsgbmFtZSB9KSxcbiAgam9pblRyaXA6IChqb2luQ29kZSkgPT4gYXBpLnBvc3QoJy90cmlwcy9qb2luJywgeyBqb2luQ29kZSB9KSxcbiAgZ2V0VHJpcERldGFpbDogKHRyaXBJZCkgPT4gYXBpLmdldChgL3RyaXBzLyR7dHJpcElkfWApLFxuICBnZXRVc2VyVHJpcHM6ICgpID0+IGFwaS5nZXQoJy90cmlwcy9tZScpLFxufTtcbiJdfQ==