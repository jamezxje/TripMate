import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/trips/TripDetailView.jsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f167c130";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=c58b322d";
import { Copy, Check, Users, KeyRound, Calendar } from "/node_modules/.vite/deps/lucide-react.js?v=c1531034";
import { Card, CardHeader, CardBody } from "/src/components/Card.jsx";
import { Badge } from "/src/components/Badge.jsx";
import { Button } from "/src/components/Button.jsx";
import { formatDate } from "/src/utils/formatters.js";
var _jsxFileName = "G:/DuyTX/TripMate/frontend/src/features/trips/TripDetailView.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f167c130";
var _s = $RefreshSig$();
export const TripDetailView = ({ trip, onRefresh }) => {
	_s();
	const { t } = useTranslation();
	const [copied, setCopied] = useState(false);
	const handleCopyCode = () => {
		if (!trip?.joinCode) return;
		navigator.clipboard.writeText(trip.joinCode);
		setCopied(true);
		setTimeout(() => setCopied(false), 2e3);
	};
	if (!trip) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-6",
		children: [/* @__PURE__ */ _jsxDEV(Card, {
			className: "bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white border-none shadow-xl relative overflow-hidden",
			children: [/* @__PURE__ */ _jsxDEV("div", { className: "absolute right-0 top-0 translate-x-8 -translate-y-8 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 mb-2",
					children: [/* @__PURE__ */ _jsxDEV(Badge, {
						variant: trip.status ? trip.status.toLowerCase() : "info",
						children: t(`trip.status.${trip.status}`, trip.status)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs text-indigo-200/80 flex items-center gap-1",
						children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 17
						}, this), formatDate(trip.createdAt)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("h1", {
					className: "text-2xl sm:text-3xl font-black tracking-tight text-white",
					children: trip.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 flex items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] font-bold uppercase tracking-wider text-indigo-200 flex items-center gap-1",
						children: [/* @__PURE__ */ _jsxDEV(KeyRound, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 17
						}, this), " Mã mời tham gia"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-2xl font-black tracking-widest text-amber-300 font-mono mt-0.5",
						children: trip.joinCode
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						size: "sm",
						onClick: handleCopyCode,
						className: "bg-white/20 border-white/30 text-white hover:bg-white/30 min-h-[44px]",
						children: copied ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-emerald-300",
							children: "Đã chép"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Copy, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold",
							children: "Sao chép"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(Card, { children: [/* @__PURE__ */ _jsxDEV(CardHeader, {
			title: /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV(Users, { className: "w-5 h-5 text-indigo-600" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
					"Thành viên chuyến đi (",
					trip.members?.length || 0,
					")"
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 13
			}, this),
			subtitle: "Danh sách các thành viên và vai trò trong nhóm."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV(CardBody, { children: /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3",
			children: trip.members?.map((m) => /* @__PURE__ */ _jsxDEV("div", {
				className: "p-4 rounded-xl border border-slate-200/80 bg-slate-50/50 flex items-center justify-between gap-3 hover:bg-slate-100/60 transition-colors",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 min-w-0",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 font-bold text-sm flex items-center justify-center border border-indigo-200 shrink-0",
						children: m.fullName ? m.fullName.charAt(0) : "U"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 19
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "font-bold text-slate-800 text-sm truncate",
							children: m.fullName
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 truncate",
							children: m.email
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 19
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV(Badge, {
					variant: m.role === "LEADER" ? "leader" : "member",
					children: m.role
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 17
				}, this)]
			}, m.userId, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 15
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 75,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 5
	}, this);
};
_s(TripDetailView, "zuIBy0psj0B50YrLYeaB9g2+yDs=", false, function() {
	return [useTranslation];
});
_c = TripDetailView;
var _c;
$RefreshReg$(_c, "TripDetailView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/trips/TripDetailView.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("G:/DuyTX/TripMate/frontend/src/features/trips/TripDetailView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("G:/DuyTX/TripMate/frontend/src/features/trips/TripDetailView.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "G:/DuyTX/TripMate/frontend/src/features/trips/TripDetailView.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLE1BQU0sT0FBTyxPQUFPLFVBQVUsZ0JBQWdCO0FBQ3ZELFNBQVMsTUFBTSxZQUFZLGdCQUFnQjtBQUMzQyxTQUFTLGFBQWE7QUFDdEIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsa0JBQWtCOzs7O0FBRTNCLE9BQU8sTUFBTSxrQkFBa0IsRUFBRSxNQUFNLGdCQUFnQjs7Q0FDckQsTUFBTSxFQUFFLE1BQU0sZUFBZTtDQUM3QixNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUUxQyxNQUFNLHVCQUF1QjtFQUMzQixJQUFJLENBQUMsTUFBTSxVQUFVO0VBQ3JCLFVBQVUsVUFBVSxVQUFVLEtBQUssUUFBUTtFQUMzQyxVQUFVLElBQUk7RUFDZCxpQkFBaUIsVUFBVSxLQUFLLEdBQUcsR0FBSTtDQUN6QztDQUVBLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FFbEIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBRUUsd0JBQUMsTUFBRDtHQUFNLFdBQVU7YUFBaEIsQ0FDRSx3QkFBQyxPQUFELEVBQUssV0FBVSwySEFBNEg7Ozs7YUFFM0ksd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFPLFNBQVMsS0FBSyxTQUFTLEtBQUssT0FBTyxZQUFZLElBQUk7Z0JBQ3ZELEVBQUUsZUFBZSxLQUFLLFVBQVUsS0FBSyxNQUFNO0tBQ3ZDOzs7O2VBQ1Asd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7OztnQkFDbEMsV0FBVyxLQUFLLFNBQVMsQ0FDdEI7Ozs7O2FBQ0g7Ozs7O2NBQ0wsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBNkQsS0FBSztJQUFTOzs7O1lBQ3RGOzs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7Z0JBQUMsa0JBQ25DOzs7OztlQUNILHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWLEtBQUs7S0FDTDs7OzthQUNBOzs7O2VBQ0wsd0JBQUMsUUFBRDtNQUNFLFNBQVE7TUFDUixNQUFLO01BQ0wsU0FBUztNQUNULFdBQVU7Z0JBRVQsU0FDQyxnREFDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSwyQkFBNEI7Ozs7Z0JBQzdDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFxQztNQUFhOzs7O2NBQ2xFOzs7O2lCQUVGLGdEQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7Z0JBQzNCLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFvQjtNQUFjOzs7O2NBQ2xEOzs7OztLQUVFOzs7O2FBQ0w7Ozs7O1lBQ0Y7Ozs7O1dBQ0Q7Ozs7O1lBR04sd0JBQUMsTUFBRCxhQUNFLHdCQUFDLFlBQUQ7R0FDRSxPQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSwwQkFBMkI7Ozs7Y0FDNUMsd0JBQUMsUUFBRDtLQUFNO0tBQXVCLEtBQUssU0FBUyxVQUFVO0tBQUU7SUFBTzs7OztZQUMzRDs7Ozs7O0dBRVAsVUFBUztFQUNWOzs7O1lBQ0Qsd0JBQUMsVUFBRCxZQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1osS0FBSyxTQUFTLEtBQUssTUFDbEIsd0JBQUMsT0FBRDtJQUVFLFdBQVU7Y0FGWixDQUlFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixFQUFFLFdBQVcsRUFBRSxTQUFTLE9BQU8sQ0FBQyxJQUFJO0tBQ2xDOzs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBNkMsRUFBRTtNQUFZOzs7O2dCQUN4RSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBbUMsRUFBRTtNQUFTOzs7O2NBQ3hEOzs7OzthQUNGOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBTyxTQUFTLEVBQUUsU0FBUyxXQUFXLFdBQVc7ZUFDOUMsRUFBRTtJQUNFOzs7O1lBQ0o7TUFmRSxFQUFFOzs7O1VBZUosQ0FDTjtFQUNFOzs7O1dBQ0c7Ozs7VUFDTjs7OztVQUNIOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUcmlwRGV0YWlsVmlldy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tICdyZWFjdC1pMThuZXh0JztcbmltcG9ydCB7IENvcHksIENoZWNrLCBVc2VycywgS2V5Um91bmQsIENhbGVuZGFyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IENhcmQsIENhcmRIZWFkZXIsIENhcmRCb2R5IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9DYXJkJztcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9CYWRnZSc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0J1dHRvbic7XG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnLi4vLi4vdXRpbHMvZm9ybWF0dGVycyc7XG5cbmV4cG9ydCBjb25zdCBUcmlwRGV0YWlsVmlldyA9ICh7IHRyaXAsIG9uUmVmcmVzaCB9KSA9PiB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcbiAgY29uc3QgW2NvcGllZCwgc2V0Q29waWVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBoYW5kbGVDb3B5Q29kZSA9ICgpID0+IHtcbiAgICBpZiAoIXRyaXA/LmpvaW5Db2RlKSByZXR1cm47XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQodHJpcC5qb2luQ29kZSk7XG4gICAgc2V0Q29waWVkKHRydWUpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkKGZhbHNlKSwgMjAwMCk7XG4gIH07XG5cbiAgaWYgKCF0cmlwKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNlwiPlxuICAgICAgey8qIFRyaXAgSW5mbyBCYW5uZXIgQ2FyZCAqL31cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1pbmRpZ28tOTAwIHZpYS1pbmRpZ28tODAwIHRvLXNsYXRlLTkwMCB0ZXh0LXdoaXRlIGJvcmRlci1ub25lIHNoYWRvdy14bCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIHRvcC0wIHRyYW5zbGF0ZS14LTggLXRyYW5zbGF0ZS15LTggdy02NCBoLTY0IGJnLWluZGlnby01MDAvMTAgcm91bmRlZC1mdWxsIGJsdXItM3hsIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICBcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTYgcmVsYXRpdmUgei0xMFwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTJcIj5cbiAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9e3RyaXAuc3RhdHVzID8gdHJpcC5zdGF0dXMudG9Mb3dlckNhc2UoKSA6ICdpbmZvJ30+XG4gICAgICAgICAgICAgICAge3QoYHRyaXAuc3RhdHVzLiR7dHJpcC5zdGF0dXN9YCwgdHJpcC5zdGF0dXMpfVxuICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5kaWdvLTIwMC84MCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAge2Zvcm1hdERhdGUodHJpcC5jcmVhdGVkQXQpfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCBmb250LWJsYWNrIHRyYWNraW5nLXRpZ2h0IHRleHQtd2hpdGVcIj57dHJpcC5uYW1lfTwvaDE+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ29weWFibGUgSm9pbiBDb2RlIFdpZGdldCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlLzEwIGJhY2tkcm9wLWJsdXItbWQgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItd2hpdGUvMjAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1pbmRpZ28tMjAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgPEtleVJvdW5kIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gTcOjIG3hu51pIHRoYW0gZ2lhXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0cmFja2luZy13aWRlc3QgdGV4dC1hbWJlci0zMDAgZm9udC1tb25vIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIHt0cmlwLmpvaW5Db2RlfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb3B5Q29kZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUvMjAgYm9yZGVyLXdoaXRlLzMwIHRleHQtd2hpdGUgaG92ZXI6Ymctd2hpdGUvMzAgbWluLWgtWzQ0cHhdXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2NvcGllZCA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtMzAwXCI+xJDDoyBjaMOpcDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPENvcHkgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZFwiPlNhbyBjaMOpcDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cblxuICAgICAgey8qIE1lbWJlcnMgTGlzdCBDYXJkICovfVxuICAgICAgPENhcmQ+XG4gICAgICAgIDxDYXJkSGVhZGVyXG4gICAgICAgICAgdGl0bGU9e1xuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWluZGlnby02MDBcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5UaMOgbmggdmnDqm4gY2h1eeG6v24gxJFpICh7dHJpcC5tZW1iZXJzPy5sZW5ndGggfHwgMH0pPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgfVxuICAgICAgICAgIHN1YnRpdGxlPVwiRGFuaCBzw6FjaCBjw6FjIHRow6BuaCB2acOqbiB2w6AgdmFpIHRyw7IgdHJvbmcgbmjDs20uXCJcbiAgICAgICAgLz5cbiAgICAgICAgPENhcmRCb2R5PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtM1wiPlxuICAgICAgICAgICAge3RyaXAubWVtYmVycz8ubWFwKChtKSA9PiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBrZXk9e20udXNlcklkfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGJnLXNsYXRlLTUwLzUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBob3ZlcjpiZy1zbGF0ZS0xMDAvNjAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctaW5kaWdvLTEwMCB0ZXh0LWluZGlnby03MDAgZm9udC1ib2xkIHRleHQtc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci1pbmRpZ28tMjAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgIHttLmZ1bGxOYW1lID8gbS5mdWxsTmFtZS5jaGFyQXQoMCkgOiAnVSd9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgdGV4dC1zbSB0cnVuY2F0ZVwiPnttLmZ1bGxOYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCB0cnVuY2F0ZVwiPnttLmVtYWlsfTwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PXttLnJvbGUgPT09ICdMRUFERVInID8gJ2xlYWRlcicgOiAnbWVtYmVyJ30+XG4gICAgICAgICAgICAgICAgICB7bS5yb2xlfVxuICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZEJvZHk+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19